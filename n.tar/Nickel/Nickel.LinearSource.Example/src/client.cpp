/*
 *  Client.cpp
 *  ==========
 *
 *  An example implementation of ZMP client. Please have a look at zmp.h for
 *  additional information.
 *
 *  This example might look a bit complex but the purpose is also to demostrate
 *  how to integrate ZMP with your mainloop with ZMP non-blocking I/O.
 */

#include <nickel-linear-source/LinearSourceFactoryDBusClient.h>
#include <libzmp-1.0/zmp/zmp.h>

#include <nickel-linear-source/ControlEventListener.h>
#include "nickel-system-api/ErrorEventContext.h"
#include "nickel-system-api/ErrorEventValue.h"

#include <fstream>
#include <poll.h>

#include <boost/scoped_ptr.hpp>
#include <boost/function.hpp>

#include <zinc-binding-runtime/dbus/detail/SingletonDBusErrorConverter.h>

#include <dbus-c++/connection.h>
#include <dbus-c++/dispatcher.h>
#include <dbus-c++/eventloop-integration.h>

using namespace Zinc::Media::LinearSource;

/*
 * ZmpDataConsumer
 * ===============
 *
 * Groups all the callbacks and maintains the state of a simple file sink
 * for our data. Stream that is received through zmp will be saved in files named
 * Segment-XXXX.ts where XXXX is the consecutive segment number.
 */
class ZmpDataConsumer
{
public:

    ZmpDataConsumer (boost::function<void()> stop_ ) :
        fileno ( 0 ),
        total_bytes_consumed ( 0 ),
        stop ( stop_ ),
        pts_first_in_portion ( -1 ),
        pts_current ( 0 )
    {

    }

    static void on_event_cb(void *user_data, ZMPStream * stream, ZMPEventHeader *header,
                 size_t payload_bytes, void *payload)
    {
        static_cast<ZmpDataConsumer*>(user_data)->onEvent( stream, header, payload_bytes, payload );
    }

    /*
     * onEvent 
     * =======
     *
     * Called everytime a new event arrives. 
     * See zmp.h for detailed description.
     *
     * Note that data is received in onData callback.
     *
     */
    void onEvent( ZMPStream *, ZMPEventHeader *header,
                 size_t payload_bytes, void *payload)
    {
        switch (header->event_type) {
        /* After receiving FLUSH_START we are guaranteed to not receive any data
           until NEW_SEGMENT */
        case ZMP_EVENT_FLUSH_START:
            /* In a real client you will probably want to flush your decoder
             * buffers when you receive this event. */
            out.reset();
            break;
        case ZMP_EVENT_FLUSH_STOP:
            break;
        case ZMP_EVENT_SEGMENT:
            if (payload_bytes >= sizeof (segment)) {
                /* In a real client you will probably want to save the segment
                 * event payload as it will be required to calculate accurate
                 * user meaningful PTS for implementing
                 * MediaRouter::getPosition().  You will also need to adjust
                 * your playback speed according to the segment's "rate" field
                 */
                segment = *static_cast<ZMPSegmentEventPayload*>(payload);

                std::stringstream new_filename;
                new_filename << "segment-" << fileno << ".ts";
                out.reset ( new std::fstream (new_filename.str().c_str(), std::ios_base::out ) );
                fileno++;
            } else {
              fprintf(stderr, "Error: Bad payload size for segment event: %zu. "
                  "Expected: %zu\n", payload_bytes, sizeof (segment));
            }
            break;
        case ZMP_EVENT_PORTION:
            if (payload_bytes >= sizeof (portion)) {
                /* Save the portion data for future reference */
                portion = *static_cast<ZMPPortionEventPayload*>(payload);

                /* Reset the portion PTS */
                pts_first_in_portion = -1;
            }
            else {
                fprintf(stderr, "Error: Bad payload size for portion metadata"
                    " event: %zu. Expected: %zu\n", payload_bytes, sizeof (portion));
            }
            break;

        default:
            fprintf(stderr, "Warning: Received unknown event %i (%i, %x).  Ignoring.\n",
                    header->event_type, header->event_type >> 8,
                    header->event_type & 0xFF);
        };
    }

    static ssize_t on_data_cb (void *user_data, ZMPStream *stream, int infd)
    {
        return static_cast<ZmpDataConsumer*>(user_data)->onData( stream, infd );
    }

    /*
     * onData
     * ======
     *
     * Called when data is available for consumption.
     */
    ssize_t onData( ZMPStream *, int infd)
    {
        /* In a real client you will want to fill your decoder buffers here by
         * reading from infd.  If your decoder buffer fills return -1 and set
         * errno to EAGAIN.  You will then later be required to call
         * zmp_notify_read_ready when your decoder buffer once again has space
         */
        char buf[4096];
        int err;
        ssize_t bytes_read = read(infd, buf, sizeof(buf));
        err = errno;
        if ( bytes_read > 0 ) {
            out->write(buf, bytes_read);
        }
        total_bytes_consumed += bytes_read;
        errno = err;
        return bytes_read;
    }

    static void on_error_cb(void *user_data, ZMPStream *stream, int error, char* desc)
    {
         static_cast<ZmpDataConsumer*>(user_data)->onError( stream, error, desc );
    }

    /*
     * onError is called to signal any abonormal conditions and errors.
     */
    void onError( ZMPStream *, int error, char* desc)
    {
        if (error == EPIPE) {
            fprintf(stderr, "EOF: exiting\n");
        }
        else {
            fprintf(stderr, "Received unexpected error %i - %s: %s\n", error,
                    strerror(error), desc);
        }

        stop();
    }


private:
    /*
     * A hypotetical callback from the decoder
     */
    void onFrameDisplayed( const int64_t pts_frame_shown )
    {
        pts_current = pts_frame_shown;
        if (pts_first_in_portion == -1) {
            pts_first_in_portion = pts_frame_shown;
        }
    }

    /*
     * An example of a helper funtion to calculate the current stream time
     * which is required when calling Nickel.LinearSource.getPosition()
     */
    uint64_t getCurrentStreamTime()
    {
        if (pts_first_in_portion != -1) {
            return zmp_portion_time_to_stream_time( &segment, &portion,
                pts_current - pts_first_in_portion );
        }
        else {
            return segment.time;
        }
    }

    int fileno;
    boost::scoped_ptr<std::fstream> out;
    size_t total_bytes_consumed;
    boost::function<void()> stop;

    ZMPSegmentEventPayload segment;
    ZMPPortionEventPayload portion;

    int64_t pts_first_in_portion;
    int64_t pts_current;
};

/*
 * This class is included to allow this example to be single-threaded.  It will
 * not be required in a real production implementation.
 */
class ZincMainloopDispatcher : public NS_ZINC::Dispatcher {
public:
    ZincMainloopDispatcher(DBus::DefaultMainLoop& d_) : d(d_) {}
    void post(boost::function<void (void)> fn) {
        d.post_function(fn);
    }
    void onWorkAdded() {
    }
    void onWorkRemoved() {
    }
    DBus::DefaultMainLoop& d;
};

/**
 * Inherit from ControlEventListener and register with
 * Control::addListener() to receive signals sent by
 * Control.
 */

struct ControlEventListenerImpl : public Zinc::Media::LinearSource::ControlEventListener
{
    virtual ~ControlEventListenerImpl()
    {
    }

    virtual void ErrorEvent(const Zinc::Media::ErrorEventValue::Enum error, const Zinc::Media::ErrorEventContext::Enum context, const std::string& info)
    {
            // received an error in MediaRouter format!
        fprintf(stderr, "Received  ErrorEvent from Control object over DBus: ErrorEventValue(%d), ErrorEventContext(%d), additional debug:\n %s\n", (int)error,
                    (int)context, info.c_str() );
    }

    virtual void Overrun() {}
};

static void nullDeletor(void*) {}

/*
 * ZmpClient
 * =========
 *
 * ZmpClient performs the following tasks:
 *
 * 1. It creates the LinearSource factory client API.
 * 2. It does that asynchoronously so that all the work is posted onto DBus
 *    mainloop, so that new threads are not involved.
 * 3. Sets the zmp client, including callbacks.
 * 4. Manages the state of the client. 
 */
struct ZmpClient {
    DBus::DefaultMainLoop& mainloop;
    DBus::Connection conn;
    boost::shared_ptr<DBus::Dispatcher> dbusDispatcher;
    boost::shared_ptr<NS_ZINC::Dispatcher> zincDispatcher;
    boost::shared_ptr<ZmpDataConsumer> consumer;
    boost::shared_ptr<Control> control;
    boost::shared_ptr< Zinc::Media::LinearSource::FactoryAsync > linearSourceFactoryProxy;
    boost::shared_ptr< ControlEventListenerImpl> listener;

    ZMPStream* stream;
    DBus::UnixFD serialized_event_fd;
    DBus::UnixFD immediate_event_fd;
    DBus::DefaultWatch* watch;

    ZmpClient(DBus::BusDispatcher& d)
     : mainloop(d),
       dbusDispatcher(boost::shared_ptr<DBus::BusDispatcher>(&d, nullDeletor)),
       zincDispatcher(boost::make_shared<ZincMainloopDispatcher>(boost::ref(mainloop))),
       stream(NULL), watch(NULL) {

    }

    /*
     * Create the LinearSource.Factory and call Create to obtain Control object
     */
    void start()
    {
        conn = DBus::StandardConnectionFactory(dbusDispatcher, NS_ZINC_DBUS_BINDING::SingletonDBusErrorConverter::get()).connectToSessionBus();

        /* Create and store a linearSource.Factory proxy. This will be used to
         * create instances of the LinearSource.Control objects in the daemon
         * that are exposed on DBus.
         */
        linearSourceFactoryProxy = createLinearSourceFactoryDBusClient ( zincDispatcher, conn );
        
        /*
         * Create a LinearSource.Control object and setup a callback for
         * asynchronous call.  An example asset URL is used. This will change
         * when multicast components will be in place.
         */
        std::map<std::string, DBus::Variant> kwargs;

        kwargs["use-buffering"] = DBus::Variant(true);
        kwargs["temp-template"] = DBus::Variant(std::string("/tmp/timeshift-buffer-XXXXXX"));
        kwargs["buffer-size"] = DBus::Variant(uint64_t(16ULL * 1024 * 1024));

        char const* const uri =
            "http://filegateway.youview.co.uk/test_assets/licence_free/VA-604.ts";

        linearSourceFactoryProxy->create2 ( uri, kwargs )
            .setCallback( *zincDispatcher, boost::bind(&ZmpClient::onCreatedCallback, this, _1 ));
    }

    /*
     * At this point the Control object was created by the daemon and exposed
     * on DBus.  Initialise our end of the ZMP stuff.
     */
    void onCreatedCallback(const NS_ZINC::FutureValue<boost::tuple<boost::shared_ptr<Control>, DBus::UnixFD, DBus::UnixFD> >& v)
    {
        if (v.getError()) {
            /* In a real production implementation this should probably produce
             * some sort of source error.  It should definitely not abort(). */
            abort();
        }
        else {
            boost::tie(control, serialized_event_fd, immediate_event_fd) = v.get();

            listener = boost::make_shared<ControlEventListenerImpl>() ;

            control->addListener( listener );

            // create ZmpDataConsumer that will consume the received data
            consumer = boost::make_shared<ZmpDataConsumer>(boost::bind( &ZmpClient::stop, this ) ); 

            /* Initialise ZMP: The file descriptors "returned" from
             * linearSourceFactoryProxy->Create have been created for zmp.  Note that we pass
             * them down to ZMP.
             */ 
            stream = zmp_stream_new(serialized_event_fd.get(), immediate_event_fd.get());
            
            /*
             * Set the callbacks, so that we receive the events and data.
             */
            zmp_stream_set_callbacks(stream, consumer.get(), &ZmpDataConsumer::on_event_cb, &ZmpDataConsumer::on_data_cb, &ZmpDataConsumer::on_error_cb );
            
            /* Ensure that we call zmp_stream_notify whenever the fd from zmp
             * becomes ready to read.  All the callbacks will be called from
             * zmp_stream_notify */
            int zmp_fd = zmp_stream_get_listen_fd(stream);
            watch = mainloop.add_watch(zmp_fd, POLLIN, boost::bind(zmp_stream_notify, stream));

            /*
             * At this point we're ready to go. Control object on the daemon
             * side is created and initialised. Our end of ZMP is also
             * initalised. So now we can call start() so we can start receiving
             * data.
             *
             * Note that data will start flowing and callbacks will be fired
             * only after DBus dispatcher will be running. This will happen in
             * the main functon in the line saying mainloop.run().
             *
             * control->start() has no interesting result so even though it's
             * asynchronous we don't need to wait for it to return or set a
             * callback.
             */
            control->start();   
        }
    }
    // house keeping
    ~ZmpClient() {
        if (watch) {
            watch->remove();
        }
        if (control) {
            control->destroy();
        }
        zmp_stream_free(stream);
    }
    void stop()
    {
        conn.close();
        watch->remove();
        watch=NULL;
    }
};

int main(int, char**)
{
    // First initialise DBus dispatcher we will be using for everything.
    DBus::BusDispatcher mainloop(NS_ZINC_DBUS_BINDING::SingletonDBusErrorConverter::get());
    ZmpClient t(mainloop);
    ((DBus::DefaultMainLoop&)mainloop).post_function(boost::bind(&ZmpClient::start, &t));
    /*
     * At this point we can just run our loop. Note how no additional threads are
     * created. This illustrates the zmp non-blocking IO. 
     */
    mainloop.run();
    return 0;
}
