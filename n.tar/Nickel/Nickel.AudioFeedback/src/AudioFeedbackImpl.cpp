/*
 * AudioFeedbackImpl.cpp
 *
 * Created on: 22 Oct 2013
 *     Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "AudioFeedbackImpl.h"

#include "AudioFeedbackAsync.h"
#include "AudioSample.h"

#include <copper-system-api/LocalStorageRepositoryAsync.h>

#include <nickel-common/NickelLogger.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/ActionProcessor.h>

#include <boost/bind.hpp>
#include <boost/foreach.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/tuple/tuple.hpp>

#include <algorithm>
#include <queue>

#include <cassert>

using NS_COPPER_SYSTEM::LocalStorageRepositoryAsync;
using NS_ZINC::completedFuture;
using NS_ZINC::ActionProcessor;
using NS_ZINC::Dispatcher;
using NS_ZINC::Future;

using boost::make_shared;
using boost::shared_ptr;

NS_NICKEL_AUDIOFEEDBACK_OPEN

namespace
{

class AudioFeedbackImpl : public AudioFeedbackAsync
{
public:

    typedef boost::tuple< uint32_t, uint32_t, uint32_t, const std::vector< uint8_t > * > sound_sample_entry_t;
    enum { SAMPLE_ID = 0, NB_BYTES_WRITTEN, NB_REPEATS_LEFT, SOUND_SAMPLE };

    AudioFeedbackImpl(shared_ptr< Dispatcher > d,
                      shared_ptr< ActionProcessor > ap,
                      shared_ptr< LocalStorageRepositoryAsync > lsr,
                      restart_sound_daemon_fn_t fn,
                      const AudioFeedbackConfig &initialConfig):
        dispatcher(d),
        actionProcessor(ap),
        localStorageRepository(lsr),
        restartSoundDaemonFn(fn),
        config(initialConfig),
        currentSoundDaemonPid(-1),
        pipeWriteEndToStdin(-1),
        lastSampleId(0)
    {
        NICKEL_INFO("AudioFeedbackImpl - Initial config: "
                    << "enabled(" << config.enabled << ") - "
                    << "relativeVolume(" << config.relativeVolume << ") - "
                    << "rawAudioSamples(" << config.rawAudioSamples.size() << ")");
        boost::tie(currentSoundDaemonPid, pipeWriteEndToStdin) =
            restartSoundDaemonFn(config.relativeVolume, -1, -1);
        startPlaybackThread();
    }

    ~AudioFeedbackImpl()
    {
        stopPlaybackThread(true);
    }

    /**
     * Add a list of samples to the queue of samples to play.
     *
     * @param samples is the list of samples to add to the queue of samples to play.
     *        For every sample:
     *        - AudioSample.name is the name of the sample (loaded from disk
     *          from $prefix/share/nickel-audio-feedback/ when audiofeedbackd
     *          starts).
     *        - AudioSample.durationInMilliseconds specifies for how
     *          long the sample has to be played. If the duration is:
     *          - 0ms: the sample is played once,
     *          - <= audio sample length: the sample is played once,
     *          - > audio sample length: the sample is played
     *              trunc((audio sample length) / duration) + 1 time(s).
     *
     * @param flush specifies whether existing audio samples not yet committed to
     *         pcmplaybackd (written to the socket) have to be flushed.
     *
     * @return a completed future when the samples to play are pushed to the queue
     *         of samples to write or an exceptional future (std::invalid_argument)
     *         if any of the samples requested were not already loaded (nothing will
     *         be pushed to the queue in this case).
     */
    NS_ZINC::Future< void > playSamples(const std::vector< AudioSample > &samples, bool flush)
    {
        if (!config.enabled || pipeWriteEndToStdin == -1)
        {
            NICKEL_INFO("playSamples - no sample to play / audio feedback disabled.");
        }
        else
        {
            std::vector< sound_sample_entry_t > resolvedSamples;
            try
            {
                resolvedSamples = resolveSamples(samples);
            }
            catch (const std::invalid_argument &e)
            {
                return NS_ZINC::exceptionalFuture< void >(e);
            }

            boost::mutex::scoped_lock l(m);
            if (flush)
            {
                // Stops playing sounds previously queued:
                // see CANPDE-370 - Scenario: User presses multiple buttons in quick succession
                samplesToPlay = std::queue< sound_sample_entry_t >(); // no method clear() on a queue...
            }
            BOOST_FOREACH(const sound_sample_entry_t &sampleToPlay, resolvedSamples)
            {
                NICKEL_DEBUG("Pushing " << sampleToPlay.get< SOUND_SAMPLE >()->size() << " bytes to write "
                             << sampleToPlay.get< NB_REPEATS_LEFT >() + 1 << " time(s)...");
                samplesToPlay.push( sampleToPlay );
            }
            if (!resolvedSamples.empty())
            {
                cond.notify_all();
            }
        }
        return completedFuture();
    }

    NS_ZINC::Future< void > setRelativeVolume(int32_t value)
    {
        NICKEL_DEBUG("setRelativeVolume(" << value << ")");
        if (value != config.relativeVolume)
        {
            NICKEL_INFO("Stopping playback thread...");
            // We want to exhaust the queue of samples before changing volume
            // this is to implement CANPDE-1599: when changing volume, user hears
            // 200ms dit with original volume and 200ms dit with new volume.
            stopPlaybackThread(false);
            config.relativeVolume = value;
            boost::tie(currentSoundDaemonPid, pipeWriteEndToStdin) =
                restartSoundDaemonFn(value, currentSoundDaemonPid, pipeWriteEndToStdin);
            NICKEL_INFO("Starting playback thread...");
            startPlaybackThread();
            return localStorageRepository->setItem(0, "", AUDIO_FEEDBACK_VOLUME_KEY,
                boost::lexical_cast< std::string >(value));
        }
        else
        {
            return completedFuture();
        }
    }

    NS_ZINC::Future< int32_t > getRelativeVolume()
    {
        return completedFuture(config.relativeVolume);
    }

    NS_ZINC::Future< void > setEnabled(bool enabled)
    {
        NICKEL_DEBUG("setEnabled(" << enabled << ")");
        config.enabled = enabled;
        return localStorageRepository->setItem(0, "", AUDIO_FEEDBACK_ENABLED_KEY, enabled ? "1" : "0");
    }

    NS_ZINC::Future< bool > getEnabled()
    {
        return completedFuture(config.enabled);
    }

private:

    uint32_t computeRepeatsRequiredForDuration(
        const std::vector< uint8_t > &soundSample,
        uint32_t durationInMs)
    {
        // 16 bits stereo samples at 48kHz
        const uint32_t bytesPerMs = 48 * 2 * 2;
        // durationInMs = 0 means play the full sample only once.
        const uint32_t bytesRequiredForDurationRequested =
            durationInMs * bytesPerMs;
        if (bytesRequiredForDurationRequested <= soundSample.size() ||
            soundSample.size() == 0)
        {
            return 0u; // play once, do not repeat
        }
        else
        {
            return (bytesRequiredForDurationRequested / soundSample.size()) - 1;
        }
    }

    std::vector< sound_sample_entry_t > resolveSamples(
        const std::vector< AudioSample > &audioSamples)
    {
        std::vector< sound_sample_entry_t > resolvedSamples;
        resolvedSamples.reserve(audioSamples.size());
        BOOST_FOREACH(const AudioSample &audioSample, audioSamples)
        {
            audio_sample_map_t::const_iterator it =
                config.rawAudioSamples.find(audioSample.name);
            if (it != config.rawAudioSamples.end())
            {
                // Pointers to elements are not invalidated during insertion in unordered_map.
                const std::vector< uint8_t > *rawAudioSample = &(it->second);
                NICKEL_DEBUG("Found audio sample: " << audioSample.name
                             << " - Size: " << rawAudioSample->size());
                ++lastSampleId;
                resolvedSamples.push_back(
                    boost::make_tuple( lastSampleId, 0u,
                        computeRepeatsRequiredForDuration(
                            *rawAudioSample, audioSample.durationInMilliSeconds),
                        rawAudioSample ) );
            }
            else
            {
                const std::string errorMsg("No sound loaded for sample " + audioSample.name);
                NICKEL_ERROR(errorMsg);
                throw std::invalid_argument(errorMsg);
            }
        }
        return resolvedSamples;
    }

    void startPlaybackThread()
    {
        keepPlaybackThreadAlive = true;
        actionProcessor->start();
        actionProcessor->post(boost::bind(&AudioFeedbackImpl::doPlay, this));
    }

    void stopPlaybackThread(bool flushQueue)
    {
        boost::mutex::scoped_lock l(m);
        keepPlaybackThreadAlive = false;
        if (flushQueue)
        {
            samplesToPlay = std::queue< sound_sample_entry_t >(); // no method clear() on a queue...
        }
        l.unlock();
        cond.notify_all();
        actionProcessor->stop(); // blocks until doPlay stops executing
    }

    void doPlay()
    {
        boost::mutex::scoped_lock l(m);
        while (keepPlaybackThreadAlive || !samplesToPlay.empty())
        {
            if (samplesToPlay.empty())
            {
                NICKEL_DEBUG("doPlay() - Waiting for audio samples to write...");
                cond.wait(l);
                NICKEL_DEBUG("doPlay() - Woken up - " << samplesToPlay.size() << " audio sample(s) to write.");
            }

            if (!samplesToPlay.empty()) // Might be empty if woken up by stopPlaybackThread
            {
                const sound_sample_entry_t &sampleToPlay =
                    samplesToPlay.front();
                uint32_t currentSampleId =
                    sampleToPlay.get< SAMPLE_ID >();
                uint32_t totalBytesWritten =
                    sampleToPlay.get< NB_BYTES_WRITTEN >();
                const std::vector< uint8_t > *soundSample =
                    sampleToPlay.get< SOUND_SAMPLE >();
                l.unlock();

                int32_t nbBytesWritten = 0;
                // Multiple of 4 bytes have to be written:
                // - pcmplaybackd expects 16 bits stereo samples
                // - a concurrent call to playSamples with flush = true
                //   would shift all the following data otherwise
                // Note that sound samples are checked to be multiple of 4 bytes.
                // DEVARCH-6645: For 1kHz-5ms.raw, multiple of 192 bytes have to be written.
                uint32_t nbBytesToWrite =
                    std::min< uint32_t >(1024u, soundSample->size() - totalBytesWritten);

                nbBytesWritten =
                    ::write(pipeWriteEndToStdin,
                        &soundSample->at(totalBytesWritten),
                        nbBytesToWrite);
                if ( -1 == nbBytesWritten || (nbBytesWritten % 4) != 0 )
                {
                    // nbBytesWritten should always be nbBytesToWrite
                    // since FD is blocking and all signals are masked.
                    NICKEL_ERROR("Failed to write to FD: " << std::strerror(errno));
                    break; // Better to stop looping on failure
                }
                else
                {
                    NICKEL_DEBUG("doPlay() - Wrote " << nbBytesWritten << " bytes.");
                }

                l.lock();
                if (nbBytesWritten > 0 && !samplesToPlay.empty() &&
                    samplesToPlay.front().get< SAMPLE_ID >() == currentSampleId)
                {
                    totalBytesWritten += nbBytesWritten;
                    if (totalBytesWritten >= soundSample->size())
                    {
                        if (samplesToPlay.front().get< NB_REPEATS_LEFT >() > 0)
                        {
                            --samplesToPlay.front().get< NB_REPEATS_LEFT >();
                            samplesToPlay.front().get< NB_BYTES_WRITTEN >() = 0;
                        }
                        else
                        {
                            samplesToPlay.pop();
                        }
                    }
                    else
                    {
                        samplesToPlay.front().get< NB_BYTES_WRITTEN >() = totalBytesWritten;
                    }
                }
            }
        }
    }

    shared_ptr< Dispatcher > dispatcher;
    shared_ptr< ActionProcessor > actionProcessor;
    shared_ptr< LocalStorageRepositoryAsync > localStorageRepository;
    restart_sound_daemon_fn_t restartSoundDaemonFn;
    AudioFeedbackConfig config;
    pid_t currentSoundDaemonPid;
    int pipeWriteEndToStdin;
    uint32_t lastSampleId;

    mutable boost::mutex m;
    boost::condition_variable cond;
    bool keepPlaybackThreadAlive;
    std::queue< sound_sample_entry_t > samplesToPlay;
};


} // anon namespace


shared_ptr< AudioFeedbackAsync > createAudioFeedbackImpl(
    shared_ptr< Dispatcher > dispatcher,
    shared_ptr< NS_ZINC::ActionProcessor > ap,
    shared_ptr< LocalStorageRepositoryAsync > lsr,
    restart_sound_daemon_fn_t fn,
    const AudioFeedbackConfig &initialConfig)
{
    return make_shared< AudioFeedbackImpl >(dispatcher, ap, lsr, fn, initialConfig);
}

NS_NICKEL_AUDIOFEEDBACK_CLOSE
