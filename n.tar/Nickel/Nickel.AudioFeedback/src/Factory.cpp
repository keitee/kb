/*
 * Factory.cpp
 *
 * Created on: 22 Oct 2013
 *     Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/Factory.h"

#include "AudioFeedbackImpl.h"

#include <nickel-common/NickelLogger.h>

#include <copper-system-api/LocalStorageRepositorySync.h>
#include <copper-system-api/Registry.h>
#include <copper-system-api/SystemFactory.h>
#include <copper-system-api/LocalStorageRepositoryConvertToSync.h>
#include <copper-system-api/LSRHelpers.h>

#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/resource-finder/ResourceSearchPathGetters.h>
#include <zinc-common/ActionProcessor.h>
#include <zinc-common/FilePluginConfig.h>
#include <zinc-common/PluginFactory.h>

#include <boost/algorithm/string/case_conv.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/filesystem.hpp>
#include <boost/foreach.hpp>
#include <boost/make_shared.hpp>

#include <string>

#include <stdio.h>

#ifndef MACRO__PACKAGE
#error "MACRO__PACKAGE is not defined"
#endif

using NS_ZINC::Dispatcher;
using NS_ZINC::PackageDataFinder;
using NS_COPPER_SYSTEM::getLSRItem;
using boost::make_shared;
using boost::shared_ptr;

namespace
{

/**
 * Find the list of audio samples available at the root of audioSamplePathStr.
 * 
 * Audio samples have the extension ".raw" (case insensitive).
 *
 * @param audioSamplePathStr is usually ($prefix)/share/nickel-audio-feedback/
 * @return audio sample filenames or an empty list.
 */
std::vector< std::string > findAudioSamples(
    const std::string &audioSamplePathStr)
{
    const boost::filesystem::path audioSamplePath(audioSamplePathStr);
    if (!boost::filesystem::exists(audioSamplePath) ||
        !boost::filesystem::is_directory(audioSamplePath) )
    {
        const std::string errorMsg(
            "Audio sample path does not exist or is not a directory: " +
            audioSamplePath.string());
        NICKEL_ERROR(errorMsg);
        throw std::runtime_error(errorMsg);
    }

    std::vector< std::string > audioSampleNames;
    boost::filesystem::directory_iterator end_it;
    for (boost::filesystem::directory_iterator it( audioSamplePath );
         it != end_it; ++it)
    {

        if (boost::filesystem::is_regular_file(it->status()))
        {
            const boost::filesystem::path currentPath(it->path());
            if ( ".raw" == boost::to_lower_copy(currentPath.extension()) )
            {
                NICKEL_INFO("Found audio sample: " << currentPath.filename());
                audioSampleNames.push_back(currentPath.filename());
            }
        }
    }
    return audioSampleNames;
}

} // anon namespace

NS_NICKEL_AUDIOFEEDBACK_OPEN

Factory::Factory(boost::shared_ptr< NS_ZINC::Dispatcher > d,
                 restart_sound_daemon_fn_t fn):
    dispatcher(d),
    restartSoundDaemonFn(fn)
{
}

shared_ptr< AudioFeedbackAsync > Factory::createAudioFeedback()
{
    NICKEL_FUNC_TRACE;
    if (!audioFeedback)
    {
        NS_COPPER_SYSTEM::LocalStorageRepositorySync &syncLSR =
            *createLocalStorageRepositorySync();

        AudioFeedbackConfig config;
        config.enabled = getLSRItem< bool >(syncLSR,
            AUDIO_FEEDBACK_ENABLED_KEY, config.enabled);
        config.relativeVolume = getLSRItem< int32_t >(syncLSR,
            AUDIO_FEEDBACK_VOLUME_KEY, config.relativeVolume);
        config.rawAudioSamples = loadRawAudioSamples();

        audioFeedback = createAudioFeedbackImpl(dispatcher,
                                                createActionProcessor(),
                                                createLocalStorageRepositoryAsync(),
                                                restartSoundDaemonFn,
                                                config);
    }
    return audioFeedback;
}

boost::shared_ptr< NS_ZINC::ActionProcessor > Factory::createActionProcessor()
{
    if (!actionProcessor)
    {
        actionProcessor = make_shared< NS_ZINC::ActionProcessor >();
        actionProcessor->start();
    }
    return actionProcessor;
}

boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > Factory::createLocalStorageRepositoryAsync()
{
    NICKEL_FUNC_TRACE;
    if (!localStorageRepositoryAsync)
    {
        localStorageRepositoryAsync = getCopperSystemFactory().createLocalStorageRepository();
    }
    return localStorageRepositoryAsync;
}

boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > Factory::createLocalStorageRepositorySync()
{
    NICKEL_FUNC_TRACE;
    if (!localStorageRepositorySync)
    {
        localStorageRepositorySync = NS_COPPER_SYSTEM::convertToSync(createLocalStorageRepositoryAsync());
    }
    return localStorageRepositorySync;
}

const audio_sample_map_t & Factory::loadRawAudioSamples()
{
    NICKEL_FUNC_TRACE;
    if (rawAudioSamples.empty())
    {
        const std::string audioSamplePath(
            NS_ZINC::getInstallDataDir() + "/" + MACRO__PACKAGE);
        std::vector< std::string > audioSampleNames =
            findAudioSamples(audioSamplePath);

        std::vector< uint8_t > buffer(1024);
        BOOST_FOREACH(const std::string &audioSampleName, audioSampleNames)
        {
            const std::string fullAudioSamplePath = audioSamplePath + "/" + audioSampleName;
            FILE *audioSampleFile = NULL;
            if ( (audioSampleFile = ::fopen(fullAudioSamplePath.c_str(), "r")) == NULL )
            {
                NICKEL_ERROR("Failed to read audio sample from file '" << fullAudioSamplePath << "'.");
            }
            else
            {
                NICKEL_INFO("Reading audio sample from file '" << fullAudioSamplePath << "'.");

                std::pair< audio_sample_map_t::iterator, bool > res =
                    rawAudioSamples.insert( std::make_pair(audioSampleName, std::vector< uint8_t >()) );
                std::vector< uint8_t > &rawData = res.first->second;

                int nbItemsRead = 0;
                while ( (nbItemsRead = ::fread(&buffer[0], sizeof(uint8_t), buffer.size(), audioSampleFile)) )
                {
                    rawData.insert(rawData.end(), buffer.begin(), buffer.begin() + nbItemsRead);
                }

                NICKEL_INFO("Read " << rawData.size() << " bytes from file '" << fullAudioSamplePath << "'");

                // pcmplaybackd expects 16 bits stereo samples (i.e. samples multiple of 4 bytes)
                if (rawData.size() % 4 != 0)
                {
                    NICKEL_ERROR("Discarding invalid 16 bits stereo sample: '" << fullAudioSamplePath << "'");
                    rawAudioSamples.erase(res.first);
                }

                ::fclose(audioSampleFile);
            }
        }
    }
    return rawAudioSamples;
}

void Factory::setLocalStorageRepositoryAsync(boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > lsr)
{
    NICKEL_FUNC_TRACE;
    localStorageRepositoryAsync = lsr;
}

void Factory::setLocalStorageRepositorySync(boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > lsr)
{
    NICKEL_FUNC_TRACE;
    localStorageRepositorySync = lsr;
}

void Factory::setRawAudioSamples(const audio_sample_map_t &samples)
{
    NICKEL_FUNC_TRACE;
    rawAudioSamples = samples;
}

NS_COPPER_SYSTEM::SystemFactory & Factory::getCopperSystemFactory()
{
    NICKEL_FUNC_TRACE;
    std::string copperConfigFilePath(NS_ZINC::PackageDataFinder().find("copper-system-factory.plugin-config"));
    NICKEL_DEBUG("Factory::getCopperSystemFactory - Using configuration file: " << copperConfigFilePath);
    const NS_ZINC::FilePluginConfig pluginConfig(copperConfigFilePath);
    return NS_ZINC::PluginFactory::getInstance< NS_COPPER_SYSTEM::SystemFactory >(pluginConfig);
}

NS_NICKEL_AUDIOFEEDBACK_CLOSE
