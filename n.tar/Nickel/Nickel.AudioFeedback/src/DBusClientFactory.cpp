/*
 * DBusClientFactory.cpp
 *
 *  Created on: 9 October 2013
 *      Author: darren.garvey@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/DBusClientFactory.h"

#include "bus-name.h"
#include "AudioFeedbackDBusToSyncAndAsync.h"

#include <zinc-binding-runtime/dbus/DBusConnectionManager.h>
#include <zinc-binding-runtime/dbus/dbus-runtime.h>
#include <zinc-binding-runtime/dbus/ProxyFactory.h>

NS_NICKEL_AUDIOFEEDBACK_OPEN

boost::shared_ptr<AudioFeedbackAsync> create(const boost::shared_ptr<NS_ZINC::Dispatcher>& dispatcher)
{
    return AudioFeedbackDBusToSyncAndAsync::create(
        NS_ZINC_DBUS_BINDING::DBusConnectionManager::instance().getSessionConnection(),
        BUS_NAME,
        OBJECT_PATH,
        dispatcher);
}

NS_NICKEL_AUDIOFEEDBACK_CLOSE
