/*
 * AudioFeedbackImpl.h
 *
 * Created on: 22 Oct 2013
 *     Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_AUDIOFEEDBACK_IMPL_H_
#define NICKEL_AUDIOFEEDBACK_IMPL_H_

#include "macros.h"

#include <copper-system-api/macros.h>

#include <zinc-common/macros.h>
#include <zinc-common/async/Dispatcher.h>

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/unordered_map.hpp>

#include <vector>
#include <string>

#include <stdint.h>

NS_ZINC_OPEN
class ActionProcessor;
class Dispatcher;
NS_ZINC_CLOSE

namespace Zinc
{
namespace Audio
{
class AudioFeedbackAsync;
} // namespace Audio
namespace System
{
class LocalStorageRepositoryAsync;
class SystemFactory;
} // namespace System
} // namespace Zinc

NS_NICKEL_AUDIOFEEDBACK_OPEN

const char * const AUDIO_FEEDBACK_ENABLED_KEY = "platform.settings.audiofeedback.enabled";
const char * const AUDIO_FEEDBACK_VOLUME_KEY = "platform.settings.audiofeedback.volume";

typedef boost::function< boost::tuple< pid_t, int > (int32_t, pid_t, int) > restart_sound_daemon_fn_t;
typedef boost::unordered_map< std::string, std::vector< uint8_t > > audio_sample_map_t;

struct AudioFeedbackConfig
{
    AudioFeedbackConfig():
        enabled(false),
        relativeVolume(0)
    {
    }

    bool enabled;
    int32_t relativeVolume;

    audio_sample_map_t rawAudioSamples;
};

boost::shared_ptr< AudioFeedbackAsync > createAudioFeedbackImpl(
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
    boost::shared_ptr< NS_ZINC::ActionProcessor > ap,
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > lsr,
    restart_sound_daemon_fn_t fn,
    const AudioFeedbackConfig &initialConfig) ZINC_EXPORT;

NS_NICKEL_AUDIOFEEDBACK_CLOSE

#endif /* NICKEL_AUDIOFEEDBACK_IMPL_H_ */
