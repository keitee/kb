/*
 * bus-name.h
 *
 *  Created on: 30 Sept 2013
 *      Author: darren.garvey@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_AUDIOFEEDBACK_BUS_NAME_H_
#define NICKEL_AUDIOFEEDBACK_BUS_NAME_H_

#include "macros.h"

NS_NICKEL_AUDIOFEEDBACK_OPEN

char const* const BUS_NAME = "Zinc.Audio";

char const* const OBJECT_PATH = "/Zinc/Audio/AudioFeedback";

NS_NICKEL_AUDIOFEEDBACK_CLOSE

#endif /* NICKEL_AUDIOFEEDBACK_BUS_NAME_H_ */
