/*
 * audiofeedbackd.cpp
 *
 *  Created on: 8 Oct 2013
 *      Author: darren.garvey@gmail.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#include "macros.h"
#include "bus-name.h"
#include "AudioFeedbackAsyncToDBus.h"

#include "../include/AudioFeedbackHelpers.h"
#include "../include/Factory.h"

#include <nickel-common/NickelLogger.h>

#include <zinc-binding-runtime/dbus/DBusService.h>
#include <zinc-binding-runtime/dbus/MainLoop.h>
#include <zinc-binding-runtime/dbus/SignalReceiver.h>

#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/noncopyable.hpp>

#include <unistd.h> // For "environ" global variable.

using namespace NS_ZINC_DBUS_BINDING;
using namespace NS_NICKEL_AUDIOFEEDBACK;

namespace {

std::vector< char* > convertStringVectorToCharStarVector(const std::vector< std::string > &input)
{
    std::vector< char* > output(input.size() + 1);
    std::transform(input.begin(), input.end(), output.begin(), StrToPtr());
    output[input.size()] = NULL;
    return output;
}

void closePipeAndWaitForChildToTerminate(pid_t pid, int pipeWriteEnd, uint32_t timeoutUsecs = 5000000)
{
    bool childExpectedToTerminate = true;
    while (const int res = ::close(pipeWriteEnd))
    {
        if (EINTR != errno)
        {
            NICKEL_ERROR("Failed to close FD: " << pipeWriteEnd
                         << ": " << sysError());
            if (EBADF == errno) // unexpected
            {
                childExpectedToTerminate = false;
            }
            break;
        }
    }

    if (childExpectedToTerminate)
    {
        NICKEL_DEBUG("Waiting for process with PID '" << pid << "' to terminate...");
        const uint32_t timeStepUsecs = 1000;
        uint32_t timeElapsedUsecs = 0;
        int res;
        while ((res = ::waitpid(pid, NULL, WNOHANG)) != pid)
        {
            if (res == -1)
            {
                NICKEL_ERROR("Failed to wait for child " << pid
                             << " to exit: " << sysError());
                break;
            }
            usleep(timeStepUsecs);
            timeElapsedUsecs += timeStepUsecs;
            if (timeElapsedUsecs >= timeoutUsecs)
            {
                NICKEL_ERROR("Child " << pid << " has not exited within " << timeoutUsecs / 1e9 << "s");
                break;
            }
        }
    }
}

// TODO: change AudioFeedback Client API so that the UI can pass a
// value relative to 0dB (0dB, -6dB, -12dB, -18dB, -24dB)
// which would avoid to hard-code values.
uint32_t mapDbVolumeToLinearVolume(int relativeVolumeDb)
{
    // NexusMgr / Nexus implements a 12 dB level change for a doubling of the volume (See CANADO-47).
    // This means that the function that maps change in dB volume (e.g. -3dB, -6dB, ...) to
    // nexus volume (between 0-100) using v(0dB)=100 can be approximated to:
    // v(x) = 100exp(0.057762265x) - see DEVARCH-6540 for more details.

    // CANPDE-1599 requires 6dB level change between AudioFeedback volume levels.
    switch (relativeVolumeDb)
    {
        case 6:
            return 100; // = v(0)
            break;
        case 3:
            return 71; // ~= v(-6)
            break;
        case 0:
            return 50; // = v(-12)
            break;
        case -3:
            return 35; // ~= v(-18)
            break;
        case -6:
            return 25; // = v(-24)
            break;
        default:
            return 50;
    }
}

/**
 * Attempt to launch the sound daemon if it is found and return
 * the write end of the pipe to the standard input of the daemon.
 * 
 * @param soundDaemonName is the name of the daemon to locate using SingletonBinFinderLocator.
 * @param volume is the relative volume in dB to use when starting the daemon.
 * @param previousDaemonPid is the pid of the previous daemon to wait for or -1.
 * @param previousPipeWriteEnd is the pipe write end to cause the daemon to exit or -1.
 * @return a tuple that contains the pid of the process or -1 if any
 *         error occurred (e.g. sound daemon not found, execve failed, ...)
 *         and the pipe write end to the standard input of the daemon or
 *         -1 if any error occurred.
 */
boost::tuple< pid_t, int > restartSoundDaemonWithPipeToStdinAndSpecificVolume(
    const std::string &soundDaemonName, int32_t volume,
    pid_t previousDaemonPid, int previousPipeWriteEnd)
{
    NICKEL_DEBUG("restartSoundDaemonWithPipeToStdinAndSpecificVolume("
                 << soundDaemonName << ", " << volume << ", "
                 << previousDaemonPid << ", " << previousPipeWriteEnd << ")");

    if (previousDaemonPid != -1 && previousPipeWriteEnd != -1)
    {
        closePipeAndWaitForChildToTerminate(previousDaemonPid, previousPipeWriteEnd);
    }

    ::pid_t pid = -1;
    int pipeWriteEnd = -1;
    try
    {
        NICKEL_INFO("Launching Sound Daemon...");
        const std::string soundDaemonPath  = NS_ZINC::SingletonBinFinderLocator::get().find(soundDaemonName, "");

        std::vector<std::string> command;
        command.push_back(soundDaemonPath);
        command.push_back("-v");
        command.push_back(boost::lexical_cast< std::string >(mapDbVolumeToLinearVolume(volume)));

        std::vector<char*> argv = convertStringVectorToCharStarVector(command);

        // Note that it is not necessary to worry about the lifetime of pcmplaybackd since:
        // - if audiofeedbackd dies, pcmplaybackd will get EOF from the PIPE and it will terminate,
        // - if pcmplaybackd dies, audiofeedbackd will receive SIGCHLD and it will terminate.
        //   DBus activation will restart everything.
        pid = yv_fork_exec(argv.data(), environ, pipeWriteEnd);
        NICKEL_INFO("Sound Daemon PID: " << pid);
    }
    catch (const std::exception &e)
    {
        NICKEL_INFO("Failed to start pcmplaybackd: " << e.what()
                    << " - Sound playback will not be available.");
        pipeWriteEnd = -1;
    }
    return boost::make_tuple(pid, pipeWriteEnd);
}

struct CustomSignalHandler
{
    typedef void result_type;
    explicit CustomSignalHandler(boost::function<void (void)> stop_)
        : state(RUNNING), stop(stop_) {}
    void operator()(const struct signalfd_siginfo& sig)
    {
        switch (sig.ssi_signo) {
        case SIGQUIT:
        case SIGINT:
        case SIGTERM:
            if (state != STOPPING) {
                state = STOPPING;
                stop();
            }
            else {
                std::cerr << "Force quitting\n";
                exit(1);
            }
            break;
        case SIGCHLD:
            // Die if the sound daemon died unexpectedly so that DBus activation
            // restarts both daemons. Note that if pcmplaybackd kept dying, this
            // would cause DBus activations every time a key would be pressed.
            // If the following call to waitpid succeeds (>0), it means that the
            // sound daemon was not expected to die. If it was expected to die
            // (volume changed), waitpid would already have been called.
            // The signal SIGCHLD is delivered to the zinc dispatcher,
            // guaranteeing there is no race between the two calls to waitpid.
            if (::waitpid(-1, NULL, WNOHANG) > 0)
            {
                std::cerr << "Child exited abnormally - Force quitting.\n";
                exit(1);
            }
            break;
        case SIGPIPE:
            std::cerr << "SIGPIPE received - Force quitting." << std::endl;
            exit(1);
            break;
        }
    }
    enum {
        RUNNING,
        STOPPING
    } state;
    boost::function<void (void)> stop;
};

/**
 * This is used in place of SignalReceiver::createExitSignalHandler to be able
 * to intercept SIGCHLD and SIGPIPE in addition to SIGQUIT, SIGINT and SIGTERM.
 */
boost::function<void(const struct signalfd_siginfo&)> createCustomSignalHandler(boost::function<void (void)> stop_)
{
    return CustomSignalHandler(stop_);
}


class AudioFeedbackDaemon : boost::noncopyable
{
public:
    AudioFeedbackDaemon(MainLoop& mainloop_):
        mainloop(mainloop_),
        sr(mainloop_, createCustomSignalHandler(boost::bind(&AudioFeedbackDaemon::stop, this))),
        dbus(mainloop_)
    {
    }

    void start()
    {
        sr.start();
        dbus.start();

        Factory factory(
            mainloop.getZincDispatcher(),
            boost::bind(&restartSoundDaemonWithPipeToStdinAndSpecificVolume,
                        std::string("pcmplaybackd"), _1, _2, _3));

        audioFeedback = factory.createAudioFeedback();

        dbus.expose(OBJECT_PATH, audioFeedback);

        dbus.request_name(BUS_NAME);
    }

    void stop()
    {
        dbus.stop();
        sr.stop();
    }

private:

    MainLoop &mainloop;
    SignalReceiver sr;
    DBusService dbus;
    boost::shared_ptr< AudioFeedbackAsync > audioFeedback;
};

}// anon namespace


int main()
{
    int result = EXIT_SUCCESS;

    try
    {
        NICKEL_INFO("Launching AudioFeedback Daemon ...");
        MainLoop mainloop(BUS_NAME);
        AudioFeedbackDaemon daemon(mainloop);
        mainloop.post(boost::bind(&AudioFeedbackDaemon::start, &daemon));
        result = mainloop.run();
    }
    catch (const std::exception &e)
    {
        NICKEL_ERROR("AudioFeedback daemon stopping: " << e.what());
        result = EXIT_FAILURE;
    }

    NICKEL_INFO("AudioFeedback Daemon shutting down...");

    return result;
}
