/*
 * Factory.h
 *
 * Created on: 22 Oct 2013
 *     Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_AUDIOFEEDBACK_FACTORY_H_
#define NICKEL_AUDIOFEEDBACK_FACTORY_H_

#include "macros.h"

#include <copper-system-api/macros.h>

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/unordered_map.hpp>

#include <vector>

#include <stdint.h>

NS_ZINC_OPEN
class ActionProcessor;
class Dispatcher;
NS_ZINC_CLOSE

namespace Zinc
{
namespace Audio
{
class AudioFeedbackAsync;
} // namespace Audio
namespace System
{
class LocalStorageRepositoryAsync;
class LocalStorageRepositorySync;
class SystemFactory;
} // namespace System
} // namespace Zinc

NS_NICKEL_AUDIOFEEDBACK_OPEN

typedef boost::function< boost::tuple< pid_t, int > (int32_t, pid_t, int) > restart_sound_daemon_fn_t;
typedef boost::unordered_map< std::string, std::vector< uint8_t > > audio_sample_map_t;

class ZINC_EXPORT Factory
{
public:
    Factory(
        boost::shared_ptr< NS_ZINC::Dispatcher > d,
        restart_sound_daemon_fn_t fn);

    boost::shared_ptr< AudioFeedbackAsync > createAudioFeedback();

public:

    boost::shared_ptr< NS_ZINC::ActionProcessor > createActionProcessor();

    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > createLocalStorageRepositoryAsync();

    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > createLocalStorageRepositorySync();

    const audio_sample_map_t & loadRawAudioSamples();

    void setLocalStorageRepositoryAsync(boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > lsr);

    void setLocalStorageRepositorySync(boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > lsr);

    void setRawAudioSamples(const audio_sample_map_t &samples);

private:

    NS_COPPER_SYSTEM::SystemFactory & getCopperSystemFactory();

    boost::shared_ptr< NS_ZINC::Dispatcher >                                dispatcher;
    boost::shared_ptr< NS_ZINC::ActionProcessor >                           actionProcessor;
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync >      localStorageRepositoryAsync;
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync >       localStorageRepositorySync;
    audio_sample_map_t                                                      rawAudioSamples;
    boost::shared_ptr< AudioFeedbackAsync >                                 audioFeedback;
    restart_sound_daemon_fn_t                                               restartSoundDaemonFn;
};

NS_NICKEL_AUDIOFEEDBACK_CLOSE

#endif /* NICKEL_AUDIOFEEDBACK_SYSTEM_FACTORY_H_ */
