/*
 * macros.h
 *
 *  Created on: 30 Sept 2013
 *      Author: darren.garvey@gmail.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_AUDIOFEEDBACK_MACROS_H_
#define NICKEL_AUDIOFEEDBACK_MACROS_H_

#include <zinc-common/macros.h>

#define NS_NICKEL_AUDIOFEEDBACK_OPEN \
 	namespace Zinc { \
    namespace Audio { \

#define NS_NICKEL_AUDIOFEEDBACK_CLOSE } }
#define NS_NICKEL_AUDIOFEEDBACK Zinc::Audio

#endif /* NICKEL_AUDIOFEEDBACK_MACROS_H_ */
