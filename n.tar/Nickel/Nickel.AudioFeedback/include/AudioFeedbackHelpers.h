/* 
 * File:   AudioFeedbackHelpers.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 31 October 2013
 * 
 * Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_AUDIOFEEDBACK_HELPERS_H_
#define NICKEL_AUDIOFEEDBACK_HELPERS_H_

#include "macros.h"

#include <nickel-common/NickelLogger.h>

#include <zinc-common/resource-finder/SingletonBinFinderLocator.h>
#include <zinc-common/ScopeExitHook.h>

#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/tuple/tuple.hpp>

#include <string>
#include <vector>

#include <errno.h>
#include <error.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <cstdlib>

namespace
{

// Most of the following code (sysError, StrToPtr, yv_fork_exec)  is stolen from
// Titanium/Titanium.System.Launcher/src/yv-sysdeps.cpp
// Support is added to redirect stdin to a custom file descriptor.
// An alternative would have been to use babysitterd and to give a named pipe in parameters.
std::string sysError(const int e)
{
    return std::strerror(e);
}

std::string sysError()
{
    return sysError(errno);
}

/**
 * A convenient function to extract C-like pointers from std::string.
 * Use only when the consumer of the pointers will not attempt to write them.
 */
struct ZINC_LOCAL StrToPtr : public std::unary_function<std::string, char*>
{
public:
    result_type operator()(const argument_type& arg) const
    {
        return const_cast<char*>(arg.c_str());
    }
};

::pid_t yv_fork_exec(char* argv[], char* env[], int &pipeWriteEnd)
{
    /**
     * The idea is: open a pipe with O_CLOEXEC and read from it in the parent process.
     *
     * If the execv() succeeds in the child process then read() returns 0 and everyone's happy.
     *
     * Otherwise it reads the message from the child process indicating the reason of the failure. Not as happy as above
     * but still pretty cool.
     */
    int pipefd[2];
    if (0 != pipe2(pipefd, O_CLOEXEC))
    {
        throw std::runtime_error("pipe2() failed: " + sysError());
    }

    /* Setting the buffer size of a pipe requires kernel >= 2.6.35
     * (google F_SETPIPE_SZ), so we use socketpair() instead. */
    int stdinpipefd[2];
    if (0 != socketpair(AF_UNIX, SOCK_STREAM, 0, stdinpipefd))
    {
        throw std::runtime_error("socketpair() failed: " + sysError());
    }

    if (-1 == fcntl(stdinpipefd[0], F_SETFD, FD_CLOEXEC) ||
        -1 == fcntl(stdinpipefd[1], F_SETFD, FD_CLOEXEC))
    {
        throw std::runtime_error("fcntl(F_SETFD, FD_CLOEXEC) failed: " + sysError());
    }

    /* We are targeting a buffer size of 16384 that corresponds to latency
     * of 85 ms, assuming 48K 16-bit stereo signal. The Linux kernel doubles
     * the requested size [see socket(7)] before applying it. Yet, the actual
     * number of bytes that can be written to a socket before blocking may
     * still be around the originally requested size, or even less than that.
     * In some cases though, it's actually close to the doubled size.
     * We are willing to accept any buffer between 8K and 16K, so we request
     * the send buffer to be slightly more than 8K. In case of a receive
     * buffer, it won't hurt to have it larger than necessary, so we request
     * a 16K one. */
    int const sndBufSize = 8320;
    int const rcvBufSize = 16384;
    if (0 != setsockopt(stdinpipefd[0], SOL_SOCKET, SO_RCVBUF, &rcvBufSize, sizeof(int)))
    {
        throw std::runtime_error("setsockopt(SO_RCVBUF) failed: " + sysError());
    }
    if (0 != setsockopt(stdinpipefd[1], SOL_SOCKET, SO_SNDBUF, &sndBufSize, sizeof(int)))
    {
        throw std::runtime_error("setsockopt(SO_SNDBUF) failed: " + sysError());
    }

    // We don't send data the other way, so set those buffers to 0.
    int const zeroSize = 0;
    if (0 != setsockopt(stdinpipefd[0], SOL_SOCKET, SO_SNDBUF, &zeroSize, sizeof(int)))
    {
        throw std::runtime_error("setsockopt(SO_SNDBUF) failed: " + sysError());
    }
    if (0 != setsockopt(stdinpipefd[1], SOL_SOCKET, SO_RCVBUF, &zeroSize, sizeof(int)))
    {
        throw std::runtime_error("setsockopt(SO_RCVBUF) failed: " + sysError());
    }

    const ::pid_t pid = ::fork();

    switch (pid)
    {
    case -1:
        throw std::runtime_error("fork() failed: " + sysError());

        break;

    case 0: // Child
        {
            std::string errorMsg;

            do
            {
                if (-1 == ::close(pipefd[0]))
                {
                    errorMsg = "close(): " + sysError();
                    break;
                }

                if (-1 == ::setpgrp())
                {
                    errorMsg = "setpgrp(): " + sysError();
                    break;
                }

                if (-1 == ::dup2(stdinpipefd[0], STDIN_FILENO))
                {
                    errorMsg = "dup2(): " + sysError();
                    break;
                }

                if (-1 == ::close(stdinpipefd[1]))
                {
                    errorMsg = "close(): " + sysError();
                    break;
                }

                const int result = ::execve(argv[0], argv, env);
                errorMsg = -1 == result ? sysError() : "unknown error";

            }
            while (false);

            // There's definitely a problem if we got here so let the parent know about it through the pipe.
            // If any of below fail, there's not much we can do.
            (void)::write(pipefd[1], errorMsg.data(), errorMsg.size());
            (void)::_exit(EXIT_FAILURE);
        }

        break;

    default: // Parent
        {
            // TODO: Paranoid: Any ideas of how to organise the logic to handle close() errors?

            ::close(pipefd[1]);
            ::close(stdinpipefd[0]);
            pipeWriteEnd = stdinpipefd[1];

            const NS_ZINC::ScopeExitHook closePipe0(boost::bind(::close, pipefd[0]));

            std::string errorMsg;

            const size_t bufferSize = 128;
            char buffer[bufferSize];

            // if we get the result != 0 then it means that the execv() failed
            while (const int res = ::read(pipefd[0], &buffer, bufferSize))
            {
                if (res > 0)
                {
                    errorMsg.append(buffer, buffer + res);
                }
                else if (EINTR != errno)
                {
                    throw std::runtime_error("read() failed: " + sysError());
                }
            }

            if (!errorMsg.empty())
            {
                throw std::runtime_error(errorMsg);
            }
        }

        break;
    }

    return pid;
}

} // anon namespace

#endif	/* NICKEL_AUDIOFEEDBACK_HELPERS_H_ */

