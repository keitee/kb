/*
 * DBusClientFactory.h
 *
 *  Created on: 9 October 2013
 *      Author: darren.garvey@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_AUDIOFEEDBACK_DBUS_CLIENT_FACTORY_H_
#define NICKEL_AUDIOFEEDBACK_DBUS_CLIENT_FACTORY_H_

#include "macros.h"
#include "AudioFeedback.h"

#include <zinc-common/async/Dispatcher.h>

#include <boost/shared_ptr.hpp>

NS_NICKEL_AUDIOFEEDBACK_OPEN

/**
 * A handy factory function to get an AudioFeedback object on the client side
 * of D-BUS.
 *
 * @param dispatcher The dispatcher to be used for dispatching evens/futures.
 *
 * @return The AudioFeedback object.
 */
boost::shared_ptr<AudioFeedbackAsync>
create(const boost::shared_ptr<NS_ZINC::Dispatcher>& dispatcher) ZINC_EXPORT;

NS_NICKEL_AUDIOFEEDBACK_CLOSE

#endif /* NICKEL_AUDIOFEEDBACK_DBUS_CLIENT_FACTORY_H_*/
