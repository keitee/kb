/*
 *  AudioFeedbackImpl.h
 *
 *  Created on: 9 October 2013
 *      Author: darren.garvey@gmail.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_AUDIOFEEDBACK_H_
#define NICKEL_AUDIOFEEDBACK_H_

#include "macros.h"
#include "AudioFeedbackAsync.h"

NS_NICKEL_AUDIOFEEDBACK_OPEN

typedef Zinc::Audio::AudioFeedbackAsync AudioFeedback;

NS_NICKEL_AUDIOFEEDBACK_CLOSE

#endif /* NICKEL_AUDIOFEEDBACK_H_ */
