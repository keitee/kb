/* 
 * File:   PipeBufferSizeTest.cpp
 * Author: joseph.artsimovich@youview.com
 *
 * Created on 22 Nov 2013
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/AudioFeedbackHelpers.h"

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/AtomicBool.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/FutureMockActions.h>
#include <zinc-common/testsupport/MockProperty.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>

#include <boost/format.hpp>

#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

using boost::format;

class ZINC_LOCAL PipeBufferSizeTest : public NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
public:
    void testPipeBufferSize()
    {
        int pipeWriteEnd = 0;

        // We need a process that hangs around without reading from stdin.
        // /bin/sleep fits that perfectly.
        char arg0[] = "/bin/sleep";
        char arg1[] = "20";
        char* argv[] = { arg0, arg1, NULL };
        char* envp[] = { NULL };
        pid_t childPid = yv_fork_exec(argv, envp, pipeWriteEnd);
        CPPUNIT_ASSERT(childPid != -1);

        // Set FD to non-blocking mode.
        int flags = fcntl(pipeWriteEnd, F_GETFL, 0);
        CPPUNIT_ASSERT(flags != -1);
        CPPUNIT_ASSERT(-1 != fcntl(pipeWriteEnd, F_SETFL, flags | O_NONBLOCK));

        // Check how much we can write before we receive EGAIN.
        size_t totalWritten = 0;
        char buf[1 << 16];
        for (;;) {
            ssize_t written = write(pipeWriteEnd, buf, sizeof(buf));
            if (written < 0) {
                CPPUNIT_ASSERT(errno == EAGAIN);
                break;
            }
            totalWritten += written;
        }

        printf("Wrote %d bytes before blocking\n", (int)totalWritten);

        size_t const sizeLowerBound = 7800;
        size_t const sizeUpperBound = 18000;
        if (totalWritten < sizeLowerBound || totalWritten > sizeUpperBound) {
            // setsockopt(SO_SNDBUF) is not precise. For more details,
            // see the comments in yv_fork_exec().
            CPPUNIT_FAIL(str(format(
                "Managed to write %u bytes before blocking, which is outside"
                " of expected range of [%u, %u]"
                ) % totalWritten % sizeLowerBound % sizeUpperBound).c_str());
        }

        kill(childPid, 9);
    }

    CPPUNIT_TEST_SUITE(PipeBufferSizeTest);

    CPPUNIT_TEST(testPipeBufferSize);

    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(PipeBufferSizeTest);
