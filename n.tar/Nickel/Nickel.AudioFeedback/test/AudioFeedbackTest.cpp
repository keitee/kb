/* 
 * File:   tunertest.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 23 October 2013
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/Factory.h"
#include "../include/AudioFeedback.h"

#include "../src/AudioFeedbackImpl.h"

#include <copper-system-api/MockLocalStorageRepositoryAsync.h>
#include <copper-system-api/MockLocalStorageRepositorySync.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/AtomicBool.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/FutureMockActions.h>
#include <zinc-common/testsupport/MockProperty.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>

#include <boost/assign/list_of.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>

#include <gmock/gmock.h>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include <unistd.h>

using NS_COPPER_SYSTEM::MockLocalStorageRepositoryAsync;
using NS_COPPER_SYSTEM::MockLocalStorageRepositorySync;

using namespace NS_NICKEL_AUDIOFEEDBACK;

using NS_ZINC::completedFuture;
using NS_ZINC::exceptionalFuture;
using NS_ZINC::returnNewCompletedFuture;
using NS_ZINC::AtomicBool;
using NS_ZINC::Dispatcher;
using NS_ZINC::Future;
using NS_ZINC::MockProperty;
using NS_ZINC::Promise;

using boost::make_shared;
using boost::shared_ptr;

using testing::_;
using testing::Expectation;
using testing::Assign;
using testing::Return;

using std::string;
using std::vector;

const Future< string > AUDIO_FEEDBACK_ENABLED = completedFuture(string("1"));
const Future< string > AUDIO_FEEDBACK_DISABLED = completedFuture(string("0"));

const Future< string > VOLUME_NORMAL = completedFuture(string("0"));
const int32_t VOLUME_NORMAL_INT = 0;
const std::string VOLUME_HIGH = "1";
const int32_t VOLUME_HIGH_INT = 1;

// All these fakes samples need to be multiple of 4 bytes
const  vector< uint8_t > FAKE_DELAY_SAMPLE_DATA =
    boost::assign::list_of(' ')(' ')(' ')(' ');

const  vector< uint8_t > FAKE_DIT_SAMPLE_DATA =
    boost::assign::list_of('r')('a')('w')('D')('i')('t')(' ')(' ');

const  vector< uint8_t > FAKE_DAH_SAMPLE_DATA =
    boost::assign::list_of('r')('a')('w')('D')('a')('h')(' ')(' ');

const string DELAY_SAMPLE_NAME  = "silence-25ms.raw";
const string DIT_SAMPLE_NAME    = "dit-200ms-1kHz.raw";
const string DAH_SAMPLE_NAME    = "dah-500ms-1kHz.raw";

const AudioSample DELAY_SAMPLE  = AudioSample(DELAY_SAMPLE_NAME, 0);
const AudioSample DIT_SAMPLE    = AudioSample(DIT_SAMPLE_NAME, 0);
const AudioSample DAH_SAMPLE    = AudioSample(DAH_SAMPLE_NAME, 0);

const audio_sample_map_t FAKE_AUDIO_SAMPLES =
    boost::assign::map_list_of(DELAY_SAMPLE_NAME, FAKE_DELAY_SAMPLE_DATA)
                              (DIT_SAMPLE_NAME, FAKE_DIT_SAMPLE_DATA)
                              (DAH_SAMPLE_NAME, FAKE_DAH_SAMPLE_DATA);

uint32_t msToBytes(uint32_t duration)
{
    return duration * 48 * 2 * 2; // 16 bits stereo samples at 48kHz
}

class ZINC_LOCAL AudioFeedbackTest : public NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
private:
    shared_ptr< MockLocalStorageRepositoryAsync >   mockLocalStorageRepositoryAsync;
    shared_ptr< MockLocalStorageRepositorySync >    mockLocalStorageRepositorySync;
    shared_ptr< Dispatcher >                        dispatcher;
    shared_ptr< AudioFeedbackAsync >                audioFeedback;
    int pipeWriteEnd;
    int pipeReadEnd;
    pid_t fakeDaemonPid;
    int32_t volume;

    void commonSetup(Future< string >       audioFeedbackEnabled,
                     Future< string >       audioFeedbackVolume,
                     const audio_sample_map_t &rawAudioSamples)
    {
        mockLocalStorageRepositoryAsync = make_shared< MockLocalStorageRepositoryAsync >();
        mockLocalStorageRepositorySync  = make_shared< MockLocalStorageRepositorySync >();

        dispatcher = boost::make_shared< NS_ZINC::SingleThreadDispatcher >();

        pipeWriteEnd = -1;
        pipeReadEnd = -1;
        fakeDaemonPid = -1;
        volume = -1;
        Factory factory(dispatcher, boost::bind(&AudioFeedbackTest::createPipeAndSetVolume, this, _1, _2, _3));

        factory.setLocalStorageRepositoryAsync(mockLocalStorageRepositoryAsync);
        factory.setLocalStorageRepositorySync(mockLocalStorageRepositorySync);
        factory.setRawAudioSamples(rawAudioSamples);

        EXPECT_CALL(*mockLocalStorageRepositorySync,
            getItem(0, "", AUDIO_FEEDBACK_ENABLED_KEY))
                .WillOnce( Return( audioFeedbackEnabled.get() ) );
        EXPECT_CALL(*mockLocalStorageRepositorySync,
            getItem(0, "", AUDIO_FEEDBACK_VOLUME_KEY))
                .WillOnce( Return( audioFeedbackVolume.get() ) );

        audioFeedback = factory.createAudioFeedback();
        
        CPPUNIT_ASSERT(pipeWriteEnd != -1);
        CPPUNIT_ASSERT(pipeReadEnd != -1);
        CPPUNIT_ASSERT(fakeDaemonPid != -1);
        CPPUNIT_ASSERT_EQUAL(boost::lexical_cast< int32_t >(audioFeedbackVolume.get()), volume);
    }

    // Return pipe write end
    boost::tuple< pid_t, int > createPipeAndSetVolume(int32_t vol, pid_t previousDaemonPid, int previousPipeWriteEnd)
    {
        CPPUNIT_ASSERT_EQUAL(fakeDaemonPid, previousDaemonPid);
        CPPUNIT_ASSERT_EQUAL(pipeWriteEnd, previousPipeWriteEnd);

        if (previousPipeWriteEnd != -1)
        {
            close(previousPipeWriteEnd);
        }

        int pipefd[2];
        if (0 != pipe(pipefd))
        {
            throw std::runtime_error("pipe() failed");
        }
        pipeWriteEnd = pipefd[1];
        pipeReadEnd = pipefd[0]; // Use the read-end of the pipe in the test
        ++fakeDaemonPid;
        volume = vol;
        return boost::make_tuple(fakeDaemonPid, pipefd[1]);
    }

    // This will block until the expectedSize of data is read unless
    // expectedSize = 0 in which case timeout will be used
    vector< uint8_t > readFromPipe(uint32_t expectedSize,
        boost::posix_time::time_duration timeout = boost::posix_time::milliseconds(0))
    {
        vector< uint8_t > rawData;
        vector< uint8_t > buffer(1024);
        boost::posix_time::time_duration timeSpent = boost::posix_time::milliseconds(0);
        do
        {
            if (getNumberOfBytesAvailableFromPipe() > 0)
            {
                int nbBytesRead = ::read(pipeReadEnd, buffer.data(), buffer.size());
                if (nbBytesRead == -1)
                {
                    throw std::runtime_error(std::string("Unexpected error: ") + std::strerror(errno));
                }
                else if (nbBytesRead > 0)
                {
                    rawData.insert(rawData.end(), buffer.begin(), buffer.begin() + nbBytesRead);
                }
            }
            else
            {
                usleep(25000);
                timeSpent += boost::posix_time::microseconds(25000);
            }
        }
        while ((expectedSize > 0 && rawData.size() < expectedSize) ||
               (expectedSize == 0 && timeout > boost::posix_time::milliseconds(0) && timeSpent < timeout));
        return rawData;
    }

    uint32_t getNumberOfBytesAvailableFromPipe()
    {
        int32_t bytesAvailable = 0;
        if (-1 == ::ioctl(pipeReadEnd, FIONREAD, &bytesAvailable))
        {
            throw std::runtime_error(std::string("Unexpected error with FIONREAD: ")
                                     + std::strerror(errno));
        }
        else
        {
            return static_cast< uint32_t >(bytesAvailable);
        }
    }

    vector< uint8_t > createCustomSizeSample(uint32_t sampleSizeInBytes)
    {
        vector< uint8_t > sampleData;
        sampleData.reserve(sampleSizeInBytes);
        for (uint32_t i = 0; i < sampleSizeInBytes; ++i)
        {
            sampleData.push_back(i);
        }
        return sampleData;
    }

public:

    virtual void tearDown()
    {
        close(pipeWriteEnd);
        VERIFY_AND_CLEAR_MOCK(mockLocalStorageRepositorySync);
        VERIFY_AND_CLEAR_MOCK(mockLocalStorageRepositoryAsync);
        mockLocalStorageRepositorySync.reset();
        mockLocalStorageRepositoryAsync.reset();
    }

    void test_playSamplesWithEmptySamples_whenEnabled_doesNotWriteAnythingToThePipe()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);

        const std::vector< AudioSample > audioSamples;

        audioFeedback->playSamples(audioSamples, true).get();

        CPPUNIT_ASSERT_EQUAL(0u, getNumberOfBytesAvailableFromPipe());
    }

    void test_playSamplesDelay_whenEnabled_writesDelaySampleToThePipe()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DELAY_SAMPLE);

        audioFeedback->playSamples(audioSamples, true).get();

        CPPUNIT_ASSERT_EQUAL(FAKE_DELAY_SAMPLE_DATA, readFromPipe(FAKE_DELAY_SAMPLE_DATA.size()));
    }

    void test_playSamplesDit_whenEnabled_writesDitToThePipeAndDoesNotHaveSideEffects()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DIT_SAMPLE);

        // Also check for unwanted side effects
        int origPipeWriteEnd = pipeWriteEnd;
        int origPipeReadEnd= pipeReadEnd;
        pid_t origFakeDaemonPid = fakeDaemonPid;
        int32_t origVolume = volume;
        audioFeedback->playSamples(audioSamples, true).get();
        CPPUNIT_ASSERT_EQUAL(origPipeWriteEnd, pipeWriteEnd);
        CPPUNIT_ASSERT_EQUAL(origPipeReadEnd, pipeReadEnd);
        CPPUNIT_ASSERT_EQUAL(origFakeDaemonPid, fakeDaemonPid);
        CPPUNIT_ASSERT_EQUAL(origVolume, volume);

        CPPUNIT_ASSERT_EQUAL(FAKE_DIT_SAMPLE_DATA, readFromPipe(FAKE_DIT_SAMPLE_DATA.size()));
    }

    void test_playSamplesDah_whenEnabled_writesDahToThePipe()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DAH_SAMPLE);

        audioFeedback->playSamples(audioSamples, true).get();

        CPPUNIT_ASSERT_EQUAL(FAKE_DAH_SAMPLE_DATA, readFromPipe(FAKE_DAH_SAMPLE_DATA.size()));
    }

    void test_playSamplesDahDit_whenEnabled_writesDahDitToThePipe()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DAH_SAMPLE)(DIT_SAMPLE);

        audioFeedback->playSamples(audioSamples, true).get();

        std::vector< uint8_t > expectedRawData;
        expectedRawData.insert(expectedRawData.end(), FAKE_DAH_SAMPLE_DATA.begin(), FAKE_DAH_SAMPLE_DATA.end());
        expectedRawData.insert(expectedRawData.end(), FAKE_DIT_SAMPLE_DATA.begin(), FAKE_DIT_SAMPLE_DATA.end());
        CPPUNIT_ASSERT_EQUAL(expectedRawData, readFromPipe(expectedRawData.size()));
    }

    void test_playSamplesDit_whenDisabled_doesNotWriteAnythingToThePipe()
    {
        commonSetup(AUDIO_FEEDBACK_DISABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DIT_SAMPLE);

        audioFeedback->playSamples(audioSamples, true).get();

        CPPUNIT_ASSERT_EQUAL(0u, getNumberOfBytesAvailableFromPipe());
    }

    void test_audioFeedbackIsDisabledByDefault_playSamplesDit_doesNotWriteAnythingToThePipe()
    {
        commonSetup(completedFuture(string("")), VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DIT_SAMPLE);

        audioFeedback->playSamples(audioSamples, true).get();

        CPPUNIT_ASSERT_EQUAL(0u, getNumberOfBytesAvailableFromPipe());

    }

    void test_playSamplesDahDit_onlyDelaySampleLoaded_throwsWithoutWritingAnythingToThePipe()
    {
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(DELAY_SAMPLE_NAME, FAKE_DELAY_SAMPLE_DATA);

        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DAH_SAMPLE)(DIT_SAMPLE);

        CPPUNIT_ASSERT_THROW(audioFeedback->playSamples(audioSamples, true).get(), std::invalid_argument);

        CPPUNIT_ASSERT_EQUAL(0u, getNumberOfBytesAvailableFromPipe());
    }

    void test_playProductionSizeSample_writesCorrectDataToThePipe()
    {
        vector< uint8_t > productionSizeSampleData = createCustomSizeSample(96000);

        const std::string productionSizeSampleName("hugeSample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(productionSizeSampleName, productionSizeSampleData);

        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(AudioSample(productionSizeSampleName, 0));

        audioFeedback->playSamples(audioSamples, true).get();

        CPPUNIT_ASSERT_EQUAL(productionSizeSampleData, readFromPipe(productionSizeSampleData.size()));
    }

    void test_setEnabled_works()
    {
        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DIT_SAMPLE);

        commonSetup(AUDIO_FEEDBACK_DISABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);
        CPPUNIT_ASSERT_EQUAL(false, audioFeedback->getEnabled().get());

        EXPECT_CALL(*mockLocalStorageRepositoryAsync,
            setItem(0, "", AUDIO_FEEDBACK_ENABLED_KEY, "1"))
                .WillOnce( Return( completedFuture() ) );
        audioFeedback->setEnabled(true).get();
        CPPUNIT_ASSERT_EQUAL(true, audioFeedback->getEnabled().get());

        audioFeedback->playSamples(audioSamples, true).get();
        CPPUNIT_ASSERT_EQUAL(FAKE_DIT_SAMPLE_DATA, readFromPipe(FAKE_DIT_SAMPLE_DATA.size()));

        EXPECT_CALL(*mockLocalStorageRepositoryAsync,
            setItem(0, "", AUDIO_FEEDBACK_ENABLED_KEY, "0"))
                .WillOnce( Return( completedFuture() ) );
        audioFeedback->setEnabled(false).get();
        CPPUNIT_ASSERT_EQUAL(false, audioFeedback->getEnabled().get());

        audioFeedback->playSamples(audioSamples, true).get();

        CPPUNIT_ASSERT_EQUAL(0u, getNumberOfBytesAvailableFromPipe());
    }

    void test_setRelativeVolume_withInitialVolume_doesNotHaveAnyEffects()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);
        CPPUNIT_ASSERT_EQUAL(VOLUME_NORMAL_INT, audioFeedback->getRelativeVolume().get());

        int origPipeWriteEnd = pipeWriteEnd;
        int origPipeReadEnd= pipeReadEnd;
        pid_t origFakeDaemonPid = fakeDaemonPid;
        int32_t origVolume = volume;
        audioFeedback->setRelativeVolume(VOLUME_NORMAL_INT).get();
        CPPUNIT_ASSERT_EQUAL(VOLUME_NORMAL_INT, audioFeedback->getRelativeVolume().get());
        CPPUNIT_ASSERT_EQUAL(origPipeWriteEnd, pipeWriteEnd);
        CPPUNIT_ASSERT_EQUAL(origPipeReadEnd, pipeReadEnd);
        CPPUNIT_ASSERT_EQUAL(origFakeDaemonPid, fakeDaemonPid);
        CPPUNIT_ASSERT_EQUAL(origVolume, volume);
    }

    void test_setRelativeVolume_withNewVolume_restartsDaemon()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);
        CPPUNIT_ASSERT_EQUAL(VOLUME_NORMAL_INT, audioFeedback->getRelativeVolume().get());

        pid_t origFakeDaemonPid = fakeDaemonPid;

        EXPECT_CALL(*mockLocalStorageRepositoryAsync,
            setItem(0, "", AUDIO_FEEDBACK_VOLUME_KEY, VOLUME_HIGH))
                .WillOnce( Return( completedFuture() ) );
        audioFeedback->setRelativeVolume(VOLUME_HIGH_INT).get();
        CPPUNIT_ASSERT_EQUAL(VOLUME_HIGH_INT, audioFeedback->getRelativeVolume().get());

        // pid is always incremented in this test
        CPPUNIT_ASSERT(fakeDaemonPid > origFakeDaemonPid);
    }

    void test_playSamplesDah_changeVolume_playSamplesDit_writesDahDitToThePipe()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);
        CPPUNIT_ASSERT_EQUAL(VOLUME_NORMAL_INT, audioFeedback->getRelativeVolume().get());

        const std::vector< AudioSample > audioSamples1 =
            boost::assign::list_of(DAH_SAMPLE);
        audioFeedback->playSamples(audioSamples1, true).get();
        CPPUNIT_ASSERT_EQUAL(FAKE_DAH_SAMPLE_DATA, readFromPipe(FAKE_DAH_SAMPLE_DATA.size()));

        EXPECT_CALL(*mockLocalStorageRepositoryAsync,
            setItem(0, "", AUDIO_FEEDBACK_VOLUME_KEY, VOLUME_HIGH))
                .WillOnce( Return( completedFuture() ) );
        audioFeedback->setRelativeVolume(VOLUME_HIGH_INT).get();
        CPPUNIT_ASSERT_EQUAL(VOLUME_HIGH_INT, audioFeedback->getRelativeVolume().get());

        const std::vector< AudioSample > audioSamples2 =
            boost::assign::list_of(DIT_SAMPLE);
        audioFeedback->playSamples(audioSamples2, true).get();
        CPPUNIT_ASSERT_EQUAL(FAKE_DIT_SAMPLE_DATA, readFromPipe(FAKE_DIT_SAMPLE_DATA.size()));
    }

    void test_playSamplesDit_afterRelativeVolumeChanged_writesDitToThePipe()
    {
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, FAKE_AUDIO_SAMPLES);
        CPPUNIT_ASSERT_EQUAL(VOLUME_NORMAL_INT, audioFeedback->getRelativeVolume().get());

        EXPECT_CALL(*mockLocalStorageRepositoryAsync,
            setItem(0, "", AUDIO_FEEDBACK_VOLUME_KEY, VOLUME_HIGH))
                .WillOnce( Return( completedFuture() ) );
        audioFeedback->setRelativeVolume(VOLUME_HIGH_INT).get();
        CPPUNIT_ASSERT_EQUAL(VOLUME_HIGH_INT, audioFeedback->getRelativeVolume().get());

        const std::vector< AudioSample > audioSamples =
            boost::assign::list_of(DIT_SAMPLE);

        audioFeedback->playSamples(audioSamples, true).get();
        CPPUNIT_ASSERT_EQUAL(FAKE_DIT_SAMPLE_DATA, readFromPipe(FAKE_DIT_SAMPLE_DATA.size()));
    }

    void test_lastCallToPlaySamples_whenEnabled_isAlwaysWrittenToThePipe()
    {
        vector< uint8_t > hugeSampleData = createCustomSizeSample(96000);

        const std::string hugeSampleName("hugeSample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(hugeSampleName, hugeSampleData)
                                      (DIT_SAMPLE_NAME, FAKE_DIT_SAMPLE_DATA);

        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > hugeSamples =
            boost::assign::list_of(AudioSample(hugeSampleName, 0))(AudioSample(hugeSampleName, 0));
        // This would take a while (~1.8MB of data to transfer) if playSamples did not clear the queue for each call
        for (uint32_t i = 0; i < 10; ++i)
        {
            audioFeedback->playSamples(hugeSamples, true).get();
        }

        const std::vector< AudioSample > lastSamples =
            boost::assign::list_of(DIT_SAMPLE);
        audioFeedback->playSamples(lastSamples, true).get();

        // The following results in an ugly 500ms sleep:
        vector< uint8_t > dataRead = readFromPipe(0, boost::posix_time::milliseconds(500));
        // The only guarantee that we have is that the last DIT_SAMPLE is not truncated
        CPPUNIT_ASSERT(dataRead.size() >= FAKE_DIT_SAMPLE_DATA.size());
        vector< uint8_t > endOfDataRead(dataRead.begin() + dataRead.size() - FAKE_DIT_SAMPLE_DATA.size(), dataRead.end());
        CPPUNIT_ASSERT_EQUAL(FAKE_DIT_SAMPLE_DATA, endOfDataRead);
    }

    void test_callsToPlaySamples_canBeQueued()
    {
        vector< uint8_t > hugeSampleData = createCustomSizeSample(96000);
        const std::string hugeSampleName("hugeSample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(hugeSampleName, hugeSampleData)
                                      (DIT_SAMPLE_NAME, FAKE_DIT_SAMPLE_DATA);
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > hugeSamples =
            boost::assign::list_of(AudioSample(hugeSampleName, 0))(AudioSample(hugeSampleName, 0));
        const std::vector< AudioSample > otherSample =
            boost::assign::list_of(DIT_SAMPLE);
        audioFeedback->playSamples(hugeSamples, false).get();
        audioFeedback->playSamples(otherSample, false).get();

        std::vector< uint8_t > expectedRawData;
        expectedRawData.insert(expectedRawData.end(), hugeSampleData.begin(), hugeSampleData.end());
        expectedRawData.insert(expectedRawData.end(), hugeSampleData.begin(), hugeSampleData.end());
        expectedRawData.insert(expectedRawData.end(), FAKE_DIT_SAMPLE_DATA.begin(), FAKE_DIT_SAMPLE_DATA.end());
        CPPUNIT_ASSERT_EQUAL(expectedRawData, readFromPipe(expectedRawData.size()));
    }

    void test_playSamples_withDurationLessThanSampleLength_playsFullSampleOnce()
    {
        vector< uint8_t > sampleData = createCustomSizeSample( msToBytes(5) );
        const std::string sampleName("5ms-sample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(sampleName, sampleData);
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > samplesRequested =
            boost::assign::list_of(AudioSample(sampleName, 1)); // 1ms requested
        audioFeedback->playSamples(samplesRequested, false).get();

        // expect 5ms worth of data even if 1ms if requested
        CPPUNIT_ASSERT_EQUAL(sampleData, readFromPipe(sampleData.size()));
    }

    void test_playSamples_withDurationEqualToSampleLength_playsFullSampleOnce()
    {
        vector< uint8_t > sampleData = createCustomSizeSample( msToBytes(5) );
        const std::string sampleName("5ms-sample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(sampleName, sampleData);
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > samplesRequested =
            boost::assign::list_of(AudioSample(sampleName, 5)); // 5ms requested
        audioFeedback->playSamples(samplesRequested, false).get();

        CPPUNIT_ASSERT_EQUAL(sampleData, readFromPipe(sampleData.size()));
    }

    void test_playSamples_withDurationGreaterThanSampleLengthButLessThanDoubleTheSampleLength_playsFullSampleOnce()
    {
        vector< uint8_t > sampleData = createCustomSizeSample( msToBytes(5) );
        const std::string sampleName("5ms-sample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(sampleName, sampleData);
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > samplesRequested =
            boost::assign::list_of(AudioSample(sampleName, 9)); // 9ms requested
        audioFeedback->playSamples(samplesRequested, false).get();

        // expect the sample to be played only once
        CPPUNIT_ASSERT_EQUAL(sampleData, readFromPipe(sampleData.size()));
    }

    void test_playSamples_withDurationEqualToFourTimesTheSampleLength_playsFullSampleFourTimes()
    {
        vector< uint8_t > sampleData = createCustomSizeSample( msToBytes(5) );
        const std::string sampleName("5ms-sample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(sampleName, sampleData);
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > samplesRequested =
            boost::assign::list_of(AudioSample(sampleName, 20)); // 20ms requested
        audioFeedback->playSamples(samplesRequested, false).get();

        std::vector< uint8_t > expectedRawData;
        for (uint32_t i = 0; i < 4; ++i)
        {
            expectedRawData.insert(expectedRawData.end(), sampleData.begin(), sampleData.end());
        }
        // expect the sample to be played four times
        CPPUNIT_ASSERT_EQUAL(expectedRawData, readFromPipe(expectedRawData.size()));
    }

    void test_playSamples_withDurationSlightlyMoreThanFourTimesTheSampleLength_playsFullSampleFourTimes()
    {
        vector< uint8_t > sampleData = createCustomSizeSample( msToBytes(5) );
        const std::string sampleName("5ms-sample.raw");
        const audio_sample_map_t sampleMap =
            boost::assign::map_list_of(sampleName, sampleData);
        commonSetup(AUDIO_FEEDBACK_ENABLED, VOLUME_NORMAL, sampleMap);

        const std::vector< AudioSample > samplesRequested =
            boost::assign::list_of(AudioSample(sampleName, 21)); // 21ms requested
        audioFeedback->playSamples(samplesRequested, false).get();

        std::vector< uint8_t > expectedRawData;
        for (uint32_t i = 0; i < 4; ++i)
        {
            expectedRawData.insert(expectedRawData.end(), sampleData.begin(), sampleData.end());
        }
        // expect the sample to be played only four times
        CPPUNIT_ASSERT_EQUAL(expectedRawData, readFromPipe(expectedRawData.size()));
    }

    CPPUNIT_TEST_SUITE(AudioFeedbackTest);

    CPPUNIT_TEST(test_playSamplesWithEmptySamples_whenEnabled_doesNotWriteAnythingToThePipe);
    CPPUNIT_TEST(test_playSamplesDelay_whenEnabled_writesDelaySampleToThePipe);
    CPPUNIT_TEST(test_playSamplesDit_whenEnabled_writesDitToThePipeAndDoesNotHaveSideEffects);
    CPPUNIT_TEST(test_playSamplesDah_whenEnabled_writesDahToThePipe);
    CPPUNIT_TEST(test_playSamplesDahDit_whenEnabled_writesDahDitToThePipe);
    CPPUNIT_TEST(test_playSamplesDit_whenDisabled_doesNotWriteAnythingToThePipe);
    CPPUNIT_TEST(test_audioFeedbackIsDisabledByDefault_playSamplesDit_doesNotWriteAnythingToThePipe);
    CPPUNIT_TEST(test_playSamplesDahDit_onlyDelaySampleLoaded_throwsWithoutWritingAnythingToThePipe);
    CPPUNIT_TEST(test_playProductionSizeSample_writesCorrectDataToThePipe);
    CPPUNIT_TEST(test_setEnabled_works);
    CPPUNIT_TEST(test_setRelativeVolume_withInitialVolume_doesNotHaveAnyEffects);
    CPPUNIT_TEST(test_setRelativeVolume_withNewVolume_restartsDaemon);
    CPPUNIT_TEST(test_playSamplesDah_changeVolume_playSamplesDit_writesDahDitToThePipe);
    CPPUNIT_TEST(test_playSamplesDit_afterRelativeVolumeChanged_writesDitToThePipe);
    CPPUNIT_TEST(test_lastCallToPlaySamples_whenEnabled_isAlwaysWrittenToThePipe);
    CPPUNIT_TEST(test_callsToPlaySamples_canBeQueued);
    CPPUNIT_TEST(test_playSamples_withDurationLessThanSampleLength_playsFullSampleOnce);
    CPPUNIT_TEST(test_playSamples_withDurationEqualToSampleLength_playsFullSampleOnce);
    CPPUNIT_TEST(test_playSamples_withDurationGreaterThanSampleLengthButLessThanDoubleTheSampleLength_playsFullSampleOnce);
    CPPUNIT_TEST(test_playSamples_withDurationEqualToFourTimesTheSampleLength_playsFullSampleFourTimes);
    CPPUNIT_TEST(test_playSamples_withDurationSlightlyMoreThanFourTimesTheSampleLength_playsFullSampleFourTimes);

    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(AudioFeedbackTest);
