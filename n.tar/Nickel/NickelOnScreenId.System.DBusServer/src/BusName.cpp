/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2012 YouView TV Ltd
 */

#include "../include/BusName.h"

namespace Zinc {
namespace OnScreenId {

char const* const BusName::ONSCREENID = "Zinc.OnScreenId";

} // namespace OnScreenId
} // namespace Zinc
