/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "RendererAsyncToDBus.h"

#include "../include/BusName.h"
#include "../include/ObjectPath.h"

#include <nickelonscreenid-system-api/Factory.h>

#include <titanium-utils/ContextCrypto.h>

#include <zinc-binding-runtime/dbus/DBusService.h>
#include <zinc-binding-runtime/dbus/MainLoop.h>
#include <zinc-binding-runtime/dbus/SignalReceiver.h>

#include <zinc-common/async/InlineFutureDispatcher.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/FilePluginConfig.h>
#include <zinc-common/PluginFactory.h>

#include <boost/bind.hpp>
#include <boost/noncopyable.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <stdexcept>

namespace {

using namespace ::Zinc::OnScreenId;

class OnScreenIdDaemon : boost::noncopyable
{
public:
    OnScreenIdDaemon(NS_ZINC_DBUS_BINDING::MainLoop& mainloop,
                     const boost::shared_ptr<RendererAsync>& renderer);

    void start();
    void stop();

private:

    NS_ZINC_DBUS_BINDING::SignalReceiver sr;
    NS_ZINC_DBUS_BINDING::DBusService dbus;

    const boost::shared_ptr<RendererAsync> renderer;
};

OnScreenIdDaemon::OnScreenIdDaemon(
    NS_ZINC_DBUS_BINDING::MainLoop& mainloop,
    const boost::shared_ptr<RendererAsync>& renderer) :
    sr(mainloop,
       NS_ZINC_DBUS_BINDING::createExitSignalHandler(
           boost::bind(&OnScreenIdDaemon::stop, this))),
    dbus(mainloop),
    renderer(renderer)
{
}

void OnScreenIdDaemon::start()
{
    sr.start();
    dbus.start();

    dbus.expose(ObjectPath::ONSCREENID_RENDERER, renderer);
    dbus.request_name(BusName::ONSCREENID);
}

void OnScreenIdDaemon::stop()
{
    dbus.stop();
    sr.stop();
}

} // namespace

int main()
{
    std::clog << "Launching OnScreenId daemon..." << std::endl;

    int result = EXIT_SUCCESS;

    try
    {
        // safe use of OpenSSL from multiple threads
        NS_TITANIUM::initOnce_CryptoMultiThreading();

        const NS_ZINC::FilePluginConfig pluginConfig(
            NS_ZINC::PackageDataFinder().find(
                "nickelonscreenid-system-factory.plugin-config"));
        const Factory& f =
            NS_ZINC::PluginFactory::getInstance<Factory>(pluginConfig);

        NS_ZINC_DBUS_BINDING::MainLoop mainloop(BusName::ONSCREENID);

        OnScreenIdDaemon daemon(
            mainloop,
            f.createRenderer(
                boost::make_shared<NS_ZINC::InlineFutureDispatcher>()));

        mainloop.post(boost::bind(&OnScreenIdDaemon::start, &daemon));

        result = mainloop.run();
    }
    catch(const std::exception& e)
    {
        std::cerr << "ERROR: " << e.what() << '\n';
        result = EXIT_FAILURE;
    }

    std::clog << "OnScreenId daemon shutting down..." << std::endl;
    return result;
}
