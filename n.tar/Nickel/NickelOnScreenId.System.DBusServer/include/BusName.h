/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_DBUSSERVER_BUSNAME_H_
#define NICKEL_ONSCREENID_SYSTEM_DBUSSERVER_BUSNAME_H_

#include <zinc-common/macros.h>

namespace Zinc {
namespace OnScreenId {

class ZINC_EXPORT BusName {
public:
    static char const* const ONSCREENID;

private:
    BusName();
};

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_DBUSSERVER_BUSNAME_H_
