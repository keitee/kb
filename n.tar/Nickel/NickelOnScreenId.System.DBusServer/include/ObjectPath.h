/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_DBUSSERVER_OBJECTPATH_H_
#define NICKEL_ONSCREENID_SYSTEM_DBUSSERVER_OBJECTPATH_H_

namespace Zinc {
namespace OnScreenId {

namespace ObjectPath {

char const* const ONSCREENID_RENDERER = "/Zinc/OnScreenId/Renderer";

} // namespace ObjectPath

} // namespace OnScreenId
} // namespace Zinc

#endif /* NICKEL_ONSCREENID_SYSTEM_DBUSSERVER_OBJECTPATH_H_ */
