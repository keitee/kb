/*
 * @file nickel-client-exceptions.cpp
 *
 * @date May 05, 2011
 * @author mark.nicoll@youview.com
 *
 * @brief exceptions.
 *
 * Copyright (C) 2011 YouView TV
 */

#include "../include/InvalidLanguage.h"
#include "../include/macros.h"

#include <zinc-common/error/ExtendedTypeidRegistrar.h>

NS_NICKEL_CLIENT_OPEN

InvalidLanguage::InvalidLanguage() :
	std::runtime_error("Invalid language.") 
{
}

InvalidLanguage::~InvalidLanguage() throw() 
{
}

ZINC_REGISTER_EXCEPTION(InvalidLanguage, std::runtime_error);

NS_NICKEL_CLIENT_CLOSE
