/*
 * destructors.cpp
 *
 *  Created on: Nov 17, 2011
 *      Author: jsadler
 */

#include "../include/nickel-client-api.h"

NS_NICKEL_CLIENT_OPEN

ABRStatus::~ABRStatus() {}

ABRStreamSet::~ABRStreamSet() {}

AnalogueDisplay::~AnalogueDisplay() {}

AudioOutput::~AudioOutput() {}

BufferStatus::~BufferStatus() {}

ClientFactory::~ClientFactory() {}

ControlCapabilities::~ControlCapabilities() {}

GraphicsResolution::GraphicsResolution():
    _width(0), _height(0)
{
}

HDMIDisplay::~HDMIDisplay() {}

Locator::~Locator() {}

MediaRouter::~MediaRouter() {}

MediaRouterEventListener::~MediaRouterEventListener() {}

MediaRouterFactory::~MediaRouterFactory() {}

MediaSettings::~MediaSettings() {}

MediaSettingsListener::~MediaSettingsListener() {}

OutputManager::~OutputManager() {}

OutputManagerEventListener::~OutputManagerEventListener() {}

Position::~Position() {}

ServiceListBuilder::~ServiceListBuilder() {}

ServiceListBuilderEventListener::~ServiceListBuilderEventListener() {}

Track::~Track() {}

VideoConversions::VideoConversions():
    _standardToWide(Conversion_4_3_To_16_9::automatic), _wideToStandard(Conversion_16_9_To_4_3::letterbox_14_9)
{
}

VideoWindowDescriptor::~VideoWindowDescriptor() {}

NS_NICKEL_CLIENT_CLOSE

NS_NICKEL_AUDIO_CLIENT_OPEN

AudioFeedback::~AudioFeedback() {}

NS_NICKEL_AUDIO_CLIENT_CLOSE
