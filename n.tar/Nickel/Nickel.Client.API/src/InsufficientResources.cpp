/*
 * @file nickel-client-exceptions.cpp
 *
 * @date May 05, 2011
 * @author mark.nicoll@youview.com
 *
 * @brief exceptions.
 *
 * Copyright (C) 2011 YouView TV
 */

#include "../include/InsufficientResources.h"
#include "../include/macros.h"

#include <zinc-common/error/ExtendedTypeidRegistrar.h>

NS_NICKEL_CLIENT_OPEN

InsufficientResources::InsufficientResources() :
	std::runtime_error("Insufficient resources.") 
{
}

InsufficientResources::~InsufficientResources() throw() 
{
}

ZINC_REGISTER_EXCEPTION(InsufficientResources, std::runtime_error);

NS_NICKEL_CLIENT_CLOSE
