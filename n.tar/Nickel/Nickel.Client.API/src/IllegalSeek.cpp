/*
 * @file nickel-client-exceptions.cpp
 *
 * @date May 05, 2011
 * @author mark.nicoll@youview.com
 *
 * @brief exceptions.
 *
 * Copyright (C) 2011 YouView TV
 */

#include "../include/IllegalSeek.h"
#include "../include/macros.h"

#include <zinc-common/error/ExtendedTypeidRegistrar.h>

NS_NICKEL_CLIENT_OPEN

IllegalSeek::IllegalSeek() :
	std::runtime_error("Illegal seek.") 
{
}

IllegalSeek::~IllegalSeek() throw() 
{
}

ZINC_REGISTER_EXCEPTION(IllegalSeek, std::runtime_error);

NS_NICKEL_CLIENT_CLOSE
