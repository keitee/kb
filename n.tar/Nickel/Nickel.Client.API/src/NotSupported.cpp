/*
 * @file NotSupported.cpp
 *
 * @date May 05, 2011
 * @author zbigniew.mandziejewicz@youview.com
 *
 * Copyright (C) 2011 YouView TV
 */

#include "../include/NotSupported.h"
#include "../include/macros.h"

#include <zinc-common/error/ExtendedTypeidRegistrar.h>

NS_NICKEL_CLIENT_OPEN

NotSupported::NotSupported() :
	std::runtime_error("Not supported.") 
{
}

NotSupported::~NotSupported() throw() 
{
}

ZINC_REGISTER_EXCEPTION(NotSupported, std::runtime_error);

NS_NICKEL_CLIENT_CLOSE
