/*
 * @file nickel-client-exceptions.cpp
 *
 * @date May 05, 2011
 * @author mark.nicoll@youview.com
 *
 * @brief exceptions.
 *
 * Copyright (C) 2011 YouView TV
 */

#include "../include/NotApplicable.h"
#include "../include/macros.h"

#include <zinc-common/error/ExtendedTypeidRegistrar.h>

NS_NICKEL_CLIENT_OPEN

NotApplicable::NotApplicable() :
	std::runtime_error("Not applicable.") 
{
}

NotApplicable::~NotApplicable() throw() 
{
}

ZINC_REGISTER_EXCEPTION(NotApplicable, std::runtime_error);

NS_NICKEL_CLIENT_CLOSE
