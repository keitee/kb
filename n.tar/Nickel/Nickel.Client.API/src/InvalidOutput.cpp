/*
 * @file InvalidOutput.cpp
 *
 * @date May 05, 2011
 * @author zbigniew.mandziejewicz@youview.com
 *
 * Copyright (C) 2011 YouView TV
 */

#include "../include/InvalidOutput.h"
#include "../include/macros.h"

#include <zinc-common/error/ExtendedTypeidRegistrar.h>

NS_NICKEL_CLIENT_OPEN

InvalidOutput::InvalidOutput() :
	std::runtime_error("Invalid AudioOutput.") 
{
}

InvalidOutput::~InvalidOutput() throw() 
{
}

ZINC_REGISTER_EXCEPTION(InvalidOutput, std::runtime_error);

NS_NICKEL_CLIENT_CLOSE
