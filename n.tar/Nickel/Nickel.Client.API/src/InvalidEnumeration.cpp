/*
 * @file nickel-client-exceptions.cpp
 *
 * @date May 05, 2011
 * @author mark.nicoll@youview.com
 *
 * @brief exceptions.
 *
 * Copyright (C) 2011 YouView TV
 */

#include "../include/InvalidEnumeration.h"
#include "../include/macros.h"

#include <zinc-common/error/ExtendedTypeidRegistrar.h>

NS_NICKEL_CLIENT_OPEN

InvalidEnumeration::InvalidEnumeration() :
	std::runtime_error("Invalid enumeration.") 
{
}

InvalidEnumeration::~InvalidEnumeration() throw() 
{
}

ZINC_REGISTER_EXCEPTION(InvalidEnumeration, std::runtime_error);

NS_NICKEL_CLIENT_CLOSE
