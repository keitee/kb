/*
 * SetSourceReason.h
 *
 *  Created on: Nov 30, 2011
 *      Author: jsadler
 */

#ifndef NICKEL_CLIENT_API_SETSOURCEREASON_H_
#define NICKEL_CLIENT_API_SETSOURCEREASON_H_

#include "macros.h"

#include <zinc-common/Enum.h>

NS_NICKEL_CLIENT_OPEN


struct SetSourceReason : NS_ZINC::Enum
{
	/**
	 * The defined set of reasons for a source-change.
	 *
	 * <p>The only valid reason for a source-change in on-demand is <code>SetSourceReason.unspecified</code>.
	 * All other values relate to broadcast streams and should not be used. </p>
	 *
	 * @see nickel::client::MediaRouter#setSource()
	 * @see nickel::client::MediaRouterEventListener#SourceEvent()
	 *
	 */
	enum Enum {

		/**
		 * Unspecified source-change reason.
		 */
		unspecified = 0,
		/**
		 * @private
		 *
		 * The source-change is as a result of a request by an MHEG Application to tune to a new service in the normal mode.
		 */
		mhegstandard = 1,
		/**
		 * @private
		 *
		 * The source change is as a result of a request by an MHEG Application to tune to a new service in the quiet mode.
		 */
		mhegquiet = 2,
		/**
		 * @private
		 *
		 * The source change is as a result of a request by an MHEG Application to perform a non-destructive
		 * tune to a new service in the normal mode.
		 */
		mhegnondestructive = 3,
		/**
		 * @private
		 *
		 * The source change is as a result of a request by an MHEG Application to perform a non-destructive
		 * tune to a new service in the quiet mode.
		 */
		mhegnondestructivequiet = 4,
	};
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_API_SETSOURCEREASON_H_ */
