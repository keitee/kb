/*
 * MediaRouterEventListener.h
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_FAKE_MEDIA_ROUTER_EVENTLISTENER_H
#define NICKEL_CLIENT_FAKE_MEDIA_ROUTER_EVENTLISTENER_H

#include "macros.h"
#include "Position.h"
#include "SetSourceReason.h"

#include <zinc-common/EventListener.h>
#include <zinc-common/Enum.h>
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include <stdint.h>

NS_NICKEL_CLIENT_OPEN


struct BufferStatusEventValue : NS_ZINC::Enum
{

	/**
	 * Defines a set of possible buffer-status values returned in a MediaRouter <code>BufferStatusEvent</code>.
	 *
	 * @see nickel::client::MediaRouterEventListener#BufferStatusEvent()
	 *
	 * @if AS3 @includeExample BufferStatusEventValueExample.as@endif
	 *
	 */
	enum Enum
	{
		/**
		 * Emitted when the MediaRouter starts buffering the source.
		 *
		 */
		buffering_started = 0,

		/**
		 * @private
		 *
		 * Reserved value.
		 *
		 */
		reserved_1 = 1,

		/**
		 * Emitted when the MediaRouter has completed buffering the source.
		 *
		 * <p>Buffering is complete when the entire play-region of the source, or the play-position
		 * and the end-time of the source is in the buffer. </p>
		 *
		 */
		buffering_complete = 2,

		/**
		 * @private
		 *
		 * Reserved value.
		 *
		 */
		reserved_3 = 3,

		/**
		 * @private
		 *
		 * Emitted when a MediaRouter has completed acquisition of an ABR segment.
		 *
		 */
		abr_segment_complete = 4,
	};
};


struct DrmEventValue : NS_ZINC::Enum
{

	/**
	 * The defined set of DRM Event values.
	 *
	 * @see nickel::client::MediaRouterEventListener#DrmEvent()
	 */
	enum Enum
	{
		/**
		 * The content that the MediaRouter is trying to play requires a licence which cannot be found in the licence store. Example: protected content where the device has no licence for the relevant DRM content ID. For MS3, this can arise if no key was provided for the DRM content ID in the SAS.
		 */
		licence_required = 0,

		/**
		 * The content could not be played because the DRM system is not in a fully functional state. A software upgrade may resolve the problem. This should not arise in a fully functional YouView device.
		 */
		system_error = 1,

		/**
		 * The MediaRouter could not process a content protection related element of the MediaLocator. Example: MS3-protected content where the S-URL is not a valid URL. 
		 */
		bad_request = 2,

		/**
		 * The MediaRouter could not contact a content protection server that is needed to play back the requested media. Examples: MS3-protected content where the MS3 server cannot be contacted.
		 */
		server_unreachable = 3,

		/**
		 * A content protection server denied information required by the MediaRouter to play back the requested media. Example: MS3-protected content where the MS3 server denied the request for an SAS by returning something other than an HTTP 200 response.
		 */
		server_denied = 4,

		/**
		 * A content protection server responded to a request from the MediaRouter in an unexpected manner. Examples: MS3-protected content where the C-URIT requires an authenticator but none was provided in the SAS; MS3-protected content where the MS3 server did not return a valid SAS.
		 */
		bad_server_response = 5,

		/**
		 * The requested media is encrypted but the MediaRouter was unable to determine the licence or decryption keys required to decrypt it. Example: Missing or invalid DRM headers, descriptors, tables etc. in content.
		 */
		bad_content_format = 6,

		/**
		 * A licence for the content exists but the device cannot meet all of its requirements. Examples: unsupported output control requirements (such as use of for-future-use values).
		 */
		unmet_licence_requirement = 7,

		/**
		 * Marlin Broadband only. For future use.
		 */
		licence_format_error = 8,

		/**
		 * Marlin Broadband only. For future use.
		 * present.
		 *
		 */
		missing_credentials = 9,

		/**
		 * Marlin Broadband only. For future use.
		 *
		 */
		expired = 10,

		/**
		 * Marlin Broadband only. For future use.
		 *
		 */
		play_count_exceeded = 11,

		/**
		 * Marlin Broadband only. For future use.
		 *
		 */
		subscription_expired = 12,

		/**
		 * The requested content cannot be played due to a content protection problem other than those described by specific event codes.
		 *
		 */
		other_drm_event = 99,
	};
};


struct SourceEventValue : NS_ZINC::Enum
{
	/**
	 * The defined set of source-event values.
	 *
	 * @see nickel::client::MediaRouterEventListener#SourceEvent()
	 */
	enum Enum
	{
		/**
		 * @private
		 *
		 * Signals that a change in the status of the source has been initiated. This will be used to indicate the start
		 * of a service selection, whether initiated by a call to <code>MediaRouter.setSource()</code> or by the MediaRouter
		 * changing service following entry into the restricted mode.
		 */
		change_initiated = 0,
		/**
		 * @private
		 *
		 * Signals the completion of a service change. A <code>CHANGE_COMPLETE</code> SourceEvent shall
		 * only be emitted following an associated <code>CHANGE_INITIATED</code> SourceEvent.
		 */
		change_complete = 1,
		/**
		 * @private
		 *
		 * Signals that the restricted mode has been entered or exited, or that the set of
		 * services available for selection in restricted mode has changed.
		 */
		source_information_change = 2,
		/**
		 * Source configuration is complete following a call of <code>MediaRouter.setSource()</code>.
		 *
		 * @see nickel::client::MediaRouter#setSource()
		 * @see nickel::client::MediaRouterEventListener#SourceEvent()
		 */
		source_config_complete = 3,
		/**
		 * A track has been added or removed.
		 *
		 * @see nickel::client::MediaRouter#addSubtitleTrack()
		 * @see nickel::client::MediaRouterEventListener#SourceEvent()
		 */
		tracks_changed = 4,
	};
};


struct StatusEventValue : NS_ZINC::Enum
{

	/**
	 * The defined set of status-event values.
	 *
	 * @see nickel::client::MediaRouterEventListener#StatusEvent()
	 */
	enum Enum
	{
		/**
		 * Playback has started or restarted. This means the first frame has been output from the decoder and is displayed on-screen.
		 *
		 * <p>Playback may have been started or restarted following :</p>
		 * <ul>
		 * <li>A call of <code>MediaRouter.start()</code> </li>
		 * <li>A call of <code>MediaRouter.seekPosition()</code> </li>
		 * <li>Recovery from a buffer underflow </li>
		 * </ul>
		 */
		started = 0,
		/**
		 * Playback is complete.
		 *
		 * <p>Raised when presentation of a MediaRouter’s media has stopped due to the end of the play region being reached.
		 * Once the COMPLETE event has been raised, it shall be possible for the same MediaRouter or another MediaRouter
		 * attached to the same sink to immediately start presentation. </p>
		 */
		complete = 1,
		/**
		 * Raised when a MediaRouter has entered the Waiting state following a call to  <code>MediaRouter.startDeferred()</code>.
		 */
		waiting = 2,
		/**
		 * Raised when a MediaRouter has stopped playback following a call to <code>MediaRouter.stop()</code>. Once the STOPPED event
		 * has been raised, it shall be possible for the same MediaRouter or another MediaRouter to immediately start presentation.
		 */
		stopped = 3,
		/**
		 * Raised when a MediaRouter pauses presentation due to a lack of buffered data ahead of play-position. Once the underflow has 
		 * ended, a <code>StatusEventValue.started</code> event is sent and playout continues.
		 */
		underflow = 4,
		/**
		 * Raised when a MediaRouter starts a seek operation following a call to <code>MediaRouter.seekPosition()</code>.
		 */
		seek_started = 5,
	};
};


struct ErrorEventValue : NS_ZINC::Enum
{

	/**
	 * The defined set of error conditions.
	 *
	 * @see nickel::client::MediaRouterEventListener#ErrorEvent()
	 *
	 */
	enum Enum
	{
		/**
		 * An undefined error.
		 */
		other_error_event = 0,

		/**
		 * The URI is invalid - possible causes include : an unsupported protocol, or a malformed URI.
		 *
		 * <p>Note that errors in the source URI will be indicated by an <code>InvalidLocator</code> error
		 * when <code>MediaRouter.setSource()</code>is called.</p>
		 *
		 * @see nickel::client::InvalidLocator
		 * @see nickel::client::MediRouter#setSource()
		 */
		locator = 1,

		/**
		 * The tag is invalid - possible causes include : no track in the track-list of the source has that
		 * tag, no track in the track-list of the external source has that tag.
		 */
		tag = 2,

		/**
		 * The language is invalid - possible causes include : no track in the track-list of the source has
		 * that language.
		 */
		language = 3,

		/**
		 * @private
		 *
		 * An error due to a failure to select a linear channel.
		 */
		linear_selection = 4,

		/**
		 * A network connection error - possible causes include : a problem with an established connection,
		 * or a problem while attempting to establish a new connection.
		 *
		 * <p>Examples include : </p>
		 * <ul>
		 * <li>Network cable unplugged.</li>
		 * <li>Wi-Fi is not connected.</li>
		 * <li>DNS error.</li>
		 * <li>No route to host.</li>
		 * <li>Connection refused.</li>
		 * <li>Timeout.</li>
		 * <li>Failed multicast join.</li>
		 * </ul>
		 */
		network = 5,

		/**
		 * A server error response.
		 *
		 * <p>Examples include :</p>
		 * <ul>
		 * <li>HTTP 4xx, 501, 502 or 505 error.</li>
		 * <li>HTTP 500, 503 or 504 error which has not been rectified before the specified timeout period
		 * (see [[IP Content Delivery specification.]] section 8).</li>
		 * </ul>
		 */
		server = 6,

		/**
		 * A data consumption error.
		 *
		 * <p>Examples include : </p>
		 * <ul>
		 * <li>Failed to parse adaptive manifest.</li>
		 * <li>Failed to parse index file.</li>
		 * <li>Failed to parse MP4 content.</li>
		 * <li>Failed to synchronise to MPEG-2 TS.</li>
		 * </ul>
		 */
		data = 7,
	};
};


struct ErrorEventContext : NS_ZINC::Enum
{
	/**
	 * The defined set of error event contexts.
	 *
	 * <p>The MediaRouter will emit an <code>ErrorEvent</code> through <code>MediaRouter.ErrorEvent()</code>
	 * when an error occurs. This event will include one of the following <code>ErrorEventContext</code> values.</p>
	 *
	 * @see nickel::client::MediaRouterEventListener#ErrorEvent()
	 */
	enum Enum
	{
		/**
		 * An undefined error.
		 */
		other_error_context = 0,

		/**
		 * A source error.
		 *
		 * <p>This error relates to either :</p>
		 * <ul>
		 * <li>Content at the source URI</li>
		 * <li>Content reached via one or more redirects from the source URI</li>
		 * <li>An ABR segment identified by a manifest file at the source URI</li>
		 * </ul>
		 *
		 * @see nickel::client::MediaRouter#setSource()
		 */
		source = 1,

		/**
		 * A video-track error.
		 *
		 * @see nickel::client::MediaRouter#setVideoTrack()
		 */
		video_track = 2,

		/**
		 * An audio-track error.
		 *
		 * @see nickel::client::MediaRouter#setAudioTrack()
		 */
		audio_track = 3,

		/**
		 * A subtitle-track error.
		 *
		 * @see nickel::client::MediaRouter#setSubtitleTrack()
		 */
		subtitle_track = 4,

		/**
		 * An index-file error - possible causes include : a fetch error of the index-file,
		 * or a parsing error of the index-file.
		 */
		index_file = 5,

		/**
		 * A subtitle-file error.
		 *
		 * @see nickel::client::MediaRouter#addSubtitleTrack()
		 */
		subtitle_file = 6,

		/**
		 * The error relates to the contents of an SDP file retrieved in
		 * response to MediaRouter.setSource().  This is only relevant for RTP
		 * multicast IP Channels.
		 *
		 * @see nickel::client::MediaRouter#setSource()
		 */
		sdp_file = 7,
	};
};

/**
 * The defined interface for a MediaRouter event-listener.
 *
 * <p>To receive events the object must be set up to listen to the MediaRouter using
 * <code>MediaRouter.addListener()</code>. </p>
 *
 * @see nickel::client::MediaRouter#addListener()
 */
struct ZINC_EXPORT MediaRouterEventListener : public NS_ZINC::EventListener {

	/**
	 * <code>BufferStatusEvents</code> signals changes in the buffer state.
	 *
	 * @param event a <code>BufferStatusEventValue</code> signals changes in the buffer state.
	 *
	 * @see nickel::client::BufferStatusEventValue::Enum
	 *
	 * @if AS3 @includeExample BufferStatusEventLisenerExample.as@endif
	 *
	 */
    virtual void BufferStatusEvent(const BufferStatusEventValue::Enum event) = 0;

	/**
	 * DrmEvents signals DRM-specific status changes. The event includes information on the nature of
	 * the problem, the DRM Content ID (if known) and any Rights Issuer URL obtained from the content.
	 *
	 * @param resultRef 			a <code>DrmEventValue</code> representing the type of DRM event.
	 *
	 * @param drmMediaIdentifier 	this field will contain, if known, the unique DRM content ID of the content for
	 * 								which the event is being emitted. Where no DRM content ID is available, this field
	 * 								will be an empty string.
	 *
	 * @param rightsIssuerUrl 		<p>this field will contain the url of the digital rights-issuer if the
	 * 								<code>resultRef</code> is one of the following <code>DrmEventValues</code> listed:
	 *
	 * 								<ul>
	 * 								<li><code>DrmEventValue.licence_required</code></li>
	 * 								<li><code>DrmEventValue.bad_content_format</code></li>
	 * 								<li><code>DrmEventValue.unmet_licence_requirement</code></li>
	 * 								<li><code>DrmEventValue.licence_format_error</code></li>
	 * 								<li><code>DrmEventValue.missing_credentials</code></li>
	 * 								<li><code>DrmEventValue.expired</code></li>
	 * 								<li><code>DrmEventValue.play_count_exceeded</code></li>
	 * 								<li><code>DrmEventValue.other_drm_event</code></li>
	 * 								</ul></p>
	 *
	 *                            	<p>In the case of Marlin DRM, this field will typically be a URL from which an
	 * 								ActionToken can be requested.</p>
	 *
	 *                        		<p>If the <code>resultRef</code> is <code>DrmEventValue.subscription_expired</code>,
	 * 								where the cause is an expired Marlin Broadband subscription link, then this field
	 * 								will carry a link renewal URL.</p>
	 *
	 *                        		<p>For all other <code>DrmEventValues</code>, or where no suitable information
	 * 								can be obtained from the media, this field will be an empty string.</p>
	 *
	 * @see nickel::client::DrmEventValue::Enum
	 *
	 */
    virtual void DrmEvent(const DrmEventValue::Enum resultRef,const std::string& drmMediaIdentifier,const std::string& rightsIssuerUrl) = 0;

	/**
	 * <code>PositionChangeEvent</code> signals changes in play-position.
	 *
	 * <p>Since, in normal playback, play-position will be constantly changing, <code>PositionChangeEvents</code>
	 * are limited in frequency to one per second.</p>
	 *
	 * @param position a <code>Position</code> structure.
	 *
	 * @if AS3 @includeExample MediaRouterEventListenerPositionChangeEvent.as@endif
	 *
	 * @see nickel::client::Position
	 */
    virtual void PositionChangeEvent(boost::shared_ptr<Position> position) = 0;

	/**
	 * SourceEvents signals changes in the source status.
	 *
	 * @param event 	a <code>SourceEventValue</code>.
	 * @param reason 	if this event is emitted as a result of a call to <code>MediaRouter.setSource()</code>, this
	 * 					value will be the same <code>SetSourceReason</code> as the reason parameter passed to that call.
	 *
     * @see nickel::client::SourceEventValue::Enum
     * @see nickel::client::SetSourceReason::Enum
	 * @see nickel::client::MediaRouter#setSource()
	 *
	 */
    virtual void SourceEvent(const SourceEventValue::Enum event, const SetSourceReason::Enum reason) = 0;

	/**
	 * SpeedChangeEvents signals changes to play-speed.
     *
	 * <p>A <code>SpeedChangeEvent</code> will not be emitted if the MediaRouter is unable to continue playback
	 * due to a buffer underflow, or if the MediaRouter resumes playback following a buffer underflow.</p>
	 *
	 * <p>A <code>SpeedChangeEvent</code> will not be emitted if the MediaRouter is not configured.</p>
	 *
	 */
    virtual void SpeedChangeEvent() = 0;

	/**
	 * StatusEvents signals changes in playing-status.
	 *
	 * @param event a <code>StatusEventValue</code> the playing-status.
	 *
	 * @see nickel::client::StatusEventValue::Enum
	 */
    virtual void StatusEvent(const StatusEventValue::Enum event) = 0;

	/**
	 * ErrorEvents signals run-time errors.
	 *
	 * @param error 	an <code>ErrorEventValue</code>, indicates the type of error encountered.
	 * @param context 	indicates the context in which the error occurred. Corresponds to a <code>ErrorEventContext</code> value.
	 * @param info 		provides any further information on the specific error condition.
	 *
	 * 					<p>If <code>error</code> is;
	 * 					<ul>
	 * 					<li><code>ErrorEventValue.locator</code> - this parameter will include the errant locator.</li>
	 * 					<li><code>ErrorEventValue.tag</code> - this parameter will include the errant tag.</li>
	 * 					<li><code>ErrorEventValue.language</code> - this parameter will include the errant language string.</li>
	 * 					<li><code>ErrorEventValue.server</code> - and if the error is due to an HTTP Request error,
	 * 					this parameter will include the Request-URI, the http error-code and its name as defined in RFC 2616.</li>
	 * 					</ul>
	 * 					</p>
	 *
	 * @see nickel::client::ErrorEventValue::Enum
	 * @see nickel::client::ErrorEventContext::Enum
	 *
	 */
	virtual void ErrorEvent(const ErrorEventValue::Enum error, const ErrorEventContext::Enum context, const std::string& info) = 0;


	virtual ~MediaRouterEventListener();
};

NS_NICKEL_CLIENT_CLOSE

#endif
