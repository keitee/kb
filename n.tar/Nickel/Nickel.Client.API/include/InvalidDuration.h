/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_InvalidDuration_H_
#define NICKEL_CLIENT_InvalidDuration_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * The media duration is invalid.
 *
 * @see nickel::client::MediaRouter#setMediaDuration()
 *
 */
struct ZINC_EXPORT InvalidDuration : public std::runtime_error
{
	InvalidDuration ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~InvalidDuration() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_InvalidDuration_H_ */
