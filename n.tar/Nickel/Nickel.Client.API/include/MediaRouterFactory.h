/*
 * MediaRouterFactory.h
 *
 * Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_MEDIA_ROUTER_FACTORY_H_
#define NICKEL_CLIENT_MEDIA_ROUTER_FACTORY_H_

#include "macros.h"

#include "MediaRouter.h"
#include <zinc-common/Polymorphic.h>
#include <boost/shared_ptr.hpp>

NS_NICKEL_CLIENT_OPEN

/**
 * Factory used to create a new MediaRouter instance.
 *
 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
 *
 * @see nickel::client::MediaRouter
 */
struct ZINC_EXPORT MediaRouterFactory : virtual public NS_ZINC::Polymorphic {

	/**
	 * Creates an unconfigured MediaRouter instance.
	 *
	 * @return an unconfigured MediaRouter instance.
	 *
	 * @throws nickel::client::InsufficientResources There is not sufficient memory to allocate a
	 *         new MediaRouter instance.
	 *
	 * @acl cp
	 */
    virtual boost::shared_ptr<MediaRouter> createMediaRouter() = 0;

    /**
     * This method is deprecated and exists purely for backwards compatibility.
     * Please call MediaRouter.recycle() directly rather than using this
     * method.
     *
     * @param router the MediaRouter instance.
     *
     * @see nickel::client::MediaRouter#recycle()
     *
     * @acl cp
     */
    void destroyMediaRouter(boost::shared_ptr<MediaRouter> router) __attribute__((deprecated)) {
        if (router) {
            router->recycle();
        }
    }

    /**
     * This method is deprecated and exists purely for backwards compatibility.
     * Please call ClientFactory.getDefaultMediaRouter() directly rather than
     * using this method.
     *
     */
    virtual boost::shared_ptr<MediaRouter> getDefaultMediaRouter() const __attribute__((deprecated)) = 0;


    virtual ~MediaRouterFactory();
};

NS_NICKEL_CLIENT_CLOSE

#endif
