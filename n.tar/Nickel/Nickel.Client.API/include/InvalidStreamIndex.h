/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_InvalidStreamIndex_H_
#define NICKEL_CLIENT_InvalidStreamIndex_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * @private
 *
 * An ABR stream index parameter does not correspond to the index of a stream within the current ABR stream-set.
 */
struct ZINC_EXPORT InvalidStreamIndex : public std::runtime_error
{
	InvalidStreamIndex ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~InvalidStreamIndex() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_InvalidStreamIndex_H_ */
