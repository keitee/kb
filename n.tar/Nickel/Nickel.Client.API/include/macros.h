/*
 * macros.h
 *
 *  Created on: Mar 18, 2009
 *      Author: jsadler
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_MACROS_H_
#define NICKEL_CLIENT_API_MACROS_H_

#include <zinc-common/macros.h>


#define NS_NICKEL_CLIENT_OPEN namespace nickel { namespace client {
#define NS_NICKEL_CLIENT_CLOSE } }
#define NS_NICKEL_CLIENT ::nickel::client

#define NS_NICKEL_AUDIO_CLIENT_OPEN namespace nickel { namespace audio { namespace client {
#define NS_NICKEL_AUDIO_CLIENT_CLOSE } } }
#define NS_NICKEL_AUDIO_CLIENT ::nickel::audio::client

#endif /* NICKEL_CLIENT_API_MACROS_H_ */
