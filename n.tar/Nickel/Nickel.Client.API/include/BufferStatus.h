/*
 * BufferStatus.h
 */

#ifndef NICKEL_CLIENT_API_BUFFER_H_
#define NICKEL_CLIENT_API_BUFFER_H_

#include "macros.h"
#include <zinc-common/Polymorphic.h>
#include <stdint.h>

NS_NICKEL_CLIENT_OPEN

/**
 * A data object holding the status of the buffer.
 * 
 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
 *
 * @see nickel::client::MediaRouter#getBufferStatus()
 *
 */
struct ZINC_EXPORT BufferStatus : virtual public NS_ZINC::Polymorphic {

public:

	/**
	 * Gets the number of bytes between play-position and end of the buffer
	 *
	 * @return the number of bytes between play-position and end of the buffer.
	 *
	 * @acl cp
	 */
    int32_t getBufferedBytes() const { return bufferedBytes; }

    /**
	 * Gets the number of bytes between play-position to the end of the source
	 *
	 * @return the number of bytes between play-position to the end of the source.
	 *
     * @acl cp
     */
    int32_t getTotalBytesRemaining() const { return totalBytesRemaining; }


    /**
	 * Gets the total number of bytes in the source stream
	 *
     * @return the total number of bytes in the source stream.
	 *
     * @acl cp
     */
    int32_t getTotalStreamBytes() const { return totalStreamBytes; }

    /**
	 * Calculates the mean rate of bytes arriving in the MediaRouter's buffer over the last 2 seconds.
	 * If there is less than 2 seconds in the buffer then that will be used to calculate the mean.
	 *
	 * @if AS3 @includeExample BufferStatusGetArrivalBytesPerSecond.as@endif
	 *
	 * @return bytes arriving in the buffer each second.
	 *
     * @acl cp
     */
    int32_t getArrivalBytesPerSecond() const { return arrivalBytesPerSecond; }

    /**
	 * Gets the average number of bytes arriving at the buffer each second.
	 *
	 * @return the average number of bytes arriving at the buffer each second.
	 *
     * @acl cp
     */
    int32_t getStreamBytesPerSecond() const { return streamBytesPerSecond; }

	/**
	 * @return the number of milliseconds of media time from the play-position to the end of the current buffer region.
	 *
     * @acl cp
     */
    int32_t getBufferedMilliseconds() const { return bufferedMilliseconds; }

    void setBufferedBytes(int32_t bufferedBytes_) { bufferedBytes = bufferedBytes_; }

    void setTotalBytesRemaining(int32_t totalBytesRemaining_) { totalBytesRemaining = totalBytesRemaining_; }

    void setTotalStreamBytes(int32_t totalStreamBytes_) { totalStreamBytes = totalStreamBytes_; }

    void setArrivalBytesPerSecond(int32_t arrivalBytesPerSecond_) { arrivalBytesPerSecond = arrivalBytesPerSecond_; }

    void setStreamBytesPerSecond(int32_t streamBytesPerSecond_) { streamBytesPerSecond = streamBytesPerSecond_; }

    void setBufferedMilliseconds(int32_t bufferedMilliseconds_) { bufferedMilliseconds = bufferedMilliseconds_; }

    virtual ~BufferStatus();

private:

    // XXX should be 64 bit
    int32_t bufferedBytes;
    // XXX should be 64 bit
    int32_t totalBytesRemaining;
    // XXX should be 64 bit
    int32_t totalStreamBytes;
    int32_t arrivalBytesPerSecond;
    int32_t streamBytesPerSecond;
    int32_t bufferedMilliseconds;
};

NS_NICKEL_CLIENT_CLOSE

#endif
