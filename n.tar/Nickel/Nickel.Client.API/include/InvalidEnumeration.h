/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_InvalidEnumeration_H_
#define NICKEL_CLIENT_InvalidEnumeration_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * The parameter is not a member of the required enumerated type.
 */
struct ZINC_EXPORT InvalidEnumeration : public std::runtime_error
{
	InvalidEnumeration ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~InvalidEnumeration() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_InvalidEnumeration_H_ */
