/*
 * AspectRatio.h
 *
 *  Created on: May 16, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited
 */

#ifndef NICKEL_ASPECT_RATIO_H_
#define NICKEL_ASPECT_RATIO_H_

#include "macros.h"

#include <zinc-common/Enum.h>

NS_NICKEL_CLIENT_OPEN

struct AspectRatio : NS_ZINC::Enum {

	enum Enum {
		_4_3 = 0,
		_16_9 = 1
	};

};

NS_NICKEL_CLIENT_CLOSE

#endif // NICKEL_ASPECT_RATIO_H_
