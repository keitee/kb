/*
 * ControlCapabilites.h
 *
 *  Created on: July 9 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_CONTROLCAPABILITIES_H_
#define NICKEL_CLIENT_API_CONTROLCAPABILITIES_H_

#include <stdint.h>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <zinc-common/Polymorphic.h>
#include "macros.h"

NS_NICKEL_CLIENT_OPEN

/**
 * A data object holding the supported playback speeds of a MediaRouter.
 * 
 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
 *
 * @see nickel::client::MediaRouter#getControlCapabilities()
 */
struct ZINC_EXPORT ControlCapabilities : virtual public NS_ZINC::Polymorphic {

public:

	/**
	 * Gets the minimum and maximum fast-forward speeds supported by the MediaRouter.
	 *
	 * <p>If the MediaRouter supports no fast-forward speeds - <code>getFastForwardRange()</code>
	 * returns an empty array ( <code>[]</code> ).</p>
	 *
	 * <p>If the MediaRouter supports one fast-forward speed, it must support (2x) (in which case) -
	 * <code>getFastForwardRange()</code> will always have 2 as the first array value.</p>
	 *
	 * <p>If, for example, the MediaRouter supports (2x and 100x) fast-forward speeds -
	 * <code>getFastForwardRange()</code> would return the array ( <code>[2, 100]</code> ).</p>
	 *
	 * @return Array - the minimum and maximum fast-forward speeds supported by the MediaRouter.
	 *
	 * @acl cp
	 */
    boost::shared_ptr<std::vector<int32_t> > getFastForwardRange() { return fastForwardRange; }

	/**
	 * Gets the maximum and minimum fast-reverse speeds supported by the MediaRouter.
	 *
	 * <p>If the MediaRouter supports no fast-reverse speeds - <code>getFastReverseRange()</code>
	 * returns an empty array ( <code>[]</code> ).</p>
	 *
	 * <p>If the MediaRouter supports one fast-reverse speed, it must support (-2x) (in which case) -
	 * <code>getFastReverseRange()</code> will always have -2 as the first array value.</p>
	 *
	 * <p>If, for example, the MediaRouter supports (-100x and -2x) fast-reverse speeds -
	 * <code>getFastReverseRange()</code> would return the array ( <code>[-100, -2]</code> ).</p>
	 *
	 * @return Array - the maximum and minimum fast-reverse speeds supported by the MediaRouter.
	 *
     * @acl cp
     */
    boost::shared_ptr<std::vector<int32_t> > getFastReverseRange() { return fastReverseRange; }

    /**
	 * Gets an array containing specific supported play speeds that are outside the fastForwardRange and fastReverseRange speeds.
	 * The set of speeds will always include 0 (paused) and 1.0 (normal speed).
	 *
	 * <p>Play-speeds are ordered in the array from lowest to highest - <code>getSlowSpeeds()</code> may, for example,
	 * return the array ( <code>[-1.5, -1.0, -0.5, 0, 0.5, 1.0, 1.5]</code> ).</p>
	 *
	 * @return Array - the set of supported play speeds that are outside the fastForwardRange and fastReverseRange speeds.
	 *
     * @acl cp
     */
    boost::shared_ptr<std::vector<double> > getSlowSpeeds() { return slowSpeeds; }


    void setFastForwardRange(boost::shared_ptr<std::vector<int32_t> > i) { fastForwardRange = i; }

    void setFastReverseRange(boost::shared_ptr<std::vector<int32_t> > i) { fastReverseRange = i; }

    void setSlowSpeeds(boost::shared_ptr<std::vector<double> > d) { slowSpeeds = d; }

    virtual ~ControlCapabilities();

private:

    boost::shared_ptr<std::vector<int32_t> > fastForwardRange;
    boost::shared_ptr<std::vector<int32_t> > fastReverseRange;
    boost::shared_ptr<std::vector<double> > slowSpeeds;
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_API_CONTROLCAPABILITIES_H_ */
