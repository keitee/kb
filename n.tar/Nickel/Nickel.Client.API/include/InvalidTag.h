/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_InvalidTag_H_
#define NICKEL_CLIENT_InvalidTag_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * The tag is invalid.
 */
struct ZINC_EXPORT InvalidTag : public std::runtime_error
{
	InvalidTag ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~InvalidTag() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_InvalidTag_H_ */
