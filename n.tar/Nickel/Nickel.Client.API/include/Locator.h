/*
 * Locator.h
 *
 *  Created on: Feb 26, 2009
 *      Author: jsadler
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_LOCATOR_H_
#define NICKEL_CLIENT_LOCATOR_H_

#include "macros.h"
#include "AudioFeedback.h"
#include "MediaRouterFactory.h"
#include "MediaSettings.h"
#include "OutputManager.h"
#include "ServiceListBuilder.h"

#include <zinc-common/Polymorphic.h>

#include <boost/shared_ptr.hpp>

#include <vector>

NS_NICKEL_CLIENT_OPEN

/**
 * This is the top-level entry-point to the media system - giving access to the
 * MediaRouterFactory (which creates instances of MediaRouter), and MediaSettings
 */
struct ZINC_EXPORT Locator : virtual public NS_ZINC::Polymorphic {

	/**
	 * Gets a new <code>MediaRouterFactory</code> object.
	 *
	 * @return a <code>MediaRouterFactory</code> object.
	 *
	 * @acl cp
	 */
	virtual boost::shared_ptr<MediaRouterFactory> getMediaRouterFactory() const = 0;

	/**
 	 * Gets a <code>MediaSettings</code> object containing a snapshot of source settings.
	 *
	 * @return a <code>MediaSettings</code> object.
	 *
	 * @acl cp
	 */
	virtual boost::shared_ptr<MediaSettings> getMediaSettings() const = 0;

	virtual boost::shared_ptr<OutputManager> getOutputManager() const = 0;

	virtual boost::shared_ptr<ServiceListBuilder> getServiceListBuilder() const = 0;

	/**
     * <strong>IMPORTANT:</strong> This internal API member is not intended for use by 3rd party applications.
     *
	 * Gets the default media router
	 * 
	 * @return a MediaRouter object
	 *
	 * @see MediaRouterFactory::getDefaultMediaRouter()
	 *
	 * @acl cp
	 */
	virtual boost::shared_ptr<MediaRouter> getDefaultMediaRouter() const = 0;

	virtual boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> getAudioFeedback() const = 0;

	virtual ~Locator();
};

NS_NICKEL_CLIENT_CLOSE

#endif /*NICKEL_CLIENT_LOCATOR_H_*/


