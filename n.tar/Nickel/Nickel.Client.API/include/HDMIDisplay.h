/*
 * HDMIDisplay.h
 *
 *  Created on: May 11, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited 
 */

#ifndef NICKEL_HDMI_DISPLAY_H_
#define NICKEL_HDMI_DISPLAY_H_

#include "macros.h"
#include "DisplayResolution.h"
#include "HDMIStatus.h"

#include <zinc-common/Polymorphic.h>
#include <zinc-common/Enum.h>

#include <vector>

NS_NICKEL_CLIENT_OPEN

struct HDCPPreference : NS_ZINC::Enum {
	enum Enum {
		always_on = 0,
		when_required = 1
	};
};

class ZINC_EXPORT HDMIDisplay : virtual public NS_ZINC::Polymorphic
{
public:
    /**
     * Returns the currently selected HDMI resolution preference. 
     * Note: this may not be the format in use.
     *
     * @see nickel::client::DisplayResolution::Enum
     */
    virtual DisplayResolution::Enum getResolutionPreference() const = 0;

    /**
     * Sets the preferred resolution and frame format for use on the HDMI connection.
     *
     * If the requested resolution is not supported by the display, the device must select an alternative.
     * It is an error to attempt to set the resolution preference to SD. In such cases, a NotSupported error shall be generated.
     * If the resolution preference is set to UNDEFINED, the device shall use the display's preferred resolution as indicated
     * in the EDID where this is a resolution supported by the YouView device.
     *
     * @see nickel::client::DisplayResolution::Enum
     */
    virtual void setResolutionPreference(DisplayResolution::Enum preference) = 0;

    /**
     * Returns the set of display resolutions and frame formats that are known to be supported by the connected display.
     * 
     * If no display is connected, an empty array is returned. 
     * @return Array of DisplayResolution
     *
     * @see nickel::client::DisplayResolution::Enum
     */
    virtual std::vector<DisplayResolution::Enum> getResolutions() const = 0;

    /**
     * Returns the current preferred mode of HDCP operation for the HDMI output.
     *
     * @see nickel::client::HDCPPreference::Enum
     */
    virtual HDCPPreference::Enum getHDCPPreference() const = 0;

    /**
     * Sets the preferred mode of HDCP operation for the HDMI output. 
     *
     * @see nickel::client::HDCPPreference::Enum
     */
    virtual void setHDCPPreference(HDCPPreference::Enum preference) = 0;

    /**
     * Returns information about the current status of the HDMI output. 
     *
     * @see nickel::client::HDMIStatus::Enum
     */
    virtual HDMIStatus::Enum getStatus() const = 0;
   
    /**
     * Set HDMI output in standby mode.
     *
     * Note: this method should be called only if the user has explicitly indicated that they wish to initiate the 
     * HDMI System Standby feature and hence put all HDMI-connected devices into their standby modes.
     */
    virtual void requestStandby() = 0; 

    virtual ~HDMIDisplay();
};

NS_NICKEL_CLIENT_CLOSE

#endif
