/*
 * ABRStatus.h
 *
 *  Created on: May 4, 2011
 *      Author: mark.nicoll@youview.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
*/

#ifndef NICKEL_CLIENT_API_ABRSTATUS_H_
#define NICKEL_CLIENT_API_ABRSTATUS_H_

#include "macros.h"
#include <zinc-common/Polymorphic.h>
#include <stdint.h>

NS_NICKEL_CLIENT_OPEN

class ZINC_EXPORT ABRStatus : virtual public NS_ZINC::Polymorphic {

public:

	int32_t getStreamIndex() { return streamIndex; }
    void setStreamIndex(const int32_t streamIndex_) { streamIndex = streamIndex_; }
    int32_t getSegmentIndex() { return segmentIndex; }
    void setSegmentIndex(const int32_t segmentIndex_) { segmentIndex = segmentIndex_; }
    int32_t getExistingSegment() { return existingSegment; }
    void setExistingSegment(const int32_t existingSegment_) { existingSegment = existingSegment_; }
    int32_t getSegmentDuration() { return segmentDuration; }
    void setSegmentDuration(const int32_t segmentDuration_) { segmentDuration = segmentDuration_; }
    int32_t getNextSegmentDuration() { return nextSegmentDuration; }
    void setNextSegmentDuration(const int32_t nextSegmentDuration_) { nextSegmentDuration = nextSegmentDuration_; }
    int32_t getDurationAcquired() { return durationAcquired; }
    void setDurationAcquired(const int32_t durationAcquired_) { durationAcquired = durationAcquired_; }
    int32_t getArrivalBitrate() { return arrivalBitrate; }
    void setArrivalBitrate(const int32_t arrivalBitrate_) { arrivalBitrate = arrivalBitrate_; }
    int32_t getLastSegmentBitrate() { return lastSegmentBitrate; }
    void setLastSegmentBitrate(const int32_t lastSegmentBitrate_) { lastSegmentBitrate = lastSegmentBitrate_; }
    int32_t getBufferedMilliseconds() { return bufferedMilliseconds; }
    void setBufferedMilliseconds(const int32_t bufferedMilliseconds_) { bufferedMilliseconds = bufferedMilliseconds_; }

    virtual ~ABRStatus();

private:

    int32_t streamIndex;
    int32_t segmentIndex;
    int32_t existingSegment;
    int32_t segmentDuration;
    int32_t nextSegmentDuration;
    int32_t durationAcquired;
    int32_t arrivalBitrate;
    int32_t lastSegmentBitrate;
    int32_t bufferedMilliseconds;
};

NS_NICKEL_CLIENT_CLOSE

#endif
