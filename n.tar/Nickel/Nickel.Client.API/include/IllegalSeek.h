/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_IllegalSeek_H_
#define NICKEL_CLIENT_IllegalSeek_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * An illegal-seek, a seek beyond media-duration was attempted.
 *
 * <p>A call to <code>MediaRouter.seekPosition()</code> was disallowed.
 *
 * This would be for any of the following reasons:</p>
 * <ul>
 * <li><code>MediaRouter.setMediaDuration()</code> value is 0.</li>
 * </ul>
 *
 * @see nickel::client::MediaRouter#seekPosition()
 */
struct ZINC_EXPORT IllegalSeek : public std::runtime_error
{
	IllegalSeek ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~IllegalSeek() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_IllegalSeek_H_ */
