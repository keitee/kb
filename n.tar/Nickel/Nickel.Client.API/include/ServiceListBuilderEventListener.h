/*
 * ServiceListBuilderListener.h
 *
 *  Created on: Fab 11 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_SERVICELISTBUILDERLISTENER_H_
#define NICKEL_CLIENT_SERVICELISTBUILDERLISTENER_H_

#include "macros.h"

#include <zinc-common/EventListener.h>
#include <zinc-common/Enum.h>

#include <boost/shared_ptr.hpp>
#include <string>
#include <map>
#include <stdint.h>

NS_NICKEL_CLIENT_OPEN

struct ScanningProgressStatus : NS_ZINC::Enum {

	enum Enum {
		IN_PROGRESS = 0,
		SUCCESS = 1,
		ABORTED = 2,
		FAILURE = 3,
	};
};

struct ZINC_EXPORT ServiceListBuilderEventListener : public NS_ZINC::EventListener {

    virtual void ScanningProgress(const int32_t progress,
            const ScanningProgressStatus::Enum status,
            const uint32_t channelsScanned,
            const uint32_t totalChannels,
            boost::shared_ptr<std::map<uint32_t,uint32_t> > servicesFound) = 0;

    virtual ~ServiceListBuilderEventListener();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_SERVICELISTBUILDERLISTENER_H_ */
