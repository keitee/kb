/*
 * HDMIDisplay.h
 *
 *  Created on: May 11, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited 
 */

#ifndef NICKEL_ANALOGUE_DISPLAY_H_
#define NICKEL_ANALOGUE_DISPLAY_H_

#include <zinc-common/Polymorphic.h>
#include <zinc-common/Enum.h>
#include <stdint.h>
#include "macros.h"

#include "AspectRatio.h"

NS_NICKEL_CLIENT_OPEN

struct VideoStandard : NS_ZINC::Enum
{
	enum Enum
	{
		pal = 0,
		secam = 1,
		ntsc = 2
	};
};

struct ColourMode : NS_ZINC::Enum
{
	enum Enum
	{
		composite = 0,
		yc = 1,
		rgb = 2
	};
};


class ZINC_EXPORT AnalogueDisplay : virtual public NS_ZINC::Polymorphic
{
public:
    /**
     * Returns the configured display shape for the analogue video output(s).
     *
     * @see nickel::client::AspectRatio::Enum
     */
    virtual AspectRatio::Enum getAspectRatio() const = 0;

    /**
     * Configures the display shape to be assumed for displays connected to the analogue output(s). 
     *
     * @see nickel::client::AspectRatio::Enum
     */
    virtual void setAspectRatio(AspectRatio::Enum ratio) = 0;

    /**
     * Returns the video standard for analogue output(s). 
     *
     * @see nickel::client::VideoStandard::Enum
     */
    virtual VideoStandard::Enum getVideoStandard() const = 0;

    /**
     * Configures the video standard for analogue output(s). 
     *
     * @see nickel::client::VideoStandard::Enum
     */
    virtual void setVideoStandard(VideoStandard::Enum standard) = 0;

    /**
     * Returns the current preferred colour mode for the SCART output(s). 
     *
     * @see nickel::client::ColourMode::Enum
     */
    virtual ColourMode::Enum getSCARTColourPreference() const = 0;

    /**
     * Configures the preferred colour mode for the SCART output(s).
     *
     * The device's main SCART output shall support all defined modes.
     * If a secondary SCART output exists and does not support the requested mode, the implementation
     * shall choose an appropriate alternative mode to use for that output.
     *
     * @see nickel::client::ColourMode::Enum
     */
    virtual void setSCARTColourPreference(ColourMode::Enum colourMode) = 0;

    virtual ~AnalogueDisplay();
};

NS_NICKEL_CLIENT_CLOSE

#endif
