/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_NotApplicable_H_
#define NICKEL_CLIENT_NotApplicable_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * The operation is not applicable in the current configuration.
 */
struct ZINC_EXPORT NotApplicable : public std::runtime_error {

	NotApplicable ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~NotApplicable() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_NotApplicable_H_ */
