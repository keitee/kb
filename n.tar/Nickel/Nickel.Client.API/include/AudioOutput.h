/*
 * AudioOutput.h
 *
 *  Created on: May 11, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited 
 */

#ifndef NICKEL_AUDIO_OUTPUT_H_
#define NICKEL_AUDIO_OUTPUT_H_

#include <zinc-common/Polymorphic.h>
#include <zinc-common/Enum.h>
#include <stdint.h>
#include <vector>
#include "macros.h"

NS_NICKEL_CLIENT_OPEN

struct AudioOutputType : NS_ZINC::Enum
{
	enum Enum
	{
		analogue_rca = 0,
		analogue_scart = 1,
		spdif = 2,
		hdmi = 3
	};
};

struct AudioFormat : NS_ZINC::Enum
{
	enum Enum
	{
		analogue = 0,
		pcm_2ch = 1,
		pcm_5_1 = 2,
		ac3 = 3,
		dts = 4,
		e_ac3 = 5
	};
};

class ZINC_EXPORT AudioOutput : virtual public NS_ZINC::Polymorphic
{
public:
    /**
     * Returns AudioOutputType of output.
     *
     * @see nickel::client::AudioOutputType::Enum
     */
    virtual AudioOutputType::Enum getType() const = 0;

    /**
     * Returns a list of audio formats that a specific audio output can support. 
     *
     * The device shall return all formats that the audio output can support, not just those that could be enabled at the time of the call. 
     * @see nickel::client::AudioFormat::Enum
     */
    virtual std::vector<AudioFormat::Enum> getFormats() const = 0;

    /**
     * Gets the currently preferred audio output format for an audio output.
     *
     * This may not be the audio format actually in use on the audio output.
     * @see nickel::client::AudioFormat::Enum
     */
    virtual AudioFormat::Enum getFormatPreference() const = 0;

    /**
     * Sets the preferred audio output format for an audio output.
     *
     * If the requested format is not supported for the output, no error is generated. The device may use an alternative format for the output
     * if the source audio format and the capabilities of the connected device prevent selection of the preferred audio format.
     * @see nickel::client::AudioFormat::Enum
     */
    virtual void setFormatPreference(AudioFormat::Enum format) = 0;

    /**
     * Returns the currently configured audio delay for an audio output. 
     *
     * @return Either the currently configured delay in milliseconds, or -1 if the default mode is in use. 
     */
    virtual int32_t getDelay() const = 0; 

    /**
     * Sets the audio delay for an output.
     *
     * If the audio output does not support a delay, a NotSupported error shall be generated. Refer to the Consumer Device Platform specification
     * for details on audio delay requirements.
     * If the delay parameter is outside the valid range, an OutOfBounds error shall be generated.
     *
     * @param delay Either a delay in milliseconds or -1 to select the default mode for the output. The maximum delay is 250 ms.
     */
    virtual void setDelay(const int32_t delay) = 0;

    virtual ~AudioOutput();

};

NS_NICKEL_CLIENT_CLOSE

#endif
