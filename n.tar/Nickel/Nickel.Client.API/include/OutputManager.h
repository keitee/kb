/*
 * OutputManager.h
 *
 *  Created on: Mar 2, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 YouView TV Limited 
 */

#ifndef NICKEL_CLIENT_API_OUTPUTMANAGER_H_
#define NICKEL_CLIENT_API_OUTPUTMANAGER_H_

#include "macros.h"
#include "OutputManagerEventListener.h"

#include "DisplayResolution.h"
#include "AspectRatio.h"

#include "AudioOutput.h"
#include "HDMIDisplay.h"
#include "AnalogueDisplay.h"
#include "VideoConversions.h"
#include "GraphicsResolution.h"

#include <zinc-common/DispatchingEventProducer.h>
#include <zinc-common/Enum.h>
#include <vector>
#include <boost/shared_ptr.hpp>

NS_NICKEL_CLIENT_OPEN

struct DisplayType : NS_ZINC::Enum
{
	enum Enum
	{
		dt_hdmi = 0,
		dt_analogue = 1
	};
};

struct ADRouting : NS_ZINC::Enum
{
	enum Enum
	{
		ad_all_outputs = 0,
		ad_spdif_only = 1
	};
};

class ZINC_EXPORT OutputManager : virtual public NS_ZINC::DispatchingEventProducer<OutputManagerEventListener> {
public:
	virtual ~OutputManager();

public:
    /**
     * Returns the currently preferred display type. 
     *
     * @see nickel::client::DisplayType::Enum
     */
	virtual DisplayType::Enum getPrimaryDisplayPreference() const = 0;

    /**
     * Sets the preferred display type. 
     *
     * The device shall optimise the output for the selected display type. 
     * Note: outputs supporting display types other than the preferred may still be active.
     * The primary display preference determines which display is considered by the 
     * getPrimaryDisplayResolution and getPrimaryDisplayAspectRatio methods.
     *
     * @param preference The current primary display preference.
     * @see nickel::client::DisplayType::Enum
     */
    virtual void setPrimaryDisplayPreference(const DisplayType::Enum preference) = 0;

    /**
     * Returns the current resolution of the primary output.
     *
     * The primary output is the output of the currently preferred primary display.
     * If no picture is currently being sent to the primary output, the method shall return 
     * UNDEFINED. This can occur if outputs are disabled or if the output requires a display
     * to be connected and there is none.
     *
     * @see nickel::client::DisplayResolution::Enum
     */
	virtual DisplayResolution::Enum getPrimaryDisplayResolution() const = 0;

    /**
     * Returns the aspect ratio of the primary display.
     *
     * If the primary display is an analogue display, the aspect ratio returned shall be the
     * configured analogue display aspect ratio set by setAnalogueDisplayAspectRatio().
     * If the primary display is an HDMI-connected display, 16:9 shall be returned.
     *
     * @see nickel::client::AspectRatio::Enum
     */
	virtual AspectRatio::Enum getPrimaryDisplayAspectRatio() const = 0;

    /**
     * Returns the array of audio output control objects.
     *
     * @see nickel::client::AudioOutput
     */
    virtual std::vector<boost::shared_ptr<AudioOutput> > getAudioOutputs() const = 0;

    /**
     * Returns HDMI Display control object.
     */
    virtual boost::shared_ptr<HDMIDisplay> getHDMIDisplay() const = 0;

    /**
     * Returns Analogue Display control object.
     */
    virtual boost::shared_ptr<AnalogueDisplay> getAnalogueDisplay() const = 0;

    /**
     * Returns the currently selected preferences for video aspect ratio conversion.
     */
    virtual VideoConversions getVideoConversionPreference() const = 0;

    /**
     * Sets the preferred aspect ratio conversion mechanisms.
     *
     * Select converson mechanism to be applied when presenting a video picture of one shape on
     * a display of a different shape. 
     *
     * @param preference The new conversion preferences to use. 
     */
    virtual void setVideoConversionPreference(const VideoConversions preference) = 0;

    /**
     * Returns resolution of current graphics layer.
     *
     * Provides information about the raw graphics layer onto which UI and application graphics are composed.
     * It corresponds to the resolution of the DirectFB DisplayLayer. For most YouView devices, this is
     * 1280x720 at all times, regardless of the current output resolution. However, hardware with limited
     * graphics plane scaling capabilities may need to select a different graphics layer resolution when
     * configured to use certain display resolutions.
     * The graphics layer fills the primary display entirely so that the pixel resolution returned represents
     * the full screen area. The pixel aspect ratio of the graphics layer can be calculated using the 
     * graphics layer resolution together with the primary display aspect ratio.
     */
    virtual GraphicsResolution getGraphicsLayerResolution() const = 0;

    /**
     * Disables all audio and video outputs. 
     *
     * Outputs shall be disabled such that a connected device would assume that the YouView device had been
     * switched off. Note: it is not sufficient simply to show a black raster.
     * The HDMI CEC actions described in section 3.2.2 shall be performed for the HDMI output.
     */
	virtual void disableOutputs() = 0;

    /**
     * Enables all audio and video outputs.
     *
     * Reverses the effect of disableOutputs, returning all outputs to a state where they are potentially
     * operating. Note: this does not necessarily result in any video or audio being sent to the output.
     * The HDMI CEC actions described in section 3.2.1 shall be performed for the HDMI output.
     */
	virtual void enableOutputs() = 0;

    /**
     * Returns the current relative audio description volume.
     */
    virtual int32_t getRelativeADVolume() const = 0;

    /**
     * Sets the level of the relative audio description volume.
     *
     * Volume value is relative to the main programme volume. It controls the offset with which the volume
     * control AD-P1 tracks volume control A-P1 as described in the Consumer Device Platform specification.
     * The units are the same as for MediaRouter.setVolume.
     * In typical usage, this volume control will be set within a small range. Devices shall support a range
     * of at least +/- 6dB. An OutOfBounds error shall be returned if the requested volume is outside the
     * range supported by the device.
     *
     * @param vol The new relative AD volume.
     */
    virtual void setRelativeADVolume(const int32_t vol) = 0;

    /**
     * Increments the current master volume setting by one unit. 
     *
     * If this would cause the volume to go outside the permitted range, the call is ignored and the volume remains
     * unchanged. This API does not affect the mute status. If the audio is muted, this method changes the 
     * volume that will apply when the audio is subsequently unmuted.
     */
	virtual void incVolume() = 0;

    /**
     * Decrements the current master volume setting by one unit.
     *
     * If this would cause the volume to go outside the permitted range, the call is ignored and the volume remains
     * unchanged. This API does not affect the mute status. If the audio is muted, this method changes the 
     * volume that will apply when the audio is subsequently unmuted.
     */
	virtual void decVolume() = 0;

    /**
     * Returns the current master volume setting.
     *
     * If the audio is currently muted, this method returns the volume setting that the device will return to when unmuted.
     */
	virtual int32_t getVolume() const = 0;

    /**
     * This sets the master volume control for the device. 
     *
     * It controls volume control A-P2 as described in the Consumer Device Platform specification.
     * This API does not affect the mute status. If the audio is muted, this method changes the volume that will apply when
     * the audio is subsequently unmuted.
     * Note: the volume scale describes an absolute volume level and is different to that used for the MediaRouter.setVolume
     * and OutputManager.setRelativeADVolume APIs which define relative volume levels.
     * If a value outside the valid range is passed, an OutOfBounds error shall be generated.
     *
     * @param volume The new system volume. The units represent a scale between 0 and 100.
     */
	virtual void setVolume(const int32_t volume) = 0;

    /**
     * Mute the master volume.
     *
     * If the OutputManager mute state is true, this API has no effect. Otherwise, this API causes the previous volume state to
     * be remembered and the mute state to be set true. 
     */
	virtual void muteVolume() = 0;

    /**
     * Unmute the master volume.
     *
     * If the OutputManager mute state is false, this API has no effect. Otherwise, this API unmutes the audio, returning the
     * volume to the value set by setVolume() and setting the mute state to false. 
     */
	virtual void unmuteVolume() = 0;

    /**
     * Returns the current mute state.
     */
    virtual bool isMuted() const = 0;

    /**
     * Returns current audio description routing setting.
     *
     * @see nickel::client::ADRouting::Enum
     */
    virtual ADRouting::Enum getADRouting() const = 0;

    /**
     * Sets routing of audio description.
     *
     * Determines whether audio description is routed to all audio outputs or to specific audio output types.
     * @param routing The new AD routing setting.
     * @see nickel::client::ADRouting::Enum
     */
    virtual void setADRouting(const ADRouting::Enum routing) = 0;
    
};	// class OutputManager 

NS_NICKEL_CLIENT_CLOSE


#endif /* NICKEL_CLIENT_API_OUTPUTMANAGER_H_ */
