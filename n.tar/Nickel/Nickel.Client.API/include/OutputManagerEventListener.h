/*
 * OutputManagerListener.h
 *
 *  Created on: Mar 2, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_OUTPUTMANAGERLISTENER_H_
#define NICKEL_CLIENT_API_OUTPUTMANAGERLISTENER_H_

#include "macros.h"

#include "AudioOutput.h"
#include "HDMIStatus.h"

#include <zinc-common/EventListener.h>
#include <zinc-common/Enum.h>

#include <string>
#include <stdint.h>
#include <boost/shared_ptr.hpp>


NS_NICKEL_CLIENT_OPEN

struct HDMICECEventType : NS_ZINC::Enum
{
	enum Enum
	{
		standby_request = 0,
		activated = 1,
		deactivated = 2
	};
};

class ZINC_EXPORT OutputManagerEventListener : public NS_ZINC::EventListener {
public:
    /**
     * This signal is raised when a display preference is changed.
     *
     * It is raised as a result of any of the following methods being called: 
     * <ul>
     * <li>setPrimaryDisplayPreference</li>
     * <li>setHDMIResolutionPreference</li>
     * <li>setVideoConversionPreference</li>
     * <li>setAnalogueDisplayAspectRatio</li>
     * </ul>
     * Note: if the change also results in a change to properties of the primary display, a PrimaryDisplayChange event may be generated at the same time.
     */
	virtual void DisplayPreferenceChange() = 0;

    /**
     * This signal is raised when the HDMI state has changed.
     *
     * Interface detects that a display has been connected or disconnected or if there is any change that affects the return value of any of the following methods: 
     * <ul>
     * <li>getHDMIResolutionOptions</li>
     * <li>getHDMIStatus</li>
     * </ul>
     * Note: if the change also results in a change to properties of the primary display, a PrimaryDisplayChange event may be generated at the same time.
     *
     * @param status The new status of the HDMI output.
     * @see nickel::client::HDMIStatus::Enum
     */
    virtual void HDMIEvent(const HDMIStatus::Enum status) = 0;

    /**
     * This signal is raised in response to certain HDMI CEC events and state changes associated with HDMI CEC as specified in section 3. 
     *
     * @see nickel::client::HDMICECEventType::Enum
     */
    virtual void HDMICECEvent(const HDMICECEventType::Enum eventType) = 0;

    /**
     * This signal is raised when there has been a change that affects the return value of any of the following methods: 
     * <ul>
     * <li>getPrimaryDisplayResolution</li>
     * <li>getPrimaryDisplayAspectRatio</li>
     * <li>getGraphicsLayerResolution</li>
     * </ul>
     */
    virtual void PrimaryDisplayChange() = 0;

    /**
     * This signal is raised when any audio preference is changed. 
     *
     * It is raised as a result of any of the following methods being called on AudioOutput: 
     * <ul>
     * <li>setFormatPreference</li>
     * <li>setDelay</li>
     * </ul>
     *
     * @see AudioOutput
     */
    virtual void AudioPreferenceChange(boost::shared_ptr<AudioOutput> output) = 0;

    /**
     * This signal is raised when the main volume or mute status changes.
     *
     * If a method is called to set the volume or mute status but the volume and mute status are unchanged, this signal shall not be raised.
     * @param volume The new volume as would be reported by getVolume().
     * @param muted The mute status as would be reported by isMuted().
     */
	virtual void VolumeChange(const uint32_t volume, const bool muted) = 0;

    /**
     * This signal is raised when enableOutputs() or disableOutputs() is called and there is a change to the outputs as a result.
     *
     * @param enabled Set to true if the outputs are enabled. 
     */
    virtual void OutputStatusEvent(const bool enabled) = 0;


    virtual ~OutputManagerEventListener();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_API_OUTPUTMANAGERLISTENER_H_ */
