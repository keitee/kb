/**
 * BufferConstraint.h
 *
 *  Created on: 07 Feb 2012
 *      Author: morgan.henry@youview.com
 *
 * Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_BUFFERCONSTRAINT_H_
#define NICKEL_CLIENT_API_BUFFERCONSTRAINT_H_

#include "macros.h"
#include <zinc-common/Enum.h>

NS_NICKEL_CLIENT_OPEN


/**
 *
 * BufferConstraint
 *
 * Constants for use with nickel::client::setBufferConstraint()
 *
 * @see nickel::client::setBufferingMode()
 * @see nickel::client::setBufferConstraint()
 *
 */
struct BufferConstraint : NS_ZINC::Enum
{
	/**
	 * The defined set of buffer constraints.
	 *
	 * @see nickel::client::MediaRouter#setBufferConstraint()
	 */
	enum Enum {
		threshold = 0,
		unlimited = 1,
		fixed = 2,
	};

};

NS_NICKEL_CLIENT_CLOSE

#endif // NICKEL_CLIENT_API_BUFFERCONSTRAINT_H_

