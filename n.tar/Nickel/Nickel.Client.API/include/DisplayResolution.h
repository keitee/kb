/*
 * DisplayResolution.h
 *
 *  Created on: May 16, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited
 */

#ifndef NICKEL_HDMI_DISPLAY_RESOLUTION_H_
#define NICKEL_HDMI_DISPLAY_RESOLUTION_H_

#include "macros.h"
#include <zinc-common/Enum.h>

NS_NICKEL_CLIENT_OPEN

struct DisplayResolution : NS_ZINC::Enum
{
	enum Enum
	{
		dr_undefined = -1,
		sd = 0,
		hd1280x720p50 = 1,
		hd1920x1080i25 = 2,
		hd1920x1080p50 = 3,
                uhd3840x2160p25c8 = 4,
                uhd3840x2160p25c10 = 5,
                uhd3840x2160p50c8 = 6,
                uhd3840x2160p50c10 =7
	};
};


NS_NICKEL_CLIENT_CLOSE

#endif // NICKEL_HDMI_DISPLAY_RESOLUTION_H_

