/*
 * ServiceListBuilder.h
 *
 *  Created on: Feb 11 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT__SERVICELISTBUILDER_H_
#define NICKEL_CLIENT__SERVICELISTBUILDER_H_

#include "macros.h"
#include "ServiceListBuilderEventListener.h"
#include <zinc-common/DispatchingEventProducer.h>
#include <string>

NS_NICKEL_CLIENT_OPEN

class ZINC_EXPORT ServiceListBuilder : virtual public NS_ZINC::DispatchingEventProducer<ServiceListBuilderEventListener> {
public:
	virtual void serviceScan() = 0;
	virtual void stopServiceScan() = 0;

protected:
	virtual ~ServiceListBuilder();

};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT__SERVICELISTBUILDER_H_ */
