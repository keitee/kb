/*
 * nickel-client-api.h
 *
 *  Created on: 03-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_H_
#define NICKEL_CLIENT_API_H_

#include "macros.h"
#include "IllegalReconfiguration.h"
#include "IllegalSeek.h"
#include "InsufficientResources.h"
#include "InvalidDuration.h"
#include "InvalidEnumeration.h"
#include "InvalidLanguage.h"
#include "InvalidLocator.h"
#include "InvalidStreamIndex.h"
#include "InvalidTag.h"
#include "InvalidOutput.h"
#include "NotApplicable.h"
#include "NotConfigured.h"
#include "NotSupported.h"
#include "OutOfBounds.h"
#include "PlayConflict.h"
#include "StopConflict.h"
#include "ABRStatus.h"
#include "ABRStreamSet.h"
#include "BufferStatus.h"
#include "BufferConstraint.h"
#include "AdaptiveMode.h"
#include "ControlCapabilities.h"
#include "Locator.h"
#include "ClientFactory.h"
#include "MediaRouter.h"
#include "MediaRouterEventListener.h"
#include "Position.h"
#include "MediaRouterFactory.h"
#include "MediaSettings.h"
#include "MediaSettingsListener.h"
#include "HDMIDisplay.h"
#include "AnalogueDisplay.h"
#include "AudioFeedback.h"
#include "AudioOutput.h"
#include "AspectRatio.h"
#include "GraphicsResolution.h"
#include "VideoConversions.h"
#include "OutputManager.h"
#include "OutputManagerEventListener.h"
#include "ServiceListBuilder.h"
#include "ServiceListBuilderEventListener.h"
#include "Track.h"
#include "VideoWindowDescriptor.h"

#endif /* NICKEL_CLIENT_API_H_ */
