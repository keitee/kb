/*
 * AudioFeedback.h
 *
 *  Created on: 7 October 2013
 *      Author: darren.garvey@youview.com
 *
 *   Copyright (C) 2013 YouView TV Limited
 */

#ifndef NICKEL_AUDIO_FEEDBACK_H_
#define NICKEL_AUDIO_FEEDBACK_H_

#include "macros.h"
#include <zinc-common/Polymorphic.h>
#include <zinc-common/Enum.h>
#include <vector>
#include <string>

NS_NICKEL_AUDIO_CLIENT_OPEN

class ZINC_EXPORT AudioSample
{
public:
    AudioSample():
        sampleName(""), lengthInMilliSeconds(0)
    {
    }

    AudioSample(const std::string &sampleName_, uint32_t lengthInMilliSeconds_):
        sampleName(sampleName_), lengthInMilliSeconds(lengthInMilliSeconds_)
    {
    }

    const std::string & getSampleName() const
    {
        return sampleName;
    }

    uint32_t getLengthInMilliSeconds() const
    {
        return lengthInMilliSeconds;
    }

private:
    std::string sampleName;
    uint32_t    lengthInMilliSeconds;
};

class ZINC_EXPORT AudioFeedback : virtual public NS_ZINC::Polymorphic
{
public:

    /**
     * Add a list of samples to the queue of samples to play.
     *
     * @param samples is the list of samples to add to the queue of samples to play.
     * @param flush specifies whether samples in the queue of audiofeedbackd (not yet committed
     *        to pcmplaybackd) have to be discarded (flush=true) or if the samples requested have
     *        to be queued (flush=false).
     * @throws std::invalid_argument if any of the samples requested were not loaded
     *         (nothing will be pushed to the queue in this case).
     * @see nickel::audio::client::AudioFeedback#makeSample()
     */
    virtual void playSamples(const std::vector<AudioSample> &samples, bool flush) const = 0;

    virtual void setRelativeVolume(int value) = 0;

    virtual int getRelativeVolume() const = 0;

    virtual void setEnabled(bool enabled) = 0;

    virtual bool getEnabled() const = 0;

    /**
     * Create an AudioSample that can be passed to playSamples to be played.
     *
     * @param sampleName is the name of the sample (case sensitive)
     *        that is located in $prefix/share/nickel-audio-feedback/.
     * @param lengthInMilliSeconds specifies for how long the
     *        sample has to be played:
     *        - if 0 &lt;= lengthInMilliSeconds &lt;= length of sample, the
     *          sample will be played once,
     *        - if lengthInMilliSeconds > length of sample, the sample
     *          will be played as many times as necessary:
     *          trunc(lengthInMilliSeconds / (audio sample length)) time(s)
     * @return an AudioSample that can be passed to nickel::audio::client::AudioFeedback#playSamples()
     */
    virtual AudioSample makeSample(const std::string &sampleName, uint32_t lengthInMilliSeconds) const = 0;

    virtual ~AudioFeedback();
};

NS_NICKEL_AUDIO_CLIENT_CLOSE

#endif /* NICKEL_AUDIO_FEEDBACK_H_ */
