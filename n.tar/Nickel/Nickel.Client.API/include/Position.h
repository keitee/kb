/*
 * Position.h
 *
 * Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_POSITION_H_
#define NICKEL_CLIENT_POSITION_H_

#include "macros.h"
#include <stdint.h>
#include <zinc-common/Polymorphic.h>


NS_NICKEL_CLIENT_OPEN

/**
 * A three field structure holding the position values of a MediaRouter.
 *
 * <p>Position - a three field structure holding :</p>
 * <ul>
 * <li><strong>start</strong> - the start-time of the media in milliseconds</li>
 * <li><strong>current</strong> - the play-position of the media in milliseconds</li>
 * <li><strong>end</strong> - the end-time of the media in milliseconds</li>
 * </ul>
 *
 * <p>A Position structure is returned by a call of <code>MediaRouter.getPosition()</code>.</p>
 * <p>If <code>MediaRouter.getPosition()</code> was called on a one hour on-demand programme that had been playing for
 * 4 seconds - the values of the returned Position structure would be :
 * <code>start = 0</code>, <code>current = 4000</code>, <code>end = 3600000</code>.</p>
 *
 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
 *
 * @see nickel::client::MediaRouter#getPosition()
 * @see nickel::client::MediaRouterEventListener
 *
 */
class ZINC_EXPORT Position : virtual public NS_ZINC::Polymorphic {

public:

    Position() : start(0), current(0), end(0) {}

    /**
     * Gets the start-time of the media in milliseconds. For on-demand content this should always return a value of 0 ms.
	 *
	 * @return the start-time of the media in milliseconds.
	 *
     * @acl cp
     */
    int32_t getStart(void) const { return start; }

    /**
     * Gets the play-position of the media in milliseconds.
	 *
	 * @return the play-position in milliseconds.
	 *
     * @acl cp
     */
    int32_t getCurrent(void) const { return current; }

    /**
     * Gets the end-time of the media in milliseconds.
	 *
	 * When the actual end-time of the media cannot be determined, its value will be set to <code>-1</code>.
	 *
	 * @return the end-time of the media in milliseconds.
	 *
	 * @see nickel::client::MediaRouter#setMediaDuration()
	 *
     * @acl cp
     */
    int32_t getEnd(void) const { return end; }

    void setStart(int32_t i) { start = i; }

    void setCurrent(int32_t i) { current = i; }

    void setEnd(int32_t i) { end = i; }

    virtual ~Position();

private:

    int32_t start;
    int32_t current;
    int32_t end;
};

NS_NICKEL_CLIENT_CLOSE

#endif
