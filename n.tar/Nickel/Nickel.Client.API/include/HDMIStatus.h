/*
 * HDMIStatus.h
 *
 *  Created on: May 16, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited
 */

#ifndef NICKEL_HDMI_STATUS_H_
#define NICKEL_HDMI_STATUS_H_

#include "macros.h"
#include <zinc-common/Enum.h>

NS_NICKEL_CLIENT_OPEN

struct HDMIStatus : NS_ZINC::Enum
{
	enum Enum
	{
		hs_disabled = 0,
		not_connected = 1,
		active_hdcp_off = 2,
		active_hdcp_failed = 3,
		active_hdcp_on = 4
	};
};


NS_NICKEL_CLIENT_CLOSE

#endif // NICKEL_HDMI_STATUS_H_
