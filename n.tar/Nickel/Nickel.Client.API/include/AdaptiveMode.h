/**
 * AdaptiveMode.h
 *
 *  Created on: 07 Feb 2012
 *      Author: morgan.henry@youview.com
 *
 * Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_ADAPTIVEMODE_H_
#define NICKEL_CLIENT_API_ADAPTIVEMODE_H_

#include "macros.h"
#include <zinc-common/Enum.h>

NS_NICKEL_CLIENT_OPEN


/**
 *
 * AdaptiveMode
 *
 * Constants for use with nickel::client::setBufferAdaptiveMode()
 *
 * @see nickel::client::setBufferAdaptiveMode
 * @see nickel::client::getBufferAdaptiveMode
 *
 */
struct AdaptiveMode : NS_ZINC::Enum
{
	/**
	 * The defined set of supported adaptive modes
	 *
	 * @see nickel::client::MediaRouter#setBufferAdaptiveMode()
	 *
	 * @since R9
	 */
	enum Enum {
		repeat = 0,
		waitfordecision = 1
	};

};

NS_NICKEL_CLIENT_CLOSE

#endif // NICKEL_CLIENT_API_ADAPTIVEMODE_H_

