/*
 * VideoConversions.h
 *
 *  Created on: May 16, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited
 */

#ifndef NICKEL_CLIENT_API_VIDEOCONVERSIONS_H_
#define NICKEL_CLIENT_API_VIDEOCONVERSIONS_H_

#include "macros.h"
#include <zinc-common/Enum.h>

NS_NICKEL_CLIENT_OPEN

struct Conversion_16_9_To_4_3 : NS_ZINC::Enum
{
	enum Enum
	{
		letterbox_14_9 = 0,
		letterbox_16_9 = 1,
		cutout_4_3 = 2
	};
};

struct Conversion_4_3_To_16_9 : NS_ZINC::Enum
{
	enum Enum
	{
		automatic = 0
	};
};

class ZINC_EXPORT VideoConversions
{
public:
    VideoConversions();

    VideoConversions(Conversion_4_3_To_16_9::Enum standardToWide, Conversion_16_9_To_4_3::Enum wideToStandard):
        _standardToWide(standardToWide), _wideToStandard(wideToStandard)
    {
    }

    Conversion_4_3_To_16_9::Enum getStandardToWide() const { return _standardToWide; }
    Conversion_16_9_To_4_3::Enum getWideToStandard() const { return _wideToStandard; }

    void setStandardToWide(Conversion_4_3_To_16_9::Enum standardToWide) { _standardToWide = standardToWide; }
    void setWideToStandard(Conversion_16_9_To_4_3::Enum wideToStandard) { _wideToStandard = wideToStandard; }

private:
    /**
     * Conversion to apply when presenting 4:3 video on a 16:9 display.
     */
    Conversion_4_3_To_16_9::Enum _standardToWide;

    /**
     * Conversion to apply when presenting 16:9 video on a 4:3 display.
     */
    Conversion_16_9_To_4_3::Enum _wideToStandard;
};

NS_NICKEL_CLIENT_CLOSE

#endif //NICKEL_CLIENT_API_VIDEOCONVERSIONS_H_
