/*
 * MediaSettings.h
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_MEDIASETTINGS_H_
#define NICKEL_CLIENT_API_MEDIASETTINGS_H_

#include "macros.h"
#include "MediaSettingsListener.h"
#include <zinc-common/DispatchingEventProducer.h>


NS_NICKEL_CLIENT_OPEN

/**
 * Gives access to the media-settings following a call of <code>Locator.getMediaSettings()</code>.
 * 
 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
 *
 * @see nickel::client::Locator#getMediaSettings()
 */
struct ZINC_EXPORT MediaSettings : virtual public NS_ZINC::DispatchingEventProducer<MediaSettingsListener>  {

	/**
	 * Gets the audio-description-enabled setting - set by the viewer in the main user-interface.
	 *
	 * @return True if audio-description is enabled
	 *
	 * @acl cp
	 */
	virtual bool getADEnabled() const = 0;

	/**
	 * @acl cp
	 */
	virtual void setADEnabled(bool value) = 0;

	/**
	 * @acl cp
	 */
	virtual bool getSubtitlesEnabled() const = 0;

	/**
	 * Sets the subtitles-enabled setting.
	 *
	 * This should only be used by a application to toggle subtitle state
	 * in response to receiving a Keyboard.SUBTITLE key press.
	 *
	 * For example:
	 * <pre>
	 * var mediaSettings:MediaSettings = Locator.getMediaSettings();
	 * if (event.keyCode == Keyboard.SUBTITLE)
	 *   {
	 *     var areSubtitlesEnabled:Boolean = mediaSettings.getSubtitlesEnabled();
	 *     mediaSettings.setSubtitlesEnabled(!areSubtitlesEnabled);
	 *   }
	 * </pre>
	 *
	 * @acl cp
	 */
	virtual void setSubtitlesEnabled(bool value) = 0;

	/**
	 * Gets the preferred audio-language - set by the viewer in the main user-interface.
	 *
	 * @return an ISO 639-2 language code.
	 *
	 * @acl cp
	 */
    virtual std::string getPreferredAudioLanguage() const = 0;

    virtual void setPreferredAudioLanguage(const std::string& value) = 0;

    /**
     * Gets the preferred subtitle-language setting - set by the viewer in the main user-interface.
	 *
	 * @return an ISO 639-2 language code.
	 *
     * @acl cp
     */
    virtual std::string getPreferredSubtitleLanguage() const = 0;

    virtual void setPreferredSubtitleLanguage(const std::string& value) = 0;

    virtual ~MediaSettings();

};	// class MediaSettings

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_API_MEDIASETTINGS_H_ */
