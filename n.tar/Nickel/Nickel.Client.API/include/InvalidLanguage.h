/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_InvalidLanguage_H_
#define NICKEL_CLIENT_InvalidLanguage_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * The language is invalid.
 */
struct ZINC_EXPORT InvalidLanguage : public std::runtime_error
{
	InvalidLanguage ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~InvalidLanguage() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_InvalidLanguage_H_ */
