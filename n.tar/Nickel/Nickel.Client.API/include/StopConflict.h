/**	@file	nickel-client-exceptions.h
 *
 *	@brief	exceptions.
 *	@author	mark.nicoll@youview.com
 *	@date	May 05 2011
 *
 *  Copyright (C) 2011 YouView Ltd
 */

#ifndef NICKEL_CLIENT_StopConflict_H_
#define NICKEL_CLIENT_StopConflict_H_

#include "macros.h"
#include <zinc-common/macros.h>
#include <stdexcept>

NS_NICKEL_CLIENT_OPEN

/**
 * A call failed because it was made when a MediaRouter was stopping.
 */
struct ZINC_EXPORT StopConflict : public std::runtime_error {

	StopConflict ();

	/** Explicit virtual destructor to control RTTI generation. */
	virtual ~StopConflict() throw();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_StopConflict_H_ */
