/*
 * VideoWindowDescriptor.h
 *
 *  Created on: July 9 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_VIDEOWINDOWDESCRIPTOR_H_
#define NICKEL_CLIENT_API_VIDEOWINDOWDESCRIPTOR_H_

#include "macros.h"
#include <stdint.h>
#include <zinc-common/Polymorphic.h>


NS_NICKEL_CLIENT_OPEN

/**
 * VideoWindowDescriptor describes a transformation that shall be applied to the selected video track of a MediaRouter’s
 * media. All co-ordinates are relative where a region of {0.0, 0.0, 1.0, 1.0} represents the entire picture or the
 * entire screen. The origin of the coordinate system is the top-left of the screen.
 *
 * <p>VideoWindowDescriptor - an eight field data object holding :</p>
 * <ul>
 * <li><strong>sourceX</strong> - The horizontal origin of the region of the video picture that is to be displayed. </li>
 * <li><strong>sourceY</strong> - The vertical origin of the region of the video picture that is to be displayed. </li>
 * <li><strong>sourceWidth</strong> - The width of the region of the video picture that is to be displayed.</li>
 * <li><strong>sourceHeight</strong> - The height of the region of the video picture that is to be displayed.</li>
 * <li><strong>destinationX</strong> - The horizontal origin of the screen region into which the source should be mapped. </li>
 * <li><strong>destinationY</strong> - The vertical origin of the screen region into which the source region should be mapped. </li>
 * <li><strong>destinationWidth</strong> - The width of the screen region into which the source region should be mapped.</li>
 * <li><strong>destinationHeight</strong> - The height of the screen region into which the source region should be mapped. </li>
 * </ul>
 *
 * The VideoWindow is initialised to: {  0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0 }
 *
 * <p>When the source-region is set to <code>{ 0.0, 0.0, 0.5, 0.5 }</code> and the destination-region is
 * set to <code>{ 0.0, 0.0, 1.0, 1.0 }</code> - only the upper-left quarter of the source (the media) is shown on the
 * whole of the destination (the screen).</p>
 *
 * <p><strong>The range of values that can be assigned to each member of videoWindow are as follows:</strong></p>
 * <ul>
 * <li><strong>sourceX</strong> - minimum <code>0.0</code>, maximum <code>1.0</code> </li>
 * <li><strong>sourceY</strong> - minimum <code>0.0</code>, maximum <code>1.0</code> </li>
 * <li><strong>sourceWidth</strong> - minimum greater-than <code>0.0</code>, maximum <code>1.0</code> </li>
 * <li><strong>sourceHeight</strong> - minimum greater-than <code>0.0</code>, maximum <code>1.0</code> </li>
 * <li><strong>destinationX</strong> - none </li>
 * <li><strong>destinationY</strong> - none </li>
 * <li><strong>destinationWidth</strong> - minimum <code>0.0</code> maximum <code>sourceWidth</code></li>
 * <li><strong>destinationHeight</strong> - minimum <code>0.0</code> maximum <code>sourceHeight</code></li>
 * </ul>
 *
 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
 *
 * @see nickel::client::MediaRouter#getVideoWindow()
 * @see nickel::client::MediaRouter#setVideoWindow()
 *
 */
struct ZINC_EXPORT VideoWindowDescriptor : virtual public NS_ZINC::Polymorphic {

public:

    /**
     * @return the horizontal origin of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    double getSourceX() { return sourceX; }

    /**
     * @return the vertical origin of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    double getSourceY() { return sourceY; }

    /**
     * @return the width of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    double getSourceWidth() { return sourceWidth; }

    /**
     * @return the height of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    double getSourceHeight() { return sourceHeight; }

    /**
     * @return the horizontal origin of the screen region into which the source should be mapped.
     *
     * @acl cp
     */
    double getDestinationX() { return destinationX; }

    /**
     * @return the vertical origin of the screen region into which the source region should be mapped.
     *
     * @acl cp
     */
    double getDestinationY() { return destinationY; }

    /**
     * @return the width of the screen region into which the source region should be mapped.
     *
     * @acl cp
     */
    double getDestinationWidth() { return destinationWidth; }

    /**
     * @return the height of the screen region into which the source region should be mapped.
     *
     * @acl cp
     */
    double getDestinationHeight() { return destinationHeight; }

    /**
     * @param sourceX_ - the horizontal origin of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    void setSourceX(const double sourceX_) { sourceX = sourceX_; }

    /**
     * @param sourceY_ - the vertical origin of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    void setSourceY(const double sourceY_) { sourceY = sourceY_; }

    /**
     * @param sourceWidth_ - the width of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    void setSourceWidth(const double sourceWidth_) { sourceWidth = sourceWidth_; }

    /**
     * @param sourceHeight_ - the height of the region of the video picture that is to be displayed.
     *
     * @acl cp
     */
    void setSourceHeight(const double sourceHeight_) { sourceHeight = sourceHeight_; }

    /**
     * @param destinationX_ - the horizontal origin of the screen region into which the source should be mapped.
     *
     * @acl cp
     */
    void setDestinationX(const double destinationX_) { destinationX = destinationX_; }

    /**
     * @param destinationY_ - the vertical origin of the screen region into which the source region should be mapped.
     *
     * @acl cp
     */
    void setDestinationY(const double destinationY_) { destinationY = destinationY_; }

    /**
     * @param destinationWidth_ - the width of the screen region into which the source region should be mapped.
     *
     * @acl cp
     */
    void setDestinationWidth(const double destinationWidth_) { destinationWidth = destinationWidth_; }

    /**
     * @param destinationHeight_ - the height of the screen region into which the source region should be mapped.
     *
     * @acl cp
     */
    void setDestinationHeight(const double destinationHeight_) { destinationHeight = destinationHeight_; }

    virtual ~VideoWindowDescriptor();

private:

    double sourceX;
    double sourceY;
    double sourceWidth;
    double sourceHeight;
    double destinationX;
    double destinationY;
    double destinationWidth;
    double destinationHeight;
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_API_VIDEOWINDOWDESCRIPTOR_H_ */
