/*
 * GraphicResolution.h
 *
 *  Created on: May 16, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2010 YouView TV Limited
 */

#ifndef NICKEL_CLIENT_API_GRAPHICRESOLUTION_H_
#define NICKEL_CLIENT_API_GRAPHICRESOLUTION_H_

#include "macros.h"
#include <stdint.h>

NS_NICKEL_CLIENT_OPEN

class ZINC_EXPORT GraphicsResolution
{
public:
    GraphicsResolution();

    GraphicsResolution(uint32_t width, uint32_t height):
        _width(width), _height(height)
    {
    }

    uint32_t getWidth() const { return _width; }
    uint32_t getHeight() const { return _height; }

private:
    uint32_t _width;
    uint32_t _height;
};

NS_NICKEL_CLIENT_CLOSE

#endif // NICKEL_CLIENT_API_GRAPHICRESOLUTION_H_
