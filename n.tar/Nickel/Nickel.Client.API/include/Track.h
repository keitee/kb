/*
 * Track.h
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_TRACK_H_
#define NICKEL_CLIENT_API_TRACK_H_

#include <stdint.h>
#include <string>

#include <zinc-common/Polymorphic.h>
#include <zinc-common/Enum.h>

#include "macros.h"

NS_NICKEL_CLIENT_OPEN


struct TrackFormat : NS_ZINC::Enum {

	/**
	 * The defined set of track-format values.
	 * 
	 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
	 *
	 * @see nickel::client::Track#getFormat()
	 * @see nickel::client::TrackType::Enum
	 */
	enum Enum {
		/**
		 * The format of the track is not one of the ones represented in TrackFormat.
		 */
		other = 0,
		/**
		 * MPEG-1 layer II audio.
		 */
		audio_mpeg1l2 = 100,
		/**
		 * MPEG-1 layer III audio.
		 */
		audio_mpeg1l3 = 101,
		/**
		 * E-AC3 audio.
		 */
		audio_eac3 = 102,
		/**
		 * HE-AAC audio.
		 */
		audio_heaac = 103,
		/**
		 * MPEG-2 video.
		 */
		video_mpeg2 = 200,
		/**
		 * H.264 / AVC video.
		 */
		video_h264 = 201,
		/**
		 * H.265 / HEVC video.
		 */
		video_h265 = 202,
		/**
		 * DVB subtitles.
		 */
		subtitle_dvb = 300,
		/**
		 * Timed-text subtitles.
		 */
		subtitle_ttml = 301,
	};
};

struct TrackType : NS_ZINC::Enum {

	/**
	 * The defined set of track-type values.
	 *
	 * @see nickel::client::Track#getType()
	 */
	enum Enum {
		/**
		 * Audio.
		 */
		audio = 0,
		/**
		 * Video.
		 */
		video = 1,
		/**
		 * Subtitle.
		 */
		subtitle = 2,
	};
};


struct TrackUsage : NS_ZINC::Enum {

	/**
	 * The defined set of track-usage values.
	 *
	 * @see nickel::client::Track#getUsage()
	 * @see nickel::client::Track#getType()
	 */
	enum Enum {
		/**
		 */
		undefined = 0,
		/**
		 * An audio track containing programme sound.
		 */
		audio_normal = 100,
		/**
		 * An audio track containing receiver-mix audio description.
		 */
		audio_description = 101,
		/**
		 * Indicates an audio track that contains broadcast-mix audio description.
		 */
		audio_description_premixed = 102,
		/**
		 * An audio track containing subtitles.
		 */
		subtitle_normal = 300,

		/**
		 * An audio track containing subtitles for hard-of-hearing.
		 */
		subtitle_hard_of_hearing = 301,
	};
};


/**
 * Track - a five field data object holding the metadata values of the source (the media) associated with the MediaRouter.
 *
 * <p>Track - a five field data object holding :</p>
 * <ul>
 * <li><strong>format</strong> - the <code>TrackFormat</code> </li>
 * <li><strong>tag</strong> - an identifier for the <code>Track</code></li>
 * <li><strong>language</strong> - the ISO 639-2 language code </li>
 * <li><strong>type</strong> - the <code>TrackType</code> </li>
 * <li><strong>usage</strong> - the <code>TrackUsage</code> </li>
 * </ul>
 *
 * <p>A MediaRouter will have a list containing at least one, but likely several, <code>Track</code> structures
 * since it requires one for the video, one for the audio, and one for each supported language. Each of the
 * created subtitle <code>Track</code> structures will have the same tag value, but will have different language values.
 * The implication of this is that single subtitle tracks, within the tracks list, are identifiable by their tag. But when there are 
 * more than one track they are identifiable by their language. Whereas audio and video tracks are only ever identifiable by their tag.</p>
 *
 * @see nickel::client::TrackFormat::Enum
 * @see nickel::client::TrackType::Enum
 * @see nickel::client::TrackUsage::Enum
 *
 * @see nickel::client::MediaRouter#getTracks()
 * @see nickel::client::MediaRouter#getAudioTrack()
 * @see nickel::client::MediaRouter#setAudioTrack()
 * @see nickel::client::MediaRouter#getVideoTrack()
 * @see nickel::client::MediaRouter#setVideoTrack()
 * @see nickel::client::MediaRouter#getSubtitleTrack()
 * @see nickel::client::MediaRouter#setSubtitleTrack()
 * @see nickel::client::MediaRouter#addSubtitleTrack()
 *
 * @if AS3 @includeExample AddTrackExample.as@endif
 */
class ZINC_EXPORT Track : virtual public NS_ZINC::Polymorphic {

public:
    Track() : tag(0), format(TrackFormat::other), type(TrackType::audio), usage(TrackUsage::undefined) {}

public:

    /**
     * Gets the <code>Tag</code>.
	 *
	 * <p>For information about how <code>Tag</code> values are generated or assigned see [[IP Content Delivery specification]].</p>
	 *
	 * @return the <code>Tag</code>.
	 *
     * @acl cp
     */
    int32_t getTag() const { return tag; }

    /**
     * Gets the ISO 639-2 language code.
	 *
	 * @return the ISO 639-2 language code.
	 *
     * @acl cp
     */
    const std::string& getLanguage() const { return language; }

    /**
     * Gets the <code>TrackFormat</code>.
	 *
	 * @return the <code>TrackFormat</code>.
	 *
	 * @see nickel::client::TrackFormat::Enum
	 *
     * @acl cp
     */
    TrackFormat::Enum getFormat() const { return format; }

    /**
     * Gets the <code>TrackType</code>.
	 *
	 * @return the <code>TrackType</code>.
	 *
	 * @see nickel::client::TrackType::Enum
	 *
     * @acl cp
     */
    TrackType::Enum getType() const { return type; }

    /**
     * Gets the <code>TrackUsage</code>.
	 *
	 * @return the <code>TrackUsage</code>.
	 *
	 * @see nickel::client::TrackUsage::Enum
	 *
     * @acl cp
     */
    TrackUsage::Enum getUsage() const { return usage; }


    void setTag(int32_t value) { tag = value; }

    void setLanguage(const std::string& value) { language = value; }

    void setFormat(TrackFormat::Enum value) { format = value; }

    void setType( TrackType::Enum value) { type = value; }

    void setUsage(TrackUsage::Enum value) { usage = value; }

    virtual ~Track();

private:

    int32_t tag;
    std::string language;
    TrackFormat::Enum format;
    TrackType::Enum type;
    TrackUsage::Enum usage;

}; // class Track

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_TRACK_H_ */
