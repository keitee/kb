/*
 * MediaRouter.h
 *
 * Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_MEDIA_ROUTER_H_
#define NICKEL_CLIENT_MEDIA_ROUTER_H_

#include "macros.h"
#include "BufferConstraint.h"
#include "AdaptiveMode.h"
#include "ABRStatus.h"
#include "ABRStreamSet.h"
#include "BufferStatus.h"
#include "Track.h"
#include "Position.h"
#include "ControlCapabilities.h"
#include "VideoWindowDescriptor.h"
#include "MediaRouterEventListener.h"
#include "SetSourceReason.h"
#include <zinc-common/DispatchingEventProducer.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/Enum.h>
#include <boost/shared_ptr.hpp>
#include <vector>
#include <map>
#include <string>


NS_NICKEL_CLIENT_OPEN


struct SeekReference : NS_ZINC::Enum {

	/**
	 * The defined set of position values from which a seek-offset is calculated.
	 *
	 * @see nickel::client::MediaRouter#seekPosition()
	 */
	enum Enum {

		/**
		 * Offset from start-time.
		 */
		sr_start = 0,
		/**
		 * Offset from play-position.
		 */
		sr_current = 1,
		/**
		 * Offset from end-time.
		 */
		sr_end = 2,

	};
};


struct SeekMode : NS_ZINC::Enum {

	/**
	 * The defined set of seek-modes.
	 *
	 * @see nickel::client::MediaRouter#seekPosition()
	 */
	enum Enum {
		/**
		 * Prioritises positional accuracy over speed in a call of <code>MediaRouter.seekPosition()</code>.
		 *
		 * <p>If the seek-position parameter doesn't correspond exactly to the presentation-time of a frame,
		 * playback will resume from the next frame. </p>
		 *
		 * <p>If that frame is not a valid random-access point within the media, then the MediaRouter may be required to
		 * decode preceeding frames from a previous valid random-access point, without outputting them to the display, until
		 * the requested frame is reached.</p>
		 *
		 * @see nickel::client::MediaRouter#seekPosition()
		 */
		prioritise_accuracy = 0,
		/**
		 * Prioritises speed over positional accuracy in a call of <code>MediaRouter.seekPosition()</code>.
		 *
		 * <p>Playback will resume from the closest random-access point to the seek-position parameter.</p>
		 *
		 * <p>If the MediaRouter does not 'know' about the random-access points in the source it will
		 * calculate a best-effort approximation. </p>
		 *
		 * @see nickel::client::MediaRouter#seekPosition()
		 *
		 */
		prioritise_speed = 1,

	};
};


struct VideoTerminationMode : NS_ZINC::Enum {

	/**
	 * The video-termination modes specify the behaviour of the MediaRouter when playback ends because play-position
	 * and end-time are equal, or when play-position reaches the end of the media.
	 *
	 * @see nickel::client::MediaRouter#getVideoTerminationMode()
	 * @see nickel::client::MediaRouter#setVideoTerminationMode()
	 *
	 */
	enum Enum {
		/**
		 * The last displayed frame is held at the display until either (a) this MediaRouter restarts playback,
		 * (b) this MediaRouter blanks the video output, or (c) another MediaRouter starts playback of video
		 */
		freeze = 0,
		/**
		 * The last-frame of the source will be replaced by a black-frame.
		 *
		 * <p>The black-frame will be shown 1/frame_rate seconds after the last displayed frame is shown. The
		 * black-frame will be shown until until this MediaRouter restarts playback or another MediaRouter starts playing.</p>
		 */
		disappear = 1,
	};
};

struct TimeShiftCaptureMode : NS_ZINC::Enum {

	enum Enum {
		disabled = 0,
		enabled = 1,
	};
};


/**
 * The main playback mechanism on the YouView platform.
 *
 * <p>The MediaRouter component provides means to control the acquisition and presentation of A/V media. Although MediaRouter has other capabilities,
 * this documentation details only those related to on-demand content provision.
 * In many scenarios, only a single MediaRouter instance will be required. However, multiple MediaRouter instances may exist concurrently
 * to support more challenging use cases such as ad-insertion.</p>
 * 
 * <p>Instances of the MediaRouter may be created using the <code>MediaRouterFactory</code> interface, each instance maintains its own
 * independent state. Device manufacturers may limit the number of MediaRouters that can be in simultaneous existence. In this case,
 * devices shall support at least eight simultaneous MediaRouter instances.</p>
 * 
 * <p>Note: This interface is NOT intended to be implemented directly by 3rd party applications.</p>
 *
 * <p>A UID is assigned to each MediaRouter when it is created by <code>MediaRouterFactory.createMediaRouter()</code>.</p>
 *
 * @if AS3
 * @includeExample PlayPauseExample.as
 * @includeExample SequencePreBufferExample.as
 * @endif
 *
 * @see nickel::client::VideoTerminationMode::Enum
 * @see nickel::client::BufferStatus
 * @see nickel::client::Track
 * @see nickel::client::VideoWindowDescriptor
 * @see nickel::client::ControlCapabilities
 */
struct ZINC_EXPORT MediaRouter : virtual public NS_ZINC::DispatchingEventProducer<MediaRouterEventListener> {

	/**
	 * Sets the source.
	 *
	 * <p>For more information about valid source-locators please see [[1125-S MediaRouter.doc]]</p>
	 *
	 * @param mediaLocator a mediaLocator.
	 * @param reason the reason for setting the source change.
	 *
	 * @throws 	nickel::client::InvalidLocator the <code>mediaLocator</code> is invalid.
	 * @throws 	nickel::client::InvalidEnumeration the reason parameter is not a member of the <code>SetSourceReason</code>
	 * 			enumerated type.
	 * @throws 	nickel::client::IllegalReconfiguration MediaRouter on-demand source is already configured and cannot be changed.
	 * @throws  nickel::client::InsufficientResources The number of extant MediaRouter instances with a set source is already at the
	 *          maximum supported by the device.
	 *
	 *
	 * @if AS3 @includeExample MediaRouterSetSource.as@endif
	 *
	 * @see nickel::client::MediaRouter
	 * @see nickel::client::SourceEventValue::Enum
	 * @see nickel::client::SetSourceReason::Enum
	 * @see nickel::client::MediaRouterEventListener#ErrorEvent()
	 * @see nickel::client::ErrorEventValue::Enum#locator
	 * @see nickel::client::ErrorEventContext::Enum#source
	 *
	 * @acl cp
	 */
    virtual void setSource(const std::string& mediaLocator, const SetSourceReason::Enum reason) = 0;

    /**
     * Gets the media source previously set via setSource().
	 *
	 * @return the media source.
	 *
	 * @see nickel::client::MediaRouter#setSource()
	 *
     * @acl cp
     */
    virtual std::string getSource() const = 0;

    /**
     * Sets the volume.
	 *
	 * Relative volume in dB for this MediaRouter. 0 dB represents maximum volume and is the default.
	 * Negative values attenuate the audio. All negative values are valid.
	 * A value of -200 dB or less is sufficient to completely mute the audio.
	 *
	 * Volume is relative to the System volume.
	 *
	 * @param volume the volume
	 *
	 * @throws nickel::client::OutOfBounds volume &gt; 0dB.
	 *
	 * @if AS3 @includeExample MediaRouterSetVolume.as@endif
	 *
	 * @see nickel::client::MediaRouter
	 * @see nickel::client::MediaRouter#getVolume()
	 * @see nickel::client::MediaRouterEventListener#ErrorEvent()
	 * @see nickel::client::ErrorEventValue::Enum
	 * @see nickel::client::ErrorEventContext::Enum
	 *
     * @acl cp
     */
    virtual void setVolume(const int32_t volume) = 0;

    /**
     * Gets the volume.
	 *
	 * @return the volume.
	 *
	 * @see nickel::client::MediaRouter
	 * @see nickel::client::MediaRouter#setVolume()
     *
     * @acl cp
     */
    virtual int32_t getVolume() const = 0;

    /**
     *
	 * Sets the audio-track.
	 *
	 * <p>Possible values for the <code>audioTrack</code> parameter value are:</p>
	 *
	 * <ul>
	 * <li><strong>tag-id</strong> - a tag-id relating to a valid audio-track (see <code>Track.getTag()</code>)</li>
	 * <li><strong>-1</strong> - the default audio-track will be played</li>
	 * <li><strong>-2</strong> - no audio-track will be played.</li>
	 * </ul>
	 *
	 * @param audioTrack the tag of the audio-track to set
	 *
	 * @throws nickel::client::InvalidTag tag &lt; <code>-2</code>.
	 *
	 * @if AS3 @includeExample MediaRouterSetAudioTrack.as@endif
	 *
	 * @see nickel::client::Track
	 * @see nickel::client::MediaRouter#getAudioTrack()
	 * @see nickel::client::MediaRouter#getTracks()
	 * @see nickel::client::Track#getTag()
	 *
     * @acl cp
     */
    virtual void setAudioTrack(const int32_t audioTrack) = 0;

    virtual void setAudioTrackExternal(const std::string& mediaLocator,const int32_t tag) = 0;

    /**
	 * Gets a Track structure describing the currently selected audio track.
	 *
	 * @return A unique tag reference to an audio-track.
	 *
	 * @see nickel::client::MediaRouter#setAudioTrack()
	 * @see nickel::client::MediaRouter#getTracks()
	 * @see nickel::client::Track#getTag()
	 *
     * @acl cp
     */
    virtual boost::shared_ptr<Track> getAudioTrack() const = 0;

    /**
     * Sets the video-track.
	 *
	 * <p>Required behaviour regarding track selection is further documented in section 7 of [[1125-s MediaRouter.doc]].</p>
	 *
	 * @param videoTrack the tag of the video-track - <code>-1</code> for the default video-track,
	 * <code>-2</code> for no track.
	 *
	 * @throws nickel::client::InvalidTag Tag &lt; -2
	 *
	 * @see nickel::client::Track
	 * @see nickel::client::MediaRouter#getVideoTrack()
	 * @see nickel::client::MediaRouter#getTracks()
	 * @see nickel::client::Track#getTag()
	 *
     * @acl cp
     */
    virtual void setVideoTrack(const int32_t videoTrack) = 0;

    virtual void setVideoTrackExternal(const std::string& mediaLocator,const int32_t tag) = 0;

    /**
     * Gets a Track structure describing the currently selected video track.
	 *
	 * <ul>
	 * <li>If a specific track is selected and exists in the tracks list at call time, this method shall return
	 * a Track structure describing the selected track.</li>
	 *
	 * </ul>
	 *
	 * @return a Track structure describing the currently selected video track.
	 *
	 * @see nickel::client::Track
	 * @see nickel::client::MediaRouter#setVideoTrack()
	 * @see nickel::client::MediaRouter#getTracks()
	 * @see nickel::client::Track#getTag()
	 *
     * @acl cp
     */
    virtual boost::shared_ptr<Track> getVideoTrack() const = 0;

    /**
     * Sets subtitle-track and subtitle-language. Together these determine which subtitle track will be presented when subtitles are enabled.
	 * 
	 * <p>Note: Setting a subtitle track will not lead to presentation of subtitles if they are currently disabled.</p>
	 *
	 * <p>The table summarises the outcome of calling this method with the possible combinations
	 * of tag and language values.</p>
	 * <table class="innertable">
	 *   <tr>
	 *     <th>tag</th>
	 *     <th>language</th>
	 *     <th>Meaning</th>
	 *   </tr>
	 *   <tr>
	 *     <td>-2</td>
	 *     <td>Not specified</td>
	 *     <td>No subtitle track should be presented.</td>
	 *   </tr>
	 *   <tr>
	 *     <td>-2</td>
	 *     <td>Specified</td>
	 *     <td>This combination of parameters is not allowed. It shall result in an InvalidLanguage error being thrown.</td>
	 *   </tr>
	 *   <tr>
	 *     <td>-1</td>
	 *     <td>Not specified</td>
	 *     <td>Select the default subtitle track.</td>
	 *   </tr>
	 *   <tr>
	 *     <td>-1</td>
	 *     <td>Specified</td>
	 *     <td>This combination of parameters is not allowed. It shall result in an InvalidLanguage error being thrown.</td>
	 *   </tr>
	 *   <tr>
	 *     <td>&gt;= 0</td>
	 *     <td>Not specified</td>
	 *     <td>Select the first subtitle track with the specified tag.</td>
	 *   </tr>
	 *   <tr>
	 *     <td>&gt;= 0</td>
	 *     <td>Specified</td>
	 *     <td>Select the subtitle track with the specified tag and language.</td>
	 *   </tr>
	 * </table>
	 *
	 * @param tagValue.
	 * @param languageCode.
	 *
	 * @throws nickel::client::InvalidTag Tag &lt; -2.
	 * @throws nickel::client::InvalidLanguage Either;
	 * <ul>
	 *   <li>language is not a valid ISO 639-2 language code.</li>
	 *   <li>tag is -1 and language is not an empty string.</li>
	 *   <li>tag is -2 and language is not an empty string.</li>
	 * </ul>
	 *
	 * @see nickel::client::Track
	 * @see nickel::client::TrackType::Enum
	 * @see nickel::client::MediaRouter#getSubtitleTrack()
	 * @see nickel::client::MediaRouter#addSubtitleTrack()
	 * @see nickel::client::MediaRouter#getTracks()
	 * @see nickel::client::Track#getTag()
	 * @see nickel::client::Track#getLanguage()
	 *
     * @acl cp
     */
    virtual void setSubtitleTrack(const int32_t tagValue,const std::string& languageCode) = 0;

    /**
     * Gets the subtitle-track.
	 * 
	 * <p>Gets a Track structure describing the currently selected subtitle track.</p>
	 *
	 * <ul>
	 * <li>If a specific track is selected and exists in the tracks list at call time, this method will
	 * return a <code>Track</code> structure representing the selected track.</li>
	 * <li>If the default track is selected and exists in the tracks list at call time, this method will return
	 * a <code>Track</code> structure representing the actual track ; it will not return a Track which will have a tag-id
	 * value of -1. This value is only used to <em>set</em> the media's subtitles to the default track (see
	 * <code>MediaRouter.setSubtitleTrack()</code>).</li>
	 * <li>If an external subtitle track is selected and information about it exists at call time, this method will
	 * return a <code>Track</code> structure representing the selected track, which will have a tag-id value of -3.</li>
	 * </ul>
	 *
	 * @return the SUBTITLE <code>Track</code>.
	 *
	 * @see nickel::client::Track
	 * @see nickel::client::TrackType::Enum
	 * @see nickel::client::MediaRouter#setSubtitleTrack()
	 * @see nickel::client::MediaRouter#addSubtitleTrack()
	 * @see nickel::client::MediaRouter#getTracks()
	 *
     * @acl cp
     */
    virtual boost::shared_ptr<Track> getSubtitleTrack() const = 0;

    /**
     * Adds an external subtitle-track to the list of tracks available to the MediaRouter.
	 *
	 * @param subtitleLocator URL for the timed-text subtitle file.
	 *
	 * @return the tag of the subtitle-track.
	 *
	 * @throws nickel::client::InvalidLocator SubtitleLocator is not a valid URL.
	 *
	 * @if AS3 @includeExample MediaRouterAddSubtitleTrack.as@endif
	 *
	 * @see nickel::client::MediaRouter#getSubtitleTrack()
	 * @see nickel::client::MediaRouter#setSubtitleTrack()
	 * @see nickel::client::MediaRouter#getTracks()
	 * @see nickel::client::SourceEventValue::Enum#tracks_changed
	 * @see nickel::client::Track#getTag()
     *
     * @acl cp
     */
    virtual int32_t addSubtitleTrack(const std::string& subtitleLocator) = 0;

    /**
     * Gets a set of Tracks currently available in the media. This includes any tracks added by <code>MediaRouter.addSubtitleTrack()</code>.
	 *
	 * @return the set of Tracks as an array of <code>Track</code> structures.
	 *
	 * @if AS3 @includeExample MediaRouterGetTracks.as@endif
	 *
	 * @see nickel::client::MediaRouter#addSubtitleTrack()
	 * @see nickel::client::MediaRouter#getSubtitleTrack()
	 * @see nickel::client::MediaRouter#setSubtitleTrack()
	 * @see nickel::client::Track
     *
     * @acl cp
     */
    virtual boost::shared_ptr<std::vector<boost::shared_ptr<Track> > > getTracks() const = 0;

    /**
	 * Sets the <code>VideoWindowDescriptor</code>.
	 *
	 * @param videoWindow the <code>VideoWindowDescriptor</code>.
	 *
	 * @throws nickel::client::OutOfBounds a value of the <code>VideoWindowDescriptor</code> is out-of-bounds.
	 *
	 * @see nickel::client::MediaRouter#getVideoWindow()
	 * @see nickel::client::VideoWindowDescriptor
	 *
     * @acl cp
     */
    virtual void setVideoWindow(boost::shared_ptr<VideoWindowDescriptor> videoWindow) = 0;

    /**
	 * Gets the <code>VideoWindowDescriptor</code>.
	 *
	 * @return the <code>VideoWindowDescriptor</code>.
	 *
	 * @if AS3 @includeExample MediaRouterGetVideoWindow.as@endif
	 *
	 * @see nickel::client::MediaRouter#setVideoWindow()
	 * @see nickel::client::VideoWindowDescriptor
	 *
     * @acl cp
     */
    virtual boost::shared_ptr<VideoWindowDescriptor> getVideoWindow() const = 0;

    /**
     *
	 * Sets the new play-speed.
	 *
	 * setPlaySpeed(playSpeed) is typically used to pause <code>setPlaySpeed(0)</code> and then resume <code>setPlaySpeed(1)</code> playback.
	 *
	 * Additional ranges of speeds maybe supported by certain hardware. See <code>ctv.media.ControlCapabilities</code>
	 *
	 * <p>If the parameter is not a play-speed supported by the MediaRouter, the play-speed will be set
	 * to the closest play-speed supported by the MediaRouter. If the parameter is not a play-speed supported by the
	 * MediaRouter and the parameter lies exactly between two play-speeds supported by the MediaRouter, the
	 * play-speed will be 'rounded-up' and set to the next-fastest play-speed supported by the MediaRouter.</p>
	 *
	 *
	 * @param playSpeed the new play-speed.
	 *
	 * @includeExample MediaRouterSetPlaySpeed.as
	 *
	 * @see nickel::client::MediaRouterEventListener#SpeedChangeEvent
	 * @see nickel::client::MediaRouter#getPlaySpeed()
	 * @see nickel::client::ControlCapabilities
	 *
     * @acl cp
     */
    virtual void setPlaySpeed(const double speed) = 0;

	/**
	 * Gets the play-speed. Normal playback speed is 1.0, paused-playback is 0.
	 *
	 * @return the play-speed.
	 *
	 * @see nickel::client::MediaRouter#setPlaySpeed()
	 *
     * @acl cp
     */
    virtual double getPlaySpeed() const = 0;

    /**
     * Sets a new play-position.
	 *
	 * @param whence the <code>SeekReference</code> origin from which the new play-position is calculated.
	 * @param offset the milliseconds, from the origin, to the new play-position.
	 * @param mode SeekMode the preferred <code>SeekMode</code>.
	 *
	 * @throws nickel::client::NotConfigured 		 The MediaRouter has not yet been configured so cannot be seeked.
	 * @throws nickel::client::StopConflict 		 The MediaRouter is in the process of stopping.
	 * 								 calling <code>MediaRouter.setMediaDuration()</code>.
	 * @throws nickel::client::IllegalSeek  		 The Media-duration is 0 so seek is not allowed. Media-duration can be set by <code>setMediaDuration()</code>.
	 * @throws nickel::client::InvalidEnumeration  <code>SeekReference</code> and/or <code>SeekMode</code> parameters are not a valid
	 *
	 * @if AS3 @includeExample MediaRouterSeekPosition.as
	 * @includeExample MediaRouterSeekPosition2.as@endif
	 *
	 * @see nickel::client::SeekReference::Enum
	 * @see nickel::client::SeekMode::Enum
	 * @see nickel::client::StatusEventValue::Enum
	 * @see nickel::client::MediaRouter#setMediaDuration()
	 *
     * @acl cp
     */
    virtual void seekPosition(const SeekReference::Enum whence,const int32_t offset, const SeekMode::Enum mode) = 0;

    /**
     * Gets the <code>Position</code>.
	 *
	 * @return the <code>Position</code>.
	 *
	 * @if AS3 @includeExample MediaRouterGetPosition.as@endif
	 *
	 * @see nickel::client::Position
	 * @see nickel::client::MediaRouterEventListener#PositionChangeEvent()
	 *
     * @acl cp
     */
    virtual boost::shared_ptr<Position> getPosition() const = 0;

    /**
     * Sets the Uniform Resource Identifier (URI) of a MediaRouter's sink. For on-demand content this 
	 * value should be set as <code>decoder://0</code>.
	 *
	 * @param mediaLocator the sink.
	 *
	 * @throws nickel::client::InvalidLocator
	 * <ul>
	 * <li>sink is malformed.</li>
	 * <li>sink does not identify a valid system resource.</li>
	 * </ul>
	 *
	 * @throws nickel::client::IllegalReconfiguration sink has already been set.
	 *
	 * @see nickel::client::MediaRouter#getSink()
	 *
     * @acl cp
     */
    virtual void setSink(const std::string& mediaLocator) = 0;

    /**
     * Gets the mediaLocator of the sink.
	 *
	 * @return the mediaLocator of the sink.
	 *
	 * @see nickel::client::MediaRouter#setSink()
	 *
     * @acl cp
     */
    virtual std::string getSink() const = 0;

    /**
     * Sets the end-time in milliseconds.
	 *
	 * <p>This method repositions the end-time of the source. The MediaRouter will stop playback at this new end-time
	 * and generate a StatusEvent with the value StatusEventValue.COMPLETE .</p>
	 *
	 * This does not affect the values returned by <code>Position#getEnd()</code> or <code>MediaRouter#getMediaDuration()</code>
	 *
	 * <p>To find out more about the effects on <code>MediaRouter</code> of redefining the play-region please view the <a href="http://devzone.youview.com/developers/development/media-playback/mediarouter-tutorials/mediarouter-playlist-and-ad-insertion-guide/">MediaRouter Ad-Insertion Guide</a>.</p>
	 *
	 * @param endTime the new end-time.
	 *
	 * @throws nickel::client::StopConflict the MediaRouter is in the process of stopping so a new end-time cannot be set.
	 *
	 * @see nickel::client::MediaRouter#getEndTime()
	 *
     * @acl cp
     */
    virtual void setEndTime(const int32_t endTime) = 0;

    /**
     * Gets the end-time in milliseconds.
	 *
	 * @return the end-time.
	 *
	 * @see nickel::client::MediaRouter#setEndTime()
	 *
     * @acl cp
     */
	virtual int32_t getEndTime() const = 0;

	/**
	 * Starts playback. We recommend waiting for a SourceEventValue.source_config_complete event prior to calling start on a MediaRouter, as shown in the example below.
	 *
	 * @if AS3
	 * @includeExample SourceConfigCompleteExample.as
	 * @endif
	 *
	 * @throws nickel::client::NotConfigured 	The MediaRouter has not yet been configured.
	 * @throws nickel::client::PlayConflict 	Another MediaRouter with the same sink is currently in the Active.
	 * @throws nickel::client::StopConflict 	The MediaRouter is currently in the process of stopping.
	 *
	 * @acl cp
	 */
    virtual void start() = 0;

    /**
     * Instructs a MediaRouter to begin playing as soon as it can.
	 *
	 * <p>The MediaRouter will only defer starting if another MediaRouter with the same sink is Active.</p>
	 *
	 * @throws nickel::client::NotConfigured 	The MediaRouter has not yet been configured.
	 * @throws nickel::client::PlayConflict 	Another MediaRouter with the same sink is currently in the Active state and
	 * 									a second is already in the waiting state.
	 * @throws nickel::client::StopConflict 	The MediaRouter is currently in the process of stopping.
	 *
	 * @see	nickel::client::MediaRouter#setSink()
	 *
     * @acl cp
     */
	virtual void startDeferred() = 0;

	/**
	 * Gets the <code>ControlCapabilities</code>.
	 *
	 * @return the <code>ControlCapabilities</code>.
	 *
	 * @if AS3 @includeExample MediaRouterGetControlCapabilities.as@endif
	 *
	 * @see nickel::client::ControlCapabilities
	 *
	 * @acl cp
	 */
    virtual boost::shared_ptr<ControlCapabilities> getControlCapabilities() const = 0;

    /**
     * Stops playback.
	 *
	 * <p>This method stops playback and/or buffering under the following conditions :</p>
	 * <ul>
	 * <li>Stops playback - when the source is not being buffered OR when source buffering is complete </li>
	 * <li>Stops playback AND buffering - when the source is being played and being buffered </li>
	 * <li>Stops buffering - when playback is stopped AND the source is being buffered </li>
	 * </ul>
	 *
	 * <p><strong>Note :</strong>Stop will always blank the video.</p>
	 *
	 * @see	nickel::client::MediaRouter#start()
	 * @see	nickel::client::MediaRouter#setPlaySpeed()
	 *
     * @acl cp
     */
    virtual void stop() = 0;

    /**
     * This is an asynchronous version of stop().
     *
     * @acl cp
     */
    virtual NS_ZINC::Future<void> stopAsync() = 0;

    /**
     * 
	 *
     * @if AS3
     * @deprecated
     * @endif
	 * @return the buffering-mode.
	 *
	 * @see nickel::client::MediaRouter#setBufferingMode()
	 *
     * @acl cp
     */
	virtual boost::shared_ptr<std::map< std::string, std::string > > getBufferingMode() const = 0;

	/**
	 * Sets the buffering-mode
	 *
	 * <p>The buffering-mode controls how much bandwidth is used to fill the buffer. It does not affect the speed with which
	 * video begins playback. To understand the buffering process in full please see the <a href="http://devzone.youview.com/developers/development/media-playback/mediarouter-tutorials/mediarouter-buffering-guide/">MediaRouter Buffering Guide</a>.</p>
	 *
	 * <ul>
	 *     <li>bufferconstraints = unlimited | threshold | fixed</li>
	 *     <li>Default value of bufferconstraints is threshold</li>
	 * </ul>
	 *
	 * <p><strong>unlimited:</strong> no limit on buffer size; buffering remains in fast-fill mode regardless of buffer occupancy.</p>
	 * 
	 * <p><strong>threshold:</strong> no limit on buffer size; buffering switches to managed-fill mode when buffer occupancy exceeds the threshold.</p>
	 * 
	 * <p><strong>fixed:</strong> no buffering beyond the threshold permitted.</p>
	 *
	 * <p>If the name component of one of the supplied name/value pairs is not valid, that pair will be ignored. If
	 * the value component of one of the supplied name/value pairs is not recognised and yet the name component is
	 * valid, the specified component of buffering-mode will be reset to its initialisation value.</p>
	 *
	 * @param bufferingMode the buffering-mode.
	 *
	 * @see nickel::client::MediaRouter
	 * @see nickel::client::MediaRouter#getBufferingMode()
	 * @see nickel::client::MediaRouter#setBufferConstraint()
	 * @see nickel::client::MediaRouter#getBufferConstraint()
	 * @see nickel::client::MediaRouter#setBufferAdaptiveMode()
	 * @see nickel::client::MediaRouter#getBufferAdaptiveMode()
	 *
	 * @acl cp
	 */
    virtual void setBufferingMode(boost::shared_ptr<std::map<std::string,std::string> > bufferingMode) = 0;

    /**
     *
     * Sets the buffering constraint.
     *
     * <p>The buffering-constraint controls how much bandwidth is used to fill the buffer. It does not affect the speed with which
	 * video begins playback. To understand the buffering process in full please see the <a href="http://devzone.youview.com/developers/development/media-playback/mediarouter-tutorials/mediarouter-buffering-guide/">MediaRouter Buffering Guide</a>.</p>
     *
     * <p><strong>threshold:</strong> no limit on buffer size; buffering switches to managed-fill mode when buffer occupancy exceeds the threshold.  This is the default value</p>
     *
     * <p><strong>unlimited:</strong> no limit on buffer size; buffering remains in fast-fill mode regardless of buffer occupancy.</p>
	 *
	 * <p><strong>fixed:</strong> no buffering beyond the threshold permitted.</p>
     *
	 * @param bufferConstraint the buffering-constraint.
     *
     * @acl cp
     */
    virtual void setBufferConstraint( BufferConstraint::Enum bufferConstraint ) = 0;

    /**
     * Get the currently configured buffering constraint. 
     * @if AS3
     * @includeExample MediaRouterGetBufferConstraint.as
     * @endif
	 *
     *
     * @see nickel::client::MediaRouter#setBufferConstraint()
     *
     * @acl cp
     */
    virtual BufferConstraint::Enum getBufferConstraint() = 0;

    /**
     * Set the current buffer adaptive mode
     *
     * The default adaptive mode is <strong>repeat</strong>.  In this mode the selected ABR stream index will persist after acquisition of the current segment.
     *
     * If the adaptive mode is set to <strong>waitfordecision</strong> the acquisition of the next segment shall not start until a new stream index has been selected.
     *
     * @see nickel::client::MediaRouter#setABRStream()
     *
     */
    virtual void setBufferAdaptiveMode( AdaptiveMode::Enum adaptiveMode ) = 0;

    /**
     * Get the current adaptive mode
     *
     */
    virtual AdaptiveMode::Enum getBufferAdaptiveMode() = 0;

    /**
     * Starts buffering.
	 *
	 * <p>To understand the buffering process in full please see the <a href="http://devzone.youview.com/developers/development/media-playback/mediarouter-tutorials/mediarouter-buffering-guide/">MediaRouter Buffering Guide</a>.</p>
	 *
	 * @throws nickel::client::NotConfigured The MediaRouter has not yet been configured.
	 * @throws nickel::client::StopConflict The MediaRouter is currently in the process of stopping.
	 *
	 * @see	nickel::client::MediaRouter#stopBuffering()
     *
     * @acl cp
     */
    virtual void startBuffering() = 0;

    /**
     * Stops buffering.
	 *
	 * <p>To understand the buffering process in full please see the <a href="http://devzone.youview.com/developers/development/media-playback/mediarouter-tutorials/mediarouter-buffering-guide/">MediaRouter Buffering Guide</a>.</p>
	 *
	 * @see	nickel::client::MediaRouter#startBuffering()
     *
     * @acl cp
     */
    virtual void stopBuffering() = 0;

    /**
     * Gets the <code>BufferStatus</code>.
	 *
	 * @return the <code>BufferStatus</code>.
	 *
	 * @throws nickel::client::NotApplicable MediaRouter is not in an On-Demand configuration.
	 *
	 * @if AS3 @includeExample MediaRouterGetBufferStatus.as@endif
	 *
	 * @see nickel::client::BufferStatus
     *
     * @acl cp
     */
    virtual boost::shared_ptr<BufferStatus> getBufferStatus() const = 0;

    /**
     * Sets the <code>VideoTerminationMode</code>.
	 *
	 * @param videoTerminationMode the <code>VideoTerminationMode</code>.
	 *
	 * @throws nickel::client::InvalidEnumeration Mode is not a member of the VideoTerminationMode enumerated type.
	 *
	 * @if AS3 @includeExample MediaRouterSetVideoTerminationMode.as@endif
	 *
	 * @see nickel::client::VideoTerminationMode::Enum
	 * @see nickel::client::MediaRouter#getVideoTerminationMode()
	 *
     * @acl cp
     */
    virtual void setVideoTerminationMode(const VideoTerminationMode::Enum mode) = 0;

    /**
     * Gets the <code>VideoTerminationMode</code>.
	 *
	 * @return the <code>VideoTerminationMode</code>.
	 *
	 * @see nickel::client::VideoTerminationMode::Enum
	 * @see nickel::client::MediaRouter#setVideoTerminationMode()
	 *
     * @acl cp
     */
    virtual VideoTerminationMode::Enum getVideoTerminationMode() const = 0;

    /**
	 * Returns the current source locator.
	 *
	 * @return Object
	 *
     * @acl cp
     */
    virtual boost::shared_ptr<std::map<std::string,std::string> > getSourceInformation() const = 0;

    /**
     * Returns key-value pairs providing information which can be used to
     * determine the quailty of received video.  This is an asynchronous
     * version of getSourceInformation() provided as getSourceInformation has
     * been seen to take some time, and there is no need for the UI to be
     * blocked waiting for this information.
     *
     * Currently it is only valid to call this on a MediaRouter in the linear
     * (DTT or IP multicast) configuration.
     *
     * @acl cp
     */
    virtual NS_ZINC::Future<std::map<std::string,std::string> >
        getSourceInformationAsync() const = 0;

    /**
	 * Sets the duration in milliseconds of the source (the media) that is, or will be, associated with
	 * the MediaRouter.
	 *
	 * <p>Setting the duration of the media has the following advantages :</p>
	 * <ul>
	 * <li>It optimises the start of playback because the MediaRouter no longer has to work out the duration itself</li>
	 * <li>It potentially increases the accuracy of Position related data</li>
	 * </ul>
	 *
	 * <p>If an Application knows that seeking will be forbidden within a MediaRouter's media, it can pass a <code>mediaDuration</code>
	 * parameter of 0 to this method. If a parameter of this value is passed, the MediaRouter shall not attempt to
	 * derive the duration of its media, and future <code>MediaRouter.seekPosition()</code> calls shall result in an
	 * IllegalSeek error. A common usecase for this might be for adverts.</p>
	 *
	 * @param mediaDuration the duration in milliseconds of the source.
	 *
	 * @throws nickel::client::InvalidDuration 	Duration &lt; 0.
	 *
     * @acl cp
     */
	virtual void setMediaDuration(const int32_t mediaDuration) = 0;

	/**
	 * Gets the duration in milliseconds of the source (the media) associated with the MediaRouter.
	 *
	 * <p>If the method returns <code>-1</code> - the duration is unknown. This could be, especially if called immediately after
	 * setting the source, because the MediaRouter is currently attempting to determine the duration.</p>
	 * <p>If the method returns <code>0</code> - it is because setMediaDuration(0) has been explicitly called by the application, the duration is unknown and is a warning that subsequent
	 * calls of <code>seekPosition()</code> will fail.</p>
	 *
	 * @return the duration in milliseconds of the source (the media) associated with the MediaRouter.
	 *
	 * @see	nickel::client::Position#getEnd()
	 *
	 * @acl cp
	 */
	virtual int32_t getMediaDuration() const = 0;

	virtual boost::shared_ptr<ABRStreamSet> getABRStreamSet() const = 0;

	virtual boost::shared_ptr<ABRStatus> getABRStatus() const = 0;

	virtual void setABRStream(const int32_t streamIndex, const bool deferred) = 0;

	/**
	 * Sets capture-mode, which determines the time-shift capture behaviour of the MediaRouter if it is in
	 * a LINEAR configuration.
	 *
	 * @param mode a value from the TimeShiftCaptureMode enumeration.
	 *
	 * @see nickel::client::TimeShiftCaptureMode::Enum
	 *
	 * @acl cp
	 */
	virtual void setCaptureMode(const TimeShiftCaptureMode::Enum mode) = 0;

	/**
	 * Returns the time-shift capture behaviour stored in capture-mode.
	 *
	 * @return a value from the TimeShiftCaptureMode enumeration.
	 *
	 * @see nickel::client::TimeShiftCaptureMode::Enum
	 *
	 * @acl cp
	 */
	virtual TimeShiftCaptureMode::Enum getCaptureMode() const = 0;

	/**
	 * Reverts a MediaRouter instance to an unconfigured state. This is the state that it was in immediately after creation.
	 * The MediaRouter instance will release all resources other than base resources.
	 *
	 * @see	nickel::client::MediaRouter#setSource()
	 * @see	nickel::client::MediaRouter#setSink()
	 *
	 * @acl cp
	 */
	virtual void recycle() = 0;


	virtual ~MediaRouter();
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_MEDIA_ROUTER_H_ */
