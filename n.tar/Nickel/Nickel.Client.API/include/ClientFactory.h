/*
 * ClientFactory.h
 *
 *  Created on: 06-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_FACTORY_H_
#define NICKEL_CLIENT_FACTORY_H_

#include "macros.h"

#include <zinc-common/Plugin.h>
#include <zinc-common/EventDispatcher.h>
#include <string>
#include <boost/shared_ptr.hpp>

NS_NICKEL_AUDIO_CLIENT_OPEN
class AudioFeedback;
NS_NICKEL_AUDIO_CLIENT_CLOSE

NS_NICKEL_CLIENT_OPEN

class Locator;
class MediaRouterFactory;
class MediaRouter;
class MediaSettings;
class OutputManager;
class ServiceListBuilder;

struct ZINC_EXPORT ClientFactory : virtual public NS_ZINC::Plugin {

	virtual boost::shared_ptr<NS_ZINC::EventDispatcher> getDefaultDispatcher() const = 0;

	virtual void setDefaultDispatcher(boost::shared_ptr<NS_ZINC::EventDispatcher> dispatcher) = 0;

	virtual boost::shared_ptr<Locator> createLocator() = 0;

	virtual boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory() = 0;

	virtual boost::shared_ptr<MediaRouter> getDefaultMediaRouter() = 0;

	virtual boost::shared_ptr<MediaSettings> createMediaSettings() = 0;

	virtual boost::shared_ptr<OutputManager> createOutputManager() = 0;

	virtual boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> createAudioFeedback() = 0;

    virtual boost::shared_ptr<ServiceListBuilder> createServiceListBuilder() = 0;

    virtual ~ClientFactory();

};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_FACTORY_H_ */
