/*
 * ABRStreamSet.h
 *
 *  Created on: May 4, 2011
 *      Author: mark.nicoll@youview.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
*/

#ifndef NICKEL_CLIENT_API_ABRSTREAMSET_H_
#define NICKEL_CLIENT_API_ABRSTREAMSET_H_

#include "macros.h"
#include <zinc-common/Polymorphic.h>
#include <boost/shared_ptr.hpp>
#include <stdint.h>
#include <string>
#include <vector>
#include <map>

NS_NICKEL_CLIENT_OPEN

class ZINC_EXPORT ABRStreamSet : virtual public NS_ZINC::Polymorphic {

public:

    int32_t getStreamCount() { return streamCount; }
    void setStreamCount(const int32_t streamCount_) { streamCount = streamCount_; }
    boost::shared_ptr<std::vector< int32_t > > getStreamBitrates() { return streamBitrates; }
    void setStreamBitrates(const boost::shared_ptr<std::vector< int32_t > > streamBitrates_) { streamBitrates = streamBitrates_; }
    boost::shared_ptr<std::map< std::string, std::string > > getStreamCharacteristics() { return streamCharacteristics; }
    void setStreamCharacteristics(const boost::shared_ptr<std::map< std::string, std::string > > streamCharacteristics_) { streamCharacteristics = streamCharacteristics_; }

    virtual ~ABRStreamSet();

private:

    int32_t streamCount;
    boost::shared_ptr<std::vector< int32_t > > streamBitrates;
    boost::shared_ptr<std::map< std::string, std::string > > streamCharacteristics;
};

NS_NICKEL_CLIENT_CLOSE

#endif
