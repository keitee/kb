/*
 * MediaSettingsListener.h
 *
 *  Created on: Feb 25, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_API_MEDIASETTINGSLISTENER_H_
#define NICKEL_CLIENT_API_MEDIASETTINGSLISTENER_H_

#include "macros.h"
#include <zinc-common/EventListener.h>

NS_NICKEL_CLIENT_OPEN

/**
 * This interface must be implemented for objects expected to receive <code>MediaSettings</code>
 * change-events.
 *
 * <p>The listener must be added by a call of <code>MediaSettings.addListener()</code>.</p>
 *
 * @see nickel::client::MediaSettings
 * @see nickel::client::MediaSettings#addListener()
 */
struct ZINC_EXPORT MediaSettingsListener : public NS_ZINC::EventListener {

	/**
	 * The <code>MediaSettings</code> change-event handler - called when a property of the
	 * <code>MediaSettings</code> structure is changed.
	 */
	virtual void MediaSettingsChange() = 0;

	virtual ~MediaSettingsListener();

}; // class MediaSettingsListener

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_API_MEDIASETTINGSLISTENER_H_ */

