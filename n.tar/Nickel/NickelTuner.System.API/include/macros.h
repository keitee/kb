/*
 * macros.h
 *
 *  Created on: 28-Jun-2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_API_MACROS_H_
#define NICKELTUNER_SYSTEM_API_MACROS_H_

#define NS_NICKELTUNER_SYSTEM_OPEN \
 	namespace Zinc { \
 	namespace Tuner {

#define NS_NICKELTUNER_SYSTEM_CLOSE } }
#define NS_NICKELTUNER_SYSTEM Zinc::Tuner

#endif /* NICKELTUNER_SYSTEM_API_MACROS_H_ */
