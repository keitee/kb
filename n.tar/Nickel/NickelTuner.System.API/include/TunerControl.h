/*
 *  TunerControl.h
 *
 *  Created on: 28-Jun-2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_API_TUNERCONTROL_H_
#define NICKELTUNER_SYSTEM_API_TUNERCONTROL_H_

#include "macros.h"
#include "TunerControlAsync.h"

NS_NICKELTUNER_SYSTEM_OPEN

typedef NS_NICKELTUNER_SYSTEM::TunerControlAsync TunerControl;

NS_NICKELTUNER_SYSTEM_CLOSE

#endif /* NICKELTUNER_SYSTEM_API_TUNERCONTROL_H_ */
