/*
 *  LinearPlaybackControl.h
 *
 *  Created on: 28-Jun-2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_API_LINEARPLAYBACKCONTROL_H_
#define NICKELTUNER_SYSTEM_API_LINEARPLAYBACKCONTROL_H_

#include "macros.h"
#include "LinearPlaybackControlAsync.h"

NS_NICKELTUNER_SYSTEM_OPEN

typedef NS_NICKELTUNER_SYSTEM::LinearPlaybackControlAsync LinearPlaybackControl;

NS_NICKELTUNER_SYSTEM_CLOSE

#endif /* NICKELTUNER_SYSTEM_API_LINEARPLAYBACKCONTROL_H_ */
