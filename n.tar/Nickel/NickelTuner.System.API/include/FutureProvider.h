/* 
 * File:   FutureProvider.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 04 July 2013
 * 
 * Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_API_FUTUREPROVIDER_H_
#define NICKELTUNER_SYSTEM_API_FUTUREPROVIDER_H_

#include "macros.h"

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/async/Promise.h>

#include <boost/noncopyable.hpp>
#include <boost/thread/locks.hpp>

#include <queue>

NS_NICKELTUNER_SYSTEM_OPEN

namespace {

struct FutureProviderState
{
    enum State
    {
        initialising,
        initialised,
    };
};

template < typename ResultType >
NS_ZINC::Future< ResultType > completedFutureFromFutureValue(NS_ZINC::FutureValue< ResultType > val)
{
    // Might be better to use promise.error?
    try
    {
        return NS_ZINC::completedFuture(val.get());
    }
    catch (const std::exception &e)
    {
        return NS_ZINC::exceptionalFuture< ResultType >(e);
    }
}

template <>
NS_ZINC::Future< void > completedFutureFromFutureValue(NS_ZINC::FutureValue< void > val)
{
    try
    {
        val.get();
        return NS_ZINC::completedFuture();
    }
    catch (const std::exception &e)
    {
        return NS_ZINC::exceptionalFuture< void >(e);
    }
}

template < typename ResultType >
void completePromiseWithFutureValue(NS_ZINC::Promise< ResultType > &promise, NS_ZINC::FutureValue< ResultType > val)
{
    if (val.getError())
    {
        promise.error(val.getError());
    }
    else
    {
        promise.complete(val.get());
    }
}

template <>
void completePromiseWithFutureValue(NS_ZINC::Promise< void > &promise, NS_ZINC::FutureValue< void > val)
{
    if (val.getError())
    {
        promise.error(val.getError());
    }
    else
    {
        promise.complete();
    }
}

}

/**
 * Make it possible to have several consumers for a single Future.
 * Example:
 *     shared_ptr< FutureProvider< vector< string > > > futureStuffProvider =
 *         FutureProvider< vector< string > >::create(dispatcher, futureStuff);
 *     // consumer 1
 *     futureStuffProvider->getNewFuture().then(&doStuff);
 *     // consumer 2	
 *     futureStuffProvider->getNewFuture().then(&doOtherStuff);
 * 
 * When the shared future is completed, the promises for the generated futures
 * will be completed in the same order as getNewFuture() was called.
 *
 * DEVARCH-7772: FutureProvider is going to be kept alive until either:
 * - the callback set on the shared future in FutureProvider::create() executes,
 * - the dispatcher goes out of scope.
 */
template < typename T >
class ZINC_EXPORT FutureProvider : private boost::noncopyable
{
public:

    /**
     * @brief Create a shared_ptr< FutureProvider< T > > to a new FutureProvider.
     *
     * This is the only way to construct a FutureProvider.
     */
    static boost::shared_ptr< FutureProvider< T > > create(
        NS_ZINC::Dispatcher& dispatcher, NS_ZINC::Future< T > future)
    {
        boost::shared_ptr< FutureProvider< T > > futureProvider(
            // Cannot use make_shared as it would be required to make
            // make_shared friend since constructor is private.
            new FutureProvider< T >(dispatcher, future));
        future.setCallback(dispatcher, boost::bind(&FutureProvider< T >::completePromises, futureProvider, _1));
        return futureProvider;
    }

    NS_ZINC::Future< T > getNewFuture()
    {
        boost::mutex::scoped_lock lock(m);
        if (state == FutureProviderState::initialised)
        {
            lock.unlock();
            return completedFutureFromFutureValue(future.getFutureValue());
        }
        else
        {
            NS_ZINC::Promise< T > p;
            promises.push(p);
            lock.unlock();
            return p.getFuture();
        }
        
    }

private:

    FutureProvider(NS_ZINC::Dispatcher &d, NS_ZINC::Future< T > f)
        : dispatcher(d),
          future(f),
          state(FutureProviderState::initialising)
    {
    }

    void completePromises(NS_ZINC::FutureValue< T > fv)
    {
        {
            boost::mutex::scoped_lock(m);
            state = FutureProviderState::initialised;
        }
        while (!promises.empty())
        {
            completePromiseWithFutureValue(promises.front(), fv);
            promises.pop();
        }
    }

    NS_ZINC::Dispatcher                    &dispatcher;
    NS_ZINC::Future< T >                    future;
    boost::mutex                            m;
    FutureProviderState::State              state;
    std::queue< NS_ZINC::Promise< T > >     promises; ///< FIFO to ensure ordering of callbacks
};

NS_NICKELTUNER_SYSTEM_CLOSE

#endif	/* NICKELTUNER_SYSTEM_API_FUTUREPROVIDER_H_ */
