/* 
 * File:   FutureProviderTest.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 24 March 2014
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/FutureProvider.h"

#include <zinc-common/async/PolledDispatcher.h>

#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>

using namespace NS_ZINC;
using namespace NS_NICKELTUNER_SYSTEM;

namespace
{
    void saveCompletionOrder(uint32_t futureNo, std::vector<uint32_t> &completionOrder)
    {
        completionOrder.push_back(futureNo);
    } 
}

class ZINC_LOCAL FutureProviderTest : public NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
private:
    boost::shared_ptr<PolledDispatcher> dispatcher;

public:
    FutureProviderTest()
    {
    }

    void runDispatcher()
    {
        while (dispatcher->processNext())
        {
        }
    }

    virtual void setUp()
    {
        dispatcher = boost::make_shared<PolledDispatcher>();
    }

    virtual void tearDown()
    {
        dispatcher.reset();
    }

    void test_that_WhenMainFutureCompletes_NewFuturesWillBeCompleted()
    {
        Promise<void> p;
        boost::shared_ptr< FutureProvider< void > > fp =
            FutureProvider< void >::create(*dispatcher, p.getFuture());

        // Create two consumers of the same future
        Future<void> future1 = fp->getNewFuture();
        Future<void> future2 = fp->getNewFuture();

        std::vector<uint32_t> completionOrder;
        future1.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 1, boost::ref(completionOrder)));
        future2.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 2, boost::ref(completionOrder)));

        // New created futures won't be completed until main future
        // has been completed
        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());
        p.complete();

        // Future completion of the new futures will be executed in the
        // passed dispatcher.
        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());

        runDispatcher();

        // Check created futures has been completed
        CPPUNIT_ASSERT(future1.isComplete());
        CPPUNIT_ASSERT(future2.isComplete());

        // Check the completion order
        CPPUNIT_ASSERT(completionOrder.at(0) == 1);
        CPPUNIT_ASSERT(completionOrder.at(1) == 2);
    }

    void test_that_IfMainFutureIsAlreadyCompletedWhenNewFuturesAreCreated_ThenNewFuturesAreCompleted()
    {
        // Create a promise and complete it before
        // passing it into FutureProvider
        Promise<void> p;
        p.complete();
        boost::shared_ptr< FutureProvider< void > > fp =
            FutureProvider< void >::create(*dispatcher, p.getFuture());
        runDispatcher();

        // Create two consumers of the same future
        Future<void> future1 = fp->getNewFuture();
        Future<void> future2 = fp->getNewFuture();

        std::vector<uint32_t> completionOrder;
        future1.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 1, boost::ref(completionOrder)));
        future2.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 2, boost::ref(completionOrder)));

        CPPUNIT_ASSERT(future1.isComplete());
        CPPUNIT_ASSERT(future2.isComplete());

        runDispatcher();

        // Check the completion order
        CPPUNIT_ASSERT(completionOrder.at(0) == 1);
        CPPUNIT_ASSERT(completionOrder.at(1) == 2);
    }

    void test_that_IfMainFutureIsAlreadyCompletedWhenNewFuturesAreCreated_ThenNewFuturesAreCompleted_WithValue()
    {
        // Create a promise and complete it before
        // passing it into FutureProvider
        Promise<uint32_t> p;
        p.complete(1);
        boost::shared_ptr< FutureProvider< uint32_t > > fp =
            FutureProvider< uint32_t >::create(*dispatcher, p.getFuture());
        runDispatcher();

        // Create two consumers of the same future
        Future<uint32_t> future1 = fp->getNewFuture();
        Future<uint32_t> future2 = fp->getNewFuture();

        std::vector<uint32_t> completionOrder;
        future1.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 1, boost::ref(completionOrder)));
        future2.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 2, boost::ref(completionOrder)));

        CPPUNIT_ASSERT(future1.isComplete());
        CPPUNIT_ASSERT(future2.isComplete());
        CPPUNIT_ASSERT(future1.get() == p.getFuture().get());
        CPPUNIT_ASSERT(future2.get() == p.getFuture().get());

        runDispatcher();

        // Check the completion order
        CPPUNIT_ASSERT(completionOrder.at(0) == 1);
        CPPUNIT_ASSERT(completionOrder.at(1) == 2);
    }

    void test_that_IfMainFutureIsAlreadyCompletedWhenNewFuturesAreCreated_ThenNewFuturesAreCompleted_WithException()
    {
        // Create a promise and complete it before
        // passing it into FutureProvider
        Promise<void> p;
        p.exception(std::runtime_error("Promise exception"));
        boost::shared_ptr< FutureProvider< void > > fp =
            FutureProvider< void >::create(*dispatcher, p.getFuture());
        runDispatcher();

        // Create two consumers of the same future
        Future<void> future1 = fp->getNewFuture();
        Future<void> future2 = fp->getNewFuture();

        std::vector<uint32_t> completionOrder;
        future1.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 1, boost::ref(completionOrder)));
        future2.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 2, boost::ref(completionOrder)));

        // Check created futures has been completed with exception
        CPPUNIT_ASSERT_THROW(future1.get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(future2.get(), std::runtime_error);

        runDispatcher();

        // Check the completion order
        CPPUNIT_ASSERT(completionOrder.at(0) == 1);
        CPPUNIT_ASSERT(completionOrder.at(1) == 2);
    }

    void test_that_WhenMainFutureCompletes_NewFuturesWillBeCompletedWithSameValueAsMainFuture()
    {
        Promise<uint32_t> p;
        boost::shared_ptr< FutureProvider< uint32_t > > fp =
            FutureProvider< uint32_t >::create(*dispatcher, p.getFuture());

        // Create two consumers of the same future
        Future<uint32_t> future1 = fp->getNewFuture();
        Future<uint32_t> future2 = fp->getNewFuture();

        std::vector<uint32_t> completionOrder;
        future1.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 1, boost::ref(completionOrder)));
        future2.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 2, boost::ref(completionOrder)));

        // New created futures won't be completed until main future
        // has been completed
        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());
        p.complete(1);

        // Future completion of the new futures will be executed in the
        // passed dispatcher.
        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());

        runDispatcher();

        // Check created futures has been completed and their value is the
        // same as the main future
        CPPUNIT_ASSERT(future1.isComplete());
        CPPUNIT_ASSERT(future2.isComplete());
        CPPUNIT_ASSERT(future1.get() == p.getFuture().get());
        CPPUNIT_ASSERT(future2.get() == p.getFuture().get());

        // Check the completion order
        CPPUNIT_ASSERT(completionOrder.at(0) == 1);
        CPPUNIT_ASSERT(completionOrder.at(1) == 2);
    }

    void test_that_WhenMainFutureCompletesWithException_NewFuturesWillReturnException()
    {
        Promise<void> p;
        boost::shared_ptr< FutureProvider< void > > fp =
            FutureProvider< void >::create(*dispatcher, p.getFuture());

        // Create two consumers of the same future
        Future<void> future1 = fp->getNewFuture();
        Future<void> future2 = fp->getNewFuture();

        std::vector<uint32_t> completionOrder;
        future1.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 1, boost::ref(completionOrder)));
        future2.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 2, boost::ref(completionOrder)));

        // New created futures won't be completed until main future
        // has been completed
        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());
        p.exception(std::runtime_error("Promise exception"));

        // Future completion of the new futures will be executed in the
        // passed dispatcher.
        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());

        runDispatcher();

        // Check created futures has been completed with exception
        CPPUNIT_ASSERT_THROW(future1.get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(future2.get(), std::runtime_error);

        // Check the completion order
        CPPUNIT_ASSERT(completionOrder.at(0) == 1);
        CPPUNIT_ASSERT(completionOrder.at(1) == 2);
    }

    void test_that_WhenFutureProviderGoesOutOfScope_NewFuturesAreNotCompletedBeforeMainFutureCompletes()
    {
        Promise<void> p;

        Future<void> future1;
        Future<void> future2;

        std::vector<uint32_t> completionOrder;
        {
            boost::shared_ptr< FutureProvider< void > > fp =
                FutureProvider< void >::create(*dispatcher, p.getFuture());

            // Create two consumers of the same future
            future1 = fp->getNewFuture();
            future2 = fp->getNewFuture();

            future1.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 1, boost::ref(completionOrder)));
            future2.setCallback(*dispatcher, boost::bind(&saveCompletionOrder, 2, boost::ref(completionOrder)));

        } // FutureProvider is going to be kept alive at the end of this scope

        // Nothing is expected to happen at this point:
        // the two promises held by FutureProvider are alive,
        // therefore, the two new futures are not already completed
        // with Zinc.Error.BrokenPromise.
        runDispatcher();

        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());

        p.complete();

        // Future completion of the new futures will be executed in the
        // passed dispatcher.
        CPPUNIT_ASSERT(!future1.isComplete());
        CPPUNIT_ASSERT(!future2.isComplete());

        runDispatcher();

        // Check created futures have been completed
        CPPUNIT_ASSERT(future1.isComplete());
        CPPUNIT_ASSERT(future2.isComplete());

        // Check the completion order
        CPPUNIT_ASSERT(completionOrder.at(0) == 1);
        CPPUNIT_ASSERT(completionOrder.at(1) == 2);
    }

    CPPUNIT_TEST_SUITE(FutureProviderTest);

    CPPUNIT_TEST(test_that_WhenMainFutureCompletes_NewFuturesWillBeCompleted);
    CPPUNIT_TEST(test_that_IfMainFutureIsAlreadyCompletedWhenNewFuturesAreCreated_ThenNewFuturesAreCompleted);
    CPPUNIT_TEST(test_that_IfMainFutureIsAlreadyCompletedWhenNewFuturesAreCreated_ThenNewFuturesAreCompleted_WithValue);
    CPPUNIT_TEST(test_that_IfMainFutureIsAlreadyCompletedWhenNewFuturesAreCreated_ThenNewFuturesAreCompleted_WithException);
    CPPUNIT_TEST(test_that_WhenMainFutureCompletes_NewFuturesWillBeCompletedWithSameValueAsMainFuture);
    CPPUNIT_TEST(test_that_WhenMainFutureCompletesWithException_NewFuturesWillReturnException);
    CPPUNIT_TEST(test_that_WhenFutureProviderGoesOutOfScope_NewFuturesAreNotCompletedBeforeMainFutureCompletes);

    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(FutureProviderTest);
