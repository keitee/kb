/*
 * MediaRouterTest.cpp
 *
 *  Created on: 19 March 2012
 *      Author: William Manley
 *
 *   Copyright (C) 2012 YouView TV Ltd.
 *
 * This is a test intended to be able to test any MediaRouter implementation
 * against the spec.
 *
 * ## Running the tests
 *
 * Building Nickel.System.API will produce an executable called mediaroutertest.
 * This should be called with:
 *
 *     $ mediaroutertest --plugin=my-implementation.plugin-config
 *
 * So you will need to create a plugin-config file for your implementation so it
 * will use that.  You may already have one of these.  An example targeting our
 * fakes can be found in
 * Nickel/Nickel.System.DBusServer/data/media-daemon.plugin-config.
 *
 * These tests depend on the YouView Testbank of example media assets.  These
 * may not be available outside the YouView network.  To specify alternate uris
 * for these assets fill a file with lines like:
 *
 *     TS_5_SECS=http://example.com/stream.mpg
 *     RTMP_5_SECS=rtmp://example.com/stream.mp4
 *
 * and provide it to the test executable with the --media-sources option.
 *
 * ## Guidence
 *
 * Some guidence about what should go in the tests:
 *
 * The tests should:
 *  * Be black-box tests (i.e. should work on any theoretically conforming
 *    implementation).
 *  * Test against the specification.  It is a good idea to name test cases
 *    after passages in the specification such as
 *    "test_thatOutOfBoundsExceptionIsThrownIfVolumeIsSetAboveMaximum".
 *  * Only interface with the MediaRouters via the System.API.
 *
 * This means that these tests should *not*:
 *  * Be implementation specific - You are encouraged to write implementation
 *    specific tests but they should live beside that implementation.  These
 *    kinds of tests would be necessary if you want to check that the actual
 *    video output is correct or feed in DVB signals as we do not specify how
 *    any implementation does this.
 *  * Depend on any non-standard hardware or software outside the YouView
 *    stack - It should be just as valid to run these tests on a PC against a
 *    Fake as on a set top-box.  This maximises the utility to developers.
 *  * Test behaviours which are outside of the specification - The spec isn't
 *    complete or entirely unambiguous about the complete behaviour of the
 *    MediaRouter.  I will add a separate test for test cases that are required
 *    for a YouView box to actually work but are not covered by the spec.  This
 *    separate test will be very important as it will serve as a memory of
 *    implicit requirements YouView has but are not explicitly called out in the
 *    spec.  We will be able to use these separate tests to inform
 *    clarifications to the spec.
 *  * Depend on reading the specification to understand what behaviour the test
 *    is trying to test.  i.e. don't name a test MediaRouterSpecSection3_3_4,
 *    name it after the contents e.g
 *    "test_thatSourceEventTRACKS_CHANGEDIsEmittedWhenASubtitleTrackIsAdded"
 *
 * These tests are not conformance tests and should be useful to you rather than
 * a burden.  Don't even feel that you need to pass all the tests in the suite:
 * all it is doing is testing the specification, and should help you: it is not
 * worth ripping up your implementation just because some test that tests some
 * obsure unuseful part of the spec fails if your implementation is actually
 * working in reality.  The thing that these tests should be most useful for is
 * preventing regressions.  You most certainly want to take it quite seriously
 * if a test that was passing now starts to fail.
 */

#include "../include/MediaRouterFactory.h"
#include "../include/nickel-system-exceptions.h"
#include "../include/mock/MockMediaRouterEventListener.h"
#include "../include/MediaRouter.h"
#include "../include/SystemFactory.h"

#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/TestRunner.h>
#include <zinc-common/testsupport/define_ostream_operator_for.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-common/testsupport/assert_within_timeout.h>
#include <zinc-common/FilePluginConfig.h>
#include <zinc-common/PluginFactory.h>
#include <cppunit/extensions/HelperMacros.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/program_options.hpp>
#include <gmock/gmock.h>

using namespace std;
using namespace boost;
using namespace NS_ZINC;
using namespace testing;

namespace po = boost::program_options;

static std::string pluginFilename;

#define TESTBANK_SOURCE(desc, name, url) \
    ( #name, po::value<std::string>(&sources:: name )->default_value(url), desc )

// Will be filled in from a configuration file:
namespace sources {
    std::string TS_5_SECS;
    std::string TS_30_SECS;
    std::string TS_10_MINS;
    std::string MPG_10_MINS;
    std::string TS_15_MINS;
    std::string TS_10_MINS_ENCRYPTED;
    std::string TS_2_HOURS;
    std::string RTMP_30_SECS;
    std::string RTMP_5_SECS;
    std::string RTMP_15_MINS;
    std::string RTMP_ABR_800;
    std::string RTMP_ABR_1500;
    std::string RTMP_ABR_2800;
    std::string RTMP_TIMING_APP;
    std::string RTMP_AAC_AUDIO;
    std::string ASSET_MISSING;
    std::string HTTP_400_ERROR_RESPONSE;
    std::string HTTP_504_ERROR_RESPONSE;
    std::string MALFORMANT_URL;
    std::string TTML_EN_10_MINS;
    std::string TTML_EN;
    std::string TTML_CY;
    std::string TTML_GD;
    std::string TTML_GA;
}

int main(int argc, char* argv[]) {

    NS_ZINC::TestRunner runner;
    std::string mediaSources;
    try {
        mediaSources = NS_ZINC::PackageDataFinder().find("test-bank.ini");
    }
    catch (NS_ZINC::ResourceNotFoundException&) {
    }

    po::options_description suiteOpts("Test suite options");
    suiteOpts.add_options()
        // Ugh.. Store plugin filename in a global static until I can find a
        // better way of passing it to the test suite:
        ("plugin",     po::value<std::string>(&pluginFilename),
                       "The plugin-config file to use for the implementation")
        ("media-sources", po::value<std::string>(&mediaSources),
                       "File from which to load the test media URLs");

    runner.parseOptions(argc, argv, suiteOpts);

    po::options_description testbankOpts("Test-bank sources");
    testbankOpts.add_options()
        TESTBANK_SOURCE("Transport stream 5 seconds",
            TS_5_SECS, "http://pmd.youview.co.uk/VA-504.ts")
        TESTBANK_SOURCE("transport stream - length 30 secs - embedded subtitles",
            TS_30_SECS,	"http://pmd.youview.co.uk/VA-503.ts")
        TESTBANK_SOURCE("MPG asset - length 10 minutes",
            TS_10_MINS,	"http://pmd.youview.co.uk/VA-301.mpg")
        TESTBANK_SOURCE("mpg stream - length  - no subtitles",
            MPG_10_MINS,	"http://pmd.youview.co.uk/VA-301.mpg")
        TESTBANK_SOURCE("MPG asset - length 15 minutes",
            TS_15_MINS,	"http://pmd.youview.co.uk/VA-501.mpg")
        TESTBANK_SOURCE("",
            TS_10_MINS_ENCRYPTED,	"https://testdrm.youview.com/sas/b00jw8y6?bt=_wAAMgAAASMAAAAATVQ2qAAAAAAAAAAAAB5HEeivE3P2wauo3xCdLTT9Ia_eAABwAAAAB_8BC63R9cwhdVH-pSbYmGRNAm1-_Vc#http://filegateway.youview.co.uk/test_assets/licence_free/VA-306.mpg")
        TESTBANK_SOURCE("MPG asset - length 2 hours",
            TS_2_HOURS,	"http://filegateway.youview.co.uk/test_assets/restricted/VA-237.mpg")
        TESTBANK_SOURCE("RTMP stream - length 30 secs",
            RTMP_30_SECS,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:VA-507_rtmp.mp4")
        TESTBANK_SOURCE("RTMP stream - length 5 secs",
            RTMP_5_SECS,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:VA-508_rtmp.mp4")
        TESTBANK_SOURCE("RTMP stream - length 15 minutes",
            RTMP_15_MINS,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_1500_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 800kbps",
            RTMP_ABR_800,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_800_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 1500kbps",
            RTMP_ABR_1500,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_1500_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 2800kbps",
            RTMP_ABR_2800,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_2800_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 2800kbps",
            RTMP_TIMING_APP,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:TimingApp.mp4")
        TESTBANK_SOURCE("RTMP AAC audio-only mp4",
            RTMP_AAC_AUDIO,	"rtmp://cp114711.edgefcs.net/ondemand/mp4:RBN2_radio_4_fm_-_tuesday_2040_b014q043_2011_09_20_20_35_00.mp4")
        TESTBANK_SOURCE("valid locator but missing asset (404)",
            ASSET_MISSING,	"http://filegateway.youview.co.uk/test_assets/licence_free/VA-503_nonavailable.ts")
        TESTBANK_SOURCE("a server error is returned",
            HTTP_400_ERROR_RESPONSE,	"http://testdrm.youview.com/400badrequest.php")
        TESTBANK_SOURCE("a server error is returned",
            HTTP_504_ERROR_RESPONSE,	"http://testdrm.youview.com/504_error.php")
        TESTBANK_SOURCE("malformat Source URL",
            MALFORMANT_URL,	"https://testdrm.youview.com/sas/b00jw8y6?bt=_wAAMgAAASMAAAAATVQ2qAAAAAAAAAAAAB5HEeivE3P2wauo3xCdLTT9Ia_eAABwAAAAB_8BC63R9cwhdVH-pSbYmGRNAm1-_Vc#httpilegateway.youview.co.uk/test_assets/licence_free/VA-306.mpg")
        TESTBANK_SOURCE("Original 10 minute file that runs with Elephants Dream",
            TTML_EN_10_MINS,	"http://filegateway.youview.co.uk/test_assets/licence_free/VA-303.ttml")
        TESTBANK_SOURCE("Language - en",
            TTML_EN,	"http://pmd.youview.co.uk/YV-TTML-9-4.4.9-AnotherLang-en.ttml")
        TESTBANK_SOURCE("Language - cy",
            TTML_CY,	"http://pmd.youview.co.uk/YV-TTML-10-4.4.9-AnotherLang-cy.ttml")
        TESTBANK_SOURCE("Language - gd",
            TTML_GD,	"http://pmd.youview.co.uk/YV-TTML-11-4.4.9-AnotherLang-gd.ttml")
        TESTBANK_SOURCE("Language - ga",
            TTML_GA,	"http://pmd.youview.co.uk/YV-TTML-13-4.4.9-AnotherLang-ga.ttml");

    if (!mediaSources.empty()) {
        po::variables_map vm;
        po::store(po::parse_config_file<char>(mediaSources.c_str(), testbankOpts, false), vm);
        notify(vm);
    }

    return runner.run();
}

namespace Zinc { namespace Media {
ZINC_DEFINE_OSTREAM_OPERATOR_FOR(NS_NICKEL_SYSTEM::Track);
} } // namespace Zinc::Media

NS_NICKEL_SYSTEM_OPEN

struct MediaRouterTest : public CppUnit::TestFixture {
    void setUp() {
        NS_ZINC::FilePluginConfig pluginConfig(pluginFilename);
        factory = &NS_ZINC::PluginFactory::getInstance<SystemFactory>(pluginConfig);
        mrf = factory->createMediaRouterFactory();

        router = mrf->createMediaRouter().get();
        listener = boost::make_shared<MockMediaRouterEventListener>();
        router->addListener(listener);
    }
    void tearDown() {
        CPPUNIT_ASSERT( Mock::VerifyAndClearExpectations(listener.get()));
        listener.reset();
        router.reset();
    }

    void test_thatCallingSetSinkTwiceThrowsIllegalConfigurationException();
    void test_thatSourceEventCHANGE_INITIATEDIsProducedOnStartOfChannelChange();
    void test_thatSourceEventCHANGE_COMPLETEIsProducedOnEndOfChannelChange();
    void test_thatSourceEventSOURCE_INFORMATION_CHANGEIsProducedWhenRestrictedModeHasBeenEntered();
    void test_thatSourceEventSOURCE_CONFIG_COMPLETEIsProducedAfterSetSourceIsComplete();
    void test_that_getMediaDurationAnd_getPosition_endAreValidAfterSetSourceIsComplete();
    void test_thatSourceEventTRACKS_CHANGEDIsProducedWhenTheListOfTracksChange();

    void test_thatStatusEventSEEK_STARTEDIsProducedWhenWeSeek();
    void test_thatStatusEventSTARTEDIsProducedWhenASeekIsComplete();
    void test_thatStatusEventSTARTEDIsProducedInResponseToACallToStart();

    void test_thatVolumeDefaultsTo0();
    void test_thatReturnsWhatSetVolumeWasSetTo();
    void test_thatOutOfBoundsExceptionIsThrownIfVolumeIsSetAboveMaximum();

    void test_that_getSourceReturnsTheMediaLocatorSetBySetSource();
    // TODO: This should probably be added to the MediaRouter spec:
    void test_that_getSourceThrowsNotConfiguredExceptionIfCalledBeforeSetSource();

    void test_that_getTracksReturnsAnEmptyListIfMediaRouterIsUnconfigured();
    void test_that_getTracksReturnsACompleteSetOfTracks();
    void test_that_tagsAreEqualToPIDs();
    void test_that_addSubtitleTrackThrowsInvalidLocatorIfInvalidURIIsPassed();
    void test_that_aTagReturnedBy_addSubtitleTrackCanBeUsedImmediatelyNotWaitingForItToBeAddedToTheTracksList();
    void test_that_getTracksReturnsAddedSubtitleTracks();
    void test_thatSourceEventTRACKS_CHANGEDIsEmittedWhenASubtitleTrackIsAdded();
    void test_that_addSubtitleTrackReturnsATagInAValidRange();
    void test_that_setVideoTrackChangesReturnOf_getVideoTrack();

    void test_that_PositionChangeEventIsEmittedEverySecondDuringSteadyStatePlayback();
    void test_that_PositionChangeEventIsEmittedInResponseToDurationBeingSet();

    // Tests lifted from CDS test-bank:
    void test_thatSeekingAndSeekEventsWork();
    void test_thatSeekingBeyondBufferedRegionWorks();
    void test_seekingBeyondBufferedRegion();
    void test_seekingBackAfterCompletionWorks();

    CPPUNIT_TEST_SUITE(MediaRouterTest);

    CPPUNIT_TEST(test_thatCallingSetSinkTwiceThrowsIllegalConfigurationException);
    CPPUNIT_TEST(test_thatSourceEventCHANGE_INITIATEDIsProducedOnStartOfChannelChange);
    CPPUNIT_TEST(test_thatSourceEventCHANGE_COMPLETEIsProducedOnEndOfChannelChange);
    CPPUNIT_TEST(test_thatSourceEventSOURCE_INFORMATION_CHANGEIsProducedWhenRestrictedModeHasBeenEntered);
    CPPUNIT_TEST(test_thatSourceEventSOURCE_CONFIG_COMPLETEIsProducedAfterSetSourceIsComplete);
    CPPUNIT_TEST(test_that_getMediaDurationAnd_getPosition_endAreValidAfterSetSourceIsComplete);
    CPPUNIT_TEST(test_thatSourceEventTRACKS_CHANGEDIsProducedWhenTheListOfTracksChange);

    CPPUNIT_TEST(test_thatStatusEventSEEK_STARTEDIsProducedWhenWeSeek);
    CPPUNIT_TEST(test_thatStatusEventSTARTEDIsProducedWhenASeekIsComplete);
    CPPUNIT_TEST(test_thatStatusEventSTARTEDIsProducedInResponseToACallToStart);

    CPPUNIT_TEST(test_thatVolumeDefaultsTo0);
    CPPUNIT_TEST(test_thatReturnsWhatSetVolumeWasSetTo);
    CPPUNIT_TEST(test_thatOutOfBoundsExceptionIsThrownIfVolumeIsSetAboveMaximum);

    CPPUNIT_TEST(test_that_getSourceReturnsTheMediaLocatorSetBySetSource);
    // TODO: This should probably be added to the MediaRouter spec:
    CPPUNIT_TEST(test_that_getSourceThrowsNotConfiguredExceptionIfCalledBeforeSetSource);

    CPPUNIT_TEST(test_that_getTracksReturnsAnEmptyListIfMediaRouterIsUnconfigured);
    CPPUNIT_TEST(test_that_getTracksReturnsACompleteSetOfTracks);
    CPPUNIT_TEST(test_that_tagsAreEqualToPIDs);
    CPPUNIT_TEST(test_that_addSubtitleTrackThrowsInvalidLocatorIfInvalidURIIsPassed);
    CPPUNIT_TEST(test_that_aTagReturnedBy_addSubtitleTrackCanBeUsedImmediatelyNotWaitingForItToBeAddedToTheTracksList);
    CPPUNIT_TEST(test_that_getTracksReturnsAddedSubtitleTracks);
    CPPUNIT_TEST(test_thatSourceEventTRACKS_CHANGEDIsEmittedWhenASubtitleTrackIsAdded);
    CPPUNIT_TEST(test_that_addSubtitleTrackReturnsATagInAValidRange);
    CPPUNIT_TEST(test_that_setVideoTrackChangesReturnOf_getVideoTrack);

    CPPUNIT_TEST(test_that_PositionChangeEventIsEmittedEverySecondDuringSteadyStatePlayback);
    CPPUNIT_TEST(test_that_PositionChangeEventIsEmittedInResponseToDurationBeingSet);

    CPPUNIT_TEST(test_thatSeekingAndSeekEventsWork);
    CPPUNIT_TEST(test_thatSeekingBeyondBufferedRegionWorks);
    CPPUNIT_TEST(test_seekingBeyondBufferedRegion);
    CPPUNIT_TEST(test_seekingBackAfterCompletionWorks);

    CPPUNIT_TEST_SUITE_END();

    NS_NICKEL_SYSTEM::SystemFactory* factory;
    boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouterFactory> mrf;
    boost::shared_ptr<MediaRouter> router;
    boost::shared_ptr<MockMediaRouterEventListener> listener;
};

CPPUNIT_TEST_SUITE_REGISTRATION(MediaRouterTest);

static const int SECOND = 1000;
static const int MINUTE = 60 * SECOND;
static const int HOUR = 60 * MINUTE;
static const int DAY = 24 * HOUR;

template <typename T1, typename T2, typename T3>
bool isNear(T1 val, T2 expected, T3 tolerance) {
    return val > expected - tolerance && val > expected + tolerance;
}

static void configure(MediaRouter& router, const std::string& source)
{
    boost::shared_ptr<MockMediaRouterEventListener> listener
        = boost::make_shared<MockMediaRouterEventListener>();
    router.addListener(listener);

    bool done = false;
    EXPECT_CALL(*listener, SourceEvent(SourceEventValue::source_config_complete, SetSourceReason::unspecified))
        .WillOnce(Assign(&done, true));
    router.setSource(source, SetSourceReason::unspecified);
    router.setSink("decoder://0").get();
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);
}

void MediaRouterTest::test_thatCallingSetSinkTwiceThrowsIllegalConfigurationException()
{
    // We intentionally don't call .get() here to exacerbate races
    router->setSink("decoder://0");
    CPPUNIT_ASSERT_THROW(router->setSink("decoder://0").get(), IllegalReconfigurationException);
}
void MediaRouterTest::test_thatSourceEventCHANGE_INITIATEDIsProducedOnStartOfChannelChange()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_thatSourceEventCHANGE_COMPLETEIsProducedOnEndOfChannelChange()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_thatSourceEventSOURCE_INFORMATION_CHANGEIsProducedWhenRestrictedModeHasBeenEntered()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_thatSourceEventSOURCE_CONFIG_COMPLETEIsProducedAfterSetSourceIsComplete()
{
    // Configure the source and wait for it to complete configuration
    bool done = false;
    EXPECT_CALL(*listener, SourceEvent(SourceEventValue::source_config_complete, SetSourceReason::unspecified))
        .WillOnce(Assign(&done, true));
    router->setSource(sources::TS_2_HOURS, SetSourceReason::unspecified);
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);

    // The "reason" passed to setSource must be passed through to the SourceEvent
    router->recycle().get();
    done = false;
    EXPECT_CALL(*listener, SourceEvent(SourceEventValue::source_config_complete, SetSourceReason::mhegnondestructive))
        .WillOnce(Assign(&done, true));
    router->setSource(sources::TS_2_HOURS, SetSourceReason::mhegnondestructive);
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);

}
void MediaRouterTest::test_that_getMediaDurationAnd_getPosition_endAreValidAfterSetSourceIsComplete()
{
    bool done = false;
    EXPECT_CALL(*listener, SourceEvent(SourceEventValue::source_config_complete, SetSourceReason::unspecified))
        .WillOnce(Assign(&done, true));
    router->setSource(sources::TS_2_HOURS, SetSourceReason::unspecified);
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);

    // Do these in parallel to get it ASAP
    NS_ZINC::Future<int32_t> duration = router->getMediaDuration();
    NS_ZINC::Future<Position> position = router->getPosition();

    CPPUNIT_ASSERT(duration.get() > 0);
    CPPUNIT_ASSERT(position.get().end > 0);
}
void MediaRouterTest::test_thatSourceEventTRACKS_CHANGEDIsProducedWhenTheListOfTracksChange()
{
    CPPUNIT_FAIL("Test not implemented");
}

// TODO: Clarify what should happen when you call getPosition when in
// "PendingPlaying" state i.e. during a seek.
void MediaRouterTest::test_thatStatusEventSEEK_STARTEDIsProducedWhenWeSeek()
{
    bool done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::started))
        .WillOnce(Assign(&done, true));
    router->setSource(sources::TS_2_HOURS, SetSourceReason::unspecified);
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);

    done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::seek_started))
        .WillOnce(Assign(&done, true));
    router->seekPosition(SeekReference::start, 100 * SECOND, SeekMode::prioritise_speed);
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);
}
void MediaRouterTest::test_thatStatusEventSTARTEDIsProducedWhenASeekIsComplete()
{
    bool done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::started))
        .WillOnce(Assign(&done, true));
    router->setSource(sources::TS_2_HOURS, SetSourceReason::unspecified);
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);

    done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::started))
        .WillOnce(Assign(&done, true));
    router->seekPosition(SeekReference::start, 100 * SECOND, SeekMode::prioritise_speed);
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);
}
void MediaRouterTest::test_thatStatusEventSTARTEDIsProducedInResponseToACallToStart()
{
    bool done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::started))
        .WillOnce(Assign(&done, true));
    router->setSource(sources::TS_2_HOURS, SetSourceReason::unspecified);
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 10000);
}

void MediaRouterTest::test_thatVolumeDefaultsTo0()
{
    CPPUNIT_ASSERT_EQUAL(router->getVolume().get(), 0);
}
void MediaRouterTest::test_thatReturnsWhatSetVolumeWasSetTo()
{
    // TODO: Find out if setVolume or getVolume should be affected by
    //       the state of the system
    router->setVolume(-23).get();
    CPPUNIT_ASSERT_EQUAL(-23, router->getVolume().get());
}
void MediaRouterTest::test_thatOutOfBoundsExceptionIsThrownIfVolumeIsSetAboveMaximum()
{
    CPPUNIT_ASSERT_THROW(router->setVolume(1).get(), OutOfBoundsException);
}

void MediaRouterTest::test_that_getSourceReturnsTheMediaLocatorSetBySetSource()
{
    // Don't wait for source_config_complete, the uri should be changed by the
    // time the method returns.
    router->setSource(sources::TS_2_HOURS, SetSourceReason::unspecified).get();
    CPPUNIT_ASSERT_EQUAL(std::string(sources::TS_2_HOURS), router->getSource().get());
}
void MediaRouterTest::test_that_getSourceThrowsNotConfiguredExceptionIfCalledBeforeSetSource()
{
    CPPUNIT_ASSERT_THROW(router->getSource().get(), NotConfiguredException);
}

void MediaRouterTest::test_that_getTracksReturnsAnEmptyListIfMediaRouterIsUnconfigured()
{
    CPPUNIT_ASSERT(router->getTracks().get().empty());
}

void MediaRouterTest::test_that_getTracksReturnsACompleteSetOfTracks()
{
    configure(*router, sources::TS_2_HOURS);

    //TODO: Find out at what point it is valid to call getTracks()
    std::vector<Track> actual = router->getTracks().get();
    // Sort the vector for easier comparison (the spec doesn't define an order)
    std::sort(actual.begin(), actual.end());

    // Values below taken from VLC's info pane:
    std::vector<Track> expected = boost::assign::list_of
        (Track(33, "",    TrackFormat::video_h264, TrackType::video, TrackUsage::undefined))
        (Track(34, "eng", TrackFormat::audio_heaac, TrackType::audio, TrackUsage::audio_normal));
    CPPUNIT_ASSERT_EQUAL(expected, actual);
    //TODO: Add additional tests for all the different formats/usages/languages
}
void MediaRouterTest::test_that_tagsAreEqualToPIDs()
{
    // Is this necessary? We check the pids in the test above
    CPPUNIT_FAIL("Test not implemented");
}
// FIXME: MediaRouter spec mentions addSubtitleFile, should be addSubtitleTrack
void MediaRouterTest::test_that_addSubtitleTrackThrowsInvalidLocatorIfInvalidURIIsPassed()
{
    // TODO: Clarify what makes a valid URL
    // TODO: Clarify what happens if the URI is valid but the pointed to
    //       subtitle track is invalid.  Is it removed from the list of tracks?
    //       Do we receive a TRACKS_CHANGED SourceEvent?
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_that_aTagReturnedBy_addSubtitleTrackCanBeUsedImmediatelyNotWaitingForItToBeAddedToTheTracksList()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_that_getTracksReturnsAddedSubtitleTracks()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_thatSourceEventTRACKS_CHANGEDIsEmittedWhenASubtitleTrackIsAdded()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_that_addSubtitleTrackReturnsATagInAValidRange()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_that_setVideoTrackChangesReturnOf_getVideoTrack()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_that_PositionChangeEventIsEmittedEverySecondDuringSteadyStatePlayback()
{
    CPPUNIT_FAIL("Test not implemented");
}
void MediaRouterTest::test_that_PositionChangeEventIsEmittedInResponseToDurationBeingSet()
{
    CPPUNIT_FAIL("Test not implemented");
}

// Transcribed from CDS test-bank test MR003
void MediaRouterTest::test_thatSeekingAndSeekEventsWork() {
    configure(*router, sources::TS_2_HOURS);

    // Start playing mr1 and wait for up to 45m for it to buffer to 15m
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(router->getBufferStatus().get().bufferedMilliseconds + router->getPosition().get().current > 15 * MINUTE, 45 * MINUTE);

    // Check that mr1 play-position can be greater than 5s
    ZINC_ASSERT_WITHIN_TIMEOUT(router->getPosition().get().current > 5000, 10000);

    // Mr1 is seeked to 3s.
    bool done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::seek_started))
        .WillOnce(Assign(&done, true));
    router->seekPosition(SeekReference::start, 3 * SECOND, SeekMode::prioritise_accuracy);
    int pos = router->getPosition().get().current;
    CPPUNIT_ASSERT(pos > 2 * SECOND && pos < 4 * SECOND);
}

// Transcribed from CDS test-bank test MR007
void MediaRouterTest::test_thatSeekingBeyondBufferedRegionWorks() {
    configure(*router, sources::TS_2_HOURS);

    // Start playing mr1 and wait for up to 60s for it to buffer to 30s
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(router->getBufferStatus().get().bufferedMilliseconds + router->getPosition().get().current > 30 * SECOND, 60 * SECOND);

    // Check that mr1 play-position is less than 30s
    CPPUNIT_ASSERT(router->getPosition().get().current < 30 * SECOND);

    // Mr1 is seeked to 1h (past the current buffered point of ~30s).
    bool done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::seek_started))
        .WillOnce(Assign(&done, true));
    router->seekPosition(SeekReference::start, 1 * HOUR, SeekMode::prioritise_accuracy);
    int pos = router->getPosition().get().current;
    CPPUNIT_ASSERT(isNear(pos, 1 * HOUR, 6 * SECOND));
}


// Transcribed from CDS test-bank test MR009
void MediaRouterTest::test_seekingBeyondBufferedRegion() {
    configure(*router, sources::TS_2_HOURS);

    // start playing router and wait for up to 30m for it to buffer to 15m
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(router->getBufferStatus().get().bufferedMilliseconds + router->getPosition().get().current > 15 * MINUTE, 30 * MINUTE);

    // Check that mr1 play-position is less than 15m
    CPPUNIT_ASSERT(router->getPosition().get().current < 15 * MINUTE);

    sleep(2);

    router->seekPosition(SeekReference::start, 15 * MINUTE, SeekMode::prioritise_accuracy);

    // router is seeked to 15m (past the current buffered point of ~10m)
    bool done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::seek_started))
        .WillOnce(Assign(&done, true));
    router->seekPosition(SeekReference::start, 15 * MINUTE, SeekMode::prioritise_accuracy);
    ZINC_ASSERT_WITHIN_TIMEOUT(isNear(router->getPosition().get().current, 15 * MINUTE, 6 * SECOND), 10 * SECOND);

    // router is seeked to 1m
    done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::seek_started))
        .WillOnce(Assign(&done, true));
    router->seekPosition(SeekReference::start, 1 * MINUTE, SeekMode::prioritise_accuracy);
    ZINC_ASSERT_WITHIN_TIMEOUT(isNear(router->getPosition().get().current, 1 * MINUTE, 6 * SECOND), 10 * SECOND);
}

// Transcribed from CDS test-bank test MR025
void MediaRouterTest::test_seekingBackAfterCompletionWorks() {
    configure(*router, sources::TS_10_MINS);

    // start playing router and wait for it to complete
    bool done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::complete))
        .WillOnce(Assign(&done, true));
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 1 * DAY);

    // Seek to 3s and wait for content to play
    router->seekPosition(SeekReference::start, 3 * SECOND, SeekMode::prioritise_accuracy);
    done = false;
    EXPECT_CALL(*listener, StatusEvent(StatusEventValue::started))
        .WillOnce(Assign(&done, true));
    router->start();
    ZINC_ASSERT_WITHIN_TIMEOUT(done, 20 * SECOND);

    CPPUNIT_ASSERT_EQUAL(1.0, router->getPlaySpeed().get());
}

NS_NICKEL_SYSTEM_CLOSE

