#!/bin/sh

ln -sf ${ZINC_DESTDIR}${ZINC_HOST_PREFIX}/share/zinc-system-api/CommonAPIMakefile-nonrecursive.am CommonAPIMakefile-nonrecursive.am

echo "Generating configure files... may take a while."

autoreconf --install --force && \
  echo "Preparing was successful if there was no error messages above." && \
  echo "Now type:" && \
  echo "  ./configure && make"  && \
  echo "Run './configure --help' for more information"

