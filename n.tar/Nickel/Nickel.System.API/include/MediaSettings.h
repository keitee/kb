#ifndef NICKEL_SYSTEM_API_INCLUDE_MEDIASETTINGS_H
#define NICKEL_SYSTEM_API_INCLUDE_MEDIASETTINGS_H

#include "MediaSettingsAsync.h"
#include "macros.h"

namespace Zinc {
namespace Media {

typedef MediaSettingsAsync MediaSettings;

} // namespace
} // namespace

#endif // NICKEL_SYSTEM_API_INCLUDE_MEDIASETTINGS_H

