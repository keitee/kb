/*
 * macros.h
 *
 *  Created on: Mar 18, 2009
 *      Author: jsadler
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_API_MACROS_H_
#define NICKEL_SYSTEM_API_MACROS_H_

#include <zinc-common/macros.h>

#define NS_NICKEL_SYSTEM_OPEN namespace nickel { namespace system {
#define NS_NICKEL_SYSTEM_CLOSE } }
#define NS_NICKEL_SYSTEM ::nickel::system

namespace Zinc {
    namespace Media {
    }
}

NS_NICKEL_SYSTEM_OPEN
    using namespace Zinc::Media;
NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_API_MACROS_H_ */
