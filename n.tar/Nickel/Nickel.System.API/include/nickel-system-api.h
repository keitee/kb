/* Copyright (C) 2009 British Broadcasting Corporation */
/*
 * nickel-system-api.h
 *
 *  Created on: 18-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 */

#ifndef NICKEL_SYSTEM_API_H_
#define NICKEL_SYSTEM_API_H_

#include "macros.h"

#include "nickel-system-exceptions.h"
#include "SystemFactory.h"
#include "LocalMediaLibrary.h"
#include "LocalMediaLibraryEventListener.h"
#include "MediaRouterFactory.h"
#include "MediaRouter.h"
#include "MediaRouterEventListener.h"
#include "MediaSettings.h"
#include "MediaSettingsEventListener.h"
#include "OutputManager.h"
#include "OutputManagerEventListener.h"
#include "ServiceListBuilder.h"
#include "ServiceListBuilderEventListener.h"

#include <zinc-system-api/zinc-system-api.h>
#include <zinc-common/zinc-common.h>

#endif /* NICKEL_SYSTEM_API_H_ */
