#ifndef NICKEL_SYSTEM_API_INCLUDE_MEDIAROUTER_H
#define NICKEL_SYSTEM_API_INCLUDE_MEDIAROUTER_H

#include "MediaRouterSync.h"
#include "MediaRouterAsync.h"
#include "macros.h"

namespace Zinc {
namespace Media {

typedef MediaRouterAsync MediaRouter;

} // namespace
} // namespace

#endif // NICKEL_SYSTEM_API_INCLUDE_MEDIAROUTER_H

