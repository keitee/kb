#ifndef NICKEL_SYSTEM_API_INCLUDE_LOCALMEDIALIBRARY_H
#define NICKEL_SYSTEM_API_INCLUDE_LOCALMEDIALIBRARY_H

#include "macros.h"
#include "LocalMediaLibraryAsync.h"

namespace Zinc {
namespace Media {

typedef LocalMediaLibraryAsync LocalMediaLibrary;

} // namespace
} // namespace

#endif // NICKEL_SYSTEM_API_INCLUDE_LOCALMEDIALIBRARY_H

