/**
 * BufferMode.h
 *
 *  Created on: 06 Feb 2012
 *      Author: morgan.henry@youview.com
 *
 * Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_API_BUFFERMODE_H_
#define NICKEL_SYSTEM_API_BUFFERMODE_H_

#include "macros.h"

NS_NICKEL_SYSTEM_OPEN

/**
 * BufferMode
 *
 * Constants for use with MediaRouter::setBufferingMode( std::map< std::string, std::string > dict )
 *
 * @see MediaRouter::setBufferingMode
 */
namespace BufferMode
{
char const * const BUFFER_CONSTRAINT = "bufferconstraints";
char const * const ADAPTIVE_MODE = "adaptivemode";
};

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKEL_SYSTEM_API_BUFFERMODE_H_
