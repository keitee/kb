#ifndef NICKEL_SYSTEM_API_INCLUDE_SERVICELISTBUILDER_H
#define NICKEL_SYSTEM_API_INCLUDE_SERVICELISTBUILDER_H

#include "ServiceListBuilderSync.h"
#include "ServiceListBuilderAsync.h"
#include "macros.h"

namespace Zinc {
namespace Media {

typedef ServiceListBuilderAsync ServiceListBuilder;

} // namespace
} // namespace

#endif // NICKEL_SYSTEM_API_INCLUDE_SERVICELISTBUILDER_H

