#ifndef NICKEL_SYSTEM_API_INCLUDE_MEDIAROUTERFACTORY_H
#define NICKEL_SYSTEM_API_INCLUDE_MEDIAROUTERFACTORY_H

#include "MediaRouterFactorySync.h"
#include "MediaRouterFactoryAsync.h"
#include "macros.h"

namespace Zinc {
namespace Media {

typedef MediaRouterFactoryAsync MediaRouterFactory;

} // namespace
} // namespace

#endif // NICKEL_SYSTEM_API_INCLUDE_MEDIAROUTERFACTORY_H

