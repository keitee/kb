/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "VirtualBinTypefind.h"

#include <nickel-common/NickelLogger.h>

NS_NICKEL_SYSTEM_OPEN

VirtualBinTypefind::VirtualBinTypefind(
    boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
    boost::shared_ptr<VirtualPadFactory> srcPadFactory,
    VirtualBin::CallbackType callback)
    : VirtualBin(sinkPadFactory, srcPadFactory, "VirtualBinTypefind", callback)
{
    NICKEL_FUNC_TRACE
    uridecodebin = gst_element_factory_make("uridecodebin", "uri-decoder");

    if (!uridecodebin) {
        throw std::runtime_error("Couldn't create element!");
    }

    if (gst_bin_add(GST_BIN(getParent().get()), uridecodebin.get())) {
        uridecodebin.retain();
    } else {
        NICKEL_ERROR("gst_bin_add failed!");
    }

    GstCaps *const caps = gst_caps_from_string(
            "application/dash+xml; "
            "application/x-hls; ");

    g_object_set(uridecodebin.get(), "caps", caps, NULL);

    if (0 == g_signal_connect(uridecodebin.get(), "pad-added",
                              G_CALLBACK(newPadCb),
                              static_cast<gpointer>(this))) {
        NICKEL_ERROR("g_signal_connect failed!");
    }

    gst_caps_unref(caps);
}

VirtualBinTypefind::~VirtualBinTypefind()
{
}

void VirtualBinTypefind::setSource(const std::string& sourceUri)
{
    NICKEL_FUNC_TRACE
    NICKEL_DEBUG("sourceUri: " << sourceUri);
    g_object_set(G_OBJECT(uridecodebin.get()),
                 "uri", sourceUri.c_str(),
                 NULL);
}

void VirtualBinTypefind::newPadCb(GstElement* element, GstPad* pad,
                                  gpointer data)
{
    NICKEL_FUNC_TRACE
    VirtualBinTypefind* const vbin = static_cast<VirtualBinTypefind*>(data);
    vbin->newPad(element, pad);
}

void VirtualBinTypefind::newPad(GstElement*, GstPad* pad)
{
    NICKEL_FUNC_TRACE
    const boost::shared_ptr<VirtualPad> wrappedPad = wrapSrcPad(pad);
    g_assert(wrappedPad);

    parentCallback(
        VirtualBinCallbackAction::RequestPadConnection,
        shared_from_this(),
        wrappedPad);
}

class VirtualBinTypefindFactory : public VirtualBinFactory
{
public:
    VirtualBinTypefindFactory(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher)
        : VirtualBinFactory(dispatcher)
    {
    }

    boost::shared_ptr<VirtualBin> create(
        boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
        boost::shared_ptr<VirtualPadFactory> srcPadFactory,
        VirtualBin::CallbackType callback)
    {
        const boost::shared_ptr<VirtualBin> bin =
            boost::make_shared<VirtualBinTypefind>(sinkPadFactory,
                                                   srcPadFactory,
                                                   callback);
        bin->setDispatcher(getDispatcher());
        return bin;
    }
};

NS_NICKEL_SYSTEM_CLOSE
