/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_VIRTUALPADINPROCESS_H_
#define NICKEL_SYSTEM_VIRTUALPADINPROCESS_H_

#include "RefObj.h"
#include "VirtualBin.h"

NS_NICKEL_SYSTEM_OPEN

class ZINC_EXPORT VirtualPadFactoryInProcess : public VirtualPadFactory
{
public:
    VirtualPadFactoryInProcess();
    virtual ~VirtualPadFactoryInProcess();

    boost::shared_ptr<VirtualPad> wrap(GstPad* pad);
    boost::tuple<GstPad*, GstElement*> unwrap(
        boost::shared_ptr<VirtualPad> pad);
};

class ZINC_EXPORT VirtualPadInProcess : public VirtualPad
{
public:
    VirtualPadInProcess(GstPad* pad,
                        boost::shared_ptr<VirtualPadFactory> factory);
    ~VirtualPadInProcess();

private:
    GstPad* getRawGstPad();
    RefObj<GstPad> pad;

    friend class VirtualPadFactoryInProcess;
};

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKEL_SYSTEM_VIRTUALPADINPROCESS_H_
