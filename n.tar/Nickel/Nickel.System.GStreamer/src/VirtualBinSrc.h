/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_VIRTUALBINSRC_H_
#define NICKEL_SYSTEM_VIRTUALBINSRC_H_

#include "VirtualBin.h"

NS_NICKEL_SYSTEM_OPEN

class ZINC_EXPORT VirtualBinSrc : public VirtualBin
{
public:
    VirtualBinSrc(boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
                  boost::shared_ptr<VirtualPadFactory> srcPadFactory,
                  VirtualBin::CallbackType callback);

    std::vector<Track> getTracks() const;
    std::map<std::string, std::string> getSourceInformation() const;

    bool isLive() const;
    int64_t getTimeshiftBufferLimitMiliseconds() const;

private:
    static void newDecodebinPadCb(GstElement* element, GstPad* pad,
                                  gpointer data);
    void newDecodebinPad(GstElement* decodebin, GstPad* pad);
    RefObj<GstElement> makeAndSetupDecodebin(const char* outputCaps);

    RefObj<GstElement> sink;
    std::string sourceCaps;
};

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKEL_SYSTEM_VIRTUALBINSRC_H_
