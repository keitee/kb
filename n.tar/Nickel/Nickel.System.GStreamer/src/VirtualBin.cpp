/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "VirtualBin.h"

#include <nickel-common/NickelLogger.h>

#include <zinc-common/ScopedObj.h>

#include <boost/make_shared.hpp>

#include <gst/gst.h>

#define NOT_IMPLEMENTED \
    throw std::runtime_error(std::string("Not implemented: ") + \
                             __PRETTY_FUNCTION__);

NS_NICKEL_SYSTEM_OPEN

inline
void gcharFree(gchar* const p)
{
    g_free(p);
}

VirtualPadFactory::VirtualPadFactory()
{
}

VirtualPadFactory::~VirtualPadFactory()
{
}

VirtualPad::VirtualPad(boost::shared_ptr<VirtualPadFactory> factory) :
    factory(factory)
{
}

VirtualPad::~VirtualPad()
{
}

boost::shared_ptr<VirtualPadFactory> VirtualPad::getFactory()
{
    return factory;
}

boost::tuple<GstPad*, GstElement*> VirtualPad::unwrap()
{
    return factory->unwrap(shared_from_this());
}

VirtualBin::VirtualBin(boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
                       boost::shared_ptr<VirtualPadFactory> srcPadFactory,
                       const char* const binName, CallbackType callback) :
    callback(callback),
    sinkPadFactory(sinkPadFactory),
    srcPadFactory(srcPadFactory),
    container(gst_bin_new(binName)),
    lock()
{
}

VirtualBin::~VirtualBin()
{
}

void VirtualBin::setSource(const std::string& /* sourceUri */)
{
    NOT_IMPLEMENTED
}

void VirtualBin::setUserAgent(const std::string& /* userAgent */)
{
    NOT_IMPLEMENTED
}

void VirtualBin::setVolume(const int32_t /* volume */)
{
    NOT_IMPLEMENTED
}

int32_t VirtualBin::getVolume() const
{
    NOT_IMPLEMENTED
}

std::vector<Track> VirtualBin::getTracks() const
{
    NOT_IMPLEMENTED
}

std::map< std::string, std::string > VirtualBin::getSourceInformation() const
{
    NOT_IMPLEMENTED
}

void VirtualBin::setVideoWindow(const VideoWindowDescriptor& /* videoWindow */)
{
    NOT_IMPLEMENTED
}

int64_t VirtualBin::getTimeshiftBufferLimitMilliseconds() const
{
    NOT_IMPLEMENTED
}

RefObj<GstPad> mirrorPad(const RefObj<GstPad>& pad,
                         const RefObj<GstElement>& bin,
                         const char* const padName)
{
    RefObj<GstPad> ghostPad;

    if (padName) {
        ghostPad = gst_ghost_pad_new(padName, pad.get());
    } else {
        const NS_ZINC::ScopedObj<gchar> staticPadName(
            gst_pad_get_name(pad.get()), gcharFree);

        if (!staticPadName) {
            NICKEL_ERROR("Failed to get pad name");
            return ghostPad;
        }

        const NS_ZINC::ScopedObj<gchar> uniquePadName(
            g_strdup_printf("%s_%p", staticPadName.get(), pad.get()),
            gcharFree);
        if (!uniquePadName) {
            NICKEL_ERROR("Failed to create unique pad name");
            return ghostPad;
        }

        ghostPad = gst_ghost_pad_new(uniquePadName.get(), pad.get());
    }

    if (!ghostPad) {
        NICKEL_ERROR("Failed to create ghost pad!");
    }

    if (!gst_pad_set_active(ghostPad.get(), TRUE)) {
        NICKEL_ERROR("gst_pad_set_active failed!");
    }

    if (gst_element_add_pad(GST_ELEMENT(bin.get()),
                            ghostPad.get())) {
        ghostPad.retain();
    } else {
        NICKEL_ERROR("gst_element_add_pad failed!");
    }

    return ghostPad;
}

namespace {

void typefindGotType(GstElement* element, guint, GstCaps*, gpointer data)
{
    NICKEL_FUNC_TRACE;
    g_signal_handlers_disconnect_by_data(element, data);

    const RefObj<GstPad> srcPad = gst_element_get_static_pad(element, "src");
    if (!srcPad) {
        NICKEL_ERROR("gst_element_get_static_pad failed!");
    }

    VirtualBin* const vbin = static_cast<VirtualBin*>(data);
    const RefObj<GstPad> sinkPad = vbin->plug(srcPad);

    if (GST_PAD_LINK_OK != gst_pad_link(srcPad.get(),
                                        sinkPad.get())) {
        NICKEL_ERROR("gst_pad_link failed!");
    }
}

} // namespace anonymous

RefObj<GstPad> VirtualBin::plug_unlocked(const RefObj<GstPad>& pad)
{
    NICKEL_FUNC_TRACE;

    RefObj<GstPad> upstreamSinkPad;
    RefObj<GstElement> upstream;

    RefObj<GstCaps> caps;

    if (GST_IS_GHOST_PAD(pad.get())) {
        // get the real pad to get proper caps
        const RefObj<GstPad> ghostPad =
            gst_ghost_pad_get_target(GST_GHOST_PAD(pad.get()));
        caps = gst_pad_get_current_caps(ghostPad.get());
    } else {
        caps = gst_pad_get_current_caps(pad.get());
    }

    if (caps) {
        const GstStructure* const s =
            gst_caps_get_structure(caps.get(), 0);
        const gchar* const mediaType = gst_structure_get_name(s);

        NICKEL_TRACE("Element has current caps, "
                     "making element for: " << mediaType);
        FactoryContainer::iterator it = elementFactory.find(mediaType);

        if (it == elementFactory.end()) {
            // We couldn't find a specific element factory function
            // So try to find a 'catch all' case
            NICKEL_TRACE("Couldn't find  factory function for: "
                << mediaType << " trying to make for ANY");
            it = elementFactory.find("ANY");
        }

        if (it != elementFactory.end()) {
            upstream = it->second();
            if (gst_bin_add(GST_BIN(container.get()), upstream.get())) {
                upstream.retain();
            }
            else {
                NICKEL_ERROR("gst_bin_add failed!");
            }

            upstreamSinkPad =
                gst_element_get_static_pad(upstream.get(), "sink");
            if (!upstreamSinkPad) {
                NICKEL_ERROR("gst_element_get_static_pad failed!");
            }

            const RefObj<GstPad> upstreamSrcPad =
                gst_element_get_static_pad(upstream.get(), "src");

            if (upstreamSrcPad) {
                NICKEL_TRACE("Another element required, recursing...");
                RefObj<GstPad> downstreamPad = plug_unlocked(upstreamSinkPad);
                if (!gst_pad_link(upstreamSrcPad.get(),
                                  downstreamPad.get())) {
                    NICKEL_ERROR("gst_pad_link failed!");
                }
            }
        } else {
            NICKEL_ERROR("Couldn't handle media type: " << mediaType);
            GST_ELEMENT_ERROR(container.get(), RESOURCE, NOT_FOUND,
                ("Couldn't handle media type: %s", mediaType), (NULL));
        }
    } else {
        NICKEL_TRACE("Element has no current caps, using typefind...");
        upstream = gst_element_factory_make("typefind", NULL);

        if (!upstream) {
            NICKEL_ERROR("gst_element_factory_make for typefind failed!");
        } else {
            if (0 == g_signal_connect(upstream.get(), "have-type",
                G_CALLBACK(typefindGotType), static_cast<gpointer>(this))) {
                NICKEL_ERROR("g_signal_connect failed!");
            }

            if (gst_bin_add(GST_BIN(container.get()), upstream.get())) {
                upstream.retain();
            }
            else {
                NICKEL_ERROR("gst_bin_add failed!");
            }

            upstreamSinkPad =
                gst_element_get_static_pad(upstream.get(), "sink");
            if (!upstreamSinkPad) {
                NICKEL_ERROR("gst_element_get_static_pad failed!");
            }
        }
    }

    if (!gst_element_sync_state_with_parent(upstream.get())) {
        NICKEL_ERROR("gst_element_sync_state_with_parent failed!");
    }

    return upstreamSinkPad;
}

RefObj<GstPad> VirtualBin::plug(const RefObj<GstPad>& pad)
{
    const boost::lock_guard<boost::mutex> l(lock);
    return plug_unlocked(pad);
}

bool VirtualBin::autoplug(boost::shared_ptr<VirtualPad> srcPad)
{
    NICKEL_FUNC_TRACE;
    const boost::lock_guard<boost::mutex> l(lock);

    RefObj<GstElement> unwrappedElem;
    RefObj<GstPad> unwrappedSrcPad;

    boost::tie(unwrappedSrcPad, unwrappedElem) = srcPad->unwrap();

    RefObj<GstPad> sinkpad = plug_unlocked(unwrappedSrcPad);

    if (unwrappedElem) {
        // we've got the element so this must be some IPC setup hence we just
        // add the element to our bin and assume we don't need to ghost our pad
        if (gst_bin_add(GST_BIN(container.get()), unwrappedElem.get())) {
            unwrappedElem.retain();
        } else {
            NICKEL_ERROR("gst_bin_add failed!");
        }
    } else {
        sinkpad = mirrorPad(sinkpad, container);
    }

    if (GST_PAD_LINK_OK != gst_pad_link_full(unwrappedSrcPad.get(),
                                             sinkpad.get(),
                                             GST_PAD_LINK_CHECK_NOTHING)) {
        NICKEL_ERROR("Couldn't link pads");
        return false;
    } else {
        NICKEL_INFO("Pads linked.");
    }

    return true;
}

bool VirtualBin::parentCallback(VirtualBinCallbackAction::Enum action,
                                boost::shared_ptr<VirtualBin> bin,
                                boost::shared_ptr<VirtualPad> pad)
{
    NICKEL_FUNC_TRACE;

    if (callback) {
        return callback(action, bin, pad);
    } else {
        NICKEL_ERROR("Parent calback wasn't set on virtual bin");
    }
    return false;
}

boost::shared_ptr<VirtualPad> VirtualBin::wrapSrcPad(GstPad* pad)
{
    return getSrcPadFactory()->wrap(
        mirrorPad(RefObj<GstPad>(pad, true), container).retain());
}

boost::shared_ptr<VirtualPad> VirtualBin::wrapSinkPad(GstPad* pad)
{
    return getSinkPadFactory()->wrap(
        mirrorPad(RefObj<GstPad>(pad, true), container).retain());
}

boost::shared_ptr<VirtualPadFactory> VirtualBin::getSrcPadFactory()
{
    return srcPadFactory;
}

boost::shared_ptr<VirtualPadFactory> VirtualBin::getSinkPadFactory()
{
    return sinkPadFactory;
}

RefObj<GstElement> VirtualBin::getParent() const
{
    return container;
}

void VirtualBin::setDispatcher(
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher)
{
    if (this->dispatcher) {
        throw std::runtime_error("dispatcher already set!");
    }
    this->dispatcher = dispatcher;
}

boost::shared_ptr<NS_ZINC::Dispatcher> VirtualBin::getDispatcher() const
{
    return dispatcher;
}

VirtualBinFactory::VirtualBinFactory(
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher)
    : dispatcher(dispatcher)
{
}

VirtualBinFactory::~VirtualBinFactory()
{
}

boost::shared_ptr<NS_ZINC::Dispatcher> VirtualBinFactory::getDispatcher()
{
    return dispatcher;
}

NS_NICKEL_SYSTEM_CLOSE
