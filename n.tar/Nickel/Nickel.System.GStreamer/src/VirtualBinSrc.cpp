/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "VirtualBinSrc.h"

#include <nickel-common/NickelLogger.h>

#include <boost/algorithm/string.hpp>
#include <boost/assert.hpp>
#include <boost/lexical_cast.hpp>

NS_NICKEL_SYSTEM_OPEN

int64_t VirtualBinSrc::getTimeshiftBufferLimitMiliseconds() const
{
    // this is temporary value until timeshifting for multicast is enabled
    return 0;
}

void VirtualBinSrc::newDecodebinPadCb(GstElement* element, GstPad* pad,
                                      gpointer data)
{
    NICKEL_FUNC_TRACE;
    VirtualBinSrc* const vbin = static_cast<VirtualBinSrc*>(data);
    vbin->newDecodebinPad(element, pad);
}

void VirtualBinSrc::newDecodebinPad(GstElement*, GstPad* pad)
{
    NICKEL_FUNC_TRACE;
    const boost::shared_ptr<VirtualPad> wrappedPad = wrapSrcPad(pad);
    BOOST_ASSERT(wrappedPad);

    parentCallback(
        VirtualBinCallbackAction::RequestPadConnection,
        shared_from_this(),
        wrappedPad);
}

RefObj<GstElement> VirtualBinSrc::makeAndSetupDecodebin(
    const char* const outputCaps)
{
    NICKEL_FUNC_TRACE;

    const RefObj<GstElement> decodebin =
        gst_element_factory_make("decodebin", NULL);
    g_object_set(decodebin.get(),
                 "caps", gst_caps_from_string(outputCaps),
                 NULL);

    NICKEL_TRACE("decoderbin: caps requested: " << outputCaps);

    g_signal_connect(decodebin.get(), "pad-added",
                     G_CALLBACK(newDecodebinPadCb),
                     static_cast<gpointer>(this));

    return sink = decodebin;
}

VirtualBinSrc::VirtualBinSrc(
    boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
    boost::shared_ptr<VirtualPadFactory> srcPadFactory,
    VirtualBin::CallbackType callback)
    : VirtualBin(sinkPadFactory, srcPadFactory, "VirtualBinSrc", callback),
      sink()
{
    elementFactory["application/dash+xml"] =
        boost::bind(&VirtualBinSrc::makeAndSetupDecodebin, this,
            "video/quicktime; audio/x-m4a; text/x-raw");

    elementFactory["application/x-hls"] =
        boost::bind(&VirtualBinSrc::makeAndSetupDecodebin, this,
            "video/mpegts");
}

std::vector<Track> VirtualBinSrc::getTracks() const
{
    return std::vector<Track>();
}

std::map<std::string, std::string> VirtualBinSrc::getSourceInformation() const
{
    NICKEL_FUNC_TRACE;
    std::map<std::string, std::string> si;

    // fake some stream health stats until we decide what we want to expose for
    // various media
    static uint64_t fake_outputs = 0;

    si["CONFIGURATION"] = "LINEAR.MULTICAST";
    si["TYPE"] = "RTP";
    si["POST_REPAIR_LOSSES"] = "0";
    si["POST_REPAIR_OUTPUTS"] =
        boost::lexical_cast<std::string>(fake_outputs++);

    return si;
}

class VirtualBinSrcFactory : public VirtualBinFactory
{
public:
    VirtualBinSrcFactory(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher) :
        VirtualBinFactory(dispatcher)
    {
    }

    boost::shared_ptr<VirtualBin> create(
        boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
        boost::shared_ptr<VirtualPadFactory> srcPadFactory,
        VirtualBin::CallbackType callback)
    {
        const boost::shared_ptr<VirtualBin> bin =
            boost::make_shared<VirtualBinSrc>(sinkPadFactory,
                                              srcPadFactory,
                                              callback);
        bin->setDispatcher(getDispatcher());
        return bin;
    }
};

NS_NICKEL_SYSTEM_CLOSE
