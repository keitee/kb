/*
 * Author: Krzysztof Konopko <kris@youview.com>
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_GST_MEDIAROUTER_FACTORY_H_
#define NICKEL_SYSTEM_GST_MEDIAROUTER_FACTORY_H_

#include <nickel-system-api/MediaRouterFactory.h>

NS_NICKEL_SYSTEM_OPEN

boost::shared_ptr<MediaRouterFactoryAsync> createGstMediaRouterFactory(
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher);

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_GST_MEDIAROUTER_FACTORY_H_ */
