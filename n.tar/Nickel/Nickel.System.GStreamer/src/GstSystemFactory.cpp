/*
 * Author: william.manley@youview.com
 *         kris@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "GstMediaRouterFactory.h"

#include <nickel-common/NickelLogger.h>

#include <nickel-system-api/SystemFactory.h>

#include <zinc-common/async/SingleThreadDispatcher.h>

#include <boost/make_shared.hpp>
#include <boost/weak_ptr.hpp>

#include <stdexcept>

#define NOT_IMPLEMENTED throw std::runtime_error("Not implemented");

NS_NICKEL_SYSTEM_OPEN

class GstSystemFactory : virtual public SystemFactory
{

public:
    GstSystemFactory(boost::shared_ptr<NS_ZINC::Dispatcher> d);

    boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory();

    boost::shared_ptr<MediaRouter> createDefaultMediaRouter();

    boost::shared_ptr<LocalMediaLibrary> createLocalMediaLibrary();

    boost::shared_ptr<MediaSettings> createMediaSettings();

    boost::shared_ptr<OutputManager> createOutputManager();

    boost::shared_ptr<ServiceListBuilder> createServiceListBuilder();

private:
    boost::shared_ptr<NS_ZINC::EventDispatcher> dispatcher;
    boost::weak_ptr<MediaRouterFactory> mediaRouterFactory;
};

GstSystemFactory::GstSystemFactory(boost::shared_ptr<NS_ZINC::Dispatcher> d) :
    dispatcher(d)
{
}

boost::shared_ptr<MediaRouterFactory>
GstSystemFactory::createMediaRouterFactory()
{
    boost::shared_ptr<MediaRouterFactory> mrf = mediaRouterFactory.lock();
    if (mrf) {
        return mrf;
    } else {
        mrf = createGstMediaRouterFactory(dispatcher);
        mediaRouterFactory = mrf;
        return mrf;
    }
}

boost::shared_ptr<MediaRouter> GstSystemFactory::createDefaultMediaRouter()
{
    const boost::shared_ptr<MediaRouterFactory> mrf =
        createMediaRouterFactory();
    return mrf->createMediaRouter().get();
}

boost::shared_ptr<LocalMediaLibrary> GstSystemFactory::createLocalMediaLibrary()
{
    NOT_IMPLEMENTED
}

boost::shared_ptr<MediaSettings> GstSystemFactory::createMediaSettings()
{
    NOT_IMPLEMENTED
}

boost::shared_ptr<OutputManager> GstSystemFactory::createOutputManager()
{
    NOT_IMPLEMENTED
}

boost::shared_ptr<ServiceListBuilder>
GstSystemFactory::createServiceListBuilder()
{
    NOT_IMPLEMENTED
}

extern "C"
NS_ZINC::Plugin* createGstSystemFactory() ZINC_EXPORT;

NS_ZINC::Plugin* createGstSystemFactory()
{
    try
    {
        return new GstSystemFactory(
            boost::make_shared<NS_ZINC::SingleThreadDispatcher>());
    }
    catch (...)
    {
        NICKEL_FATAL("Error while creating GstSystemFactory");
        return NULL;
    }
}

NS_NICKEL_SYSTEM_CLOSE
