/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_VIRTUALBIN_H_
#define NICKEL_SYSTEM_VIRTUALBIN_H_

#include "RefObj.h"

#include <nickel-system-api/MediaRouter.h>

#include <zinc-common/async/Dispatcher.h>

#include <boost/tuple/tuple.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/thread/mutex.hpp>

#include <gst/gst.h>

NS_NICKEL_SYSTEM_OPEN

// Some utility bits mainly for the clients
RefObj<GstPad> mirrorPad(const RefObj<GstPad>& pad,
                         const RefObj<GstElement>& bin,
                         const char* padName = NULL);

struct VirtualBinCallbackAction
{
    enum Enum
    {
        StateChange = 0,
        RequestPadConnection
    };
};

class VirtualPad;

class VirtualPadFactory
    : boost::noncopyable,
      public boost::enable_shared_from_this<VirtualPadFactory>
{
public:

    /*
     * Parent can register a callback which will be executed when there's a new
     * pad managed by the factory added. This is handy in the process split
     * model where factories will negotiate new pads over IPC mechanism (DBus)
     * and client application will be then notified about new source pads in the
     * process to use.
     *
     */
    VirtualPadFactory();

    virtual ~VirtualPadFactory();

    /*
     * Takes a raw GstPad and returns VirtualPad which represents the raw
     * pad. This can be passed in a wrapped form and it's up to the concrete
     * implementation to know how to deal with that pad - especially across
     * process boundary.
     *
     */
    virtual boost::shared_ptr<VirtualPad> wrap(GstPad* pad) = 0;

    /*
     * Unwraps an abstract pad and returns a GstPad and a GstElement.
     *
     * GstElement is optional and is not used in the in-process version but as
     * soon as the factory needs to add additional elements to the pipeline to
     * unwrap a pad, like it would for IPC pipeline, that GstElement should be
     * added to the client's pipeline.
     *
     */
    virtual boost::tuple<GstPad*, GstElement*> unwrap(
        boost::shared_ptr<VirtualPad> pad) = 0;

private:
    boost::function<bool(boost::shared_ptr<VirtualPad>)> callback;
};

class VirtualPad
    : boost::noncopyable,
      public boost::enable_shared_from_this<VirtualPad>
{
public:
    VirtualPad(boost::shared_ptr<VirtualPadFactory> factory);
    virtual ~VirtualPad();

    boost::shared_ptr<VirtualPadFactory> getFactory();
    boost::tuple<GstPad*, GstElement*> unwrap();

private:
    boost::shared_ptr<VirtualPadFactory> factory;
};

class ZINC_EXPORT VirtualBin
    : boost::noncopyable,
      public boost::enable_shared_from_this<VirtualBin>
{
public:
    typedef boost::function<
        bool(VirtualBinCallbackAction::Enum,
             boost::shared_ptr<VirtualBin>,
             boost::shared_ptr<VirtualPad>)> CallbackType;

    VirtualBin(boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
               boost::shared_ptr<VirtualPadFactory> srcPadFactory,
               const char* binName,
               CallbackType callback = CallbackType());

    virtual ~VirtualBin();

    /*
     * Parent calls this when it gets a new pad from downstream virtual bin.  At
     * this point this virtual bin tries to autoplug the pad or returns false if
     * it failed.
     */
    bool autoplug(boost::shared_ptr<VirtualPad> srcpad);

    /*
     * Gets a GStreamer element which must be added to the master pipeline after
     * virtual bin is created. All the elements required by the implementation
     * of the particular virtual bin must be contained within this parent bin
     * element.
     */
    RefObj<GstElement> getParent() const;

    /*
     * Media related interface
     *
     * These methods are a copy of equivalent MediaRouter calls.
     */

    virtual void setSource(const std::string& sourceUri);
    virtual void setUserAgent(const std::string& userAgent);
    virtual void setVolume(const int32_t volume);
    virtual int32_t getVolume() const;
    virtual std::vector<Track> getTracks() const;
    virtual void setVideoWindow(const VideoWindowDescriptor& videoWindow);

    /*
     * Helper functions required for the MediaRouter to function correctly
     */
    virtual int64_t getTimeshiftBufferLimitMilliseconds() const;

    std::map<std::string, std::string> getSourceInformation() const;

    void setDispatcher(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher);
    boost::shared_ptr<NS_ZINC::Dispatcher> getDispatcher() const;

    RefObj<GstPad> plug(const RefObj<GstPad>& pad);

protected:
    bool parentCallback(VirtualBinCallbackAction::Enum action,
                        boost::shared_ptr<VirtualBin> bin,
                        boost::shared_ptr<VirtualPad> pad);

    boost::shared_ptr<VirtualPad> wrapSrcPad(GstPad* pad);
    boost::shared_ptr<VirtualPad> wrapSinkPad(GstPad* pad);

    boost::shared_ptr<VirtualPadFactory> getSrcPadFactory();
    boost::shared_ptr<VirtualPadFactory> getSinkPadFactory();

    typedef std::map<std::string,
                     boost::function<RefObj<GstElement>()> > FactoryContainer;

    FactoryContainer elementFactory;

private:
    RefObj<GstPad> plug_unlocked(const RefObj<GstPad>& pad);

    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;
    CallbackType callback;
    boost::shared_ptr<VirtualPadFactory> sinkPadFactory;
    boost::shared_ptr<VirtualPadFactory> srcPadFactory;
    const RefObj<GstElement> container;
    boost::mutex lock;
};

class VirtualBinFactory
    : boost::noncopyable,
      public boost::enable_shared_from_this<VirtualBinFactory>
{
public:
    VirtualBinFactory(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher);
    virtual ~VirtualBinFactory();

    virtual boost::shared_ptr<VirtualBin> create(
        boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
        boost::shared_ptr<VirtualPadFactory> srcPadFactory,
        VirtualBin::CallbackType callback) = 0;

    boost::shared_ptr<NS_ZINC::Dispatcher> getDispatcher();

private:
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;
};

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKEL_SYSTEM_VIRTUALBIN_H_
