/*
 * Author: William Manley <william.manley@youview.com>
 *         Krzysztof Konopko <kris@youview.com>
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "GstMediaRouterFactory.h"
#include "GstMediaRouter.h"

#include <nickel-common/NickelLogger.h>

#include <zinc-common/async/async-helpers.h>

#include <boost/make_shared.hpp>
#include <boost/noncopyable.hpp>
#include <boost/thread.hpp>

#include <glib.h>
#include <gst/gst.h>

NS_NICKEL_SYSTEM_OPEN

class GstMediaRouterFactory : public MediaRouterFactoryAsync, boost::noncopyable
{
public:
    GstMediaRouterFactory(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher);
    virtual ~GstMediaRouterFactory();

    virtual NS_ZINC::Future<boost::shared_ptr<MediaRouterAsync> >
    createMediaRouter();

private:
    struct Semaphore
    {
        boost::mutex m;
        boost::condition_variable cond;
    };

    static gboolean startFunc(gpointer data);
    void start();

    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;

    GMainLoop* loop;
    boost::thread glibMainThread;
};

GstMediaRouterFactory::GstMediaRouterFactory(
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher) : dispatcher(dispatcher)
{
    NICKEL_FUNC_TRACE;

    /* init GStreamer */
    gst_init(NULL, NULL);
    loop = g_main_loop_new(NULL, FALSE);

    boost::thread(g_main_loop_run, loop).swap(glibMainThread);

    /*
     * We do not want to return until the main loop has started.  This is to
     * avoid race conditions like this object being destroyed and trying to join
     * the main loop thread right after the main loop entered "poll" sequence
     * without noticing it's been stopped.
     */
    start();
}

GstMediaRouterFactory::~GstMediaRouterFactory()
{
    NICKEL_FUNC_TRACE;
    g_main_loop_quit(loop);
    glibMainThread.join();
}

void GstMediaRouterFactory::start()
{
    Semaphore sem;

    boost::mutex::scoped_lock lock(sem.m);
    g_idle_add(startFunc, &sem);

    sem.cond.wait(lock);
}

gboolean GstMediaRouterFactory::startFunc(gpointer data)
{
    Semaphore* const sem = static_cast<Semaphore*>(data);

    const boost::mutex::scoped_lock lock(sem->m);
    sem->cond.notify_one();

    return G_SOURCE_REMOVE;
}

NS_ZINC::Future<boost::shared_ptr<MediaRouterAsync> >
GstMediaRouterFactory::createMediaRouter()
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*dispatcher,
                                    createGstMediaRouter(dispatcher));
}

boost::shared_ptr<MediaRouterFactoryAsync> createGstMediaRouterFactory(
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher)
{
    return boost::make_shared<GstMediaRouterFactory>(dispatcher);
}

NS_NICKEL_SYSTEM_CLOSE
