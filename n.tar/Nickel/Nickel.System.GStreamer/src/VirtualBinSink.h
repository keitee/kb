/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_VIRTUALBINSINK_H_
#define NICKEL_SYSTEM_VIRTUALBINSINK_H_

#include "VirtualBin.h"

NS_NICKEL_SYSTEM_OPEN

class ZINC_EXPORT VirtualBinSink : public VirtualBin
{
public:
    VirtualBinSink(boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
                   boost::shared_ptr<VirtualPadFactory> srcPadFactory,
                   VirtualBin::CallbackType callback);
    ~VirtualBinSink();

    void setVideoWindow(const VideoWindowDescriptor& videoWindow);
};

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKEL_SYSTEM_VIRTUALBINSINK_H_
