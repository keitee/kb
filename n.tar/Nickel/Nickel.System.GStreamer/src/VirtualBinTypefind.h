/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_VIRTUALBINTYPEFIND_H_
#define NICKEL_SYSTEM_VIRTUALBINTYPEFIND_H_

#include "VirtualBin.h"

NS_NICKEL_SYSTEM_OPEN

class ZINC_EXPORT VirtualBinTypefind : public VirtualBin
{
public:
    VirtualBinTypefind(boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
                       boost::shared_ptr<VirtualPadFactory> srcPadFactory,
                       VirtualBin::CallbackType);
    ~VirtualBinTypefind();

    void setSource(const std::string& sourceUri);

private:
    static void newPadCb(GstElement *element, GstPad *pad, gpointer data);
    void newPad(GstElement *decodebin, GstPad *pad);

    RefObj<GstElement> uridecodebin;
};

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKEL_SYSTEM_VIRTUALBINTYPEFIND_H_
