/*
 * Author: william.manley@youview.com
 *         mariusz.buras@youview.com
 *         kris@youview.com
 *
 * Copyright(C) 2015 YouView TV Ltd.
 */

#include "GstMediaRouter.h"

#include "RefObj.h"

// IPC abstraction layer
#include "VirtualBinTypefind.h"
#include "VirtualBinSrc.h"
#include "VirtualBinSink.h"
#include "VirtualPadInProcess.h"

#include <nickel-common/NickelLogger.h>

#include <nickel-system-api/nickel-system-exceptions.h>
#include <nickel-system-api/MediaRouterEventListener.h>

#include <zinc-common/async/async-helpers.h>

#include <boost/algorithm/string/predicate.hpp>
#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/signals2.hpp>
#include <boost/thread/locks.hpp>
#include <boost/thread/mutex.hpp>

#include <gst/gst.h>

#include <stdexcept>

#define NOT_IMPLEMENTED \
    throw std::runtime_error(std::string("Not implemented: ") + \
                             __PRETTY_FUNCTION__);

// NOTE:
//
// Some functions are not implemented. For some of the not implemented functions
// we fake some value and pretend it worked. This is to support enough methods
// to convince any simple client into thinking it's all fine. For some less
// often used functions we throw.

// TODO: Additional events to produce:
//
// BufferStatusEvent(BufferStatusEventValue type)
//   types:
//      BUFFERING_STARTED
//      BUFFERING_COMPLETE
//      ABR_SEGMENT_COMPLETE
// DrmEvent(DrmEventValue type, string drmMediaIdentifier, string rightsIssuerUrl)
//   types:
//      LICENCE_REQUIRED
//      SYSTEM_ERROR
//      BAD_REQUEST
//      SERVER_UNREACHABLE
//      SERVER_DENIED
//      BAD_SERVER_RESPONSE
//      BAD_CONTENT_FORMAT
//      UNMET_LICENCE_REQUIREMENT
//      LICENCE_FORMAT_ERROR
//      MISSING_CREDENTIALS
//      EXPIRED
//      PLAY_COUNT_EXCEEDED
//      SUBSCRIPTION_EXPIRED
//      OTHER
// PositionChangeEvent(Position position)
// SourceEvent(SourceEventValue type, SetSourceReason reason)
//   types:
//      CHANGE_INITIATED <-- Start of channel change
// (*)  CHANGE_COMPLETE <-- End of channel change
//      SOURCE_INFORMATION_CHANGE <-- "Restricted mode" has been entered/exited
//      SOURCE_CONFIG_COMPLETE <-- SetSource is complete and getMediaDuration will now work and getPosition().end are now valid
//      TRACKS_CHANGED <-- List of tracks???? have changed
//   reasons:
//      UNSPECIFIED <-- Always unspecified unless event raised in response to setSource() in which case it's whatever was passed in
//      MHEGSTANDARD
//      MHEGQUIET
//      MHEGNONDESTRUCTIVE
//      MHEGNONDESTRUCTIVEQUIET
// SpeedChangeEvent()
// StatusEvent(StatusEventValue type)
//    types:
//      STARTED
//      COMPLETE
//      WAITING
//      STOPPED
//      UNDERFLOW
//      SEEK_STARTED

NS_NICKEL_SYSTEM_OPEN

struct OneShotFunctionCall
{
    typedef void result_type;

    OneShotFunctionCall(boost::function<void(void)> func, GstState desiredState)
        : func(func), desiredState(desiredState) {}
    OneShotFunctionCall(boost::function<void(void)> func)
        : func(func), desiredState(GST_STATE_VOID_PENDING) {}

    void operator()(const boost::signals2::connection& connection,
                    GstState /* oldstate */,
                    GstState newstate,
                    GstState /* pending */)
    {
        if (newstate == desiredState) {
            func();
            connection.disconnect();
        }
    }

    void operator()(const boost::signals2::connection& connection)
    {
        func();
        connection.disconnect();
    }

    boost::function<void(void)> func;
    const GstState desiredState;
};

class GstMediaRouter : public MediaRouterAsync
{

public:
    GstMediaRouter(boost::shared_ptr<NS_ZINC::Dispatcher> d);
    virtual ~GstMediaRouter();

    virtual NS_ZINC::Future<void> setSource(
        const std::string& mediaLocator,
        const SetSourceReason::Enum reason);
    virtual NS_ZINC::Future<std::string> getSource() const;

    virtual NS_ZINC::Future<void> setVolume(const int32_t volume);
    virtual NS_ZINC::Future<int32_t> getVolume() const;

    virtual NS_ZINC::Future<void> setAudioTrack(const int32_t tag);
    virtual NS_ZINC::Future<void> setAudioTrackExternal(
        const std::string& mediaLocator,
        const int32_t tag);
    virtual NS_ZINC::Future<Track> getAudioTrack() const;

    virtual NS_ZINC::Future<void> setVideoTrack(const int32_t tag);
    virtual NS_ZINC::Future<void> setVideoTrackExternal(
        const std::string& mediaLocator,
        const int32_t tag);
    virtual NS_ZINC::Future<Track> getVideoTrack() const;

    virtual NS_ZINC::Future<void> setSubtitleTrack(
        const int32_t tag,
        const std::string& language);
    virtual NS_ZINC::Future<Track> getSubtitleTrack() const;
    virtual NS_ZINC::Future<int32_t> addSubtitleTrack(
        const std::string& subtitleLocator);

    virtual NS_ZINC::Future<std::vector<Track> > getTracks() const;

    virtual NS_ZINC::Future<void> setVideoWindow(
        const VideoWindowDescriptor& videoWindow);
    virtual NS_ZINC::Future<VideoWindowDescriptor> getVideoWindow() const;

    virtual NS_ZINC::Future<void> setPlaySpeed(const double speed);
    virtual NS_ZINC::Future<double> getPlaySpeed() const;

    virtual NS_ZINC::Future<void> seekPosition(
        const SeekReference::Enum whence,
        const int32_t offset,
        const SeekMode::Enum mode);
    virtual NS_ZINC::Future<Position> getPosition() const;

    virtual NS_ZINC::Future<void> setSink(const std::string& mediaLocator);
    virtual NS_ZINC::Future<std::string> getSink() const;

    virtual NS_ZINC::Future<void> setEndTime(const int32_t end);
    virtual NS_ZINC::Future<int32_t> getEndTime() const;

    virtual NS_ZINC::Future<void> start();
    virtual NS_ZINC::Future<void> startDeferred();
    virtual NS_ZINC::Future<ControlCapabilities> getControlCapabilities() const;
    virtual NS_ZINC::Future<void> stop();

    virtual NS_ZINC::Future<void> setBufferingMode(
        const std::map<std::string, std::string>& bufferingMode);
    virtual NS_ZINC::Future<std::map<std::string, std::string> >
        getBufferingMode() const;
    virtual NS_ZINC::Future<void> startBuffering();
    virtual NS_ZINC::Future<void> stopBuffering();
    virtual NS_ZINC::Future<BufferStatus> getBufferStatus() const;

    virtual NS_ZINC::Future<void> setVideoTerminationMode(
        const VideoTerminationMode::Enum mode);
    virtual NS_ZINC::Future<VideoTerminationMode::Enum>
        getVideoTerminationMode() const;

    virtual NS_ZINC::Future<std::map<std::string, std::string> >
        getSourceInformation() const;

    virtual NS_ZINC::Future<void> setMediaDuration(const int32_t duration);
    virtual NS_ZINC::Future<int32_t> getMediaDuration() const;

    virtual NS_ZINC::Future<ABRStreamSet> getABRStreamSet() const;
    virtual NS_ZINC::Future<ABRStatus> getABRStatus() const;
    virtual NS_ZINC::Future<void> setABRStream(
        const int32_t streamIndex,
        const bool deferred);

    virtual NS_ZINC::Future<void> setCaptureMode(
        const TimeShiftCaptureMode::Enum mode);
    virtual NS_ZINC::Future<TimeShiftCaptureMode::Enum> getCaptureMode() const;

    virtual NS_ZINC::Future<void> recycle();

private:

    void init();
    void deinit();

    static gboolean busCallback(GstBus* bus, GstMessage* msg, gpointer data);
    bool handleBusCallback(GstBus* bus, GstMessage* msg);

    bool plugVirtualPad(VirtualBinCallbackAction::Enum action,
        boost::shared_ptr<VirtualBin>, boost::shared_ptr<VirtualPad>);

    void produceStatusEvent(StatusEventValue::Enum what);
    void produceBufferingEvent(BufferStatusEventValue::Enum what);

    // locked functions
    NS_ZINC::Future<void> stop_locked(StatusEventValue::Enum eventValue);
    NS_ZINC::Future<void> recycle_locked();

    mutable boost::mutex lock;

    std::string src, sink;
    bool live;
    mutable RefObj<GstElement> pipeline;

    guint watchId;

    bool stopped;
    boost::signals2::signal<void(GstState, GstState, GstState)> onStateChange;
    boost::signals2::signal<void(void)> onAsyncEvent;

    // TODO: all this should be construction injected
    // but until we have proper IPC split this may wait

    // typefind section doesn't need to have src pad factory
    boost::shared_ptr<VirtualBin> typefindBin;
    boost::shared_ptr<VirtualPadFactory> typefindPadFactory_sinkpads;

    // source section needs both sink and source pads
    boost::shared_ptr<VirtualBin> srcBin;
    boost::shared_ptr<VirtualPadFactory> srcPadFactory_sinkpads;
    boost::shared_ptr<VirtualPadFactory> srcPadFactory_srcpads;

    // sink section needs only sink pads
    boost::shared_ptr<VirtualBin> sinkBin;
    boost::shared_ptr<VirtualPadFactory> sinkPadFactory_sinkpads;
};

gboolean GstMediaRouter::busCallback(GstBus* bus, GstMessage* msg, gpointer data)
{
    return static_cast<GstMediaRouter*>(data)->handleBusCallback(bus, msg) ?
        TRUE : FALSE;
}

bool GstMediaRouter::handleBusCallback(GstBus* /*bus*/, GstMessage* msg)
{
    const boost::lock_guard<boost::mutex> l(lock);

    switch (GST_MESSAGE_TYPE(msg)) {

    case GST_MESSAGE_EOS:
        (void)stop_locked(StatusEventValue::complete);
        break;

    case GST_MESSAGE_ASYNC_DONE:
        onAsyncEvent();
        break;

    case GST_MESSAGE_ERROR:
        break;

    case GST_MESSAGE_STATE_CHANGED:
    {
        GstState oldstate, newstate, pending;

        gst_message_parse_state_changed(msg, &oldstate, &newstate, &pending);

        // sink state changes can be usefull to determine tracks availability
        if (pipeline == GST_ELEMENT(msg->src)) {
            NICKEL_TRACE(
                "State transition "
                << gst_element_state_get_name(oldstate)
                << " -> " << gst_element_state_get_name(newstate)
                << " wanted " << gst_element_state_get_name(pending));

            onStateChange(oldstate, newstate, pending);
        }

        break;
    }

    default:
        // we ignore anything we don't explicitly want
        break;
    }

    return true;
}

bool GstMediaRouter::plugVirtualPad(VirtualBinCallbackAction::Enum action,
    boost::shared_ptr<VirtualBin> bin,
    boost::shared_ptr<VirtualPad> vpad)
{
    NICKEL_FUNC_TRACE;
    boost::lock_guard<boost::mutex> l(lock);
    if (action == VirtualBinCallbackAction::RequestPadConnection) {
        if (bin == typefindBin && srcBin->autoplug(vpad)) {
            NICKEL_TRACE("connected typefindbin to srcbin!");
        } else if (bin == srcBin && sinkBin->autoplug(vpad)) {
            NICKEL_TRACE("srcbin requested connection");
        } else if (bin == sinkBin) {
            NICKEL_TRACE("sinkbin shouldn't request pad connection!");
        } else {
            NICKEL_ERROR("Pad linking failed!");
            return false;
        }
    }
    return true;
}

void GstMediaRouter::produceStatusEvent(
    const StatusEventValue::Enum what)
{
    produceEvent(
        boost::bind(&MediaRouterEventListener::StatusEvent,
                    _1,
                    what));
}

void GstMediaRouter::produceBufferingEvent(
    const BufferStatusEventValue::Enum what)
{
    produceEvent(
        boost::bind(&MediaRouterEventListener::BufferStatusEvent,
                    _1,
                    what));
}


void GstMediaRouter::init()
{
    NICKEL_FUNC_TRACE;

    typefindBin =
        boost::make_shared<VirtualBinTypefind>(
            boost::shared_ptr<VirtualPadFactoryInProcess>(),
            typefindPadFactory_sinkpads,
            boost::bind(&GstMediaRouter::plugVirtualPad, this, _1, _2, _3));

    srcBin =
        boost::make_shared<VirtualBinSrc>(
            srcPadFactory_srcpads,
            srcPadFactory_sinkpads,
            boost::bind(&GstMediaRouter::plugVirtualPad, this, _1, _2, _3));

    sinkBin =
        boost::make_shared<VirtualBinSink>(
            sinkPadFactory_sinkpads,
            boost::shared_ptr<VirtualPadFactoryInProcess>(),
            boost::bind(&GstMediaRouter::plugVirtualPad, this, _1, _2, _3));

    typefindBin->setDispatcher(getDispatcher());
    srcBin->setDispatcher(getDispatcher());
    sinkBin->setDispatcher(getDispatcher());

    RefObj<GstElement> elem = gst_pipeline_new("pipeline");
    if (!elem) {
        NICKEL_ERROR("Failed to create pipeline element");
        return;
    }

    gst_bin_add_many(GST_BIN(elem.get()),
                     typefindBin->getParent().retain(),
                     srcBin->getParent().retain(),
                     sinkBin->getParent().retain(), NULL);

    const RefObj<GstBus> bus =
        gst_pipeline_get_bus(GST_PIPELINE(elem.get()));
    if (!bus) {
        NICKEL_ERROR("Failed to get pipeline bus");
        return;
    }

    watchId = gst_bus_add_watch(bus.get(), busCallback, this);

    src.clear();
    sink.clear();

    live = false;
    stopped = true;
    elem.swap(pipeline);
}

void GstMediaRouter::deinit()
{
    NICKEL_FUNC_TRACE;

    onStateChange.disconnect_all_slots();
    onAsyncEvent.disconnect_all_slots();

    g_source_remove(watchId);
    watchId = 0;

    // setting state to NULL is a blocking operation
    if (GST_STATE_CHANGE_SUCCESS !=
        gst_element_set_state(pipeline.get(), GST_STATE_NULL)) {
        NICKEL_ERROR("Failed to set pipeline state to NULL");
    }

    live = false;
    stopped = true;
    pipeline.reset();
}

GstMediaRouter::GstMediaRouter(boost::shared_ptr<NS_ZINC::Dispatcher> d) :
    NS_ZINC::DispatchingEventProducer<MediaRouterEventListener>(d),
    live(false),
    watchId(0),
    stopped(true)
{
    NICKEL_FUNC_TRACE;

    typefindPadFactory_sinkpads = boost::make_shared<VirtualPadFactoryInProcess>();
    srcPadFactory_srcpads = boost::make_shared<VirtualPadFactoryInProcess>();
    srcPadFactory_sinkpads = boost::make_shared<VirtualPadFactoryInProcess>();
    sinkPadFactory_sinkpads = boost::make_shared<VirtualPadFactoryInProcess>();

    init();
}

GstMediaRouter::~GstMediaRouter()
{
    NICKEL_FUNC_TRACE;

    deinit();
}

NS_ZINC::Future<void> GstMediaRouter::setSource(
    const std::string& mediaLocator,
    const SetSourceReason::Enum reason)
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);

    if (!src.empty()) {
        return
            NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                             IllegalReconfigurationException());
    }

    if (mediaLocator.empty()) { 
        return NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                                InvalidLocatorException());
    } else if (boost::starts_with(mediaLocator, "dvb://")) {
        return NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                                InvalidLocatorException());
    } else if (boost::starts_with(mediaLocator, "linear:")) {
        return NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                                InvalidLocatorException());
    } else {
        src = mediaLocator;
    }

    // TODO: work out whether the source is live

    typefindBin->setSource(src);

    // send CHANGE_COMPLETE signal
    // TODO: in the future move to a place when we know that source if configured
    produceEvent(
        boost::bind(
            &MediaRouterEventListener::SourceEvent, _1,
            SourceEventValue::change_complete, reason));

    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<std::string> GstMediaRouter::getSource() const
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);

    return src.empty() ?
        NS_ZINC::exceptionalFuture<std::string>(*getDispatcher(),
                                                NotConfiguredException()) :
        NS_ZINC::completedFuture<std::string>(*getDispatcher(), src);
}

NS_ZINC::Future<void> GstMediaRouter::setVolume(const int32_t volume)
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);

    sinkBin->setVolume(volume);
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<int32_t> GstMediaRouter::getVolume() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), 0);
}

NS_ZINC::Future<void> GstMediaRouter::setAudioTrack(const int32_t /* tag */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<void> GstMediaRouter::setAudioTrackExternal(
    const std::string& /* mediaLocator */,
    const int32_t /* tag */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<Track> GstMediaRouter::getAudioTrack() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), Track());
}

NS_ZINC::Future<void> GstMediaRouter::setVideoTrack(const int32_t /* tag */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<void> GstMediaRouter::setVideoTrackExternal(
    const std::string& /* mediaLocator */,
    const int32_t /* tag */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<Track> GstMediaRouter::getVideoTrack() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), Track());
}

NS_ZINC::Future<void> GstMediaRouter::setSubtitleTrack(
    const int32_t /* tag */,
    const std::string& /* language */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<Track> GstMediaRouter::getSubtitleTrack() const
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<int32_t> GstMediaRouter::addSubtitleTrack(
    const std::string& /* subtitleLocator */)
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<std::vector<Track> > GstMediaRouter::getTracks() const
{
    NICKEL_FUNC_TRACE;
    const boost::lock_guard<boost::mutex> l(lock);
    return NS_ZINC::completedFuture(*getDispatcher(), srcBin->getTracks());
}

NS_ZINC::Future<void> GstMediaRouter::setVideoWindow(
    const VideoWindowDescriptor& /* videoWindow */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<VideoWindowDescriptor> GstMediaRouter::getVideoWindow() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(),
                                    VideoWindowDescriptor(0.0, 0.0, 1.0, 1.0,
                                                          0.0, 0.0, 1.0, 1.0));
}

NS_ZINC::Future<void> GstMediaRouter::setPlaySpeed(const double speed)
{
    NICKEL_FUNC_TRACE;
    const boost::lock_guard<boost::mutex> l(lock);

    if (!stopped) {
        if (speed == 1.0) {
            gst_element_set_state(pipeline.get(), GST_STATE_PLAYING);
        } else if (speed == 0.0) {
            gst_element_set_state(pipeline.get(), GST_STATE_PAUSED);
        } else {
            // TODO: support trickplay :)
            NICKEL_WARN("Client shouldn't request unsupported play speed!");
        }
    } else {
        NICKEL_WARN("setPlaySpeed called on stopped MediaRouter");
    }

    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<double> GstMediaRouter::getPlaySpeed() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), 1.0);
}

NS_ZINC::Future<void> GstMediaRouter::seekPosition(
    const SeekReference::Enum /* whence */,
    const int32_t /* offset */,
    const SeekMode::Enum /* mode */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<Position> GstMediaRouter::getPosition() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), Position());
}

NS_ZINC::Future<void> GstMediaRouter::setSink(
    const std::string& mediaLocator)
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);

    if (!sink.empty()) {
        return
            NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                             IllegalReconfigurationException());
    }

    if (mediaLocator != "decoder://0") {
        return
            NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                             InvalidLocatorException());
    }

    sink = mediaLocator;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<std::string> GstMediaRouter::getSink() const
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);

    return sink.empty() ?
        NS_ZINC::exceptionalFuture<std::string>(*getDispatcher(),
                                                NotConfiguredException()) :
        NS_ZINC::completedFuture(*getDispatcher(), sink);
}

NS_ZINC::Future<void> GstMediaRouter::setEndTime(const int32_t /* end */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<int32_t> GstMediaRouter::getEndTime() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), 0);
}

NS_ZINC::Future<void> GstMediaRouter::start()
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);

    if (sink.empty() || src.empty()) {
        return NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                                NotConfiguredException());
    }

    stopped = false;

    // TODO: StopConflict error state is not implemented

    onStateChange.connect_extended(
        OneShotFunctionCall(
            boost::bind(&GstMediaRouter::produceStatusEvent,
                        this,
                        StatusEventValue::started),
            GST_STATE_PLAYING));

    if (GST_STATE_CHANGE_FAILURE ==
        gst_element_set_state(pipeline.get(), GST_STATE_PLAYING)) {
        NICKEL_ERROR("Failed to set the pipeline to playing");
    }

    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<void> GstMediaRouter::startDeferred()
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<ControlCapabilities>
GstMediaRouter::getControlCapabilities() const
{
    NICKEL_FUNC_TRACE;

    // Initially we just want to be an on-demand MediaRouter, which doesn't
    // support trick-play.
    // TODO: Support FF/RW/Slo-mo with "locally stored media" and then with
    //       linear playback buffer.

    return NS_ZINC::completedFuture(*getDispatcher(),
                                    ControlCapabilities(
                                        std::vector<int32_t>(),
                                        std::vector<int32_t>(),
                                        std::vector<double>(1, 1.0)));
}

NS_ZINC::Future<void> GstMediaRouter::stop_locked(
    StatusEventValue::Enum eventValue)
{
    NICKEL_FUNC_TRACE;

    if (!stopped) {
        onStateChange.connect_extended(
            OneShotFunctionCall(
                boost::bind(&GstMediaRouter::produceStatusEvent,
                            this,
                            eventValue),
                GST_STATE_PAUSED));

        const GstStateChangeReturn ret =
            gst_element_set_state(pipeline.get(), GST_STATE_PAUSED);

        if (ret == GST_STATE_CHANGE_FAILURE) {
            NICKEL_INFO("Failed to stop the pipeline");
        }

        stopped = true;
    }

    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<void> GstMediaRouter::stop()
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);
    return stop_locked(StatusEventValue::stopped);
}

NS_ZINC::Future<void> GstMediaRouter::setBufferingMode(
    const std::map<std::string, std::string>& /* bufferingMode */)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<std::map<std::string, std::string> >
GstMediaRouter::getBufferingMode() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(),
                                    std::map<std::string, std::string>());
}

NS_ZINC::Future<void> GstMediaRouter::startBuffering()
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);

    if (sink.empty() || src.empty()) {
        return NS_ZINC::exceptionalFuture<void>(*getDispatcher(),
                                                NotConfiguredException());
    }

    if (!stopped) {
        if (!live) {
            produceEvent(
                boost::bind(&MediaRouterEventListener::BufferStatusEvent,
                            _1,
                            BufferStatusEventValue::buffering_started));
        }

        // start preroll which in GStreamer implies acquiring enough content to
        // be able to transition into playing state very quickly
        onAsyncEvent.connect_extended(
            OneShotFunctionCall(
                boost::bind(&GstMediaRouter::produceBufferingEvent,
                            this,
                            BufferStatusEventValue::buffering_complete)));

        const GstStateChangeReturn ret =
            gst_element_set_state(pipeline.get(), GST_STATE_PAUSED);

        if (GST_STATE_CHANGE_FAILURE == ret) {
            // we're aready in paused state nothing to do
            NICKEL_ERROR("Could not start buffering");
        }
    }

    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<void> GstMediaRouter::stopBuffering()
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<BufferStatus> GstMediaRouter::getBufferStatus() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), BufferStatus());
}

NS_ZINC::Future<void> GstMediaRouter::setVideoTerminationMode(
    const VideoTerminationMode::Enum /* mode */)
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<VideoTerminationMode::Enum>
GstMediaRouter::getVideoTerminationMode() const
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<std::map<std::string, std::string> >
GstMediaRouter::getSourceInformation() const
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<void> GstMediaRouter::setMediaDuration(
    const int32_t /* duration */)
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<int32_t> GstMediaRouter::getMediaDuration() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher(), 0);
}

NS_ZINC::Future<ABRStreamSet> GstMediaRouter::getABRStreamSet() const
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<ABRStatus> GstMediaRouter::getABRStatus() const
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<void> GstMediaRouter::setABRStream(const int32_t, const bool)
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<void> GstMediaRouter::setCaptureMode(
    const TimeShiftCaptureMode::Enum)
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<TimeShiftCaptureMode::Enum>
GstMediaRouter::getCaptureMode() const
{
    NICKEL_FUNC_TRACE;
    NOT_IMPLEMENTED
}

NS_ZINC::Future<void> GstMediaRouter::recycle_locked()
{
    NICKEL_FUNC_TRACE;

    if (!src.empty() || !sink.empty()) {
        NICKEL_INFO("Bouncing Media Router state");

        if (!stopped) {
            stop_locked(StatusEventValue::stopped);
        }

        deinit();
        init();
    } else {
        NICKEL_INFO("Skipping recycle: already in recycled state");
    }

    return NS_ZINC::completedFuture(*getDispatcher());
}

NS_ZINC::Future<void> GstMediaRouter::recycle()
{
    NICKEL_FUNC_TRACE;

    const boost::lock_guard<boost::mutex> l(lock);
    return recycle_locked();
}

boost::shared_ptr<MediaRouterAsync> createGstMediaRouter(
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher)
{
    return boost::make_shared<GstMediaRouter>(dispatcher);
}

NS_NICKEL_SYSTEM_CLOSE
