/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "VirtualPadInProcess.h"

#include <nickel-common/NickelLogger.h>

NS_NICKEL_SYSTEM_OPEN

VirtualPadInProcess::VirtualPadInProcess(
    GstPad* pad, boost::shared_ptr<VirtualPadFactory> factory) :
    VirtualPad(factory),
    pad(pad, true /* increment ref counter */)
{
}

VirtualPadInProcess::~VirtualPadInProcess()
{
}

GstPad* VirtualPadInProcess::getRawGstPad()
{
    return pad.get();
}

VirtualPadFactoryInProcess::VirtualPadFactoryInProcess()
{
}

VirtualPadFactoryInProcess::~VirtualPadFactoryInProcess()
{
}

boost::shared_ptr<VirtualPad> VirtualPadFactoryInProcess::wrap(GstPad* pad)
{
    return boost::make_shared<VirtualPadInProcess>(pad, shared_from_this());
}

boost::tuple<GstPad*, GstElement*> VirtualPadFactoryInProcess::unwrap(
    boost::shared_ptr<VirtualPad> pad)
{
    NICKEL_FUNC_TRACE;

    const boost::shared_ptr<VirtualPadFactoryInProcess> upcastedFactory =
        boost::dynamic_pointer_cast<VirtualPadFactoryInProcess>(
            pad->getFactory());
    if (upcastedFactory && upcastedFactory.get() != this) {
        throw std::runtime_error("Can't unwrap pads from other factories.");
    }
    // we know that it was this factory which produced the pad so dynamic
    // casting will always work.
    const boost::shared_ptr<VirtualPadInProcess> upcasted =
        boost::dynamic_pointer_cast<VirtualPadInProcess>(pad);

    return boost::make_tuple<GstPad*, GstElement*>(upcasted->getRawGstPad(),
                                                   NULL);
}

NS_NICKEL_SYSTEM_CLOSE
