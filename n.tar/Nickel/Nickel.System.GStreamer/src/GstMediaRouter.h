/*
 * Author: william.manley@youview.com
 *         mariusz.buras@youview.com
 *         kris@youview.com
 *
 * Copyright(C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_GST_MEDIA_ROUTER_H_
#define NICKEL_SYSTEM_GST_MEDIA_ROUTER_H_

#include <nickel-system-api/MediaRouter.h>

NS_NICKEL_SYSTEM_OPEN

boost::shared_ptr<MediaRouterAsync> createGstMediaRouter(
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher);

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_GST_MEDIA_ROUTER_H_ */
