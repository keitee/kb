/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "VirtualBinSink.h"

#include <nickel-common/NickelLogger.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/Promise.h>
#include <zinc-common/async/Future.h>

#include <zinc-common/ScopedObj.h>

#include <boost/bind.hpp>
#include <boost/pointer_cast.hpp>

NS_NICKEL_SYSTEM_OPEN

namespace {

typedef boost::function<RefObj<GstPad>(const RefObj<GstPad>&)> PlugFunc;

RefObj<GstElement> makeMp4Element(PlugFunc plug)
{
    struct NewPadCallback{
        static void callback(GstElement* elem, GstPad* pad, gpointer data)
        {
            NICKEL_FUNC_TRACE;
            const PlugFunc* plugFunc = static_cast<PlugFunc*>(data);
            const RefObj<GstPad> sink = (*plugFunc)(RefObj<GstPad>(pad, true));
            if (GST_PAD_LINK_OK != gst_pad_link(pad, sink.get())) {
                NICKEL_ERROR("Couldn't link pads.");
            }
            g_signal_handlers_disconnect_by_data(elem, data);
            delete plugFunc;
        }
    };

    const RefObj<GstElement> qtdemux =
        gst_element_factory_make("qtdemux", NULL);

    if (!qtdemux) {
        NICKEL_ERROR("Couldn't create qtdemux!");
    }

    if (0 == g_signal_connect(qtdemux.get(), "pad-added",
                              G_CALLBACK(&NewPadCallback::callback),
                              static_cast<gpointer>(new PlugFunc(plug)))) {
        NICKEL_ERROR("g_signal_connect failed!");
    }

    return qtdemux;
}

RefObj<GstElement> makeSinkElement(const std::string& desc)
{
    NICKEL_FUNC_TRACE;

    GError *error = NULL;
    const RefObj<GstElement> elem =
        gst_parse_bin_from_description(desc.c_str(),
                                       TRUE, /* create ghost pads */
                                       &error);

    if (error) {
        const NS_ZINC::ScopedObj<GError> errorScoped(error, g_error_free);
        NICKEL_ERROR("Failed to create element from description '"
                     << desc << "': " << GST_STR_NULL(error->message));
    }

    return elem;
}

RefObj<GstElement> makeElementSimple(const char* const elementName)
{
    return gst_element_factory_make(elementName, NULL);
}

} // namespace anonymous

VirtualBinSink::VirtualBinSink(
    boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
    boost::shared_ptr<VirtualPadFactory> srcPadFactory,
    VirtualBin::CallbackType callback)
    : VirtualBin(sinkPadFactory, srcPadFactory, "VirtualBinSink", callback)
{
    elementFactory["video/quicktime"] =
        boost::bind(makeMp4Element,
                    PlugFunc(boost::bind(&VirtualBin::plug,
                                         static_cast<VirtualBin*>(this),
                                         _1)));
    elementFactory["audio/x-m4a"] =  boost::bind(makeElementSimple, "fakesink");

    if (const RefObj<GstElementFactory> nexusFactory =
        gst_element_factory_find ("nexussink")) {

        elementFactory["video/x-h264"] =
            boost::bind(makeSinkElement,
                        "h264parse ! nexussink");

        elementFactory["video/mpegts"] =
            boost::bind(makeSinkElement,
                        "tsnexusbin");

    } else {
        elementFactory["video/x-h264"] =
            boost::bind(makeSinkElement,
                        "h264parse ! avdec_h264 ! autovideosink");
    }
}

VirtualBinSink::~VirtualBinSink()
{
}

void VirtualBinSink::setVideoWindow(
    const VideoWindowDescriptor& /* videoWindow */)
{
    throw std::runtime_error("Please implement!");
}

class VirtualBinSinkFactory : public VirtualBinFactory
{
public:
    VirtualBinSinkFactory(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher) :
        VirtualBinFactory(dispatcher)
    {
    }

    boost::shared_ptr<VirtualBin> create(
        boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
        boost::shared_ptr<VirtualPadFactory> srcPadFactory,
        VirtualBin::CallbackType callback)
    {
        const boost::shared_ptr<VirtualBin> bin =
            boost::make_shared<VirtualBinSink>(sinkPadFactory,
                                               srcPadFactory,
                                               callback);
        bin->setDispatcher(getDispatcher());
        return bin;
    }
};

NS_NICKEL_SYSTEM_CLOSE
