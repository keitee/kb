/*
 * Author: mariusz.buras@youview.com
 *         kris@youview.com
 *
 * Copyright(C) 2015 YouView TV Ltd.
 */

#ifndef NICKEL_SYSTEM_REFOBJS_H_
#define NICKEL_SYSTEM_REFOBJS_H_

#include <boost/intrusive_ptr.hpp>

#include <gst/gst.h>

inline
GstElement* intrusive_ptr_add_ref(GstElement* const p)
{
    return GST_ELEMENT_CAST(gst_object_ref(p));
}

inline
void intrusive_ptr_release(GstElement* const p)
{
    gst_object_unref(p);
}

inline
GstElementFactory* intrusive_ptr_add_ref(GstElementFactory* const p)
{
    return GST_ELEMENT_FACTORY_CAST(gst_object_ref(p));
}

inline
void intrusive_ptr_release(GstElementFactory* const p)
{
    gst_object_unref(p);
}

inline
GstBus* intrusive_ptr_add_ref(GstBus* const p)
{
    return GST_BUS_CAST(gst_object_ref(p));
}

inline
void intrusive_ptr_release(GstBus* const p)
{
    gst_object_unref(p);
}

inline
GstCaps* intrusive_ptr_add_ref(GstCaps* const p)
{
    return GST_CAPS_CAST(gst_caps_ref(p));
}

inline
void intrusive_ptr_release(GstCaps* const p)
{
    gst_caps_unref(p);
}

inline
GstPad* intrusive_ptr_add_ref(GstPad* const p)
{
    return GST_PAD_CAST(gst_object_ref(p));
}

inline
void intrusive_ptr_release(GstPad* const p)
{
    gst_object_unref(p);
}

/**
 * Ideally `boost::intrusive_ptr` should be used directly but unfortunately its
 * constructor by default increments the reference counter which is not handy as
 * GStreamer (GObject) objects are returned with reference counter already
 * initialised.  Also specifying `incRef` as `false` for most of the instances
 * is inconvenient or sometimes even impossible.
 *
 * This thin class does _not_ increment the reference counter by default which
 * suits most of the use cases.
 */
template <typename T>
class RefObj : public boost::intrusive_ptr<T>
{
public:
    inline RefObj() : boost::intrusive_ptr<T>() {}

    /**
     * Initialise the pointer but do _not_ increment reference counter by
     * default.
     */
    inline RefObj(T* const elem, const bool incRef = false)
        : boost::intrusive_ptr<T>(elem, incRef)
    {
    }

    /**
     * In some contexts it's necessary to retain the ownership of the object.
     * This happens in situations when a function takes ownership of the object
     * provided but the caller wants to keep a reference to the object as well.
     *
     * In other contexts this also means transferring ownership of the object as
     * the original object goes out of scope after a call to a function
     * expecting transfer of ownership.
     */
    inline T* retain() const
    {
        if (T* const p = this->get()) {
            return intrusive_ptr_add_ref(p);
        }

        return NULL;
    }
};

#endif /* NICKEL_SYSTEM_REFOBJS_H_ */
