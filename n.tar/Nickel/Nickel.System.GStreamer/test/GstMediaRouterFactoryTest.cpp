/*
 * Author: William Manley <william.manley@youview.com>
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include <nickel-system-api/MediaRouterFactory.h>
#include <nickel-system-api/SystemFactory.h>

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>

#include <zinc-common/PluginFactory.h>
#include <zinc-common/FixedPluginConfig.h>

NS_NICKEL_SYSTEM_OPEN

struct ZINC_LOCAL GstMediaRouterFactoryTest
    : NS_ZINC::UnitTestSandbox, CppUnit::TestFixture
{
    virtual void setUp();
    virtual void tearDown();

    void testThatNewMediaRouterIsNotNULL();

    CPPUNIT_TEST_SUITE(GstMediaRouterFactoryTest);
    CPPUNIT_TEST(testThatNewMediaRouterIsNotNULL);
    CPPUNIT_TEST_SUITE_END();

    boost::shared_ptr<MediaRouterFactory> mrf;
};

CPPUNIT_TEST_SUITE_REGISTRATION(GstMediaRouterFactoryTest);

void GstMediaRouterFactoryTest::setUp()
{
    SystemFactory& factory =
        NS_ZINC::PluginFactory::getInstance<SystemFactory>(
            NS_ZINC::FixedPluginConfig("libNickelSystemGStreamer.so",
                                       "createGstSystemFactory"));
    mrf = factory.createMediaRouterFactory();
    CPPUNIT_ASSERT(mrf);
}

void GstMediaRouterFactoryTest::tearDown()
{
    mrf.reset();
}

void GstMediaRouterFactoryTest::testThatNewMediaRouterIsNotNULL()
{
    const boost::shared_ptr<MediaRouter> mr = mrf->createMediaRouter().get();
    CPPUNIT_ASSERT(mr);
}

NS_NICKEL_SYSTEM_CLOSE
