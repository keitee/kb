/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include <nickel-system-api/MediaRouter.h>
#include <nickel-system-api/SystemFactory.h>

#include <nickel-system-api/nickel-system-exceptions.h>
#include <nickel-system-api/MockMediaRouterEventListener.h>

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/VerifyAndClearDispatcher.h>

#include <zinc-common/PluginFactory.h>
#include <zinc-common/FixedPluginConfig.h>

NS_NICKEL_SYSTEM_OPEN

struct ZINC_LOCAL GstMediaRouterTest
    : NS_ZINC::UnitTestSandbox, CppUnit::TestFixture
{
    void test_thatCallingSetSinkTwiceThrowsIllegalConfigurationException();
    void test_thatCallingSetSinkWithInvalidLocatorThrowsInvalidLocatorException();
    void test_thatGetSinkReturnsWhatWasSetFromSetSink();
    void test_thatCallingGetSinkBeforeSetSinkThrowsNotConfiguredException();
    void test_thatCallingSetSinkWithAnInvalidLocatorDoesntAffectGetSink();

    void test_thatGetSourceReturnsTheMediaLocatorSetBySetSource();
    void test_thatGetSourceThrowsNotConfiguredExceptionIfCalledBeforeSetSource();
    void test_thatSetSourceDoesNotAcceptEmptyString();

    void test_thatGetTracksReturnsAnEmptyListIfMediaRouterIsUnconfigured();

    virtual void setUp();
    virtual void tearDown();

    CPPUNIT_TEST_SUITE(GstMediaRouterTest);
    CPPUNIT_TEST(test_thatCallingSetSinkTwiceThrowsIllegalConfigurationException);
    CPPUNIT_TEST(test_thatCallingSetSinkWithInvalidLocatorThrowsInvalidLocatorException);
    CPPUNIT_TEST(test_thatGetSinkReturnsWhatWasSetFromSetSink);
    CPPUNIT_TEST(test_thatCallingGetSinkBeforeSetSinkThrowsNotConfiguredException);
    CPPUNIT_TEST(test_thatCallingSetSinkWithAnInvalidLocatorDoesntAffectGetSink);

    CPPUNIT_TEST(test_thatGetSourceReturnsTheMediaLocatorSetBySetSource);
    CPPUNIT_TEST(test_thatGetSourceThrowsNotConfiguredExceptionIfCalledBeforeSetSource);
    CPPUNIT_TEST(test_thatSetSourceDoesNotAcceptEmptyString);

    CPPUNIT_TEST(test_thatGetTracksReturnsAnEmptyListIfMediaRouterIsUnconfigured);
    CPPUNIT_TEST_SUITE_END();

    boost::shared_ptr<MediaRouterFactory> mrf;
    boost::shared_ptr<MediaRouterAsync> mr;
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;
    boost::shared_ptr<MockMediaRouterEventListener> listener;
};

CPPUNIT_TEST_SUITE_REGISTRATION(GstMediaRouterTest);

void GstMediaRouterTest::setUp()
{
    dispatcher = boost::make_shared<NS_ZINC::SingleThreadDispatcher>();

    SystemFactory& factory =
        NS_ZINC::PluginFactory::getInstance<SystemFactory>(
            NS_ZINC::FixedPluginConfig("libNickelSystemGStreamer.so",
                                       "createGstSystemFactory"));

    mrf = factory.createMediaRouterFactory();

    mr = mrf->createMediaRouter().get();
    listener = boost::make_shared<MockMediaRouterEventListener>();
}

void GstMediaRouterTest::tearDown()
{
    VERIFY_AND_CLEAR_DISPATCHER(dispatcher, 5000);

    mr.reset();
    mrf.reset();
    dispatcher.reset();
}

void GstMediaRouterTest::test_thatCallingSetSinkTwiceThrowsIllegalConfigurationException()
{
    // We intentionally don't call .get() here to exacerbate races
    mr->setSink("decoder://0");
    CPPUNIT_ASSERT_THROW(mr->setSink("decoder://0").get(),
                         IllegalReconfigurationException);
}

void GstMediaRouterTest::test_thatCallingSetSinkWithInvalidLocatorThrowsInvalidLocatorException()
{
    CPPUNIT_ASSERT_THROW(mr->setSink("invalid://0").get(),
                         InvalidLocatorException);
}

void GstMediaRouterTest::test_thatGetSinkReturnsWhatWasSetFromSetSink()
{
    mr->setSink("decoder://0").get();
    CPPUNIT_ASSERT_EQUAL("decoder://0", mr->getSink().get());
}

void GstMediaRouterTest::test_thatCallingGetSinkBeforeSetSinkThrowsNotConfiguredException()
{
    // TODO: Clarify whether this should throw or should return ""
    CPPUNIT_ASSERT_THROW(mr->getSink().get(), NotConfiguredException);
}

void GstMediaRouterTest::test_thatCallingSetSinkWithAnInvalidLocatorDoesntAffectGetSink()
{
    // We intentionally don't call .get() here to exacerbate races
    mr->setSink("decoder://0").get();
    CPPUNIT_ASSERT_THROW(mr->setSink("invalid://0").get(),
                         IllegalReconfigurationException);
    CPPUNIT_ASSERT_EQUAL("decoder://0", mr->getSink().get());
}

void GstMediaRouterTest::test_thatGetSourceReturnsTheMediaLocatorSetBySetSource()
{
    // Don't wait for source_config_complete, the uri should be changed by the
    // time the method returns.
    mr->setSource("http://dummy", SetSourceReason::unspecified).get();
    CPPUNIT_ASSERT_EQUAL("http://dummy", mr->getSource().get());
}

void GstMediaRouterTest::test_thatSetSourceDoesNotAcceptEmptyString()
{
    // Don't wait for source_config_complete, the uri should be changed by the
    // time the method returns.
    CPPUNIT_ASSERT_THROW(mr->setSource("", SetSourceReason::unspecified).get(),
                         InvalidLocatorException);
    // now get the source, it should throw
    CPPUNIT_ASSERT_THROW(mr->getSource().get(), NotConfiguredException);
}

void GstMediaRouterTest::test_thatGetSourceThrowsNotConfiguredExceptionIfCalledBeforeSetSource()
{
    CPPUNIT_ASSERT_THROW(mr->getSource().get(), NotConfiguredException);
}

void GstMediaRouterTest::test_thatGetTracksReturnsAnEmptyListIfMediaRouterIsUnconfigured()
{
    CPPUNIT_ASSERT(mr->getTracks().get().empty());
}

NS_NICKEL_SYSTEM_CLOSE
