/*
 * Author: mariusz.buras@youview.com
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */

#include "../src/VirtualBin.h"

#include <zinc-common/testsupport/CppUnit.h>

NS_NICKEL_SYSTEM_OPEN

struct ZINC_LOCAL VirtualBinInProcessTest : public CppUnit::TestFixture
{
    virtual void setUp();
    virtual void tearDown();

    CPPUNIT_TEST_SUITE(VirtualBinInProcessTest);
    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(VirtualBinInProcessTest);

void VirtualBinInProcessTest::setUp()
{
}

void VirtualBinInProcessTest::tearDown()
{
}

NS_NICKEL_SYSTEM_CLOSE
