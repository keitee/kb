/*
 * Author: Mariusz Buras <mariusz.buras@youview.com>
 *
 * Copyright (C) 2015 YouView TV Ltd.
 */


#include "../src/VirtualBin.h"

#include <zinc-common/testsupport/CppUnit.h>

#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>

#include <gst/gst.h>

NS_NICKEL_SYSTEM_OPEN

struct VirtualPadDummy: public VirtualPad
{
    VirtualPadDummy(boost::shared_ptr<VirtualPadFactory> factory) :
        VirtualPad(factory) {}
};

struct VirtualPadFactoryDummy: public VirtualPadFactory
{
    virtual boost::shared_ptr<VirtualPad> wrap(GstPad* /* pad */)
    {
        return boost::make_shared<VirtualPadDummy>(shared_from_this());
    }

    virtual boost::tuple<GstPad*, GstElement*> unwrap(
        boost::shared_ptr<VirtualPad> /* pad */)
    {
        return boost::make_tuple<GstPad*, GstElement*>(NULL, NULL);
    }

private:
    boost::function<bool(boost::shared_ptr<VirtualPad>)> callback;
};

struct VirtualBinDummy: public VirtualBin
{
    VirtualBinDummy(boost::shared_ptr<VirtualPadFactory> sinkPadFactory,
                    boost::shared_ptr<VirtualPadFactory> srcPadFactory) :
        VirtualBin(sinkPadFactory, srcPadFactory, "test")
    {
    }

    boost::tuple<RefObj<GstElement>, RefObj<GstPad> > makeElementForCaps(
        std::string& /* caps */)
    {
        return boost::make_tuple(RefObj<GstElement>(), RefObj<GstPad>());
    }

};

struct ZINC_LOCAL VirtualBinTest : public CppUnit::TestFixture
{
    virtual void setUp();
    virtual void tearDown();

    void test_thatUnimplementedFunctionsThrow();
    void test_thatMirrorPadCreatesRequiredGhostpad();
    void test_thatParentCallbackIsFired();
    void test_thatAutoplugPadWorks();
    void test_thatGetParentReturnsGstBin();

    CPPUNIT_TEST_SUITE(VirtualBinTest);
    CPPUNIT_TEST(test_thatUnimplementedFunctionsThrow);
    CPPUNIT_TEST(test_thatMirrorPadCreatesRequiredGhostpad);
    CPPUNIT_TEST(test_thatParentCallbackIsFired);
    CPPUNIT_TEST(test_thatAutoplugPadWorks);
    CPPUNIT_TEST(test_thatGetParentReturnsGstBin);
    CPPUNIT_TEST_SUITE_END();

    boost::shared_ptr<VirtualBinDummy> impl;
};

CPPUNIT_TEST_SUITE_REGISTRATION(VirtualBinTest);

void VirtualBinTest::setUp()
{
    gst_init(NULL, NULL);

    impl = boost::make_shared<VirtualBinDummy>(
        boost::make_shared<VirtualPadFactoryDummy>(),
        boost::make_shared<VirtualPadFactoryDummy>());
}

void VirtualBinTest::tearDown()
{
    impl.reset();

    gst_deinit();
}

void VirtualBinTest::test_thatUnimplementedFunctionsThrow()
{
}

void VirtualBinTest::test_thatMirrorPadCreatesRequiredGhostpad()
{
}

void VirtualBinTest::test_thatParentCallbackIsFired()
{
}

void VirtualBinTest::test_thatAutoplugPadWorks()
{
}

void VirtualBinTest::test_thatGetParentReturnsGstBin()
{
}

NS_NICKEL_SYSTEM_CLOSE
