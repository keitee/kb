#!/bin/bash

# Author: kris@youview.com
#
# Copyright 2015 YouView TV Ltd.

# Exit immediately if any unexpected error occurs
set -e

#/ Utility to play content from a URI with YouView GStreamer Media Router
#/
#/ Usage: gstmr-play.sh OPTION | [OPTION] URI | URI_NUMBER
#/
#/ OPTION:
#/
#/   -h | --help        print this message
#/
#/   -d | --debug       enable printing lots of debug information
#/
#/                      This is a predefined set of debug information enabled.
#/                      It is still possible to instead control the kind of
#/                      debug information with environment variables like
#/                      GST_DEBUG, G_MESSAGES_DEBUG, NICKEL_LOGGING_RULE etc.
#/
#/   -l | --list        list known URIs to play (use the URI no. as URL_NUMBER)
#/
#/   -p | --proxy       use YV media proxy
#/
#/ URI:
#/
#/   A URI to play.
#/
#/ URI_NUMBER:
#/
#/ A number associated with one of URIs this script knows about.  Use --list to
#/ get the URIs and their associated numbers.
#/
#/ Examples:
#/
#/ * play from a supplied URI
#/
#/   gstmr-play.sh http://example.tld/dash.mpd
#/
#/ * play from a predefined URI
#/
#/   gstmr-play.sh 1
#/

#/ DASH: unencrypted, pseudo-live
#/ http://dash.bidi.int.bbc.co.uk/e/pseudolive/bbb/client_manifest.mpd
#/
#/ DASH: encrypted, non-live
#/ https://ms3.youview.co.uk/s/Big+Buck+Bunny+DASH+2#http://test-media.youview.co.uk/ondemand/bbb/avc3/1/2drm_manifest.mpd
#/
#/ HLS: unencrypted, non-live
#/ http://184.72.239.149/vod/smil:bigbuckbunnyiphone.smil/playlist.m3u8
#/
declare -ar urls=(
    http://dash.bidi.int.bbc.co.uk/e/pseudolive/bbb/client_manifest.mpd
    https://ms3.youview.co.uk/s/Big+Buck+Bunny+DASH+2#http://test-media.youview.co.uk/ondemand/bbb/avc3/1/2drm_manifest.mpd
    http://184.72.239.149/vod/smil:bigbuckbunnyiphone.smil/playlist.m3u8
)

declare -a vars=(
    G_DEBUG=fatal_warnings
    GST_DEBUG_NO_COLOR=1
)

declare BUS_NAME="Zinc.Media2"

function list_assets() {
    local i

    for i in ${!urls[@]}; do
        echo "[$((i + 1))] ${urls[${i}]}"
    done
}

function mr_call() {
    local bus_name="$1"
    local mr="$2"
    local meth="$3"

    shift 3

    dbus-send --session --type=method_call \
              --dest=${bus_name} ${mr} Zinc.Media.MediaRouter.${meth} "$@" \
              >/dev/null
}

function list_join() {
    local sep="$1"
    shift

    (
        IFS="$sep"
        echo "$*"
    )
}

function sleep_with_progress() {
    local let duration="$1"
    local -r let period=1

    for ((; $duration > 0; duration -= $period)); do
        echo -n "."
        sleep $period
    done

    echo
}

clean_up() {
    trap - {0..15}

    echo
    echo "Cleaning up ..."

    # NOTE: Since this is usually run in an interactive shell, Ctrl-C will send
    #       SIGINT to child processes as well so they might be terminated
    #       already.
    echo "Terminating dbussenddaemon ..."
    kill -INT %?dbussenddaemon &>/dev/null

    echo "Terminating MR daemon ..."
    kill -INT %?nickelmediad &>/dev/null

    if [ -x "$(command -v nexus-inspect)" ]; then
        echo "Cleaning up Nexus resources ..."
        nexus-inspect -r
    fi

    [ -n "$cfg" ] && rm "$cfg"
}

debug=""

while [ $# -gt 0 ]; do
    case "$1" in
        (-h | -help | --help)
            grep '^#/' "$0" | cut -c 4-
            exit 0;;

        (-d | --debug)
            debug="1"
            shift;;

        (-l | --list)
            list_assets
            exit 0;;

        (-p | --proxy)
            BUS_NAME="Zinc.MediaProxy2"
            USE_PROXY="true"
            shift;;

        (*)
            break;;
    esac
done

if [ $# -ne 1 ]; then
    echo "Too many arguments" >&2
    grep '^#/' "$0" | cut -c 4- >&2

    exit 1
fi

uri="$1"
[[ $uri =~ [1-9][0-9]* ]] && uri="${urls[$(($uri - 1))]}"

if [ -x "$(command -v nexus-inspect)" ]; then
    echo "Running on a Nexus enabled system"
    declare -ar preload_libs=(
        /usr/local/lib/libdirectfb.so
        /usr/local/lib/libdirect.so
        /usr/local/lib/libinit.so
        /lib/libpthread.so.0
    )

    vars+=(LD_PRELOAD=$(list_join ":" ${preload_libs[@]}))

    echo "Stopping DefaultMediaRouter ..."
    mr_call Zinc.Media /Zinc/Media/DefaultMediaRouter stop
fi

if [ -n "$debug" ]; then
    declare -ar gst_debug_elems=(
        nexussink:3
        decodebin:4
        uridecodebin:4
        dashdemux:4
        adaptivedemux:4
        h264parse:4
    )

    vars+=(
        NICKEL_LOGGING_RULE=TRACE,STDOUT
        GST_DEBUG=3,$(list_join "," ${gst_debug_elems[@]})
    )
fi

trap clean_up EXIT

if [ -z "${USE_PROXY:-}" ]; then
    declare -r cfg=$(mktemp)
    echo "libNickelSystemGStreamer.so createGstSystemFactory" > $cfg

    echo "Starting GStreamer MR daemon ..."
    env ${vars[@]} nickelmediad \
        --no-mediasettings --no-localmedialibrary \
        --no-outputmanager --no-servicelistbuilder \
        -b $BUS_NAME -f $cfg &
else
    echo "Starting YV MR daemon ..."
    env ${vars[@]} nickelmediad -b $BUS_NAME &
fi

dbuswaitbusname $BUS_NAME

echo "Starting dbussenddaemon ..."
dbussenddaemon &
dbuswaitbusname "Zinc.DBusSendDaemon"

declare -r MR=$(dbus-send --session --print-reply --type=method_call \
                          --dest='Zinc.DBusSendDaemon' \
                          /Zinc/Media/MediaRouterFactory \
                          Zinc.Media.MediaRouterFactory.createMediaRouter \
                          string:${BUS_NAME} 2>/dev/null | \
                       grep "/Zinc/Media/MediaRouters/" | \
                       cut -d'"' -f2)

echo "New MediaRouter: $MR"

mr_call $BUS_NAME $MR setSource string:"$uri" int32:0
mr_call $BUS_NAME $MR setSink string:"decoder://0"

echo "Starting playback: $uri"
mr_call $BUS_NAME $MR start

wait
