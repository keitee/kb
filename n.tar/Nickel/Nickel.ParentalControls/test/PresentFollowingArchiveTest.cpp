/*
 * ParentalControlsTest.cpp
 *
 *  Created on: 2 May, 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/PresentFollowingArchive.h"

#include <cobalt-system-api/MockUnifiedEventRepositoryAsync.h>
#include <cobalt-system-api/MockUnifiedEventRepositoryEventListener.h>
#include <cobalt-system-api/UnifiedEventHelpers.h>
#include <cobalt-system-api/UnifiedService.h>

#include <nickel-system-api/MockMediaRouterAsync.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/InlineDispatcher.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>
#include <zinc-common/MonotonicClock.h>

#include <boost/make_shared.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/bind.hpp>

#include <gmock/gmock.h>

#include <vector>

#include "Common.h"

NS_NICKEL_SYSTEM_OPEN

using testing::Assign;
using testing::Invoke;
using testing::Return;

class ZINC_LOCAL PresentFollowingArchiveTest : public CppUnit::TestFixture
{
public:

    VariableTimeReference timeRef;
    boost::shared_ptr< NS_ZINC::InlineDispatcher > inlineDispatcher;
    boost::shared_ptr< NS_COBALT_SYSTEM::MockUnifiedEventRepositoryAsync > eventMock;
    boost::shared_ptr< PresentFollowingArchive > pfarch;
    std::vector< std::string > eventLocators;
    std::string serviceLocator;
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime;


    PresentFollowingArchiveTest()
    {
        timeRef.setDate("2013-02-01T15:00:00Z");
        getMonotonicTime = boost::bind(&VariableTimeReference::getMonotonicTime, &timeRef);
    }

    virtual void setUp() 
    {
        inlineDispatcher = boost::make_shared< NS_ZINC::InlineDispatcher >();
        eventMock = boost::make_shared< NS_COBALT_SYSTEM::MockUnifiedEventRepositoryAsync >();
        eventMock->setDispatcher(inlineDispatcher);

        // Note that this is used for IP channels and that the following
        // locators are not representative.
        serviceLocator = "dvb://233a..1044";
        eventLocators = boost::assign::list_of ("dvb://233a..1044;1")
                                               ("dvb://233a..1044;2")
                                               ("dvb://233a..1044;3")
                                               ("dvb://233a..1044;4")
                                               ("dvb://233a..1044;5");
    }

    virtual void tearDown()
    {
    }

    void setupInitialPFAndCreatePFArchive(const std::string &presentEventStartTime, uint32_t presentEventDuration,
        const std::string &followingEventStartTime, uint32_t followingEventDuration)
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", presentEventStartTime, presentEventDuration ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", followingEventStartTime, followingEventDuration));
        EXPECT_CALL(*eventMock,
            getPresentFollowing(std::vector< std::string >(1, serviceLocator))).WillOnce(
                                    Return(NS_ZINC::completedFuture((makePresentFollowing(pf1)))));
        pfarch = createPresentFollowingArchiveAsync( 
                        eventMock, inlineDispatcher, serviceLocator,
                        getMonotonicTime, boost::posix_time::hours(3)).get();
        VERIFY_AND_CLEAR_MOCK(eventMock);
    }

    void sendFirstPF(const std::string &actualStartTime,
        const std::string &presentEventScheduledStartTime, uint32_t presentEventDuration,
        const std::string &followingEventStartTime, uint32_t followingEventDuration)
    {
        std::vector< DttEventTestData > pf1Updated = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", presentEventScheduledStartTime,
                             presentEventDuration ))
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", followingEventStartTime, followingEventDuration));
        // No field actualStartTime in UnifiedEvent for the moment
        timeRef.setDate(actualStartTime);
        eventMock->emitPresentFollowingChange(makePresentFollowing(pf1Updated));
    }

    void test_getEventAtTime_duringAndAfterPresentEventSchedule_returnsPresentEvent()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        NS_COBALT_SYSTEM::UnifiedEvent event1 = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T15:59:59Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(event1));
        CPPUNIT_ASSERT_EQUAL(eventLocators[0], event1.data.eventLocator);

        NS_COBALT_SYSTEM::UnifiedEvent event2 = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T16:00:01Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(event2));
        CPPUNIT_ASSERT_EQUAL(eventLocators[0], event2.data.eventLocator);
    }

    void test_getEventAtTime_beforeEventSchedule_returnsScheduleGap()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        NS_COBALT_SYSTEM::UnifiedEvent event1 = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T14:59:59Z"));
        CPPUNIT_ASSERT(NS_COBALT_SYSTEM::isInvalid(event1));
    }

    void test_getEventAtTime_presentEventDurationIncreased_returnsCorrectEvent()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        // Last present event lasted 10 minutes more than expected
        sendFirstPF("2013-02-01T16:10:00Z", // actualStartTime
                    "2013-02-01T16:00:00Z", 3600, // scheduleStartTime
                    "2013-02-01T17:00:00Z", 3600);

        // Request getEventAtTime for the presentEvent
        NS_COBALT_SYSTEM::UnifiedEvent event = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T16:09:00Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(event));
        CPPUNIT_ASSERT_EQUAL(eventLocators[0], event.data.eventLocator);

        // Request getEventAtTime for the start of the next event
        NS_COBALT_SYSTEM::UnifiedEvent nextEvent = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T16:11:00Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(nextEvent));
        CPPUNIT_ASSERT_EQUAL(eventLocators[1], nextEvent.data.eventLocator);
    }

    void test_getEventAtTime_presentEventDurationShortened_returnsCorrectEvent()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        // Last present event lasted 10 minutes more than expected
        sendFirstPF("2013-02-01T15:50:00Z", // actualStartTime
                    "2013-02-01T16:00:00Z", 3600, // scheduleStartTime
                    "2013-02-01T17:00:00Z", 3600);

        // Request getEventAtTime for the previous event
        NS_COBALT_SYSTEM::UnifiedEvent event = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T15:45:00Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(event));
        CPPUNIT_ASSERT_EQUAL(eventLocators[0], event.data.eventLocator);

        // Request getEventAtTime for the following event
        NS_COBALT_SYSTEM::UnifiedEvent nextEvent = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T15:55:00Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(nextEvent));
        CPPUNIT_ASSERT_EQUAL(eventLocators[1], nextEvent.data.eventLocator);
    }

    void test_getEventAtTime_presentEventReplacedByAnotherEvent_returnsCorrectEvent()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        NS_COBALT_SYSTEM::UnifiedEvent event1 = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T15:05:00Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(event1));
        CPPUNIT_ASSERT_EQUAL(eventLocators[0], event1.data.eventLocator);

        // A really important event came up and replaced the present event
        std::vector< DttEventTestData > pf1Updated = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", "2013-02-01T15:10:00Z", 3600 - 10 * 60 ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600));
        timeRef.setDate("2013-02-01T15:10:00Z");
        eventMock->emitPresentFollowingChange(makePresentFollowing(pf1Updated));

        // Request getEventAtTime for the previous event
        NS_COBALT_SYSTEM::UnifiedEvent pevent = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T15:05:00Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(pevent));
        CPPUNIT_ASSERT_EQUAL(eventLocators[0], pevent.data.eventLocator);

        // Request getEventAtTime for the new present event
        NS_COBALT_SYSTEM::UnifiedEvent fevent = pfarch->getEventAtTime(
            iso8601DateToMonotonicTimePoint("2013-02-01T15:15:00Z"));
        CPPUNIT_ASSERT(!NS_COBALT_SYSTEM::isInvalid(fevent));
        CPPUNIT_ASSERT_EQUAL(eventLocators[2], fevent.data.eventLocator);
    }

    void test_getEventAtTime_presentEventsAreCorrectlyArchivedAndPurged()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        std::vector< DttEventTestData > pf2 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600 ))
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", "2013-02-01T17:00:00Z", 3600 ));
        timeRef.setDate("2013-02-01T16:00:00Z");
        eventMock->emitPresentFollowingChange(makePresentFollowing(pf2));

        std::vector< DttEventTestData > pf3 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", "2013-02-01T17:00:00Z", 2*3600 ))
            (DttEventTestData(serviceLocator, eventLocators[3],
                             "title_4", "2013-02-01T19:00:00Z", 3600 ));
        timeRef.setDate("2013-02-01T17:00:00Z");
        eventMock->emitPresentFollowingChange(makePresentFollowing(pf3));

        CPPUNIT_ASSERT_EQUAL(
            eventLocators[0],
            pfarch->getEventAtTime(
                iso8601DateToMonotonicTimePoint("2013-02-01T15:10:00Z")).data.eventLocator);
        CPPUNIT_ASSERT_EQUAL(
            eventLocators[1],
            pfarch->getEventAtTime(
                iso8601DateToMonotonicTimePoint("2013-02-01T16:10:00Z")).data.eventLocator);

        // Tests events are purged: this PFChange should cause eventLocators[0] to be purged
        std::vector< DttEventTestData > pf4 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[3],
                             "title_3", "2013-02-01T19:00:00Z", 3600 ))
            (DttEventTestData(serviceLocator, eventLocators[4],
                             "title_4", "2013-02-01T20:00:00Z", 3600 ));
        timeRef.setDate("2013-02-01T19:00:00Z");
        eventMock->emitPresentFollowingChange(makePresentFollowing(pf3));

        CPPUNIT_ASSERT_EQUAL(
            std::string(""), // Should be purged
            pfarch->getEventAtTime(
                iso8601DateToMonotonicTimePoint("2013-02-01T15:10:00Z")).data.eventLocator);
        CPPUNIT_ASSERT_EQUAL(
            std::string(eventLocators[1]),
            pfarch->getEventAtTime(
                iso8601DateToMonotonicTimePoint("2013-02-01T16:10:00Z")).data.eventLocator);
        CPPUNIT_ASSERT_EQUAL(
            eventLocators[2],
            pfarch->getEventAtTime(
                iso8601DateToMonotonicTimePoint("2013-02-01T17:10:00Z")).data.eventLocator);
        CPPUNIT_ASSERT_EQUAL(
            eventLocators[2], // We did not get any PF Change for title_4, so assuming title_3
            pfarch->getEventAtTime(
                iso8601DateToMonotonicTimePoint("2013-02-01T19:10:00Z")).data.eventLocator);
    }

    void test_getEventByEventLocator_returnsCorrectEventAndCorrectTransitionTime()
    {
        // Test that transitionTime for the initialPF is the time PF Archive is created
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600 ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600 ));
        EXPECT_CALL(*eventMock,
            getPresentFollowing(std::vector< std::string >(1, serviceLocator))).WillOnce(
                                    Return(NS_ZINC::completedFuture((makePresentFollowing(pf1)))));
        timeRef.setDate("2013-02-01T15:30:00Z");
        pfarch = createPresentFollowingArchiveAsync( 
                        eventMock, inlineDispatcher, serviceLocator,
                        getMonotonicTime, boost::posix_time::hours(3)).get();
        VERIFY_AND_CLEAR_MOCK(eventMock);

        boost::optional< EventTransition > eventTransition1 = pfarch->getEventByEventLocator(eventLocators[0]);
        CPPUNIT_ASSERT(eventTransition1 && !eventTransition1->event.data.descriptions.empty());
        CPPUNIT_ASSERT_EQUAL(std::string("title_1"), eventTransition1->event.data.descriptions[0].title);
        CPPUNIT_ASSERT_EQUAL(iso8601DateToMonotonicTimePoint("2013-02-01T15:30:00Z")._d.tv_sec,
                             eventTransition1->transitionTime._d.tv_sec);

        // Test that transitionTime for PFChanges is the time PFChanges are received
        std::vector< DttEventTestData > pf1Updated = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600 ))
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", "2013-02-01T17:00:00Z", 3600 ));
        timeRef.setDate("2013-02-01T16:00:05Z"); // PF arrived a few seconds later
        eventMock->emitPresentFollowingChange(makePresentFollowing(pf1Updated));

        boost::optional< EventTransition > eventTransition2 = pfarch->getEventByEventLocator(eventLocators[1]);
        CPPUNIT_ASSERT(eventTransition2 && !eventTransition2->event.data.descriptions.empty());
        CPPUNIT_ASSERT_EQUAL(std::string("title_2"), eventTransition2->event.data.descriptions[0].title);
        CPPUNIT_ASSERT_EQUAL(iso8601DateToMonotonicTimePoint("2013-02-01T16:00:05Z")._d.tv_sec,
                             eventTransition2->transitionTime._d.tv_sec);
    }

    void test_getEventByEventLocator_forEmptyEventLocator_returnsNothing()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        boost::optional< EventTransition > event = pfarch->getEventByEventLocator("");
        CPPUNIT_ASSERT(!event);
    }

    void test_getEventByEventLocator_forNonArchivedEventLocator_returnsNothing()
    {
        setupInitialPFAndCreatePFArchive("2013-02-01T15:00:00Z", 3600,
                                         "2013-02-01T16:00:00Z", 3600);

        boost::optional< EventTransition > event = pfarch->getEventByEventLocator(eventLocators[2]);
        CPPUNIT_ASSERT(!event);
    }

CPPUNIT_TEST_SUITE(PresentFollowingArchiveTest);
    CPPUNIT_TEST(test_getEventAtTime_duringAndAfterPresentEventSchedule_returnsPresentEvent);
    CPPUNIT_TEST(test_getEventAtTime_beforeEventSchedule_returnsScheduleGap);
    CPPUNIT_TEST(test_getEventAtTime_presentEventDurationIncreased_returnsCorrectEvent);
    CPPUNIT_TEST(test_getEventAtTime_presentEventDurationShortened_returnsCorrectEvent);
    CPPUNIT_TEST(test_getEventAtTime_presentEventReplacedByAnotherEvent_returnsCorrectEvent);
    CPPUNIT_TEST(test_getEventAtTime_presentEventsAreCorrectlyArchivedAndPurged);
    CPPUNIT_TEST(test_getEventByEventLocator_returnsCorrectEventAndCorrectTransitionTime);
    CPPUNIT_TEST(test_getEventByEventLocator_forEmptyEventLocator_returnsNothing);
    CPPUNIT_TEST(test_getEventByEventLocator_forNonArchivedEventLocator_returnsNothing);
CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(PresentFollowingArchiveTest);

NS_NICKEL_SYSTEM_CLOSE
