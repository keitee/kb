/*
 * LinearEventTrackerTest.cpp
 *
 *  Created on: 3 Oct, 2013
 *      Author: hubert.lacote@youview
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/LinearEventTracker.h"
#include "../include/PresentFollowingArchive.h"

#include "Common.h"

#include <cobalt-system-api/DateParsing.h>
#include <cobalt-system-api/UnifiedEvent.h>

#include <nickel-system-api/MockMediaRouterAsync.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/InlineDispatcher.h>
#include <zinc-common/MonotonicClock.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/TestRunner.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>

#include <boost/make_shared.hpp>
#include <boost/optional.hpp>
#include <boost/shared_ptr.hpp>

#include <stdexcept>
#include <string>

using NS_ZINC::completedFuture;
using NS_ZINC::exceptionalFuture;
using NS_ZINC::Future;

using testing::Return;

NS_NICKEL_SYSTEM_OPEN

namespace
{

struct MockLinearEventTrackerEventListener : public LinearEventTrackerEventListener
{
    MOCK_METHOD1( LinearEventChanged, void (const NS_COBALT_SYSTEM::UnifiedEvent &event) );
};

class MockPresentFollowingArchive : public PresentFollowingArchive
{
public:
    MOCK_CONST_METHOD1(getEventAtTime, NS_COBALT_SYSTEM::UnifiedEvent (const NS_ZINC::monotonic_clock::time_point &time));

    MOCK_CONST_METHOD1(getEventByEventLocator, boost::optional< EventTransition > (const std::string &eventLocator));
};

MATCHER_P(MatchTimePoint, timePoint, "")
{
    return arg.time_since_epoch() == timePoint.time_since_epoch();
}

} // anon namespace

class ZINC_LOCAL LinearEventTrackerTest : public CppUnit::TestFixture
{
private:
    boost::shared_ptr< MockMediaRouterAsync > mrMock;
    boost::shared_ptr< MockPresentFollowingArchive > pfArchiveMock;
    boost::shared_ptr< LinearEventTracker > linearEventTracker;
    boost::shared_ptr< NS_ZINC::InlineDispatcher > inlineDispatcher;
    boost::shared_ptr< MockLinearEventTrackerEventListener > listenerMock;
    VariableTimeReference timeRef;
    Future< boost::shared_ptr< PresentFollowingArchive > > completedPFArchive;
    NS_COBALT_SYSTEM::UnifiedEvent testEvent1;
    NS_COBALT_SYSTEM::UnifiedEvent testEvent2;

public:
    virtual void setUp() 
    {
        inlineDispatcher = boost::make_shared< NS_ZINC::InlineDispatcher >();
        mrMock = boost::make_shared< MockMediaRouterAsync >();
        mrMock->setDispatcher(inlineDispatcher);
        pfArchiveMock = boost::make_shared< MockPresentFollowingArchive >();

        listenerMock = boost::make_shared< MockLinearEventTrackerEventListener >();

        completedPFArchive = completedFuture< boost::shared_ptr< PresentFollowingArchive > >(pfArchiveMock);

        testEvent1.data.eventLocator    = "dvb://233a..1044;1";
        testEvent1.data.startTime       = NS_COBALT_SYSTEM::parseISO8601DateTo64BitEpochTime("2013-02-01T16:00:00Z");
        testEvent1.data.duration        = 3600 * 2;

        testEvent2.data.eventLocator    = "dvb://233a..1044;2";
        testEvent2.data.startTime       = NS_COBALT_SYSTEM::parseISO8601DateTo64BitEpochTime("2013-02-01T18:00:00Z");
        testEvent2.data.duration        = 3600 * 2;
    }

    NS_ZINC::Future< boost::shared_ptr< LinearEventTracker > > createLinearEventTracker(
        Future< boost::shared_ptr< PresentFollowingArchive > > pfArchiveFuture,
        Future< Position > initialMrPosition)
    {
        if (!pfArchiveFuture.getFutureValue().getError())
        {
            EXPECT_CALL(*mrMock,getPosition())
                .WillOnce( Return( initialMrPosition ) );
        }
        NS_ZINC::Future< boost::shared_ptr< LinearEventTracker > > linearEventTrackerFuture =
            createLinearEventTrackerAsync(
                pfArchiveFuture, mrMock, listenerMock, inlineDispatcher,
                boost::bind(&VariableTimeReference::getMonotonicTime, &timeRef));
        if (!pfArchiveFuture.getFutureValue().getError())
        {
            linearEventTracker = linearEventTrackerFuture.get();
        }
        VERIFY_AND_CLEAR_MOCK(mrMock);
        return linearEventTrackerFuture;
    }

    virtual void tearDown()
    {
        CPPUNIT_ASSERT( 
            testing::Mock::VerifyAndClearExpectations( pfArchiveMock.get() ) );
        pfArchiveMock.reset();
        CPPUNIT_ASSERT( 
            testing::Mock::VerifyAndClearExpectations( mrMock.get() ) );
        mrMock.reset();
        CPPUNIT_ASSERT( 
            testing::Mock::VerifyAndClearExpectations( listenerMock.get() ) );
        listenerMock.reset();
    }

    void test_createLinearEventTracker_exceptionalPfArchive_returnsExceptionalFuture()
    {
        // There is no expected reason that createPFArchive fails.
        // If it does, we want that the error is propagated.
        NS_ZINC::Future< boost::shared_ptr< LinearEventTracker > > futureLinearEventTracker =
            createLinearEventTracker(
                exceptionalFuture< boost::shared_ptr< PresentFollowingArchive > >(std::runtime_error("Failed!")),
                completedFuture(Position(0,0,0)));
        CPPUNIT_ASSERT(futureLinearEventTracker.getFutureValue().getError());
    }

    void test_createLinearEventTracker_getPositionFails_assumesPositionIs0_returnsLinearEventTracker()
    {
        // It is not fatal to get an exception for the initial call to getPosition: 0,0,0 will be assumed
        NS_ZINC::Future< boost::shared_ptr< LinearEventTracker > > futureLinearEventTracker =
            createLinearEventTracker(
                completedPFArchive,
                exceptionalFuture< Position >(std::runtime_error("getPosition failed!")));
        CPPUNIT_ASSERT(!futureLinearEventTracker.getFutureValue().getError());


        // Expect a call to pfArchive with no shift from now
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T16:30:00Z"))))
                .WillOnce(Return(testEvent1));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent1))
            .Times(1);
        timeRef.setDate("2013-02-01T16:30:00Z");
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

    void test_getCurrentLinearEvent_isCalledFirst_triggersLinearEventChanged()
    {
        createLinearEventTracker(completedPFArchive, completedFuture( Position( 0, 0, 0 ) ));

        // Expect a call to pfArchive with no shift from now
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T16:30:00Z"))))
                .WillOnce(Return(testEvent1));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent1))
            .Times(1);
        timeRef.setDate("2013-02-01T16:30:00Z");
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

    void test_getCurrentLinearEvent_isCalledFirst_oneHourTimeshift_triggersLinearEventChanged()
    {
        createLinearEventTracker(completedPFArchive, completedFuture( Position( 0, -3600 * 1000, 0 ) ));

        // Expect a call to pfArchive with 1 hour shift from now
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:20:00Z"))))
                .WillOnce(Return(testEvent1));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent1))
            .Times(1);
        timeRef.setDate("2013-02-01T18:20:00Z");
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

    void test_PositionChangeEvent_isCalledFirst_triggersLinearEventChanged()
    {
        createLinearEventTracker(completedPFArchive, completedFuture( Position( 0, -3600 * 1000, 0 ) ));

        // Expect a call to pfArchive with 30 minutes shift from now
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:50:00Z"))))
                .Times(2).WillRepeatedly(Return(testEvent1));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent1))
            .Times(1);

        timeRef.setDate("2013-02-01T18:20:00Z");
        mrMock->emitPositionChangeEvent( Position (0, -1800 * 1000, 0) );

        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

    void test_getCurrentLinearEvent_whenOnlyTimeChanged_doesNotTriggerLinearEventChanged()
    {
        test_getCurrentLinearEvent_isCalledFirst_triggersLinearEventChanged();

        timeRef.setDate("2013-02-01T16:40:00Z");
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T16:40:00Z"))))
                .WillOnce(Return(testEvent1));
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

    void test_PositionChangeEvent_whenPositionDidNotChangeEnough_doesNotTriggerLinearEventChanged()
    {
        test_getCurrentLinearEvent_isCalledFirst_triggersLinearEventChanged(); // 16H30 testEvent1

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:59:00Z"))))
                .Times(2).WillRepeatedly(Return(testEvent1));

        timeRef.setDate("2013-02-01T18:10:00Z");
        mrMock->emitPositionChangeEvent( Position (0, -60 * 11 * 1000, 0) ); // 17:59:00

        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

    void test_PositionChangeEvent_whenPositionEntersADifferentEvent_triggersLinearEventChanged()
    {
        test_getCurrentLinearEvent_isCalledFirst_triggersLinearEventChanged(); // 16H30 testEvent1

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:01Z"))))
                .Times(2).WillRepeatedly(Return(testEvent2));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent2))
            .Times(1);

        timeRef.setDate("2013-02-01T18:00:01Z");
        mrMock->emitPositionChangeEvent( Position (0, 0, 0) );

        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

    void test_PositionChangeEventOscillating_alreadyCrossedEventBoundary_andThenPlaybackIsResumed_doesNotTriggerLinearEventChanged()
    {
        // Scenario 1 paused slightly after event boundary and playback resumes
        createLinearEventTracker(completedPFArchive, completedFuture( Position( 0, 0, 0 ) ));

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:01Z"))))
                .WillOnce(Return(testEvent2));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent2))
            .Times(1);
        timeRef.setDate("2013-02-01T18:00:01Z");
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        // Assume we paused right after the event boundary, in some OEM implementations,
        // this might lead to inaccurate PositionChangeEvent.causing unwanted LinearEventChanged to be triggered.
        // LINEAR_EVENT_CHANGED_THRESHOLD_MS is used to avoid that.
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:59:59Z"))))
                .Times(2).WillRepeatedly(Return(testEvent1));
        timeRef.setDate("2013-02-01T18:00:02Z");
        mrMock->emitPositionChangeEvent( Position (0, -3 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:02Z"))))
                .Times(2).WillRepeatedly(Return(testEvent2));
        timeRef.setDate("2013-02-01T18:00:03Z");
        mrMock->emitPositionChangeEvent( Position (0, -1 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:10:00Z"))))
                .Times(2).WillRepeatedly(Return(testEvent2));
        timeRef.setDate("2013-02-01T18:10:00Z");
        mrMock->emitPositionChangeEvent( Position (0, 0, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }
    
    void test_PositionChangeEventOscillating_alreadyCrossedEventBoundary_andThenUserRewinds_triggersLinearEventChangedAfterThreshold()
    {
        // Scenario 2 pause slightly after event boundary and rewind: 11:00:01 EVENT2 PAUSED 10:59:00 11:00:01 11:00:00 REWIND 10:59:59 10:59:54
        createLinearEventTracker(completedPFArchive, completedFuture( Position( 0, 0, 0 ) ));

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:01Z"))))
                .WillOnce(Return(testEvent2));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent2))
            .Times(1);
        timeRef.setDate("2013-02-01T18:00:01Z");
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        // Assume we paused right after the event boundary, in some OEM implementations,
        // this might lead to inaccurate PositionChangeEvent.causing unwanted LinearEventChanged to be triggered.
        // LINEAR_EVENT_CHANGED_THRESHOLD_MS is used to avoid that.
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:59:59Z"))))
                .Times(2).WillRepeatedly(Return(testEvent1));
        timeRef.setDate("2013-02-01T18:00:02Z");
        mrMock->emitPositionChangeEvent( Position (0, -3 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:02Z"))))
                .Times(2).WillRepeatedly(Return(testEvent2));
        timeRef.setDate("2013-02-01T18:00:03Z");
        mrMock->emitPositionChangeEvent( Position (0, -1 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:59:57Z"))))
                .Times(2).WillRepeatedly(Return(testEvent1));
        timeRef.setDate("2013-02-01T18:00:04Z");
        mrMock->emitPositionChangeEvent( Position (0, -7 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:59:55Z"))))
                .Times(2).WillRepeatedly(Return(testEvent1));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent1))
            .Times(1);
        timeRef.setDate("2013-02-01T18:00:05Z");
        mrMock->emitPositionChangeEvent( Position (0, -10 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }
    
    void test_PositionChangeEvent_notCrossedEventBoundary_andThenPlaybackResumes_triggersLinearEventChangedAfterThresholdOfPlayback()
    {
        //Scenario 3 paused slightly before event boundary and playback resumes: 10:59:59 EVENT2 PAUSED 10:59:00 11:00:01 11:00:00 RESUME 11:00:05
        createLinearEventTracker(completedPFArchive, completedFuture( Position( 0, 0, 0 ) ));

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T17:59:59Z"))))
                .WillOnce(Return(testEvent1));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent1))
            .Times(1);
        timeRef.setDate("2013-02-01T17:59:59Z");
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        // Assume we paused right before the event boundary, in some OEM implementations,
        // this might lead to inaccurate PositionChangeEvent.causing unwanted LinearEventChanged to be triggered.
        // LINEAR_EVENT_CHANGED_THRESHOLD_MS is used to avoid that.
        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:01Z"))))
                .Times(2).WillRepeatedly(Return(testEvent2));
        timeRef.setDate("2013-02-01T18:00:02Z");
        mrMock->emitPositionChangeEvent( Position (0, -1 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:03Z"))))
                .Times(2).WillRepeatedly(Return(testEvent2));
        timeRef.setDate("2013-02-01T18:00:04Z");
        mrMock->emitPositionChangeEvent( Position (0, -1 * 1000, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent1.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);

        EXPECT_CALL(*pfArchiveMock,
            getEventAtTime(MatchTimePoint(iso8601DateToMonotonicTimePoint("2013-02-01T18:00:05Z"))))
                .Times(2).WillRepeatedly(Return(testEvent2));
        EXPECT_CALL(*listenerMock, LinearEventChanged(testEvent2))
            .Times(1);
        timeRef.setDate("2013-02-01T18:00:05Z");
        mrMock->emitPositionChangeEvent( Position (0, 0, 0) );
        CPPUNIT_ASSERT_EQUAL(testEvent2.data.eventLocator,
                             linearEventTracker->getCurrentLinearEvent().data.eventLocator);
    }

CPPUNIT_TEST_SUITE(LinearEventTrackerTest);
    CPPUNIT_TEST(test_createLinearEventTracker_exceptionalPfArchive_returnsExceptionalFuture);
    CPPUNIT_TEST(test_createLinearEventTracker_getPositionFails_assumesPositionIs0_returnsLinearEventTracker);
    CPPUNIT_TEST(test_getCurrentLinearEvent_isCalledFirst_triggersLinearEventChanged);
    CPPUNIT_TEST(test_getCurrentLinearEvent_isCalledFirst_oneHourTimeshift_triggersLinearEventChanged);
    CPPUNIT_TEST(test_PositionChangeEvent_isCalledFirst_triggersLinearEventChanged);
    CPPUNIT_TEST(test_getCurrentLinearEvent_whenOnlyTimeChanged_doesNotTriggerLinearEventChanged);
    CPPUNIT_TEST(test_PositionChangeEvent_whenPositionDidNotChangeEnough_doesNotTriggerLinearEventChanged);
    CPPUNIT_TEST(test_PositionChangeEvent_whenPositionEntersADifferentEvent_triggersLinearEventChanged);
    CPPUNIT_TEST(test_PositionChangeEventOscillating_alreadyCrossedEventBoundary_andThenPlaybackIsResumed_doesNotTriggerLinearEventChanged);
    CPPUNIT_TEST(test_PositionChangeEventOscillating_alreadyCrossedEventBoundary_andThenUserRewinds_triggersLinearEventChangedAfterThreshold);
    CPPUNIT_TEST(test_PositionChangeEvent_notCrossedEventBoundary_andThenPlaybackResumes_triggersLinearEventChangedAfterThresholdOfPlayback);
CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(LinearEventTrackerTest);

NS_NICKEL_SYSTEM_CLOSE
