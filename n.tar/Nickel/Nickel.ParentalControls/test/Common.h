
/*
 * Common.h
 *
 *  Created on: 9 May 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 *
 */

#ifndef PARENTALCONTROLS_TEST_COMMON_H
#define PARENTALCONTROLS_TEST_COMMON_H

#include "../include/ParentalControlsHelpers.h"

#include <boost/tuple/tuple.hpp>

#include <cobalt-system-api/DateParsing.h>
#include <cobalt-system-api/PresentFollowingInfo.h>

#include <ctime>
#include <iostream>

NS_NICKEL_SYSTEM_OPEN


static const uint32_t HOUR = 3600;
static const uint32_t MINUTE = 60;

inline boost::tuple< std::string, std::string > yvGuidanceCode(const std::string &yvRating)
{
    return boost::make_tuple("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25", yvRating);
}

struct DttEventTestData
{
    DttEventTestData(const std::string& serviceLocator_,
                     const std::string &startTimeISO8601_,
                     const uint32_t duration_):
        eventType(NS_COBALT_SYSTEM::EventType::invalid),
        serviceLocator(serviceLocator_),
        startTimeISO8601(startTimeISO8601_),
        duration (duration_)
    {
    }

    DttEventTestData(const std::string& serviceLocator_,
            const std::string& eventLocator_,
            const std::string& shortTitle_,
            const std::string &startTimeISO8601_,
            const uint32_t duration_,
            const boost::tuple< std::string, std::string > &guidanceCode_ = yvGuidanceCode("unused")
            )
        :
        eventType(NS_COBALT_SYSTEM::EventType::valid),
        serviceLocator(serviceLocator_),
        eventLocator(eventLocator_),
        shortTitle(shortTitle_),
        startTimeISO8601(startTimeISO8601_),
        duration (duration_),
        guidanceCode ( guidanceCode_ )
    {
    }

    NS_COBALT_SYSTEM::EventType::Enum eventType;
    std::string serviceLocator;
    std::string eventLocator;
    std::string shortTitle;
    std::string startTimeISO8601;
    uint32_t    duration;
    boost::tuple< std::string, std::string > guidanceCode;
};

inline NS_ZINC::monotonic_clock::time_point monotonicTimePointFromEpochTime(int64_t epochTime)
{
    timespec ts;
    ts.tv_sec = epochTime;
    ts.tv_nsec = 0;
    return NS_ZINC::monotonic_clock::time_point(ts);
}

inline NS_ZINC::monotonic_clock::time_point iso8601DateToMonotonicTimePoint(const std::string &iso8601Date)
{
    return monotonicTimePointFromEpochTime(
        NS_COBALT_SYSTEM::parseISO8601DateTo64BitEpochTime(iso8601Date));
}

class VariableTimeReference
{
public:
    VariableTimeReference():
        variableEpochTimeInSeconds(0)
    {
    }

    NS_ZINC::monotonic_clock::time_point getMonotonicTime()
    {
        return monotonicTimePointFromEpochTime(variableEpochTimeInSeconds);
    }

    int64_t getVariableEpochTimeInNanoSeconds()
    {
        return variableEpochTimeInSeconds * 1e9;
    }

    void setDate(int64_t epochTime)
    {
        // No need to hold a mutex, no asynchronous operation in this test.
        variableEpochTimeInSeconds = epochTime;
    }

    void setDate(const std::string &dateISO8601)
    {
        // No need to hold a mutex, no asynchronous operation in this test.
        variableEpochTimeInSeconds = NS_COBALT_SYSTEM::parseISO8601DateTo64BitEpochTime(dateISO8601);
    }

private:
    int64_t variableEpochTimeInSeconds;
};


inline NS_COBALT_SYSTEM::UnifiedEvent createUnifiedEventFromDTTEventTestData(
    const DttEventTestData &dttEventTestData)
{
    NS_COBALT_SYSTEM::UnifiedEvent event;
    event.data.serviceLocator    = dttEventTestData.serviceLocator;
    event.data.eventLocator      = dttEventTestData.eventLocator;
    event.data.descriptions.push_back(
        NS_COBALT_SYSTEM::EventDescription("eng", dttEventTestData.shortTitle, "", "", "", ""));
    event.data.startTime         = NS_COBALT_SYSTEM::parseISO8601DateTo64BitEpochTime(dttEventTestData.startTimeISO8601);
    event.data.duration          = dttEventTestData.duration;
    event.data.guidanceRatingScheme = dttEventTestData.guidanceCode.get< 0 >();
    event.data.guidanceRating    = dttEventTestData.guidanceCode.get< 1 >();
    event.data.eventType         = dttEventTestData.eventType;
    return event;
}

inline NS_COBALT_SYSTEM::UnifiedService createUnifiedService(const std::string &serviceLocator,
                                                      const boost::tuple< std::string, std::string > &guidanceCode)
{
    NS_COBALT_SYSTEM::UnifiedService unifiedService;
    unifiedService.serviceLocator   = serviceLocator;
    unifiedService.guidanceScheme   = guidanceCode.get< 0 >();
    unifiedService.guidanceCodes    = guidanceCode.get< 1 >();
    return unifiedService;
}

inline std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo > makePresentFollowing(
        const std::vector< DttEventTestData > &allData)
{
    BOOST_ASSERT(allData.size() == 2);
    BOOST_ASSERT(allData[0].serviceLocator == allData[1].serviceLocator);

    NS_COBALT_SYSTEM::PresentFollowingInfo pf(
        allData[0].serviceLocator,
        createUnifiedEventFromDTTEventTestData(allData[0]),
        createUnifiedEventFromDTTEventTestData(allData[1]));

    return std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo >(1, pf);
}

inline int32_t secondsToMilis(int32_t seconds)
{
    return seconds*1000;
}

inline void assign(bool* p, bool v)
{
    *p = v;
}

inline void noop()
{
}


// Do not remove this method as it is picked up during linking.
inline std::string monotonicToDayTimePrintable(const NS_ZINC::monotonic_clock::time_point &time)
{
    // We actually know that the "monotonic time" used in tests is actually epoch time.
    return epochToDayTimePrintable(time._d.tv_sec);
}

NS_NICKEL_SYSTEM_CLOSE

#endif // PARENTALCONTROLS_TEST_COMMON_H
