/*
 * ParentalControlsTest.cpp
 *
 *  Created on: 2 May, 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/ParentalControls.h"
#include "../include/LinearEventTracker.h"
#include "../include/ParentallyControlledMediaRouter.h"
#include "../include/PresentFollowingArchive.h"

#include <cobalt-system-api/cobalt-system-api.h>
#include <cobalt-system-api/MockUnifiedEventRepositoryAsync.h>
#include <cobalt-system-api/MockUnifiedServiceRepositoryAsync.h>
#include <cobalt-system-api/MockUnifiedEventRepositoryEventListener.h>

#include <mercury-system-api/MockUIManagerAsync.h>

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/MockMediaRouterAsync.h>

#include <zinc-common/zinc-common.h>
#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/InlineDispatcher.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/TestRunner.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>

#include <boost/make_shared.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/foreach.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/bind.hpp>

#include <gmock/gmock.h>

#include <vector>

#include "Common.h"

NS_NICKEL_SYSTEM_OPEN

static const size_t updateTimerIntervalMilis = 500;
using testing::_;
using testing::Assign;
using testing::Return;
using boost::bind;
using NS_ZINC::completedFuture;
using NS_ZINC::exceptionalFuture;
using NS_ZINC::Future;

namespace {

struct MockParentalControlsEventListener : public ParentalControlsEventListener
{
    MOCK_METHOD1( ParentalControlsStateChange, void(bool) );
};


enum UpdateResult
{
    no_change_still_locked,
    no_change_still_unlocked,
    locked,
    unlocked,
};

std::vector< DttEventTestData > constructExpectedPfFromPreviousPF(const std::vector< DttEventTestData > &pf1)
{
    const DttEventTestData &pf1Event2 = pf1[1];
    DttEventTestData unusedDttEventTestData(pf1Event2.serviceLocator, "unusedEventLocator",
        "unusedTitle", "2013-12-31T03:00:00Z", 3600, yvGuidanceCode("unused"));

    std::vector< DttEventTestData > pf2;
    if (pf1Event2.eventType == NS_COBALT_SYSTEM::EventType::invalid)
    {
        pf2 = boost::assign::list_of
                (DttEventTestData(pf1Event2.serviceLocator, pf1Event2.startTimeISO8601, pf1Event2.duration ))
                (unusedDttEventTestData);
    }
    else
    {
        pf2 = boost::assign::list_of
                (DttEventTestData(pf1Event2.serviceLocator, pf1Event2.eventLocator,
                                 pf1Event2.shortTitle, pf1Event2.startTimeISO8601,
                                 pf1Event2.duration, pf1Event2.guidanceCode ))
                (unusedDttEventTestData);
    }
    return pf2;
}

} // namespace anonymous

class ZINC_LOCAL ParentalControlsTest : public CppUnit::TestFixture
{
private:
    boost::shared_ptr< NS_NICKEL_SYSTEM::MockMediaRouterAsync > mrMock;
    boost::shared_ptr< NS_COBALT_SYSTEM::MockUnifiedEventRepositoryAsync > eventMock;
    boost::shared_ptr< ParentalControls > prcImpl;
    boost::shared_ptr< NS_ZINC::InlineDispatcher > inlineDispatcher;
    boost::shared_ptr< MockParentalControlsEventListener > listenerMock;
    boost::shared_ptr< NS_MERCURY_SYSTEM::MockUIManagerAsync > uiManagerMock;
    VariableTimeReference timeRef;
    std::string serviceLocator;
    std::vector< std::string > eventLocators;
    bool      mrIsLocked;

    void updateAndCheckExpectations(uint32_t intervalMillis,
                                    UpdateResult resultExpected)
    {
        switch (resultExpected)
        {
            case no_change_still_locked:
                EXPECT_CALL(*listenerMock, ParentalControlsStateChange(_)).Times(0);
                prcImpl->update(intervalMillis);
                CPPUNIT_ASSERT( mrIsLocked == true );
                VERIFY_AND_CLEAR_MOCK(listenerMock);
            break;
            case no_change_still_unlocked:
                EXPECT_CALL(*listenerMock, ParentalControlsStateChange(_)).Times(0);
                prcImpl->update(intervalMillis);
                CPPUNIT_ASSERT( mrIsLocked == false );
                VERIFY_AND_CLEAR_MOCK(listenerMock);
            break;
            case locked:
                {
                    bool restricted = false;
                    EXPECT_CALL(*listenerMock, ParentalControlsStateChange(true))
                        .WillOnce( Assign( &restricted, true) );
                    prcImpl->update(intervalMillis);
                    CPPUNIT_ASSERT( restricted == true );
                    CPPUNIT_ASSERT( mrIsLocked == true );
                    VERIFY_AND_CLEAR_MOCK(listenerMock);
                }
            break;
            case unlocked:
                {
                    bool restrictionLifted = false;
                    EXPECT_CALL(*listenerMock, ParentalControlsStateChange(false))
                        .WillOnce( Assign( &restrictionLifted, true) );
                    prcImpl->update(intervalMillis);
                    CPPUNIT_ASSERT( restrictionLifted == true );
                    CPPUNIT_ASSERT( mrIsLocked == false );
                    VERIFY_AND_CLEAR_MOCK(listenerMock);
                }
            break;
        }
    }

    void allowAndCheckExpectations(uint32_t autoAcceptSeconds,
                                   UpdateResult resultExpected)
    {
        switch (resultExpected)
        {
            case no_change_still_unlocked:
                EXPECT_CALL(*listenerMock, ParentalControlsStateChange(_)).Times(0);
                prcImpl->allowRestrictedContent(autoAcceptSeconds);
                CPPUNIT_ASSERT( mrIsLocked == false );
                VERIFY_AND_CLEAR_MOCK(listenerMock);
            break;
            case unlocked:
                {
                    bool restrictionLifted = false;
                    EXPECT_CALL(*listenerMock, ParentalControlsStateChange(false))
                        .WillOnce( Assign( &restrictionLifted, true) );
                    prcImpl->allowRestrictedContent(autoAcceptSeconds);
                    CPPUNIT_ASSERT( restrictionLifted == true );
                    CPPUNIT_ASSERT( mrIsLocked == false );
                    VERIFY_AND_CLEAR_MOCK(listenerMock);
                }
            break;
            case no_change_still_locked:
            case locked:
                CPPUNIT_FAIL("Error in unit test: this scenario is invalid.");
            break;
        }
    }

    void setDate(const std::string &dateISO8601)
    {
        timeRef.setDate(dateISO8601);
    }

    void emitPFChange(const std::vector< DttEventTestData > &pf)
    {
        setDate(pf[0].startTimeISO8601);
        eventMock->emitPresentFollowingChange(makePresentFollowing(pf));
    }

    void emitPositionChange(const NS_NICKEL_SYSTEM::Position &position)
    {
        mrMock->emitPositionChangeEvent( position );
    }

    void emitViewerPerceivedStateChange(NS_MERCURY_SYSTEM::ViewerPerceivedState::Enum viewerPerceivedState)
    {
        uiManagerMock->emitViewerPerceivedStateEvent(viewerPerceivedState);
    }

    void prepareScenario(const NS_COBALT_SYSTEM::UnifiedService &unifiedService,
                         Future< std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo > > initialPF,
                         Future< NS_NICKEL_SYSTEM::Position > initialMrPosition,
                         uint32_t watershedStartTime, uint32_t watershedEndTime
                        )
    {
        mrIsLocked = false;

        EXPECT_CALL(*eventMock,
                getPresentFollowing(std::vector< std::string >(1, unifiedService.serviceLocator)))
                    .WillOnce( Return( initialPF ) );

        EXPECT_CALL(*mrMock,getPosition())
            .WillOnce( Return( initialMrPosition ) );

        ParentalControlsSettings settings;
        settings.watershedStartTime = watershedStartTime;  // watershed starts at 8pm
        settings.watershedEndTime = watershedEndTime;      // watershed ends at 6am
        settings.restrictedRatings =
            boost::assign::list_of("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
                                  ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#sixteen")
                                  ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#eighteen")
                                  ("http://bbfc.org.uk/BBFCRatingCS/2002#18");

        if (!initialPF.getFutureValue().getError())
        {
            // Need to happen before PFArchive is created
            timeRef.setDate(initialPF.get()[0].presentEvent.data.startTime);
        }

        NS_ZINC::Future< boost::shared_ptr< PresentFollowingArchive > > pfArchiveFuture =
            NS_NICKEL_SYSTEM::createPresentFollowingArchiveAsync(eventMock, inlineDispatcher,
                unifiedService.serviceLocator,
                boost::bind(&VariableTimeReference::getMonotonicTime, &timeRef),
                boost::posix_time::hours(3));
        boost::shared_ptr< LinearEventTracker > linearEventTracker = createLinearEventTrackerAsync(
            pfArchiveFuture, mrMock, boost::shared_ptr< LinearEventTrackerEventListener >(), inlineDispatcher,
            boost::bind(&VariableTimeReference::getMonotonicTime, &timeRef)).get();

        prcImpl = createParentalControls(
            uiManagerMock,
            inlineDispatcher,
            linearEventTracker,
            boost::make_shared<ParentallyControlledMediaRouter>(mrMock,
                                                                boost::bind( assign, &mrIsLocked, true),
                                                                boost::bind( assign, &mrIsLocked, false),
                                                                &noop),
            boost::bind(&VariableTimeReference::getVariableEpochTimeInNanoSeconds, &timeRef),
            settings, unifiedService);
        prcImpl->addListener(inlineDispatcher, listenerMock);

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

public:

    virtual void setUp() 
    {
        inlineDispatcher = boost::make_shared< NS_ZINC::InlineDispatcher >();
        mrMock = boost::make_shared< NS_NICKEL_SYSTEM::MockMediaRouterAsync >();
        mrMock->setDispatcher(inlineDispatcher);
        eventMock = boost::make_shared< NS_COBALT_SYSTEM::MockUnifiedEventRepositoryAsync >();
        eventMock->setDispatcher(inlineDispatcher);
        uiManagerMock = boost::make_shared< NS_MERCURY_SYSTEM::MockUIManagerAsync >();
        uiManagerMock->setDispatcher(inlineDispatcher);        
        listenerMock = boost::make_shared< MockParentalControlsEventListener >();

        serviceLocator = "dvb://233a..1044";

        eventLocators = boost::assign::list_of ("dvb://233a..1044;1")
                            ("dvb://433a..1044;1")
                            ("dvb://533a..1044;1")
                            ("dvb://633a..1044;1");
    }

    virtual void tearDown()
    {
        CPPUNIT_ASSERT( 
            testing::Mock::VerifyAndClearExpectations( uiManagerMock.get() ) );
        uiManagerMock.reset();
        CPPUNIT_ASSERT( 
            testing::Mock::VerifyAndClearExpectations( eventMock.get() ) );
        eventMock.reset();
        CPPUNIT_ASSERT( 
            testing::Mock::VerifyAndClearExpectations( mrMock.get() ) );
        mrMock.reset();
        CPPUNIT_ASSERT( 
            testing::Mock::VerifyAndClearExpectations( listenerMock.get() ) );
        listenerMock.reset();
    }

    void test_transitionFromUnratedToRated_allowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlock()
    {
        // This scenario covers CANPDE-2737.

        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("twelve") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf1));

        setDate("2013-02-01T16:00:01Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        setDate("2013-02-01T16:02:00Z");
        allowAndCheckExpectations(0, unlocked);

        setDate("2013-02-01T16:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
    }

    void test_transitionFromUnratedToRatedToUnrated_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("twelve") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));
        std::vector< DttEventTestData > pf2 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", "2013-02-01T17:00:00Z", 3600, yvGuidanceCode("twelve")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitPFChange(pf2);
        setDate("2013-02-01T16:00:01Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        setDate("2013-02-01T16:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf2));
        setDate("2013-02-01T17:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, unlocked);
    }

    void test_transitionFromUnratedToRatedToUnrated_outsideWatershed_outsideBST_withTimeshift_causesLockAndUnlock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("twelve") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));
        std::vector< DttEventTestData > pf2 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", "2013-02-01T17:00:00Z", 3600, yvGuidanceCode("twelve")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        emitPFChange(pf2);

        // 10 minutes timeshift
        emitPositionChange(Position(secondsToMilis(-10 * MINUTE),secondsToMilis(-10 * MINUTE), 0));

        setDate("2013-02-01T16:05:01Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        setDate("2013-02-01T16:10:01Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        setDate("2013-02-01T16:20:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf2));

        setDate("2013-02-01T17:09:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);

        setDate("2013-02-01T17:11:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, unlocked);
    }

    void test_transitionFromRatedToRated_firstRatedAllowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlockAndLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        setDate("2013-02-01T15:12:00Z");
        allowAndCheckExpectations(0, unlocked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf1));

        setDate("2013-02-01T16:00:01Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
    }

    void test_transitionFromRatedToRated_nothingAllowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlockAndLock()
    {
        // This scenario covers the latest Product requirement.

        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        setDate("2013-02-01T15:50:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf1));

        setDate("2013-02-01T16:00:01Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        setDate("2013-02-01T16:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);
    }

    void test_resumeFromStandbyOnRatedEvent_whenRatedEventAllowed_causesLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        setDate("2013-02-01T15:12:00Z");
        allowAndCheckExpectations(0, unlocked);

        emitViewerPerceivedStateChange(NS_MERCURY_SYSTEM::ViewerPerceivedState::viewer_standby);
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitViewerPerceivedStateChange(NS_MERCURY_SYSTEM::ViewerPerceivedState::viewer_on);
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);
    }

    void test_resumeFromStandbyOnRatedEvent_whenRatedEventNotAllowed_causesLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        emitViewerPerceivedStateChange(NS_MERCURY_SYSTEM::ViewerPerceivedState::viewer_standby);
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);

        // Like for the transition from rated event to rated event, send
        // a notification to the UI so that the PIN is displayed.
        emitViewerPerceivedStateChange(NS_MERCURY_SYSTEM::ViewerPerceivedState::viewer_on);
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_locked);
    }

    void test_resumeFromStandbyOnNonRatedEvent_doesNotCauseLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("twelve") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("twelve")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitViewerPerceivedStateChange(NS_MERCURY_SYSTEM::ViewerPerceivedState::viewer_standby);
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitViewerPerceivedStateChange(NS_MERCURY_SYSTEM::ViewerPerceivedState::viewer_on);
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
    }

    void test_transitionToScheduleGap_ratedService_outsideWatershed_outsideBST_withoutTimeshift_causesLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("twelve")))
            (DttEventTestData(serviceLocator, "2013-02-01T16:00:00Z", 3600)); // Schedule gap;

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("fifteen")), // Rated service
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf1));

        setDate("2013-02-01T16:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
    }

    void test_transitionToScheduleGap_unratedService_outsideWatershed_outsideBST_withoutTimeshift_doesNotCauseLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("twelve")))
            (DttEventTestData(serviceLocator, "2013-02-01T16:00:00Z", 3600)); // Schedule gap;

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf1));

        setDate("2013-02-01T16:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
    }

    void test_transitionFromGapToUnratedToGap_ratedService_firstGapAllowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlockAndLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, "2013-02-01T15:00:00Z", 3600)) // Schedule gap
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("twelve")));
        std::vector< DttEventTestData > pf2 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("twelve")) )
            (DttEventTestData(serviceLocator, "2013-02-01T17:00:00Z", 3600)); // Other schedule Gap

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("fifteen")), // Rated service
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);

        allowAndCheckExpectations(0, unlocked);

        emitPFChange(pf2);

        setDate("2013-02-01T16:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf2));

        setDate("2013-02-01T17:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
    }

    void test_enteringWatershedWithUnratedEvent_outsideBST_withoutTimeshift_doesNotCauseLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T19:30:00Z", 3600*2, yvGuidanceCode("twelve") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T21:30:00Z", 3600, yvGuidanceCode("twelve")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T19:50:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
        setDate("2013-02-01T20:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
    }

    void test_enteringWatershedWithRatedEvent_outsideBST_withoutTimeshift_causesUnlock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T19:30:00Z", 3600*2, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T21:30:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T19:50:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
        setDate("2013-02-01T20:00:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, unlocked);
        setDate("2013-02-01T20:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
    }

    void test_leavingWatershedWithUnratedEvent_outsideBST_withoutTimeshift_doesNotCauseLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-02T05:00:00Z", 3600, yvGuidanceCode("twelve") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-02T06:00:00Z", 3600, yvGuidanceCode("twelve")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-02T05:20:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
        setDate("2013-02-02T05:40:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
    }

    void test_leavingWatershedWithRatedEvent_outsideBST_withoutTimeshift_causesLock()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-02T05:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-02T06:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-02T05:20:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
        setDate("2013-02-02T05:30:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
    }

    void test_leavingWatershedWithRatedEvent_insideBST_withoutTimeshift_causesLock()
    {
        // In 2013 BST began on 31 March 01:00 GMT
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-03-31T04:00:00Z", 3600, yvGuidanceCode("fifteen") )) // 04:00 UTC -> 05:00 BST
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-03-31T05:00:00Z", 3600, yvGuidanceCode("fifteen"))); // 05:00 UTC -> 06:00 BST

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-03-31T04:20:00Z"); // 04:20 UTC -> 05:20 BST
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);
        setDate("2013-03-31T04:30:00Z"); // 04:30 UTC -> 05:30 BST
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
    }

    void test_autoAcceptingRatedEventWithDuration_suppressesEventsOnTransitionForTheRequiredTime()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T17:00:00Z", 3600, yvGuidanceCode("fifteen")));
        std::vector< DttEventTestData > pf2 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T17:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[2],
                             "title_3", "2013-02-01T18:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T16:30:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
        allowAndCheckExpectations(1 * HOUR, unlocked);
        emitPFChange(pf2);
        setDate("2013-02-01T17:10:00Z");
        updateAndCheckExpectations(40 * MINUTE * 1000, no_change_still_unlocked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf2));
        setDate("2013-02-01T18:00:01Z");
        updateAndCheckExpectations(50 * MINUTE * 1000, locked);
    }

    void test_initialRequestToGetPositionFails_doesNotCauseAnyProblem()
    {
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("twelve") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("fifteen")));

        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        completedFuture( makePresentFollowing(pf1) ),
                        // It is not a major problem if the first request to getPosition fails, the position
                        // will be assumed to be 0 - until the first PositionChange event arrives.
                        NS_ZINC::exceptionalFuture< NS_NICKEL_SYSTEM::Position >(std::runtime_error("Failed!")),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        setDate("2013-02-01T15:59:50Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        emitPFChange(constructExpectedPfFromPreviousPF(pf1));

        setDate("2013-02-01T16:00:01Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
    }

    void test_initialRequestToGetPFFails_causesScheduleGap_untilPFChangeArrives()
    {
        prepareScenario(createUnifiedService(serviceLocator, yvGuidanceCode("twelve")),
                        // Configure the request to fail -
                        // Causes a schedule gap and will recover when 1st PFChange arrives
                        NS_ZINC::exceptionalFuture< std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo > >(std::runtime_error("Failed!")),
                        completedFuture( Position(0,0,0) ),
                        20*HOUR, 5*HOUR + 0.5*HOUR);

        // There is a "schedule gap" as the initial request to getPF failed
        // but as the service is 12 rated, nothing is blocked.
        setDate("2013-02-01T15:10:00Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, no_change_still_unlocked);

        // PF1 eventually arrives and tells us the present event is restricted...
        std::vector< DttEventTestData > pf1 = boost::assign::list_of
            (DttEventTestData(serviceLocator, eventLocators[0],
                             "title_1", "2013-02-01T15:00:00Z", 3600, yvGuidanceCode("fifteen") ))
            (DttEventTestData(serviceLocator, eventLocators[1],
                             "title_2", "2013-02-01T16:00:00Z", 3600, yvGuidanceCode("twelve")));
        emitPFChange(pf1);

        // Update is called again after LINEAR_EVENT_CHANGED_THRESHOLD_MS
        setDate("2013-02-01T15:10:06Z");
        updateAndCheckExpectations(updateTimerIntervalMilis, locked);
    }

CPPUNIT_TEST_SUITE(ParentalControlsTest);
    // basic events
    CPPUNIT_TEST(test_transitionFromUnratedToRated_allowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlock);
    CPPUNIT_TEST(test_transitionFromUnratedToRatedToUnrated_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlock);
    CPPUNIT_TEST(test_transitionFromUnratedToRatedToUnrated_outsideWatershed_outsideBST_withTimeshift_causesLockAndUnlock);
    CPPUNIT_TEST(test_transitionFromRatedToRated_firstRatedAllowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlockAndLock);
    CPPUNIT_TEST(test_transitionFromRatedToRated_nothingAllowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlockAndLock);
    // Resuming from standby
    CPPUNIT_TEST(test_resumeFromStandbyOnRatedEvent_whenRatedEventAllowed_causesLock);
    CPPUNIT_TEST(test_resumeFromStandbyOnRatedEvent_whenRatedEventNotAllowed_causesLock);
    CPPUNIT_TEST(test_resumeFromStandbyOnNonRatedEvent_doesNotCauseLock);
    // schedule gaps
    CPPUNIT_TEST(test_transitionToScheduleGap_ratedService_outsideWatershed_outsideBST_withoutTimeshift_causesLock);
    CPPUNIT_TEST(test_transitionToScheduleGap_unratedService_outsideWatershed_outsideBST_withoutTimeshift_doesNotCauseLock);
    CPPUNIT_TEST(test_transitionFromGapToUnratedToGap_ratedService_firstGapAllowed_outsideWatershed_outsideBST_withoutTimeshift_causesLockAndUnlockAndLock);
    // entering/leaving watershed
    CPPUNIT_TEST(test_enteringWatershedWithUnratedEvent_outsideBST_withoutTimeshift_doesNotCauseLock);
    CPPUNIT_TEST(test_enteringWatershedWithRatedEvent_outsideBST_withoutTimeshift_causesUnlock);
    CPPUNIT_TEST(test_leavingWatershedWithUnratedEvent_outsideBST_withoutTimeshift_doesNotCauseLock);
    CPPUNIT_TEST(test_leavingWatershedWithRatedEvent_outsideBST_withoutTimeshift_causesLock);
    CPPUNIT_TEST(test_leavingWatershedWithRatedEvent_insideBST_withoutTimeshift_causesLock);
    // autoaccepting events
    CPPUNIT_TEST(test_autoAcceptingRatedEventWithDuration_suppressesEventsOnTransitionForTheRequiredTime);
    // error handling
    CPPUNIT_TEST(test_initialRequestToGetPositionFails_doesNotCauseAnyProblem);
    CPPUNIT_TEST(test_initialRequestToGetPFFails_causesScheduleGap_untilPFChangeArrives);
CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(ParentalControlsTest);

NS_NICKEL_SYSTEM_CLOSE
