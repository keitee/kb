/*
 * ParentallyControlledMediaRouterTest.cpp
 *
 *  Created on: 16 May, 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/ParentallyControlledMediaRouter.h"

#include <zinc-common/async/InlineDispatcher.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/TestRunner.h>

#include <nickel-system-api/MockMediaRouterAsync.h>
#include <nickel-system-api/MockMediaRouterEventListener.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>

#include <gmock/gmock.h>

#include <boost/make_shared.hpp>

NS_NICKEL_SYSTEM_OPEN

using namespace testing;

class ZINC_LOCAL ParentallyControlledMediaRouterTest :
    public CppUnit::TestFixture
{
public:
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > pcmr;
    boost::shared_ptr< MockMediaRouterAsync > mrMock;
    boost::shared_ptr< NS_ZINC::InlineDispatcher > inlineDispatcher;
    boost::function< void (void) > lockMR;
    boost::function< void (void) > unlockMR;
    boost::function< void (void) > resetMR;

    virtual void setUp() 
    {
        inlineDispatcher = boost::make_shared< NS_ZINC::InlineDispatcher >();
        mrMock = boost::make_shared< MockMediaRouterAsync >();
        mrMock->setDispatcher(inlineDispatcher);
    }
    
    virtual void tearDown()
    {
    }

    void setupParentallyControlledMediaRouter()
    {
        boost::shared_ptr< ParentallyControlledMediaRouter > pc =
            createParentallyControlledMR(mrMock,
                                         inlineDispatcher);
        pcmr = pc->mr;
        lockMR = pc->lockMR;
        unlockMR = pc->unlockMR;
        resetMR = pc->resetMR;
    }

    void test_IfRealMediaRouterGetsBlocked()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,setVideoTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-1,_)).WillOnce(Return(NS_ZINC::completedFuture()));
        unlockMR();

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_IfRealMediaRouterGetsBlockedAgainAfterStartIsCalled()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);

        // Check that if start is called while locked, the proxied MR is locked again.
        EXPECT_CALL(*mrMock,start()).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        pcmr->start();

        EXPECT_CALL(*mrMock,setVideoTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-1,_)).WillOnce(Return(NS_ZINC::completedFuture()));
        unlockMR();

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_thatResetClearsParentallyControlledMediaRouterState()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);

        resetMR();

        // This call would have normally unlocked the MediaRouter if reset had not been called
        unlockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_IfInterceptedCallsAreForwardedToTheRealMediaRouterWhenNotLocked()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrack(666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrackExternal("loc",666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setVideoTrackExternal("loc",666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(666,"en")).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,recycle()).WillOnce(Return(NS_ZINC::completedFuture()));

        pcmr->setVideoTrack(666);
        pcmr->setAudioTrack(666);
        pcmr->setAudioTrackExternal("loc",666);
        pcmr->setVideoTrackExternal("loc",666);
        pcmr->setSubtitleTrack(666,"en");
        pcmr->recycle();

        VERIFY_AND_CLEAR_MOCK(mrMock);

        // test start() in separation as this has additional implications
        EXPECT_CALL(*mrMock,start()).WillOnce(Return(NS_ZINC::completedFuture()));
        pcmr->start();
        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_IfInterceptedCallsAreIgnoredWhenLockedExceptForSetPlaySpeed()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrack(666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(667)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(668,"fr")).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setPlaySpeed(669)).WillOnce(Return(NS_ZINC::completedFuture()));
        pcmr->setVideoTrack(666);
        pcmr->setAudioTrack(667);
        pcmr->setSubtitleTrack(668,"fr");
        pcmr->setPlaySpeed(669);
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);

        // Should not have any effect
        EXPECT_CALL(*mrMock,setVideoTrack(_)).Times(0);
        EXPECT_CALL(*mrMock,setAudioTrack(_)).Times(0);
        EXPECT_CALL(*mrMock,setSubtitleTrack(_,_)).Times(0);
        pcmr->setVideoTrack(28);
        pcmr->setAudioTrack(29);
        pcmr->setSubtitleTrack(30,"it");
        VERIFY_AND_CLEAR_MOCK(mrMock);

        // Call to setPlaySpeed have an effect so that the user can dismiss PIN prompt and
        // continue playback WITH blanked screen.
        EXPECT_CALL(*mrMock,setPlaySpeed(31)).WillOnce(Return(NS_ZINC::completedFuture()));
        pcmr->setPlaySpeed(31);
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,setVideoTrack(666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(667)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(668,"fr")).WillOnce(Return(NS_ZINC::completedFuture()));
        unlockMR();

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_scenarioWhenPinPromptIsDismissedCausingTheUIToResumePlaybackAndAnotherRatedEventIsReached()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setPlaySpeed(0.0)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        // Simulate UI calling setPlaySpeed(0) when PIN prompt is displayed
        pcmr->setPlaySpeed(0.0);
        VERIFY_AND_CLEAR_MOCK(mrMock);

        // Simulate UI calling setPlaySpeed(1) when PIN prompt is dismissed
            EXPECT_CALL(*mrMock,setPlaySpeed(1.0)).WillOnce(Return(NS_ZINC::completedFuture()));
            pcmr->setPlaySpeed(1.0);
            VERIFY_AND_CLEAR_MOCK(mrMock);

        // Simulate that a second rated event is reached: even though the state has
        // not changed, a signal ParentalControlsStateChange needs to be sent again to the UI
        // so that it can bring up the PIN prompt.
        // It is not really necessary to blank again the video but this is what the implementation
        // does, so check that it does not cause anything unexpected:
            EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
            EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
            EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
            lockMR();

        EXPECT_CALL(*mrMock,setVideoTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-1,_)).WillOnce(Return(NS_ZINC::completedFuture()));
        unlockMR();

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_IfUnlockRestoreParametersSetBeforeLock()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrack(666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(667)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(668,"fr")).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setPlaySpeed(669)).WillOnce(Return(NS_ZINC::completedFuture()));
        pcmr->setVideoTrack(666);
        pcmr->setAudioTrack(667);
        pcmr->setSubtitleTrack(668,"fr");
        pcmr->setPlaySpeed(669);
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,setVideoTrack(666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(667)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(668,"fr")).WillOnce(Return(NS_ZINC::completedFuture()));
        unlockMR();

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_IfSeekIsWorkingWhileLocked()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,seekPosition(SeekReference::start, -15.0, SeekMode::prioritise_speed)).WillOnce(Return(NS_ZINC::completedFuture()));
        pcmr->seekPosition(SeekReference::start, -15.0, SeekMode::prioritise_speed);

        EXPECT_CALL(*mrMock,setVideoTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-1)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-1,_)).WillOnce(Return(NS_ZINC::completedFuture()));
        unlockMR();

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_IfUnlockRestoreParametersSetBeforeLockWhenExternalMethodsWereUsed()
    {
        setupParentallyControlledMediaRouter();

        EXPECT_CALL(*mrMock,setVideoTrackExternal("loc1",666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrackExternal("loc2",667)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(668,"fr")).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setPlaySpeed(669)).WillOnce(Return(NS_ZINC::completedFuture()));
        pcmr->setVideoTrackExternal("loc1",666);
        pcmr->setAudioTrackExternal("loc2",667);
        pcmr->setSubtitleTrack(668,"fr");
        pcmr->setPlaySpeed(669);
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,setVideoTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrack(-2)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(-2,"")).WillOnce(Return(NS_ZINC::completedFuture()));
        lockMR();
        VERIFY_AND_CLEAR_MOCK(mrMock);

        EXPECT_CALL(*mrMock,setVideoTrackExternal("loc1",666)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setAudioTrackExternal("loc2",667)).WillOnce(Return(NS_ZINC::completedFuture()));
        EXPECT_CALL(*mrMock,setSubtitleTrack(668,"fr")).WillOnce(Return(NS_ZINC::completedFuture()));
        unlockMR();

        VERIFY_AND_CLEAR_MOCK(mrMock);
    }

    void test_IfRealMediaRouterEventsArePropagated()
    {
        setupParentallyControlledMediaRouter();

        boost::shared_ptr< MockMediaRouterEventListener > mockEventListener =
            boost::make_shared< MockMediaRouterEventListener >();
        pcmr->addListener(inlineDispatcher, mockEventListener);

        EXPECT_CALL(*mockEventListener,
            BufferStatusEvent(BufferStatusEventValue::buffering_complete)).Times(1);
        mrMock->emitBufferStatusEvent(BufferStatusEventValue::buffering_complete);
        VERIFY_AND_CLEAR_MOCK(mockEventListener);

        EXPECT_CALL(*mockEventListener,
            DrmEvent(DrmEventValue::server_denied, "param1", "param2")).Times(1);
        mrMock->emitDrmEvent(DrmEventValue::server_denied, "param1", "param2");
        VERIFY_AND_CLEAR_MOCK(mockEventListener);

        EXPECT_CALL(*mockEventListener,
            PositionChangeEvent(Position(1, 2, 3))).Times(1);
        mrMock->emitPositionChangeEvent(Position(1, 2, 3));
        VERIFY_AND_CLEAR_MOCK(mockEventListener);

        EXPECT_CALL(*mockEventListener,
            SourceEvent(SourceEventValue::tracks_changed, SetSourceReason::mhegstandard)).Times(1);
        mrMock->emitSourceEvent(SourceEventValue::tracks_changed, SetSourceReason::mhegstandard);
        VERIFY_AND_CLEAR_MOCK(mockEventListener);

        EXPECT_CALL(*mockEventListener,
            SpeedChangeEvent()).Times(1);
        mrMock->emitSpeedChangeEvent();
        VERIFY_AND_CLEAR_MOCK(mockEventListener);

        EXPECT_CALL(*mockEventListener,
            StatusEvent(StatusEventValue::stopped)).Times(1);
        mrMock->emitStatusEvent(StatusEventValue::stopped);
        VERIFY_AND_CLEAR_MOCK(mockEventListener);

        EXPECT_CALL(*mockEventListener,
            ErrorEvent(ErrorEventValue::network, ErrorEventContext::subtitle_file, "details")).Times(1);
        mrMock->emitErrorEvent(ErrorEventValue::network, ErrorEventContext::subtitle_file, "details");
        VERIFY_AND_CLEAR_MOCK(mockEventListener);
    }

    void test_itIsImpossibleToParentaliseAMediaRouterSeveralTimes()
    {
        setupParentallyControlledMediaRouter();

        CPPUNIT_ASSERT_THROW( createParentallyControlledMR(pcmr, inlineDispatcher),
                              std::runtime_error);
    }

CPPUNIT_TEST_SUITE(ParentallyControlledMediaRouterTest);
    CPPUNIT_TEST(test_IfRealMediaRouterGetsBlocked);
    CPPUNIT_TEST(test_IfRealMediaRouterGetsBlockedAgainAfterStartIsCalled);
    CPPUNIT_TEST(test_thatResetClearsParentallyControlledMediaRouterState);
    CPPUNIT_TEST(test_IfInterceptedCallsAreForwardedToTheRealMediaRouterWhenNotLocked);
    CPPUNIT_TEST(test_IfInterceptedCallsAreIgnoredWhenLockedExceptForSetPlaySpeed);
    CPPUNIT_TEST(test_scenarioWhenPinPromptIsDismissedCausingTheUIToResumePlaybackAndAnotherRatedEventIsReached);
    CPPUNIT_TEST(test_IfUnlockRestoreParametersSetBeforeLock);
    CPPUNIT_TEST(test_IfSeekIsWorkingWhileLocked);
    CPPUNIT_TEST(test_IfUnlockRestoreParametersSetBeforeLockWhenExternalMethodsWereUsed);
    CPPUNIT_TEST(test_IfRealMediaRouterEventsArePropagated);
    CPPUNIT_TEST(test_itIsImpossibleToParentaliseAMediaRouterSeveralTimes);
CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(ParentallyControlledMediaRouterTest);

NS_NICKEL_SYSTEM_CLOSE
