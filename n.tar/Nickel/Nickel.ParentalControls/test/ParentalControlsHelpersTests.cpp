/* 
 * File:   ParentalControlsHelpersTests.cpp
 * Author: mariusz.buras@youview.com
 *         hubert.lacote@youview.com
 *
 * Created on 16-Jul-2013
 * 
 * Copyright (C) 2012 YouView TV Ltd
 */

#include "../include/ParentalControlsHelpers.h"

#include <cobalt-system-api/DateParsing.h>
#include <cobalt-system-api/EventType.h>
#include <cobalt-system-api/UnifiedEvent.h>
#include <cobalt-system-api/UnifiedService.h>

#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/macros.h>

#include <boost/assign/list_of.hpp>

#include <algorithm>
#include <vector>
#include <string>

static const uint32_t typicalWatershedStartTimeSecs = 20 * 3600;
static const uint32_t typicalWatershedEndTimeSecs   = 5 * 3600 + 0.5 * 3600;

using boost::assign::list_of;
using namespace NS_NICKEL_SYSTEM;

class ZINC_LOCAL ParentalControlsHelpersTests : public CppUnit::TestFixture
{
private:
    void testIsRestricted_commonCombinationsWork_Impl(NS_COBALT_SYSTEM::EventType::Enum eventType);
public:
    void testIsRestricted_commonCombinationsWork();
    void testIsRestricted_commonCombinationsWorkSimilarlyForDummyEvents();
    void testIsRestricted_supportsFifteenPlusRestriction();
    void testIsRestricted_supportsBBFCScheme();
    void testIsRestricted_usesServiceRatingToCoverScheduleGap();
    void testIsRestricted_supportsSpecificRatings();
    void testIsRestricted_supportsMaximumRestriction();

    void testIsInsideWatershed_duringBST();
    void testIsInsideWatershed_outsideBST();

    CPPUNIT_TEST_SUITE(ParentalControlsHelpersTests);

    CPPUNIT_TEST(testIsRestricted_commonCombinationsWork);
    CPPUNIT_TEST(testIsRestricted_commonCombinationsWorkSimilarlyForDummyEvents);
    CPPUNIT_TEST(testIsRestricted_supportsFifteenPlusRestriction);
    CPPUNIT_TEST(testIsRestricted_supportsBBFCScheme);
    CPPUNIT_TEST(testIsRestricted_usesServiceRatingToCoverScheduleGap);
    CPPUNIT_TEST(testIsRestricted_supportsSpecificRatings);
    CPPUNIT_TEST(testIsRestricted_supportsMaximumRestriction);

    CPPUNIT_TEST(testIsInsideWatershed_duringBST);
    CPPUNIT_TEST(testIsInsideWatershed_outsideBST);

    CPPUNIT_TEST_SUITE_END();
};


namespace
{
bool isRestricted(const std::vector< std::string > &restrictedRatings,
                  const std::string &serviceScheme, const std::string &serviceRating,
                  const std::string &eventScheme, const std::string &eventRating,
                  NS_COBALT_SYSTEM::EventType::Enum eventType
                 )
{
    std::vector< std::string > sortedRestrictedRatings(restrictedRatings);
    std::sort(sortedRestrictedRatings.begin(), sortedRestrictedRatings.end());

    NS_COBALT_SYSTEM::UnifiedService service;
    service.guidanceScheme          = serviceScheme;
    service.guidanceCodes           = serviceRating;

    NS_COBALT_SYSTEM::UnifiedEvent event;
    event.data.guidanceRatingScheme = eventScheme;
    event.data.guidanceRating       = eventRating;
    event.data.eventType            = eventType;

    return NS_NICKEL_SYSTEM::isRestricted(event, service, sortedRestrictedRatings);
}
}

void ParentalControlsHelpersTests::testIsRestricted_commonCombinationsWork_Impl(NS_COBALT_SYSTEM::EventType::Enum eventType)
{
    const std::vector< std::string > fifteenRestriction =
        list_of("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#15");

    const std::string yvRatingScheme = "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25";

    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            yvRatingScheme, "fifteen", yvRatingScheme, "",         eventType));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenRestriction,            yvRatingScheme, "fifteen", yvRatingScheme, "fifteen",  eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            yvRatingScheme, "fifteen", yvRatingScheme, "twelve",   eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            yvRatingScheme, "",        yvRatingScheme, "",         eventType));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenRestriction,            yvRatingScheme, "",        yvRatingScheme, "fifteen",  eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            yvRatingScheme, "",        yvRatingScheme, "twelve",   eventType));

    CPPUNIT_ASSERT_EQUAL(false, isRestricted(std::vector< std::string >(),    yvRatingScheme, "fifteen", yvRatingScheme, "",         eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(std::vector< std::string >(),    yvRatingScheme, "fifteen", yvRatingScheme, "fifteen",  eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(std::vector< std::string >(),    yvRatingScheme, "fifteen", yvRatingScheme, "twelve",   eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(std::vector< std::string >(),    yvRatingScheme, "",        yvRatingScheme, "",         eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(std::vector< std::string >(),    yvRatingScheme, "",        yvRatingScheme, "fifteen",  eventType));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(std::vector< std::string >(),    yvRatingScheme, "",        yvRatingScheme, "twelve",   eventType));
}

void ParentalControlsHelpersTests::testIsRestricted_commonCombinationsWork()
{
    testIsRestricted_commonCombinationsWork_Impl(NS_COBALT_SYSTEM::EventType::valid);
}

void ParentalControlsHelpersTests::testIsRestricted_commonCombinationsWorkSimilarlyForDummyEvents()
{
    testIsRestricted_commonCombinationsWork_Impl(NS_COBALT_SYSTEM::EventType::null);
}

void ParentalControlsHelpersTests::testIsRestricted_supportsFifteenPlusRestriction()
{
    const std::vector< std::string > fifteenPlusRestriction =
        list_of("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#15")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#sixteen")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#eighteen")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#18");
    const std::string yvRatingScheme = "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25";

    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenPlusRestriction,        yvRatingScheme, "",        yvRatingScheme, "twelve",    NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenPlusRestriction,        yvRatingScheme, "",        yvRatingScheme, "fifteen",   NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenPlusRestriction,        yvRatingScheme, "",        yvRatingScheme, "sixteen",   NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenPlusRestriction,        yvRatingScheme, "",        yvRatingScheme, "eighteen",  NS_COBALT_SYSTEM::EventType::valid));
}

void ParentalControlsHelpersTests::testIsRestricted_supportsBBFCScheme()
{
    const std::vector< std::string > fifteenPlusRestriction =
        list_of("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#15")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#sixteen")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#eighteen")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#18");
    const std::string bbfcRatingScheme = "http://bbfc.org.uk/BBFCRatingCS/2002";

    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenPlusRestriction,        bbfcRatingScheme, "",        bbfcRatingScheme, "12",    NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenPlusRestriction,        bbfcRatingScheme, "",        bbfcRatingScheme, "15",    NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenPlusRestriction,        bbfcRatingScheme, "",        bbfcRatingScheme, "18",    NS_COBALT_SYSTEM::EventType::valid));
}

void ParentalControlsHelpersTests::testIsRestricted_usesServiceRatingToCoverScheduleGap()
{
    const std::vector< std::string > fifteenRestriction =
        list_of("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#15");

    const std::string yvRatingScheme = "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25";

    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenRestriction,            yvRatingScheme, "fifteen", yvRatingScheme, "",         NS_COBALT_SYSTEM::EventType::invalid));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenRestriction,            yvRatingScheme, "fifteen", yvRatingScheme, "fifteen",  NS_COBALT_SYSTEM::EventType::invalid));
    CPPUNIT_ASSERT_EQUAL(true,  isRestricted(fifteenRestriction,            yvRatingScheme, "fifteen", yvRatingScheme, "twelve",   NS_COBALT_SYSTEM::EventType::invalid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            yvRatingScheme, "",        yvRatingScheme, "",         NS_COBALT_SYSTEM::EventType::invalid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            yvRatingScheme, "",        yvRatingScheme, "fifteen",  NS_COBALT_SYSTEM::EventType::invalid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            yvRatingScheme, "",        yvRatingScheme, "twelve",   NS_COBALT_SYSTEM::EventType::invalid));
}

void ParentalControlsHelpersTests::testIsRestricted_supportsSpecificRatings()
{
    const std::vector< std::string > fifteenRestriction =
        list_of("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#15");

    const std::string yvRatingScheme    = "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25";
    const std::string bbfcRatingScheme  = "http://bbfc.org.uk/BBFCRatingCS/2002";

    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", bbfcRatingScheme, "U",                     NS_COBALT_SYSTEM::EventType::valid)); // U for Universal
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", bbfcRatingScheme, "PG",                    NS_COBALT_SYSTEM::EventType::valid)); // PG for Parental Guidance
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", yvRatingScheme,   "no_parental_controls",  NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", yvRatingScheme,   "parental_guidance",     NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", yvRatingScheme,   "unrated",               NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", yvRatingScheme,   "!!! made up rating *#%", NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", "!!! made up scheme",   "!!! made up rating *#%", NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(fifteenRestriction,            bbfcRatingScheme, "fifteen", "",   "", NS_COBALT_SYSTEM::EventType::valid));
}

void ParentalControlsHelpersTests::testIsRestricted_supportsMaximumRestriction()
{
    const std::vector< std::string > maximumRestriction =
        list_of("http://bbfc.org.uk/BBFCRatingCS/2002#12")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#15")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#18")
                ("http://bbfc.org.uk/BBFCRatingCS/2002#PG")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#eighteen")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#parental_guidance")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#sixteen")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#twelve")
                ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#unrated")
                ("urn:dtg:metadata:cs:DTGContentWarningCS:2011:G")
                ("urn:dtg:metadata:cs:DTGContentWarningCS:2011:W");

    const std::string yvRatingScheme        = "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25";
    const std::string bbfcRatingScheme      = "http://bbfc.org.uk/BBFCRatingCS/2002";
    const std::string dentonRatingScheme    = "urn:dtg:metadata:cs:DTGContentWarningCS:2011";

    CPPUNIT_ASSERT_EQUAL(false, isRestricted(maximumRestriction,           "", "", bbfcRatingScheme, "",    NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(maximumRestriction,           "", "", bbfcRatingScheme, "U",   NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(false, isRestricted(maximumRestriction,           "", "", yvRatingScheme,   "no_parental_controls",    NS_COBALT_SYSTEM::EventType::valid));

    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", bbfcRatingScheme, "12",  NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", bbfcRatingScheme, "15",  NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", bbfcRatingScheme, "18",  NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", bbfcRatingScheme, "PG",  NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", yvRatingScheme,   "eighteen",                NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", yvRatingScheme,   "fifteen",                 NS_COBALT_SYSTEM::EventType::valid));

    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", yvRatingScheme,   "parental_guidance",       NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", yvRatingScheme,   "sixteen",                 NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", yvRatingScheme,   "twelve",                  NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", yvRatingScheme,      "unrated",              NS_COBALT_SYSTEM::EventType::valid));
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", dentonRatingScheme,  "G",    NS_COBALT_SYSTEM::EventType::valid)); // G for Guidance
    CPPUNIT_ASSERT_EQUAL(true, isRestricted(maximumRestriction,            "", "", dentonRatingScheme,  "W",    NS_COBALT_SYSTEM::EventType::valid)); // W for Watershed
}

void ParentalControlsHelpersTests::testIsInsideWatershed_duringBST()
{
    using NS_COBALT_SYSTEM::parseISO8601DateTo64BitEpochTime;

    int64_t watershedStartTimeNS        = secondsToNanosecs(typicalWatershedStartTimeSecs); // 20:00 BST
    int64_t watershedEndTimeNS          = secondsToNanosecs(typicalWatershedEndTimeSecs);   // 05:30 BST

    int64_t earlyMorning                = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T01:00:00Z")); //02:00:00 BST -> 01:00:00 UTC
    int64_t rightBeforeWatershedEnd     = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T04:29:59Z")); //05:29:59 BST -> 04:29:59 UTC
    int64_t rightAtWatershedEnd         = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T04:30:00Z")); //05:30:00 BST -> 04:30:00 UTC
    int64_t rightAfterWatershedEnd      = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T04:30:01Z")); //05:30:01 BST -> 04:30:01 UTC
    int64_t lateMorning                 = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T11:00:00Z")); //12:00:00 BST -> 11:00:00 UTC
    int64_t earlyAfternoon              = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T15:00:00Z")); //16:00:00 BST -> 15:00:00 UTC
    int64_t rightBeforeWatershedStart   = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T18:59:59Z")); //19:59:59 BST -> 18:59:59 UTC
    int64_t rightAtWatershedStart       = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T19:00:00Z")); //20:00:00 BST -> 19:00:00 UTC
    int64_t rightAfterWatershedStart    = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T19:00:01Z")); //20:00:01 BST -> 19:00:01 UTC
    int64_t lateEvening                 = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-07-28T22:00:00Z")); //23:00:00 BST -> 22:00:00 UTC

    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(earlyMorning,              watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(rightBeforeWatershedEnd,   watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(rightAtWatershedEnd,       watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(rightAfterWatershedEnd,    watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(lateMorning,               watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(earlyAfternoon,            watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(rightBeforeWatershedStart, watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(rightAtWatershedStart,     watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(rightAfterWatershedStart,  watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(lateEvening,               watershedStartTimeNS, watershedEndTimeNS));
}

void ParentalControlsHelpersTests::testIsInsideWatershed_outsideBST()
{
    using NS_COBALT_SYSTEM::parseISO8601DateTo64BitEpochTime;

    int64_t watershedStartTimeNS        = secondsToNanosecs(typicalWatershedStartTimeSecs); // 20:00 BST / UTC
    int64_t watershedEndTimeNS          = secondsToNanosecs(typicalWatershedEndTimeSecs);   // 05:30 BST / UTC

    int64_t earlyMorning                = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T02:00:00Z"));
    int64_t rightBeforeWatershedEnd     = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T05:29:59Z"));
    int64_t rightAtWatershedEnd         = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T05:30:00Z"));
    int64_t rightAfterWatershedEnd      = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T05:30:01Z"));
    int64_t lateMorning                 = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T12:00:00Z"));
    int64_t earlyAfternoon              = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T16:00:00Z"));
    int64_t rightBeforeWatershedStart   = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T19:59:59Z"));
    int64_t rightAtWatershedStart       = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T20:00:00Z"));
    int64_t rightAfterWatershedStart    = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T20:00:01Z"));
    int64_t lateEvening                 = secondsToNanosecs(parseISO8601DateTo64BitEpochTime("2013-01-01T23:00:00Z"));

    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(earlyMorning,              watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(rightBeforeWatershedEnd,   watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(rightAtWatershedEnd,       watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(rightAfterWatershedEnd,    watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(lateMorning,               watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(earlyAfternoon,            watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(false, isInsideWatershed(rightBeforeWatershedStart, watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(rightAtWatershedStart,     watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(rightAfterWatershedStart,  watershedStartTimeNS, watershedEndTimeNS));
    CPPUNIT_ASSERT_EQUAL(true,  isInsideWatershed(lateEvening,               watershedStartTimeNS, watershedEndTimeNS));
}


CPPUNIT_TEST_SUITE_REGISTRATION(ParentalControlsHelpersTests);
