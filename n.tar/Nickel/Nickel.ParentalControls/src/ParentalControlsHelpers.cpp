/* 
 * File:   ParentalControlsHelpers.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 16 July 2013
 * 
 * Copyright (C) 2012 YouView TV Ltd
 */

#include "../include/ParentalControlsHelpers.h"

#include <cobalt-system-api/DateParsing.h>
#include <cobalt-system-api/UnifiedEventHelpers.h>

#include <stdexcept>

#include <time.h>

NS_NICKEL_SYSTEM_OPEN

namespace {

bool isRestrictedRating( const std::string& scheme, const std::string& rating,
                         const std::vector< std::string >& sortedRestrictedRatings )
{
    const std::string bbfcOrYvCompleteRating(scheme + "#" + rating);
    const std::string dantonCompleteRating(scheme + ":" + rating);
    return std::binary_search(
                sortedRestrictedRatings.begin(), sortedRestrictedRatings.end(), bbfcOrYvCompleteRating) ||
           std::binary_search(
                sortedRestrictedRatings.begin(), sortedRestrictedRatings.end(), dantonCompleteRating);
}

} // anon namespace

bool isRestricted( const NS_COBALT_SYSTEM::UnifiedEvent& event,
                   const NS_COBALT_SYSTEM::UnifiedService& service,
                   const std::vector< std::string >& sortedRestrictedRatings)
{
    // If this event represents a gap in the schedule, the
    // Service Metadata needs to be checked (see SPECWIP-3786).
    if (NS_COBALT_SYSTEM::isInvalid(event))
    {
        return isRestrictedRating(service.guidanceScheme, service.guidanceCodes, sortedRestrictedRatings);
    }
    else
    {
        // Dummy events are treated like other types of events (see SPECWIP-3788).
        return isRestrictedRating(event.data.guidanceRatingScheme, event.data.guidanceRating, sortedRestrictedRatings);
    }
}

bool isInsideWatershed(int64_t nanosecondsUTC,
                       int64_t watershedStartTimeNS, int64_t watershedEndTimeNS)
{
    int64_t dayTimeNs = epochToDayTimeNS( nanosecondsUTC );

    if ( NS_COBALT_SYSTEM::isDaylightSavingTime(nanosecsToSeconds(nanosecondsUTC)) )
    {
        if ( dayTimeNs < watershedEndTimeNS - secondsToNanosecs(3600) || // after midnight case
            dayTimeNs >= watershedStartTimeNS - secondsToNanosecs(3600) ) // before midnight case
        {
            return true;
        }
    }
    else
    {
        if ( dayTimeNs < watershedEndTimeNS || // after midnight case
            dayTimeNs >= watershedStartTimeNS ) // before midnight case
        {
            return true;
        }
    }
    return false;
}

std::string epochToDayTimePrintable(const time_t epochTime)
{
    char buff[9];
    struct tm localtime;
    if (strftime(buff, 9, "%H:%M:%S", localtime_r(&epochTime, &localtime)) == 8)
    {
        return buff;
    }
    else
    {
        return "";
    }
}

std::string monotonicToDayTimePrintable(const NS_ZINC::monotonic_clock::time_point& time)
{
    boost::posix_time::time_duration positiveDuration = NS_ZINC::monotonic_clock::now() - time;

    struct timespec now;
    int res = clock_gettime(CLOCK_REALTIME, &now);
    if (res != 0)
    {
        throw std::runtime_error("Failed to call clock_gettime.");
    }
    return epochToDayTimePrintable(now.tv_sec - positiveDuration.total_seconds());
}

NS_NICKEL_SYSTEM_CLOSE
