/*
 * ParentallyControlledMediaRouterImpl.cpp
 *
 *  Created on: 22 Apr 2013
 *      Author: william.manely@youview.com
 *              mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/ParentallyControlledMediaRouter.h"

#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/MediaRouterEventListener.h>

#include <zinc-common/async/Future.h>
#include <zinc-common/async/async-helpers.h>

#include <boost/thread/locks.hpp>

#include <map>
#include <stdexcept>
#include <string>
#include <vector>

NS_NICKEL_SYSTEM_OPEN

ParentallyControlledMediaRouter::~ParentallyControlledMediaRouter()
{
}

struct ParentallyControlledMediaRouterImpl : 
    public virtual NS_NICKEL_SYSTEM::MediaRouterAsync,
    public MediaRouterEventListener
{

public:
    virtual NS_ZINC::Future< void > 
    setSource(const std::string& mediaLocator_in, 
                const SetSourceReason::Enum reason_in)
    {
        return real->setSource(mediaLocator_in, reason_in);
    }
    virtual NS_ZINC::Future< std::string > getSource() const
    {
        return real->getSource();
    }
    virtual NS_ZINC::Future< void > setVolume(const int32_t volume_in)
    {
        return real->setVolume(volume_in);
    }
    virtual NS_ZINC::Future< int32_t > getVolume() const
    {
        return real->getVolume();
    }
    virtual NS_ZINC::Future< std::vector< Track > > getTracks() const
    {
        return real->getTracks();
    }
    virtual NS_ZINC::Future< void > 
        setVideoWindow(const VideoWindowDescriptor& videoWindow_in)
    {
        return real->setVideoWindow(videoWindow_in);
    }
    virtual NS_ZINC::Future< VideoWindowDescriptor > getVideoWindow() const
    {
        return real->getVideoWindow(); 
    }
    virtual NS_ZINC::Future< void > setSink(const std::string& mediaLocator_in)
    {
        return real->setSink(mediaLocator_in);
    }
    virtual NS_ZINC::Future< std::string > getSink() const
    {
        return real->getSink();
    }
    virtual NS_ZINC::Future< void > setEndTime(const int32_t end_in)
    {
        return real->setEndTime(end_in);
    }
    virtual NS_ZINC::Future< int32_t > getEndTime() const
    {
        return real->getEndTime();
    }
    virtual NS_ZINC::Future< void > startDeferred()
    {
        return real->startDeferred();
    }
    virtual NS_ZINC::Future< ControlCapabilities > getControlCapabilities() const
    {
        return real->getControlCapabilities();
    }
    virtual NS_ZINC::Future< void > stop()
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::stop()");
        return real->stop();
    }
    virtual NS_ZINC::Future< void > 
        setBufferingMode(const std::map< std::string, std::string >& bufferingMode_in)
    {
        return real->setBufferingMode(bufferingMode_in);
    }
    virtual NS_ZINC::Future< std::map< std::string, std::string > >
        getBufferingMode() const
    {
        return real->getBufferingMode();
    }
    virtual NS_ZINC::Future< void > startBuffering()
    {
        return real->startBuffering();
    }
    virtual NS_ZINC::Future< void > stopBuffering()
    {
        return real->stopBuffering();
    }
    virtual NS_ZINC::Future< BufferStatus > getBufferStatus() const
    {
        return real->getBufferStatus();
    }
    virtual NS_ZINC::Future< void > 
        setVideoTerminationMode(const VideoTerminationMode::Enum mode_in)
    {
        return real->setVideoTerminationMode(mode_in);
    }
    virtual NS_ZINC::Future< VideoTerminationMode::Enum > 
        getVideoTerminationMode() const
    {
        return real->getVideoTerminationMode();
    }
    virtual NS_ZINC::Future< std::map< std::string, std::string > > 
        getSourceInformation() const
    {
        return real->getSourceInformation();
    }
    virtual NS_ZINC::Future< void > setMediaDuration(const int32_t duration_in)
    {
        return real->setMediaDuration(duration_in);
    }
    virtual NS_ZINC::Future< int32_t > getMediaDuration() const
    {
        return real->getMediaDuration();
    }
    virtual NS_ZINC::Future< ABRStreamSet > getABRStreamSet() const
    {
        return real->getABRStreamSet();
    }
    virtual NS_ZINC::Future< ABRStatus > getABRStatus() const
    {
        return real->getABRStatus();
    }
    virtual NS_ZINC::Future< void > 
        setABRStream(const int32_t streamIndex_in, const bool deferred_in)
    {
        return real->setABRStream(streamIndex_in,deferred_in);
    }
    virtual NS_ZINC::Future< void > 
        setCaptureMode(const TimeShiftCaptureMode::Enum mode_in)
    {
        return real->setCaptureMode(mode_in);
    }
    virtual NS_ZINC::Future< TimeShiftCaptureMode::Enum > getCaptureMode() const
    {
        return real->getCaptureMode();
    }
    virtual NS_ZINC::Future< Track > getAudioTrack() const
    {
        return real->getAudioTrack();
    }
    virtual NS_ZINC::Future< Track > getVideoTrack() const
    {
        return real->getVideoTrack();
    }
    virtual NS_ZINC::Future< Track > getSubtitleTrack() const
    {
        return real->getSubtitleTrack();
    }
    virtual NS_ZINC::Future< int32_t > 
        addSubtitleTrack(const std::string& subtitleLocator_in)
    {
        return real->addSubtitleTrack(subtitleLocator_in);
    }
    virtual NS_ZINC::Future< double > getPlaySpeed() const
    {
        return real->getPlaySpeed();
    }
    virtual NS_ZINC::Future< Position > getPosition() const
    {
        return real->getPosition();
    }

    virtual NS_ZINC::Future< void > setAudioTrack(const int32_t tag_in)
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::setAudioTrack(" << tag_in << ")");
        boost::mutex::scoped_lock l(m);
        if (!locked)
        {
            externalAudioTrackLocatorToRestoreAfterUnlock = "";
            audioTrackToRestoreAfterUnlock = tag_in;
            l.unlock();
            return real->setAudioTrack(tag_in);
        }
        else
        {
            return NS_ZINC::completedFuture();
        }
    }
    virtual NS_ZINC::Future< void > 
    setAudioTrackExternal(const std::string& mediaLocator_in, 
        const int32_t tag_in) 
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::setAudioTrackExternal(" << mediaLocator_in << ", "<< tag_in << ")");
        boost::mutex::scoped_lock l(m);
        if (!locked)
        {
            externalAudioTrackLocatorToRestoreAfterUnlock = mediaLocator_in;
            audioTrackToRestoreAfterUnlock = tag_in;
            l.unlock();
            return real->setAudioTrackExternal(mediaLocator_in, tag_in);
        }
        else
        {
            return NS_ZINC::completedFuture();
        }
    }
    virtual NS_ZINC::Future< void > setVideoTrack(const int32_t tag_in)
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::setVideoTrack(" << tag_in << ")");
        boost::mutex::scoped_lock l(m);
        if (!locked)
        {
            externalVideoTrackLocatorToRestoreAfterUnlock = "";
            videoTrackToRestoreAfterUnlock = tag_in;
            l.unlock();
            return real->setVideoTrack(tag_in);
        }
        else
        {
            return NS_ZINC::completedFuture();
        }
    }
    virtual NS_ZINC::Future< void > 
    setVideoTrackExternal(const std::string& mediaLocator_in, const int32_t tag_in)
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::setVideoTrackExternal(" << mediaLocator_in << ", " << tag_in << ")");
        boost::mutex::scoped_lock l(m);
        if (!locked)
        {
            externalVideoTrackLocatorToRestoreAfterUnlock = mediaLocator_in;
            videoTrackToRestoreAfterUnlock = tag_in;
            l.unlock();
            return real->setVideoTrackExternal(mediaLocator_in, tag_in);
        }
        else
        {
            return NS_ZINC::completedFuture();
        }
    }
    virtual NS_ZINC::Future< void >
    setSubtitleTrack(const int32_t tag_in, const std::string& language_in)
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::setSubtitleTrack(" << tag_in << ", " << language_in << ")");
        boost::mutex::scoped_lock l(m);
        if (!locked)
        {
            subtitleTrackToRestoreAfterUnlock = tag_in;
            subtitleLanguageToRestoreAfterUnlock = language_in;
            l.unlock();
            return real->setSubtitleTrack(tag_in, language_in);
        }
        else
        {
            return NS_ZINC::completedFuture();
        }
    }
    virtual NS_ZINC::Future< void > setPlaySpeed(const double speed_in)
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::setPlaySpeed(" << speed_in << ")");
        return real->setPlaySpeed(speed_in);
    }
    virtual NS_ZINC::Future< void > start()
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::start()");
        NS_ZINC::Future< void > f = real->start();
        boost::mutex::scoped_lock l(m);
        if (locked)
        {
            // If started after locked, make sure we lock it again
            // so that pause/blanking would work as expected.
            lockImpl();
        }
        return f;
    }

    virtual NS_ZINC::Future< void > seekPosition(
        const SeekReference::Enum whence_in, const int32_t offset_in,
        const SeekMode::Enum mode_in)
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::seekPosition(" << whence_in << ", " << offset_in << ", " << mode_in << ")");
        return real->seekPosition(whence_in, offset_in, mode_in);
    }

    virtual NS_ZINC::Future< void > recycle()
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::recycle()");
        return real->recycle();
    }

    void lock()
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::lock()");
        boost::mutex::scoped_lock l(m);
        // It is not a problem to lock several times the MediaRouter:
        // This is to deal with this scenario:
        // The user dismisses PIN prompt, playback continues and hits
        // another rated event, the PIN prompt comes up again and the
        // video should be paused again.
        locked = true;
        lockImpl();
    }

    void unlock()
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::unlock()");
        boost::mutex::scoped_lock l(m);
        if (locked)
        {
            locked = false;
            // Voluntarily keep the mutex locked a bit longer so that the variables
            // ...ToRestoreAfterUnlock are protected.
            NICKEL_DEBUG("ParentallyControlledMediaRouter::unlock() - unblank");
            if (externalVideoTrackLocatorToRestoreAfterUnlock.empty())
            {
                real->setVideoTrack(videoTrackToRestoreAfterUnlock);
            }
            else
            {
                real->setVideoTrackExternal(externalVideoTrackLocatorToRestoreAfterUnlock,
                                             videoTrackToRestoreAfterUnlock);
            }
            if (externalAudioTrackLocatorToRestoreAfterUnlock.empty())
            {
                real->setAudioTrack(audioTrackToRestoreAfterUnlock);
            }
            else
            {
                real->setAudioTrackExternal(externalAudioTrackLocatorToRestoreAfterUnlock,
                                            audioTrackToRestoreAfterUnlock);
            }
            real->setSubtitleTrack(subtitleTrackToRestoreAfterUnlock,
                                   subtitleLanguageToRestoreAfterUnlock);
        }
    }

    void reset()
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::reset()");
        boost::mutex::scoped_lock l(m);

        audioTrackToRestoreAfterUnlock = TRACK_DEFAULT;
        externalAudioTrackLocatorToRestoreAfterUnlock = "";

        videoTrackToRestoreAfterUnlock = TRACK_DEFAULT;
        externalVideoTrackLocatorToRestoreAfterUnlock = "";

        subtitleTrackToRestoreAfterUnlock = TRACK_DEFAULT;
        subtitleLanguageToRestoreAfterUnlock = "";

        locked = false;
    }

    enum
    {
        TRACK_DEFAULT = -1,
        TRACK_DISABLED = -2
    };

    ParentallyControlledMediaRouterImpl(
        boost::shared_ptr< MediaRouterAsync > mr)
     : real(mr)
    {
        reset();
    }

public: // NS_NICKEL_SYSTEM::MediaRouterEventListener
    virtual void BufferStatusEvent(const BufferStatusEventValue::Enum event)
    {
        NICKEL_FUNC_TRACE;
        produceEvent(
            boost::bind(
                &MediaRouterEventListener::BufferStatusEvent,
                _1, event ));
    }

    virtual void DrmEvent(const DrmEventValue::Enum event, const std::string& drmMediaIdentifier, const std::string& rightsIssuerUrl)
    {
        produceEvent(
            boost::bind(
                &MediaRouterEventListener::DrmEvent,
                _1, event, drmMediaIdentifier, rightsIssuerUrl ));
    }

    virtual void PositionChangeEvent(const Position& position)
    {
        produceEvent(
            boost::bind(
                &MediaRouterEventListener::PositionChangeEvent,
                _1, position ));
    }

    virtual void SourceEvent(const SourceEventValue::Enum event, const SetSourceReason::Enum reason)
    {
        produceEvent(
            boost::bind(
                &MediaRouterEventListener::SourceEvent,
                _1, event, reason ));
    }

    virtual void SpeedChangeEvent()
    {
        produceEvent(
            boost::bind(
                &MediaRouterEventListener::SpeedChangeEvent,
                _1 ));
    }

    virtual void StatusEvent(const StatusEventValue::Enum event)
    {
        produceEvent(
            boost::bind(
                &MediaRouterEventListener::StatusEvent,
                _1, event ));
    }

    virtual void ErrorEvent(const ErrorEventValue::Enum error, const ErrorEventContext::Enum context, const std::string& info)
    {
        produceEvent(
            boost::bind(
                &MediaRouterEventListener::ErrorEvent,
                _1, error, context, info ));
    }

private:

    // Called with mutex locked
    void lockImpl()
    {
        NICKEL_DEBUG("ParentallyControlledMediaRouter::lock - blanking");
        real->setVideoTrack(TRACK_DISABLED);
        real->setAudioTrack(TRACK_DISABLED);
        real->setSubtitleTrack(TRACK_DISABLED,"");
    }

    boost::shared_ptr< MediaRouterAsync > real;

    boost::mutex m;
    bool locked;
    int audioTrackToRestoreAfterUnlock;
    int videoTrackToRestoreAfterUnlock;
    int subtitleTrackToRestoreAfterUnlock;
    std::string externalAudioTrackLocatorToRestoreAfterUnlock;
    std::string externalVideoTrackLocatorToRestoreAfterUnlock;
    std::string subtitleLanguageToRestoreAfterUnlock;
};

ZINC_EXPORT 
boost::shared_ptr< ParentallyControlledMediaRouter >
createParentallyControlledMR(
                            boost::shared_ptr< MediaRouterAsync > mr,
                            boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher)
{
    // Safety check to make sure the MediaRouter is not parentalised over and over.
    if (boost::dynamic_pointer_cast< NS_NICKEL_SYSTEM::ParentallyControlledMediaRouterImpl >(mr) != 0)
    {
        NICKEL_ERROR("Cannot parentalise an already parentalised MediaRouter.");
        throw std::runtime_error("createParentallyControlledMR - MediaRouter is already parentalised!");
    }

    boost::shared_ptr< ParentallyControlledMediaRouterImpl > pcmr =
        boost::make_shared< ParentallyControlledMediaRouterImpl >(mr);
    mr->addListener(dispatcher, pcmr);
    return boost::make_shared< ParentallyControlledMediaRouter >(
                pcmr,
                boost::bind(&ParentallyControlledMediaRouterImpl::lock, pcmr),
                boost::bind(&ParentallyControlledMediaRouterImpl::unlock, pcmr),
                boost::bind(&ParentallyControlledMediaRouterImpl::reset, pcmr));
}

NS_NICKEL_SYSTEM_CLOSE
