/*
 * ParentalControlsImpl.cpp
 *
 *  Created on: 22 Apr 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 *
 */

#include "../include/ParentalControls.h"

#include "../include/LinearEventTracker.h"
#include "../include/ParentalControlsHelpers.h"
#include "../include/ParentallyControlledMediaRouter.h"

#include <nickel-common/NickelLogger.h>
#include <nickel-common/NickelProfiler.h>

#include <zinc-common/async/FutureValue.h>

#include <cobalt-system-api/UnifiedService.h>

#include <mercury-system-api/UIManagerAsync.h>
#include <mercury-system-api/UIManagerEventListener.h>

#include <boost/algorithm/string/join.hpp>
#include <boost/bind.hpp>
#include <boost/foreach.hpp>
#include <boost/make_shared.hpp>
#include <boost/thread/mutex.hpp>

#include <stdexcept>
#include <string>

using NS_COBALT_SYSTEM::UnifiedEvent;
using NS_COBALT_SYSTEM::UnifiedService;

NS_NICKEL_SYSTEM_OPEN

ParentalControls::~ParentalControls()
{
}

ParentalControlsEventListener::~ParentalControlsEventListener()
{
}

class ParentalControlsImpl : public ParentalControls,
                             public NS_MERCURY_SYSTEM::UIManagerEventListener
{
public:
    ParentalControlsImpl(boost::shared_ptr< LinearEventTracker > linearEventTracker_,
                         boost::shared_ptr< ParentallyControlledMediaRouter > mr,
                         boost::function< int64_t (void) > getEpochTimeInNanoSeconds_,
                         const ParentalControlsSettings& settings,
                         const UnifiedService& service):
        linearEventTracker( linearEventTracker_ ),
        lockMR( mr->lockMR ),
        unlockMR( mr->unlockMR ),
        getEpochTimeInNanoSeconds( getEpochTimeInNanoSeconds_ ),
        watershedStartTime( secondsToNanosecs(settings.watershedStartTime) ),
        watershedEndTime( secondsToNanosecs(settings.watershedEndTime) ),
        sortedRestrictedRatings( settings.restrictedRatings ),
        unifiedService( service ),
        blocked( false ),
        autoAcceptMiliseconds( 0 ),
        justResumedFromStandby( false )
    {
        NICKEL_DEBUG("ParentalControlsImpl - Using watershedStartTime=" << settings.watershedStartTime);
        NICKEL_DEBUG("ParentalControlsImpl - Using watershedEndTime=" << settings.watershedEndTime);
        std::sort(sortedRestrictedRatings.begin(), sortedRestrictedRatings.end());
        NICKEL_DEBUG("ParentalControlsImpl - Restricted ratings: '"
                     << boost::algorithm::join(sortedRestrictedRatings, ", ") << "'");
        NICKEL_DEBUG("ParentalControlsImpl - Using service '" << unifiedService.serviceLocator << "' ("
                     << unifiedService.guidanceScheme << " " << unifiedService.guidanceCodes << ")");
    }

    /* Interface */
    virtual bool isLocked() const;
    virtual void allowRestrictedContent(uint32_t autoAcceptSeconds);
    virtual void update(uint32_t updateIntervalMilis);

public: // NS_MERCURY_SYSTEM::UIManagerEventListener
    virtual void ViewerPerceivedStateEvent(const NS_MERCURY_SYSTEM::ViewerPerceivedState::Enum viewerPerceivedState)
    {
        NICKEL_DEBUG("ViewerPerceivedStateEvent = " << viewerPerceivedState);
        if (viewerPerceivedState == NS_MERCURY_SYSTEM::ViewerPerceivedState::viewer_on)
        {
            boost::mutex::scoped_lock l(m);
            justResumedFromStandby = true;
        }
    }

private:
    void updateInternal(uint32_t updateIntervalMilis);
    void blockAndSignal();
    void unblockAndSignal();

    boost::shared_ptr< LinearEventTracker > linearEventTracker;
    boost::function< void (void) > lockMR;
    boost::function< void (void) > unlockMR;
    boost::function< int64_t (void) > getEpochTimeInNanoSeconds;
    const int64_t watershedStartTime;
    const int64_t watershedEndTime;
    std::vector< std::string > sortedRestrictedRatings;
    NS_COBALT_SYSTEM::UnifiedService unifiedService;

    mutable boost::mutex m;
    bool blocked;
    int64_t autoAcceptMiliseconds;
    boost::optional< std::string > previousEventLocator;
    boost::optional< bool > previouslyInsideWatershed;
    bool justResumedFromStandby;
};

bool ParentalControlsImpl::isLocked() const
{
    NICKEL_PROFILE_FUNC;
    boost::mutex::scoped_lock l(m);
    return blocked;
}

void ParentalControlsImpl::allowRestrictedContent(uint32_t autoAcceptSeconds)
{
    NICKEL_PROFILE_FUNC;
    boost::mutex::scoped_lock l(m);
    NICKEL_DEBUG("allowRestrictedContent - autoAcceptSeconds = " << autoAcceptSeconds);

    autoAcceptMiliseconds = autoAcceptSeconds*1000;
    if (blocked)
    {
        unblockAndSignal();
    }
}

void ParentalControlsImpl::update(uint32_t updateIntervalMilis)
{
    NICKEL_PROFILE_FUNC;
    boost::mutex::scoped_lock l(m);
    updateInternal(updateIntervalMilis);
}

// call with ParentalControlsImpl.mutex locked 
void ParentalControlsImpl::updateInternal(uint32_t updateIntervalMilis)
{
    int64_t nowNS = getEpochTimeInNanoSeconds();
    bool insideWatershed = isInsideWatershed(nowNS, watershedStartTime, watershedEndTime);
    NS_COBALT_SYSTEM::UnifiedEvent currentEvent = linearEventTracker->getCurrentLinearEvent();
    bool currentEventRestricted =
        insideWatershed ? false : isRestricted(currentEvent, unifiedService, sortedRestrictedRatings);

    if ( autoAcceptMiliseconds > 0 )
    {
        autoAcceptMiliseconds -= updateIntervalMilis;
        if ( autoAcceptMiliseconds < 0)
        {
            autoAcceptMiliseconds = 0;
        }
    }
    bool autoAcceptState = autoAcceptMiliseconds > 0;

    NICKEL_TRACE("updateInternal - now(" << epochToDayTimePrintable( nowNS / 1e9 ) << ")");

    // Check if we came across a new event
    if (!previousEventLocator || *previousEventLocator != currentEvent.data.eventLocator ||
        // Special case - resuming from stand-by - rated content must be restricted again even if it was accepted
        justResumedFromStandby)
    {
        NICKEL_DEBUG("updateInternal - New head event: '"
                     << currentEvent.data.eventLocator << "' ("
                     << currentEvent.data.guidanceRatingScheme << " " << currentEvent.data.guidanceRating << ")"
                     << " - eventType(" << currentEvent.data.eventType << ")"
                     << " - blocked(" << blocked << ")"
                     << " - now(" << epochToDayTimePrintable( nowNS / 1e9 ) << ")"
                     << " - watershed(" << insideWatershed << ")"
                     << " - currentEventRestricted(" << currentEventRestricted << ")"
                     << " - justResumedFromStandby(" << justResumedFromStandby << ")"
                     << " - autoAcceptMs(" << autoAcceptMiliseconds << ")");
        justResumedFromStandby = false;
        if (blocked && !currentEventRestricted)
        {
            unblockAndSignal();
        }
        else if (currentEventRestricted && !autoAcceptState)
        {
            blockAndSignal();
        }
    }

    // Check if watershed started
    if (previouslyInsideWatershed && !(*previouslyInsideWatershed) && insideWatershed)
    {
        if (blocked)
        {
            unblockAndSignal();
        }
    }
    // Check if watershed ended
    else if (previouslyInsideWatershed && (*previouslyInsideWatershed) && !insideWatershed)
    {
        if (!blocked && currentEventRestricted && !autoAcceptState)
        {
            blockAndSignal();
        }
    }

    previousEventLocator = currentEvent.data.eventLocator;
    previouslyInsideWatershed = insideWatershed;
}

void ParentalControlsImpl::blockAndSignal()
{
    NICKEL_PROFILE_FUNC;
    NICKEL_INFO("ParentalControlsImpl::blockAndSignal");

    if(lockMR)
    {
        lockMR();
    }

    produceEvent( boost::bind(&ParentalControlsEventListener::ParentalControlsStateChange, _1, true ) );

    blocked = true;
}

void ParentalControlsImpl::unblockAndSignal()
{
    NICKEL_PROFILE_FUNC;
    NICKEL_INFO("ParentalControlsImpl::unblockAndSignal");

    if(unlockMR)
    {
        unlockMR();
    }

    produceEvent( boost::bind(&ParentalControlsEventListener::ParentalControlsStateChange, _1, false ) );

    blocked = false;
}

boost::shared_ptr< ParentalControls >
    createParentalControls(boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync > uiManager,
                           boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
                           boost::shared_ptr< LinearEventTracker > linearEventTracker,
                           boost::shared_ptr< ParentallyControlledMediaRouter > mr,
                           boost::function< int64_t (void) > getEpochTimeInNanoSeconds,
                           const ParentalControlsSettings& settings,
                           const UnifiedService& service)
{
    NICKEL_PROFILE_FUNC;
    boost::shared_ptr<ParentalControlsImpl> impl =
        boost::make_shared< ParentalControlsImpl >(
            linearEventTracker, mr,
            getEpochTimeInNanoSeconds, settings, service);
    uiManager->addListener(dispatcher, impl);
    return impl;
}

NS_NICKEL_SYSTEM_CLOSE
