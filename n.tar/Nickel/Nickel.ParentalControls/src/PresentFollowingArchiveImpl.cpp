/*
 * PresentFollowingArchiveImpl.cpp
 *
 *  Created on: 2 May, 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/PresentFollowingArchive.h"

#include "../include/ParentalControlsHelpers.h"
#include <cobalt-system-api/UnifiedEventRepositoryEventListener.h>
#include <cobalt-system-api/UnifiedEventRepository.h>
#include <cobalt-system-api/UnifiedEventHelpers.h>
#include <zinc-common/async/Dispatcher.h>

#include <nickel-system-api/macros.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-common/NickelProfiler.h>

#include <boost/bind.hpp>
#include <boost/foreach.hpp>

#include <algorithm>
#include <sstream>

NS_NICKEL_SYSTEM_OPEN

namespace
{
void printSchedule(const std::string& printReason, const std::deque< EventTransition >& events)
{
    std::stringstream schedule;
    BOOST_FOREACH(const EventTransition& eventTransition, events)
    {
        schedule << " | "
            << monotonicToDayTimePrintable( eventTransition.transitionTime ) << " ("
            << eventTransition.event.data.eventLocator << "@"
            << epochToDayTimePrintable( NS_COBALT_SYSTEM::getStartTime(eventTransition.event) ) << "-"
            << epochToDayTimePrintable( NS_COBALT_SYSTEM::getEndTime(eventTransition.event) ) << " "
            << eventTransition.event.data.guidanceRating << ")";
    }
    NICKEL_DEBUG(printReason << " - Schedule" << schedule.str());
}

bool eventTransitionMatchesEventLocator(const EventTransition& eventTransition, const std::string& eventLocator)
{
    return eventTransition.event.data.eventLocator == eventLocator;
}

bool eventTransitionIsBeforeTime(const EventTransition& eventTransition,
                                 const NS_ZINC::monotonic_clock::time_point& time)
{
    return eventTransition.transitionTime < time;
}

} // anon namespace

PresentFollowingArchive::~PresentFollowingArchive()
{
}

class PresentFollowingArchiveImpl :
    public PresentFollowingArchive,
    public  NS_COBALT_SYSTEM::UnifiedEventRepositoryEventListener
{
public:
    PresentFollowingArchiveImpl(
        const std::string& service_,
        boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime_,
        const boost::posix_time::time_duration& purgePeriod_,
        const std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo >& initialPFInfos):
            service(service_),
            getMonotonicTime(getMonotonicTime_),
            purgePeriod(purgePeriod_)
    {
        NICKEL_FUNC_TRACE;
        BOOST_FOREACH(const NS_COBALT_SYSTEM::PresentFollowingInfo& pfInfo, initialPFInfos)
        {
            if (pfInfo.serviceLocator == service)
            {
                eventTransitions.push_back(EventTransition(pfInfo.presentEvent, getMonotonicTime()));
                printSchedule("Initial PF", eventTransitions);
            }
        }
    }

    virtual NS_COBALT_SYSTEM::UnifiedEvent getEventAtTime(const NS_ZINC::monotonic_clock::time_point& time) const
    {
        NICKEL_PROFILE_FUNC;
        NICKEL_FUNC_TRACE;
        boost::mutex::scoped_lock lock(mutex);
        BOOST_REVERSE_FOREACH(const EventTransition& eventTransition, eventTransitions)
        {
            if (eventTransition.transitionTime < time)
            {
                return eventTransition.event;
            }
        }
        NS_COBALT_SYSTEM::UnifiedEvent scheduleGap; // Create an invalid event.
        scheduleGap.data.eventType = NS_COBALT_SYSTEM::EventType::invalid; // Insist that this is an invalid event
        return scheduleGap;
    }

    virtual boost::optional< EventTransition >
        getEventByEventLocator(const std::string& eventLocator) const
    {
        std::deque< EventTransition >::const_reverse_iterator i =
            std::find_if(eventTransitions.rbegin(), eventTransitions.rend(),
                boost::bind(eventTransitionMatchesEventLocator, _1, eventLocator));
        return (i != eventTransitions.rend()) ? *i : boost::optional< EventTransition >();
    }

private: // NS_COBALT_SYSTEM::UnifiedEventRepositoryEventListener

    virtual void PresentFollowingChange(const std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo >& pfEvents)
    {
        NICKEL_PROFILE_FUNC;
        BOOST_FOREACH(const NS_COBALT_SYSTEM::PresentFollowingInfo& pfInfo, pfEvents)
        {
            if (pfInfo.serviceLocator == service)
            {
                boost::mutex::scoped_lock lock(mutex);
                eventTransitions.push_back(EventTransition(pfInfo.presentEvent, getMonotonicTime()));
                printSchedule("PFChange", eventTransitions);
                lock.unlock();
                NS_ZINC::monotonic_clock::time_point purgeTime = getMonotonicTime();
                purgeTime += -purgePeriod;
                purgeOlderThan(purgeTime);
            }
        }
    }

    virtual void ScheduleChange(
        const std::vector< std::string >& , uint32_t, uint32_t)
    {
    }


private:

    void purgeOlderThan(const NS_ZINC::monotonic_clock::time_point& purgeTime)
    {
        NICKEL_PROFILE_FUNC;
        NICKEL_FUNC_TRACE;

        boost::mutex::scoped_lock lock(mutex);
        std::deque< EventTransition >::iterator it =
            std::lower_bound(eventTransitions.begin(), eventTransitions.end(), purgeTime, &eventTransitionIsBeforeTime);
        if (it != eventTransitions.begin())
        {
            eventTransitions.erase(eventTransitions.begin(), it);
            printSchedule("Events purged", eventTransitions);
        }
    }

    std::string                                                    service;
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime;
    boost::posix_time::time_duration                               purgePeriod;

    mutable boost::mutex mutex;
    std::deque< EventTransition > eventTransitions; ///< List of present events
};

boost::shared_ptr< PresentFollowingArchive > createPresentFollowingArchive(
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > eventRepository,
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
    const std::string& service,
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime,
    const boost::posix_time::time_duration& purgePeriod,
    const NS_ZINC::FutureValue< std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo > >& fv)
{
    std::vector< NS_COBALT_SYSTEM::PresentFollowingInfo > initialPF;
    if (fv.getError())
    {
        // This is not fatal - a schedule gap will be assumed until the first PFChange arrives
        NICKEL_ERROR("createPresentFollowingArchive - Couldn't get PF with the following error: "
                     << fv.getError() << " - " << fv.getError().message() );
    }
    else
    {
        initialPF = fv.get();
    }
    boost::shared_ptr< PresentFollowingArchiveImpl > pfArchive =
        boost::make_shared< PresentFollowingArchiveImpl >(
            service, getMonotonicTime, purgePeriod, initialPF);
    eventRepository->addListener(dispatcher, pfArchive);
    return pfArchive;
}

NS_ZINC::Future< boost::shared_ptr< PresentFollowingArchive > >
createPresentFollowingArchiveAsync(
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > eventRepository,
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
    const std::string& service,
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime,
    const boost::posix_time::time_duration& purgePeriod)
{
    NICKEL_PROFILE_FUNC;
    return eventRepository->getPresentFollowing(std::vector< std::string >(1, service)).then(
            *dispatcher,
            boost::bind(&createPresentFollowingArchive, eventRepository, dispatcher, service,
                        getMonotonicTime, purgePeriod, _1 ));
}

NS_NICKEL_SYSTEM_CLOSE
