/*
 * LinearEventTrackerImpl.cpp
 *
 *  Created on: 14 Aug 2013
 *      Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 *
 */

#include "../include/LinearEventTracker.h"
#include "../include/PresentFollowingArchive.h"
#include "../include/ParentalControlsHelpers.h"

#include <cobalt-system-api/UnifiedEventHelpers.h>

#include <nickel-common/NickelLogger.h>

#include <nickel-system-api/MediaRouterAsync.h>
#include <nickel-system-api/MediaRouterEventListener.h>

#include <zinc-common/async/Continuation.h>
#include <zinc-common/async/Dispatcher.h>

#include <boost/make_shared.hpp>
#include <boost/optional.hpp>
#include <boost/date_time/time_duration.hpp>
#include <boost/thread/locks.hpp>

#include <cstdlib>
#include <ctime>

using namespace NS_COBALT_SYSTEM;
using namespace NS_NICKEL_SYSTEM;
using namespace NS_ZINC;

using boost::make_shared;
using boost::optional;
using boost::shared_ptr;

NS_NICKEL_SYSTEM_OPEN

LinearEventTrackerEventListener::~LinearEventTrackerEventListener()
{
}

LinearEventTracker::~LinearEventTracker()
{
}

class LinearEventTrackerImpl : public LinearEventTracker, public MediaRouterEventListener
{
public:
    LinearEventTrackerImpl(boost::shared_ptr< PresentFollowingArchive > pfArchive_,
                           boost::function< NS_ZINC::monotonic_clock::time_point (void) >  getMonotonicTime_,
                           const NS_NICKEL_SYSTEM::Position& initialPosition):
        pfArchive(pfArchive_),
        getMonotonicTime(getMonotonicTime_),
        positiveTimeshift( boost::posix_time::milliseconds(initialPosition.end - initialPosition.current) )
    {
    }

    UnifiedEvent getCurrentLinearEvent()
    {
        return doRefreshCurrentLinearEvent();
    }

    /* MediaRouter event listener interface implementation */
    virtual void BufferStatusEvent(const NS_NICKEL_SYSTEM::BufferStatusEventValue::Enum)
    {
    }
    virtual void DrmEvent(const NS_NICKEL_SYSTEM::DrmEventValue::Enum, const std::string& , const std::string& )
    {
    }
    virtual void SourceEvent(const NS_NICKEL_SYSTEM::SourceEventValue::Enum, const NS_NICKEL_SYSTEM::SetSourceReason::Enum)
    {
    }
    virtual void SpeedChangeEvent()
    {
    }
    virtual void StatusEvent(const NS_NICKEL_SYSTEM::StatusEventValue::Enum)
    {
    }
    virtual void ErrorEvent(const NS_NICKEL_SYSTEM::ErrorEventValue::Enum, const NS_NICKEL_SYSTEM::ErrorEventContext::Enum, const std::string& )
    {
    }

    virtual void PositionChangeEvent(const NS_NICKEL_SYSTEM::Position& position)
    {
        boost::mutex::scoped_lock l(mutex);
        positiveTimeshift = boost::posix_time::milliseconds(position.end - position.current);
        l.unlock();
        doRefreshCurrentLinearEvent();
    }

private:

    NS_COBALT_SYSTEM::UnifiedEvent doRefreshCurrentLinearEvent()
    {
        boost::mutex::scoped_lock l(mutex);
        NS_ZINC::monotonic_clock::time_point timeshiftedNow = getMonotonicTime();
        timeshiftedNow += -positiveTimeshift;
        NICKEL_TRACE("LinearEventTracker: "
                     << "timeshiftedNow(" << monotonicToDayTimePrintable( timeshiftedNow ) << ")");

        NS_COBALT_SYSTEM::UnifiedEvent newEvent =  pfArchive->getEventAtTime( timeshiftedNow );

        if (!currentLinearEvent ||
            (currentLinearEvent->data.eventLocator != newEvent.data.eventLocator &&
             abs((*currentLinearEventTransitionTime - timeshiftedNow).total_milliseconds()) > 
                LINEAR_EVENT_CHANGED_THRESHOLD_MS
            ))
        {
            currentLinearEvent = newEvent;
            currentLinearEventTransitionTime = timeshiftedNow;
            l.unlock();
            NICKEL_DEBUG("LinearEventTracker: LinearEventChanged: "
                 << monotonicToDayTimePrintable( timeshiftedNow ) << " ("
                 << newEvent.data.eventLocator << " "
                 << epochToDayTimePrintable( NS_COBALT_SYSTEM::getStartTime(newEvent) ) << "-"
                 << epochToDayTimePrintable( NS_COBALT_SYSTEM::getEndTime(newEvent) ) << ")");
            produceEvent( boost::bind(&LinearEventTrackerEventListener::LinearEventChanged, _1, newEvent ) );
        }
        else
        {
            // Make sure we always return the currentEvent and not necessarily what PFArchive gave us
            // (see LINEAR_EVENT_CHANGED_THRESHOLD_MS).
            newEvent = *currentLinearEvent;
        }

        return newEvent;
    }

    shared_ptr< PresentFollowingArchive >                           pfArchive;
    boost::function< NS_ZINC::monotonic_clock::time_point (void) >  getMonotonicTime;

    boost::mutex mutex;
    boost::posix_time::time_duration                                positiveTimeshift;
    optional< UnifiedEvent >                                        currentLinearEvent;
    optional< NS_ZINC::monotonic_clock::time_point >                currentLinearEventTransitionTime;
};

struct CreateLinearEventTrackerContinuation:
        Continuation< boost::shared_ptr< LinearEventTracker >, CreateLinearEventTrackerContinuation >
{
    boost::shared_ptr< MediaRouterAsync > mr;
    boost::shared_ptr< LinearEventTrackerEventListener > eventListener;
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher;
    boost::shared_ptr< PresentFollowingArchive > pfArchive;
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime;

    void start(Future< boost::shared_ptr< PresentFollowingArchive > > pfArchiveFuture,
               boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher_,
               boost::shared_ptr< MediaRouterAsync > mr_,
               boost::shared_ptr< LinearEventTrackerEventListener > eventListener_,
               boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime_)
    {
        NICKEL_DEBUG("CreateLinearEventTrackerContinuation::start()");
        mr = mr_;
        eventListener = eventListener_;
        dispatcher = dispatcher_;
        getMonotonicTime = getMonotonicTime_;

        continueOnSuccess(pfArchiveFuture, &This::onGotPFArchive);
    }

    void onGotPFArchive(boost::shared_ptr< PresentFollowingArchive > pfArchive_)
    {
        NICKEL_DEBUG("CreateLinearEventTrackerContinuation::onGotPFArchive()");
        pfArchive = pfArchive_;
        continueOn(mr->getPosition(),
                  &This::onGotInitialPosition);
    }

    void onGotInitialPosition(const NS_ZINC::FutureValue<NS_NICKEL_SYSTEM::Position>& fv)
    {
        NS_NICKEL_SYSTEM::Position initialPosition(0, 0, 0);
        if (fv.getError())
        {
            // This is not fatal, the position will be assumed to be 0 until the first
            // PositionChange event arrives.
            NICKEL_ERROR("CreateLinearEventTrackerContinuation::onGotInitialPosition("
                         << fv.getError() << " - " << fv.getError().message() << ") - Failed to get initial position" );
        }
        else
        {
            initialPosition = fv.get();
            NICKEL_DEBUG("CreateLinearEventTrackerContinuation::onGotInitialPosition("
                         << initialPosition.current << ")" );
        }
        boost::shared_ptr< LinearEventTrackerImpl > impl =
            boost::make_shared< LinearEventTrackerImpl >(pfArchive, getMonotonicTime,
                                                         initialPosition);
        // Add the EventTracker listener before starting listening to MR signals to guarantee that
        // the listener will not miss any signals.
        if (eventListener)
        {
            impl->addListener(dispatcher, eventListener);
        }
        mr->addListener(dispatcher, impl);
        promise.complete(impl);
    }
};

Future< boost::shared_ptr< LinearEventTracker > >
createLinearEventTrackerAsync(
    Future< boost::shared_ptr< PresentFollowingArchive > > pfArchiveFuture,
    boost::shared_ptr< MediaRouterAsync > mr,
    boost::shared_ptr< LinearEventTrackerEventListener > eventListener,
    boost::shared_ptr< Dispatcher > dispatcher,
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime)
{
    return CreateLinearEventTrackerContinuation::create(
        *dispatcher, pfArchiveFuture, dispatcher, mr, eventListener, getMonotonicTime);
}

NS_NICKEL_SYSTEM_CLOSE
