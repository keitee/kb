/*
 * ParentallyControlledMediaRouter.h
 *
 *  Created on: 22 Apr 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 *
 */
#ifndef NICKEL_PARENTALCONTROLS_PARENTALLY_CONTROLLED_MEDIA_ROUTER_H
#define NICKEL_PARENTALCONTROLS_PARENTALLY_CONTROLLED_MEDIA_ROUTER_H

#include <nickel-system-api/macros.h>
#include <nickel-system-api/MediaRouterAsync.h>
#include <boost/shared_ptr.hpp>

#include <boost/function.hpp>

NS_NICKEL_SYSTEM_OPEN

struct ZINC_EXPORT ParentallyControlledMediaRouter
{
    ParentallyControlledMediaRouter(boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > mr_,
                                    boost::function< void (void) > lockMR_,
                                    boost::function< void (void) > unlockMR_,
                                    boost::function< void (void) > resetMR_):
        mr(mr_),
        lockMR(lockMR_),
        unlockMR(unlockMR_),
        resetMR(resetMR_)
    {
    }

    ~ParentallyControlledMediaRouter();

    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > mr;
    boost::function< void (void) >                          lockMR;
    boost::function< void (void) >                          unlockMR;
    boost::function< void (void) >                          resetMR;
};

/**
 * createParentallyControlledMR creates a mediarouter wrapper
 * such that calls to the functions returned can lock and unlock
 * the wrapped (controlled) mediarouter for parental control
 * purposes.
 * 
 * The returned struct contains a wrapper for the MediaRouter,
 * a functor that locks and functor that unlocks the mediarouter.
 * This approach was used to avoid creation of the new public types.
 *
 * @param mr is the MediaRouter to wrap
 * @param dispatcher is used to dispatch events received from the proxied MediaRouter.
 */
ZINC_EXPORT
boost::shared_ptr< ParentallyControlledMediaRouter >
createParentallyControlledMR(
                            boost::shared_ptr< MediaRouterAsync > mr,
                            boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher);

NS_NICKEL_SYSTEM_CLOSE

#endif //NICKEL_PARENTALCONTROLS_PARENTALLY_CONTROLLED_MEDIA_ROUTER_H
