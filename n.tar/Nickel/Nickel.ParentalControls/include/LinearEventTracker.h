/*
 * LinearEventTracker.h
 *
 *  Created on: 14 August, 2013
 *      Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_PARENTALCONTROLS_LINEAREVENTTRACKER_H
#define NICKEL_PARENTALCONTROLS_LINEAREVENTTRACKER_H

#include <nickel-system-api/macros.h>

#include <cobalt-system-api/UnifiedEvent.h>

#include <zinc-common/async/Future.h>
#include <zinc-common/DispatchingEventProducer.h>
#include <zinc-common/EventListener.h>
#include <zinc-common/MonotonicClock.h>
#include <zinc-common/macros.h>

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

// TODO: DEVARCH-6925 - Create fwd decl in every project
NS_ZINC_OPEN
class Dispatcher;
NS_ZINC_CLOSE

namespace Zinc {
namespace Media {
class MediaRouterAsync;
} //namespace Media
}

NS_NICKEL_SYSTEM_OPEN

class PresentFollowingArchive;

struct ZINC_EXPORT LinearEventTrackerEventListener : public NS_ZINC::EventListener
{
    virtual ~LinearEventTrackerEventListener();

    virtual void LinearEventChanged(const NS_COBALT_SYSTEM::UnifiedEvent& event) = 0;
};

class ZINC_EXPORT LinearEventTracker :
    public NS_ZINC::DispatchingEventProducer< LinearEventTrackerEventListener >
{
public:

    virtual ~LinearEventTracker();

    /**
     * @brief Return the linear event that is being played.
     * 
     * This takes into account timeshifting.
     */
    virtual NS_COBALT_SYSTEM::UnifiedEvent getCurrentLinearEvent() = 0;
};

/**
 * Create a LinearEventTracker that enables to track what event is playing now with timeshift.
 *
 * @param eventListener is a listener that will be added to LinearEventTracker's event listeners
 *        with the guarantee that it cannot miss the first signal LinearEventChanged.
 */
NS_ZINC::Future< boost::shared_ptr< LinearEventTracker > >
ZINC_EXPORT createLinearEventTrackerAsync(
    NS_ZINC::Future< boost::shared_ptr< PresentFollowingArchive > > pfArchiveFuture,
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > mr,
    boost::shared_ptr< LinearEventTrackerEventListener > eventListener,
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime);

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKEL_PARENTALCONTROLS_LINEAREVENTTRACKER_H
