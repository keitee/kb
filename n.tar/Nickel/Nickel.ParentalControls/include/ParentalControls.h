/* 
 * File:   ParentalControls.h
 * Author: mariusz.buras@youview.com
 *         hubert.lacote@youview.com
 *
 * Created on 15 July 2013
 * 
 * Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_PARENTALCONTROLS_PARENTALCONTROLS_H
#define NICKEL_PARENTALCONTROLS_PARENTALCONTROLS_H

#include <nickel-system-api/macros.h>

#include <cobalt-system-api/macros.h>

#include <mercury-system-api/macros.h>

#include <zinc-common/macros.h>
#include <zinc-common/DispatchingEventProducer.h>
#include <zinc-common/EventListener.h>

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

#include <string>
#include <vector>

// Cannot include cstdint because it requires C++0x support
#include <stdint.h>

// TODO: DEVARCH-6925 - Create fwd decl in every project
NS_ZINC_OPEN
class Dispatcher;
NS_ZINC_CLOSE

namespace Zinc {
namespace Application {
class UIManagerAsync;
} // namespace Application
namespace Media {
class MediaRouterAsync;
} // namespace Media
namespace Broker {
class UnifiedService;
} // namespace Broker
} // namespace Zinc

NS_NICKEL_SYSTEM_OPEN

class LinearEventTracker;
class ParentallyControlledMediaRouter;

struct ZINC_EXPORT ParentalControlsEventListener : public NS_ZINC::EventListener
{
    virtual ~ParentalControlsEventListener();
    virtual void ParentalControlsStateChange(bool locked) = 0;
};

class ZINC_EXPORT ParentalControls :
    public virtual NS_ZINC::DispatchingEventProducer< ParentalControlsEventListener >
{
public:
    virtual ~ParentalControls();
    virtual bool isLocked() const = 0;
    virtual void allowRestrictedContent(uint32_t autoAcceptSeconds) = 0;

    /*
     * An implementation of ParentalControls doesn't have a thread to execute
     * its logic on. Instead, it expects that update() will be called 
     * periodically. This way, it greatly simplifies tests by making it
     * deterministic.
     */
    virtual void update(uint32_t updateIntervalMilis) = 0;
};

struct ParentalControlsSettings
{
    uint32_t watershedStartTime;
    uint32_t watershedEndTime;
    std::vector< std::string > restrictedRatings;
};

ZINC_EXPORT
boost::shared_ptr< ParentalControls >
    createParentalControls(boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync > uiManager,
                           boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
                           boost::shared_ptr< LinearEventTracker > linearEventTracker,
                           boost::shared_ptr< ParentallyControlledMediaRouter > mr,
                           boost::function< int64_t (void) > getEpochTimeInNanoSeconds,
                           const ParentalControlsSettings& settings,
                           const NS_COBALT_SYSTEM::UnifiedService& service);

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_PARENTALCONTROLS_PARENTALCONTROLS_H */

