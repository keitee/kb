/*
 * PresentFollowingArchive.h
 *
 *  Created on: 2 May, 2013
 *      Author: mariusz.buras@youview.com
 *              hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_PARENTALCONTROLS_PRESENT_FOLLOWING_ARCHIVE_H
#define NICKEL_PARENTALCONTROLS_PRESENT_FOLLOWING_ARCHIVE_H

#include <nickel-system-api/macros.h>
#include <cobalt-system-api/macros.h>
#include <cobalt-system-api/UnifiedEvent.h>

#include <zinc-common/async/Future.h>
#include <zinc-common/MonotonicClock.h>

#include <boost/date_time/time_duration.hpp>
#include <boost/function.hpp>
#include <boost/optional.hpp>

#include <string>

// TODO: DEVARCH-6925 - Create fwd decl in every project
NS_ZINC_OPEN
class Dispatcher;
NS_ZINC_CLOSE

namespace Zinc {
namespace Broker {
class UnifiedEventRepositoryAsync;
}
}

NS_NICKEL_SYSTEM_OPEN

struct ZINC_EXPORT EventTransition
{
    EventTransition()
    {
    }

    EventTransition(const NS_COBALT_SYSTEM::UnifiedEvent& event_,
                    const NS_ZINC::monotonic_clock::time_point& transitionTime_):
        event(event_), transitionTime(transitionTime_)
    {
    }

    NS_COBALT_SYSTEM::UnifiedEvent event;
    NS_ZINC::monotonic_clock::time_point transitionTime;
};

class ZINC_EXPORT PresentFollowingArchive
{
public:

    virtual ~PresentFollowingArchive();

    /**
     * @brief Return event that was present at the time specified.
     *
     * This will return an invalid event when there is a schedule gap.
     */
    virtual NS_COBALT_SYSTEM::UnifiedEvent getEventAtTime(
        const NS_ZINC::monotonic_clock::time_point& time) const = 0;

    /**
     * @brief Return event matching the event locator specified.
     */
    virtual boost::optional< EventTransition >
        getEventByEventLocator(const std::string& eventLocator) const = 0;
};

NS_ZINC::Future< boost::shared_ptr< PresentFollowingArchive > >
ZINC_EXPORT createPresentFollowingArchiveAsync(
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > eventRepository,
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
    const std::string& service,
    boost::function< NS_ZINC::monotonic_clock::time_point (void) > getMonotonicTime,
    const boost::posix_time::time_duration& purgePeriod);

NS_NICKEL_SYSTEM_CLOSE

#endif //NICKEL_PARENTALCONTROLS_PRESENT_FOLLOWING_ARCHIVE_H
