/* 
 * File:   ParentalControlsHelpers.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 16 July 2013
 * 
 * Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_PARENTALCONTROLS_PARENTALCONTROLSHELPERS_H
#define NICKEL_PARENTALCONTROLS_PARENTALCONTROLSHELPERS_H

#include <cobalt-system-api/UnifiedEvent.h>
#include <cobalt-system-api/UnifiedService.h>

#include <nickel-system-api/macros.h>

#include <zinc-common/macros.h>
#include <zinc-common/MonotonicClock.h>

#include <boost/shared_ptr.hpp>

#include <vector>
#include <string>

NS_NICKEL_SYSTEM_OPEN

/**
 * Threshold used to avoid succession of ParentalControlsStateChange
 * when paused between two events (happens usually when PIN is prompted).
 * This means that LinearEventTracker assumes there is at least 5 seconds
 * in content time between two events.
 * This is required since PositionChange events sent by OEM are oscillating.
 */
const int32_t LINEAR_EVENT_CHANGED_THRESHOLD_MS = 5000;

/**
 * This is used to implement Parental Controls for events in the timeshift buffer.
 * See CANPDE-2737, CANPDE-3080, CANPDE-3081 and CANPDE-3082.
 *
 * @param event is the event that will be checked for restriction.
 * @param service is the service that contains event.
 * @param sortedRestrictedRatings is a sorted list of B2C ratings from
 *        the Controlled Vocabulary BBFCRatingCS, YouViewContentRatingCS
 *        and DentonContentWarningCS.
 * @return true if the event is not restricted by Parental Controls.
 *
 * More details about the implementation is described in SPECWIP-3786 and SPECWIP-3788.
 */
bool isRestricted( const NS_COBALT_SYSTEM::UnifiedEvent& event,
                   const NS_COBALT_SYSTEM::UnifiedService& service,
                   const std::vector< std::string >& sortedRestrictedRatings) ZINC_EXPORT;

bool isInsideWatershed( int64_t nanosecondsUTC,
                        int64_t watershedStartTimeNS, int64_t watershedEndTimeNS) ZINC_EXPORT;

std::string epochToDayTimePrintable(const time_t epochTime) ZINC_EXPORT;

/**
 * @brief Return the time assuming there was no time warp.
 */
std::string monotonicToDayTimePrintable(const NS_ZINC::monotonic_clock::time_point& time) ZINC_EXPORT;

inline int64_t milisecsToNanosecs(int64_t milis)
{
    return milis * 1e6;
}

inline int64_t secondsToNanosecs(int64_t seconds)
{
    return seconds * 1e9;
}

inline int64_t nanosecsToSeconds(int64_t nanosecs)
{
    return nanosecs / 1e9;
}

inline int64_t epochToDayTimeNS(int64_t nanosSinceEpoch)
{
    return nanosSinceEpoch % secondsToNanosecs ( 24*3600 );
}

NS_NICKEL_SYSTEM_CLOSE

#endif	/* NICKEL_PARENTALCONTROLS_PARENTALCONTROLSHELPERS_H */

