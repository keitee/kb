/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include <nickel-common/NickelLogger.h>
#include <nickelonscreenid-system-api/Factory.h>

#include "ProductionImageDownloader.h"
#include "ProductionRenderEngine.h"

#include <copper-system-api/LocalStorageRepository.h>
#include <copper-system-api/Registry.h>
#include <copper-system-api/SystemFactory.h>

#include <zinc-common/FilePluginConfig.h>
#include <zinc-common/PluginFactory.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <zinc-http/client/UserAgentGenerator.h>

#include <boost/lexical_cast.hpp>
#include <boost/make_shared.hpp>

#include <cstdlib>
#include <stdexcept>

namespace Zinc {
namespace OnScreenId {

// see Mercury/Mercury.System.UIManager/src/MercuryWindow.h
const unsigned long ONSCREENID_WINDOW_APPLICATION_ID = 0x80000006ul;

namespace {

template<typename T>
T convertOrDefault(const std::string& v, const T d)
{
    try
    {
        return boost::lexical_cast<T>(v);
    }
    catch (const boost::bad_lexical_cast&)
    {
        return d;
    }
}

boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepository> createLSR()
{
    const NS_ZINC::FilePluginConfig pluginConfig(
        NS_ZINC::PackageDataFinder().find(
            "copper-system-factory.plugin-config"));

    NS_COPPER_SYSTEM::SystemFactory& f =
        NS_ZINC::PluginFactory::getInstance<NS_COPPER_SYSTEM::SystemFactory>(
            pluginConfig);

    return f.createLocalStorageRepository();
}

std::string getUserAgent(
    const boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepository>& lsr,
    const boost::shared_ptr<NS_ZINC::FutureDispatcher>& disp)
{
    client::UserAgentGeneratorAsync g(lsr, disp);
    return g.generateDefaultHTTPUserAgentString().get();
}

std::string getFontPath()
{
    /**
     * Currently the "IP Channels" spec(0018-S) says in the Annex F.4:
     *
     *  "Textual identifiers will be rendered using the YouView system font
     *   typeface (currently FS Me)."
     */

    return
        NS_ZINC::PackageDataFinder("mercury-system-uimanager")
            .find("FSMe-Regular.ttf");
}

class ProductionFactory : public Factory
{
public:
    ProductionFactory();

    virtual boost::shared_ptr<ImageDownloader> createImageDownloader(
        const boost::shared_ptr<NS_ZINC::FutureDispatcher>& disp) const;

    virtual boost::shared_ptr<RenderEngine> createRenderEngine() const;
};

ProductionFactory::ProductionFactory()
{
    initialiseProductionRenderEngine();
}

boost::shared_ptr<ImageDownloader> ProductionFactory::createImageDownloader(
    const boost::shared_ptr<NS_ZINC::FutureDispatcher>& disp) const
{
    enum LsrKeysIndex
    {
        LSR_MCD = 0,
        LSR_RT,

        NUM_LSR_KEYS
    };

    std::vector<std::string> keys(NUM_LSR_KEYS);
    // TODO: Request keys in Platform Config
    keys[LSR_MCD] = "platform.onscreenid.request.concurrent";
    keys[LSR_RT] = "platform.onscreenid.request.timeoutms";

    const boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepository> lsr =
        createLSR();

    const boost::shared_ptr<NS_COPPER_SYSTEM::Registry> reg =
        NS_COPPER_SYSTEM::createRegistry(disp, lsr);

    const std::vector<std::string> keyValues = reg->get(keys).get();

    const uint32_t maxConcurrentDownloads =
        convertOrDefault<uint32_t>(keyValues[LSR_MCD], 1);
    const uint32_t requestTimeoutMs =
        convertOrDefault<uint32_t>(keyValues[LSR_RT], 15 * 1000);

    std::map<ProductionImageDownloaderParams::Enum, std::string> kwargs;
    kwargs[ProductionImageDownloaderParams::DOWNLOAD_DIR_ROOT] =
        "/tmp";
    kwargs[ProductionImageDownloaderParams::CA_BUNDLE] =
        "/opt/youview/pki/tls/ca-bundle.crt";
    kwargs[ProductionImageDownloaderParams::USER_AGENT] =
        getUserAgent(lsr, disp);

    return createProductionImageDownloader(
        boost::make_shared<NS_ZINC::HttpDownloader>(disp,
                                                    maxConcurrentDownloads,
                                                    requestTimeoutMs),
        kwargs);
}

boost::shared_ptr<RenderEngine> ProductionFactory::createRenderEngine() const
{
    return createProductionRenderEngine(ONSCREENID_WINDOW_APPLICATION_ID,
                                        getFontPath());
}

} // namespace

extern "C"
NS_ZINC::Plugin* createProductionFactory() ZINC_EXPORT;

NS_ZINC::Plugin* createProductionFactory()
{
    try
    {
        return new ProductionFactory();
    }
    catch (const std::exception& e)
    {
        NICKEL_FATAL(e.what());
    }
    catch (...)
    {
        NICKEL_FATAL("Unknown error");
    }

    std::abort();
}

} // namespace OnScreenId
} // namespace Zinc
