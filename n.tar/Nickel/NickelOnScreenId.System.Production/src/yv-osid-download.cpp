/*
 * Author: Krzysztof Konopko <kris@youview.com>
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include <nickelonscreenid-system-api/Factory.h>
#include <nickelonscreenid-system-api/ImageDownloader.h>

#include <zinc-common/async/InlineFutureDispatcher.h>
#include <zinc-common/FixedPluginConfig.h>
#include <zinc-common/PluginFactory.h>

#include <boost/filesystem/convenience.hpp>
#include <boost/make_shared.hpp>

#include <cstdlib>
#include <iostream>

int main(int argc, char* argv[])
{
    using namespace Zinc::OnScreenId;

    if (argc != 3)
    {
        std::cerr << "Usage:  " << argv[0] << " <URL> <dest>\n";
        return EXIT_FAILURE;
    }

    const uint8_t ref = 0;

    try
    {
        const NS_ZINC::FixedPluginConfig pluginConfig(
            "libNickelOnScreenIdSystemProduction.so", "createProductionFactory");
        const Factory& f =
            NS_ZINC::PluginFactory::getInstance<Factory>(pluginConfig);

        const boost::shared_ptr<NS_ZINC::InlineFutureDispatcher> disp =
            boost::make_shared<NS_ZINC::InlineFutureDispatcher>();

        const boost::shared_ptr<ImageDownloader> d =
            f.createImageDownloader(disp);

        std::cout << "Downloading " << argv[1] << " ..." << std::endl;

        d->download(ref, argv[1]);
        boost::filesystem::copy_file(d->getPath(ref), argv[2]);

        std::cout << "Downloaded to " << argv[2] << std::endl;
        return EXIT_SUCCESS;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
    }

    return EXIT_FAILURE;
}
