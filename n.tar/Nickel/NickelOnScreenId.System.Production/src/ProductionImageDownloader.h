/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_PRODUCTION_PRODUCTIONIMAGEDOWNLOADER_H_
#define NICKEL_ONSCREENID_SYSTEM_PRODUCTION_PRODUCTIONIMAGEDOWNLOADER_H_

#include <nickelonscreenid-system-api/ImageDownloader.h>

#include <zinc-downloader/HttpDownloader.h>

#include <boost/shared_ptr.hpp>

#include <map>
#include <string>

namespace Zinc {
namespace OnScreenId {

struct ProductionImageDownloaderParams
{
    enum Enum
    {
        DOWNLOAD_DIR_ROOT,
        CA_BUNDLE,
        USER_AGENT
    };
};

boost::shared_ptr<ImageDownloader> createProductionImageDownloader(
    const boost::shared_ptr<NS_ZINC::HttpDownloader>& downloader,
    const std::map<ProductionImageDownloaderParams::Enum, std::string>& kwargs =
        std::map<ProductionImageDownloaderParams::Enum, std::string>()) ZINC_EXPORT;

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_PRODUCTION_PRODUCTIONIMAGEDOWNLOADER_H_
