/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "ProductionImageDownloader.h"

#include <nickelonscreenid-system-api/ResourceFailureException.h>

#include <zinc-common/async/async-helpers.h>

#include <boost/bind.hpp>
#include <boost/filesystem/convenience.hpp>
#include <boost/filesystem/operations.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/make_shared.hpp>

#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <map>
#include <stdexcept>
#include <vector>

namespace Zinc {
namespace OnScreenId {

namespace {

namespace fs = boost::filesystem;

std::vector<char> createBuffer(const fs::path& p)
{
    const std::string s = p.string();

    std::vector<char> v(s.begin(), s.end());
    v.push_back('\0');

    return v;
}

class ProductionImageDownloader : public ImageDownloader
{
public:
    ProductionImageDownloader(
        const boost::shared_ptr<NS_ZINC::HttpDownloader>& downloader,
        const std::map<ProductionImageDownloaderParams::Enum,
                       std::string>& kwargs);

    virtual ~ProductionImageDownloader();

    virtual void download(uint8_t ref, const std::string& url);

    virtual std::string getPath(uint8_t ref);

    virtual void dispose();

private:
    typedef std::map<uint8_t, NS_ZINC::Future<fs::path> > jobs_t;

    struct CancelJob
    {
        void operator()(jobs_t::value_type& job) const
        {
            job.second.cancel();
        }
    };

    static fs::path createDownloadDir(const fs::path& tmpDirRoot);

    static fs::path getDownloadDirRoot(
        const std::map<ProductionImageDownloaderParams::Enum,
                       std::string>& kwargs);

    static NS_ZINC::DownloadOptions getDownloadOptions(
        const std::map<ProductionImageDownloaderParams::Enum,
                       std::string>& kwargs);

    static std::map<std::string, std::string> getDownloadHeaders(
        const std::map<ProductionImageDownloaderParams::Enum,
                       std::string>& kwargs);

    static fs::path storeImage(const NS_ZINC::HttpResponse& resp,
                               const fs::path& path);

    const fs::path dir;

    const NS_ZINC::DownloadOptions options;
    const std::map<std::string, std::string> headers;
    const boost::shared_ptr<NS_ZINC::HttpDownloader> downloader;

    jobs_t jobs;
};

ProductionImageDownloader::ProductionImageDownloader(
    const boost::shared_ptr<NS_ZINC::HttpDownloader>& downloader,
    const std::map<ProductionImageDownloaderParams::Enum, std::string>& kwargs)
    : dir(createDownloadDir(getDownloadDirRoot(kwargs))),
      options(getDownloadOptions(kwargs)),
      headers(getDownloadHeaders(kwargs)),
      downloader(downloader)
{
}

ProductionImageDownloader::~ProductionImageDownloader()
{
    dispose();
    fs::remove(dir);
}

void ProductionImageDownloader::download(const uint8_t ref,
                                         const std::string& url)
{
    if (0 != jobs.count(ref))
    {
        throw std::invalid_argument("Download job exists");
    }

    const fs::path path =
        dir /
        (boost::lexical_cast<std::string>(static_cast<uint32_t>(ref)) + ".png");

    jobs[ref] =
        NS_ZINC::transformFuture(downloader->download(url, options, headers),
                                 boost::bind(storeImage, _1, path));
}

std::string ProductionImageDownloader::getPath(const uint8_t ref)
{
    try
    {
        return jobs.at(ref).get().string();
    }
    catch (const NS_ZINC::DownloaderException& e)
    {
        throw ResourceFailureException(e.what());
    }
}

void ProductionImageDownloader::dispose()
{
    std::for_each(jobs.begin(), jobs.end(), CancelJob());
    std::for_each(fs::directory_iterator(dir), fs::directory_iterator(),
                  fs::remove<fs::directory_iterator::path_type>);

    jobs.clear();
}

fs::path ProductionImageDownloader::createDownloadDir(
    const fs::path& tmpDirRoot)
{
    std::vector<char> dirTemplate = createBuffer(tmpDirRoot / "osid-XXXXXX");
    const char* const dir = ::mkdtemp(dirTemplate.data());

    /*
     * `mkdtemp()` should return NULL if it fails but that's not the case in
     * old uClibc so need to check whether the directory has been actually
     * created.
     */
    if (!dir || !fs::is_directory(dir))
    {
        throw ResourceFailureException("Cannot create directory for"
                                       " downloading images");
    }

    return dir;
}

fs::path ProductionImageDownloader::getDownloadDirRoot(
    const std::map<ProductionImageDownloaderParams::Enum, std::string>& kwargs)
{
    const std::map<ProductionImageDownloaderParams::Enum,
                   std::string>::const_iterator it =
        kwargs.find(ProductionImageDownloaderParams::DOWNLOAD_DIR_ROOT);

    return it != kwargs.end() ? it->second : "/tmp";
}

NS_ZINC::DownloadOptions ProductionImageDownloader::getDownloadOptions(
        const std::map<ProductionImageDownloaderParams::Enum,
                       std::string>& kwargs)
{
    NS_ZINC::DownloadOptions options;

    const std::map<ProductionImageDownloaderParams::Enum,
                   std::string>::const_iterator it =
        kwargs.find(ProductionImageDownloaderParams::CA_BUNDLE);
    if (it != kwargs.end())
    {
        options.sslCABundle = it->second;
    }

    return options;
}

std::map<std::string, std::string>
ProductionImageDownloader::getDownloadHeaders(
        const std::map<ProductionImageDownloaderParams::Enum,
                       std::string>& kwargs)
{
    std::map<std::string, std::string> headers;

    const std::map<ProductionImageDownloaderParams::Enum,
                   std::string>::const_iterator it =
        kwargs.find(ProductionImageDownloaderParams::USER_AGENT);
    if (it != kwargs.end())
    {
        headers["User-Agent"] = it->second;
    }

    return headers;
}

fs::path ProductionImageDownloader::storeImage(
    const NS_ZINC::HttpResponse& resp,
    const fs::path& path)
{
    std::ofstream out(path.string().c_str(), std::ios::binary);
    if (!out.is_open())
    {
        throw ResourceFailureException("Cannot open file for writing: " +
                                       path.string());
    }

    out.write(
        reinterpret_cast<const std::ofstream::char_type*>(
            resp.getBody().data()),
        resp.getBody().size());

    return path;
}

} // namespace

boost::shared_ptr<ImageDownloader> createProductionImageDownloader(
    const boost::shared_ptr<NS_ZINC::HttpDownloader>& downloader,
    const std::map<ProductionImageDownloaderParams::Enum, std::string>& kwargs)
{
    return boost::make_shared<ProductionImageDownloader>(downloader, kwargs);
}

} // namespace OnScreenId
} // namespace Zinc
