/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_PRODUCTIONRENDERENGINE_H_
#define NICKEL_ONSCREENID_PRODUCTIONRENDERENGINE_H_

#include <nickelonscreenid-system-api/RenderEngine.h>

#include <boost/shared_ptr.hpp>

#include <string>

namespace Zinc {
namespace OnScreenId {

void initialiseProductionRenderEngine();

boost::shared_ptr<RenderEngine> createProductionRenderEngine(
    unsigned long appId,
    const std::string& fontPath);

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_PRODUCTIONRENDERENGINE_H_
