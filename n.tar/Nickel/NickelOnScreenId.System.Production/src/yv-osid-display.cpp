/*
 * Author: Krzysztof Konopko <kris@youview.com>
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "ProductionRenderEngine.h"

#include <nickelonscreenid-system-api/Factory.h>
#include <nickelonscreenid-system-api/osid-misc.h>
#include <nickelonscreenid-system-api/ResourceFailureException.h>

#include <zinc-common/FixedPluginConfig.h>
#include <zinc-common/PluginFactory.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <boost/filesystem/path.hpp>
#include <boost/program_options.hpp>

#include <signal.h>

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

namespace po = boost::program_options;

namespace {

bool isHelpRequested(const std::string& arg)
{
    return arg == "-h" || arg == "-help" || arg == "--help";
}

po::options_description getProgramOptions()
{
    po::options_description options;
    options.add_options()
        ("help", "Print this message")

        ("text,t", po::value<std::string>(),
         "The text to display")
        ("image,i", po::value<std::string>(),
         "The image to display")

        ("font-size,s", po::value<uint32_t>()->default_value(20),
         "Font size")
        ("fg-colour,c", po::value<std::string>()->default_value("FF909090"),
         "Foreground colour(<AARRGGBB> hex) of the displayed text")
        ("bg-colour,b", po::value<std::string>()->default_value("00000000"),
         "Background colour(<AARRGGBB> hex) of the displayed text")
        ;

    return options;
}

po::options_description getAdditionalOptions()
{
    po::options_description options("options");
    options.add_options()
        ("pos-x,x", po::value<uint32_t>()->default_value(0),
         "X position of the window")
        ("pos-y,y", po::value<uint32_t>()->default_value(0),
         "Y position of the window")
        ("width,w", po::value<uint32_t>()->default_value(100),
         "Window width")
        ("height,h", po::value<uint32_t>()->default_value(100),
         "Window height")
        ("quit,q", po::value<int32_t>()->default_value(-1),
         "How to quit the application")

        // gets consumed by DFB but let's have it here for consistent presentation
        ("dfb:<options>",
         "Colon-separated list of DirectFB options")
        ;

    return options;
}

po::variables_map parseArgs(int argc, char* argv[])
{
    po::options_description cmdOptions =
        getProgramOptions().add(getAdditionalOptions());

    po::variables_map params;
    po::store(po::parse_command_line(argc, argv, cmdOptions), params);
    po::notify(params);

    return params;
}

void usage(const char *const argv0, std::ostream& out)
{
    const boost::filesystem::path execPath(argv0);
    const std::string exec = execPath.leaf();

    out
        << "Usage:\n"
        << "  " << exec << " --help\n"
        << "  " << exec << " -t <text to display>"
                           " [-s <font size>] [-c <FG font colour>]"
                           " [-b <BG font colour>] [options]\n"
        << "  " << exec << " -i <PNG image> [options]\n"
        << '\n'
        <<
           "Display text with the specified font or an image in a specified\n"
           "window and quit according to `--quit` option.\n\n"
        << getProgramOptions() << '\n'
        << getAdditionalOptions()
        << '\n'
        << "where:\n"
           "  quit : <arg>  < 0 quits on any of SIGHUP, SIGINT, SIGQUIT\n"
           "                    or SIGTERM signals\n"
           "         <arg> == 0 quits on Enter\n"
           "         <arg>  > 0 quits after <arg> seconds.\n"
        << "\n\n";

    out
        << "Examples:\n"
        << "  " << exec << " --dfb:no-quiet -t 'let us go!' -s 25 -c ffff00ff\n"
        << "  " << exec
        << " --text \"Test\" --width 240 --height 280\n"
        << "  " << exec << " --image logo_youview.png --quit 30\n"
        ;
}

void handleQuit(const po::variable_value& quit)
{
    const int32_t arg = quit.as<int32_t>();

    if (arg > 0)
    { // delay
        std::cout << "The application terminates in " << arg << " seconds..."
                  << std::endl;
        sleep(arg);
    }
    else if (arg == 0)
    { // press Enter
        std::cout << "\n[Press Enter to finish]";
        std::cin.ignore();
    }
    else
    { // signals
        ::sigset_t mask;
        if (0 != ::sigfillset(&mask))
        {
            std::perror("Intialising signal mask failed");
            return;
        }

        if (0 != ::sigprocmask(SIG_BLOCK, &mask, NULL))
        {
            std::perror("Blocking all signals failed");
            return;
        }

        if (0 != ::sigemptyset(&mask))
        {
            std::perror("Emptying signal mask failed");
            return;
        }

        if (0 != ::sigaddset(&mask, SIGHUP) ||
            0 != ::sigaddset(&mask, SIGINT) ||
            0 != ::sigaddset(&mask, SIGQUIT) ||
            0 != ::sigaddset(&mask, SIGTERM))
        {
            std::perror("Creating signal mask failed");
            return;
        }

        std::cout << "Waiting for signal(s)..." << std::endl;
        int sig;
        if (0 != ::sigwait(&mask, &sig))
        {
            std::perror("Signal wait failed");
            return;
        }

        std::cout << "Received signal " << sig << ".  Terminating..."
                  << std::endl;
    }
}

po::variables_map initialise(int argc, char* argv[])
{
    // make DirectFB quiet by default
    if (0 != ::setenv("DFBARGS", "quiet", 1))
    {
        throw std::runtime_error("setenv() failed");
    }

    return parseArgs(argc, argv);
}

} // namespace

int main(int argc, char* argv[])
{
    using namespace Zinc::OnScreenId;

    try
    {
        if (argc < 2)
        {
            usage(argv[0], std::cerr);
            return EXIT_FAILURE;
        }
        else if (isHelpRequested(argv[1]))
        {
            usage(argv[0], std::cout);
            return EXIT_SUCCESS;
        }

        const po::variables_map params = initialise(argc, argv);

        const bool hasText = 0 != params.count("text");
        const bool hasImage = 0 != params.count("image");

        if (!(hasText ^ hasImage))
        {
            std::cerr << "Error: Either --text or --image "
                         "must be specified\n\n";
            usage(argv[0], std::cerr);
            return EXIT_FAILURE;
        }

        // get all parameters here (even if not relevant) to perform early
        // validation

        const std::pair<uint32_t, uint32_t> pos =
            std::make_pair(params["pos-x"].as<uint32_t>(),
                           params["pos-y"].as<uint32_t>());

        const std::pair<uint32_t, uint32_t> bbox =
            std::make_pair(params["width"].as<uint32_t>(),
                           params["height"].as<uint32_t>());

        const uint32_t fontSize = params["font-size"].as<uint32_t>();

        const std::pair<uint32_t, uint32_t> fontColours =
            std::make_pair(hexToUint32(params["fg-colour"].as<std::string>()),
                           hexToUint32(params["bg-colour"].as<std::string>()));

        const NS_ZINC::FixedPluginConfig pluginConfig(
            "libNickelOnScreenIdSystemProduction.so",
            "createProductionFactory");
        const Factory& f =
            NS_ZINC::PluginFactory::getInstance<Factory>(pluginConfig);

        const boost::shared_ptr<RenderEngine> engine = f.createRenderEngine();

        std::clog << "INFO: Positioning surface at "
                  << pos.first << ":" << pos.second << std::endl;

        const uint8_t ref = 0;
        if (hasImage)
        {
            engine->prerenderImage(ref, pos, bbox,
                                   params["image"].as<std::string>());
        }
        else
        {
            engine->prerenderText(ref, pos, bbox, fontSize, fontColours,
                                  params["text"].as<std::string>());
        }

        engine->show(ref);

        handleQuit(params["quit"]);
        return EXIT_SUCCESS;
    }
    catch(const ResourceFailureException& e)
    {
        std::cerr << "Failed to prerender requested identifier\n";
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
    }
    catch(...)
    {
        std::cerr << "Unknown error\n";
    }

    return EXIT_FAILURE;
}
