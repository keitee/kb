/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "ProductionRenderEngine.h"

#include <nickel-common/NickelLogger.h>
#include <nickelonscreenid-system-api/ResourceFailureException.h>

/*
 * This is to avoid issues with `dynamic_cast` which this library is not
 * prepared to deal with when changing the default visibility.
 *
 * See http://gcc.gnu.org/wiki/Visibility for more details.
 */
#pragma GCC visibility push(default)
#include <++dfb.h>
#pragma GCC visibility pop

#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/make_shared.hpp>
#include <boost/optional.hpp>
#include <boost/scoped_ptr.hpp>

#include <cmath>
#include <map>
#include <stdexcept>
#include <sstream>
#include <string>

namespace Zinc {
namespace OnScreenId {

namespace {

inline int toFract(const int pixelSize)
{
    // fractional sizes are 26.6 fixed point integers, the unit is 1/64 pixel
    const int FRACT_FACTOR = 64;

    return pixelSize * FRACT_FACTOR;
}

inline u8 getByte(const uint32_t value, const uint32_t byte)
{
    return(value >> (byte << 3)) & 0xFFU;
}

DFBColor argbToColour(const uint32_t argb)
{
    DFBColor c;
    c.a = getByte(argb, 3);
    c.r = getByte(argb, 2);
    c.g = getByte(argb, 1);
    c.b = getByte(argb, 0);

    return c;
}

/*
 * Create a proportional font given only the font size.
 */
IDirectFBFont createFont(
    const IDirectFB& dfb, const std::string& path, const int fontSize)
{
    DFBFontDescription desc;
    desc.flags = DFBFontDescriptionFlags(DFDESC_HEIGHT);
    desc.height = fontSize;

    return dfb.CreateFont(path.c_str(), desc);
}

/*
 * Create font with width and height explicitly specified in fractional units.
 */
IDirectFBFont createFont(
    const IDirectFB& dfb, const std::string& path,
    const int fractW, const int fractH)
{
    DFBFontDescription desc;
    desc.flags =
        DFBFontDescriptionFlags(DFDESC_FRACT_WIDTH | DFDESC_FRACT_HEIGHT);
    desc.fract_width = fractW;
    desc.fract_height = fractH;

    return dfb.CreateFont(path.c_str(), desc);
}

/*
 * Get the real width of the area occupied by drawing a text with a given font.
 */
int getTextWidth(const IDirectFBFont& font, const std::string& text)
{
    DFBRectangle rectReal;
    font.GetStringExtents(text.data(), text.size(), NULL, &rectReal);

    return rectReal.w;
}

/*
 * Create(load) a font so it can be used to draw a text that will fit into the
 * bounding box of size `w` (width) by `h` (height).
 */
IDirectFBFont createMatchingFont(
     const IDirectFB& dfb,
     const std::string& fontPath, const int fontSize,
     const int w, const int h,
     const std::string& text)
{
    const IDirectFBFont font = createFont(dfb, fontPath, fontSize);

    const int wNatural = getTextWidth(font, text);

    if (w >= wNatural && h >= fontSize)
    {
        // OK, the text using the natural font will fit into the bounding box
        return font;
    }
    else
    {
        // need to squeeze the font

        int fractW = toFract(fontSize);
        int fractH = toFract(std::min(fontSize, h));

        if (h < fontSize)
        {
            // font height is squeezed already
            NICKEL_INFO("Adjusting font height to " << h
                        << " to fit into the bounding box");
        }

        if (w < wNatural)
        {
            /**
             * We truncate the result to int as it's better to err on the small
             * side so it doesn't sum up to a text a bit wider than the
             * requested bounding box.  To preserve a better accuracy, we use
             * fractional units.
             */

            const double wAdj = double(w) / double(wNatural);
            NICKEL_INFO("Adjusting text width by " << wAdj
                        << " to fit into the bounding box");

            fractW = static_cast<uint32_t>(fractW * wAdj);
        }

        return createFont(dfb, fontPath, fractW, fractH);
    }
}

/*
 * If the requested bounding box's area is bigger than allowed, scale
 * the dimensions accordingly to not exceed the maximum allowed area but
 * but preserve the proportions.
 */
std::pair<uint32_t, uint32_t> getNormalisedBoundingBox(
    uint32_t w, uint32_t h)
{
    /**
     * See YouView "IP Channels" (0018-S), Annex F.4
     */
    const uint32_t MAX_BBOX_AREA = 200 * 200;

    const uint32_t requestedBboxArea = w * h;
    if (requestedBboxArea > MAX_BBOX_AREA)
    {
        const double adj =
            std::sqrt(double(MAX_BBOX_AREA) / requestedBboxArea);

        w = static_cast<uint32_t>(w * adj);
        h = static_cast<uint32_t>(h * adj);

        NICKEL_INFO("Adjusted bounding box to " << w << " x " << h);
    }

    return std::make_pair(w, h);
}

void drawText(
    IDirectFBSurface& srfc,
    const IDirectFBFont& font, const uint32_t posYTop,
    const DFBColor& fg, const DFBColor& bg,
    const std::string& text)
{
    DFBRectangle rectLogical, rectReal;
    font.GetStringExtents(text.data(), text.size(), &rectLogical, &rectReal);

    srfc.SetRenderOptions(DSRO_ANTIALIAS);
    srfc.Clear(bg.r, bg.g, bg.b, bg.a);
    srfc.SetFont(font);
    srfc.SetColor(fg.r, fg.g, fg.b, fg.a);

    /*
     * There is a vertical and horizontal position adjustment here.  The reason
     * is that text rendering engine uses font oriented concepts like baseline,
     * leading etc.  This makes laying out the text a bit less "predictable" in
     * a given bounding box.  Fortunately `IDirectFBFont::GetStringExtents()`
     * provides relevant information about laying out the actual text so we can
     * position it precisely in the box according to the on-screen ID
     * requirements.
     *
     * Particularly, we want to eliminate the effect of text "drift" to the
     * right side and pull it to the left edge.  Similarly for the vertical
     * position but in this case it has to be center-aligned so the "virtual"
     * top position is provided as `pos_y_top` argument which corresponds to the
     * top of a center-aligned text.
     */
    srfc.DrawString(
        text.data(), text.size(),
        rectLogical.x - rectReal.x, posYTop + rectLogical.y - rectReal.y,
        DSTF_TOPLEFT);
}

/*
 * Set up a surface we can draw on.
 */
IDirectFBSurface setupTargetSurface(IDirectFBWindow& window)
{
    IDirectFBSurface srfc = window.GetSurface();

    srfc.SetPorterDuff(DSPD_SRC_OVER);
    srfc.SetBlittingFlags(DSBLIT_BLEND_ALPHACHANNEL);

    srfc.Clear();
    srfc.Flip();
    srfc.Clear();

    return srfc;
}

IDirectFBWindow createWindow(IDirectFB& dfb,
                             int x, int y,
                             int w, int h,
                             unsigned long id)
{
    DFBWindowDescription desc;
    desc.flags =
        DFBWindowDescriptionFlags(DWDESC_POSX | DWDESC_POSY | DWDESC_WIDTH |
                                  DWDESC_HEIGHT | DWDESC_CAPS | DWDESC_OPTIONS |
                                  DWDESC_PIXELFORMAT | DWDESC_SURFACE_CAPS);
    desc.posx = x;
    desc.posy = y;
    desc.width = w;
    desc.height = h;
    desc.caps = DFBWindowCapabilities(DWCAPS_ALPHACHANNEL|
                                      DWCAPS_DOUBLEBUFFER);
    desc.options = DWOP_ALPHACHANNEL;
    desc.pixelformat = DSPF_ARGB;
    desc.surface_caps = DSCAPS_PREMULTIPLIED;

    IDirectFBWindow window =
        dfb.GetDisplayLayer(DLID_PRIMARY).CreateWindow(desc);
    IDirectFBSurface windowSurface = window.GetSurface();	
    windowSurface.Clear(0,0,0,0xFF); 
    windowSurface.Flip(NULL, DSFLIP_NONE);

    window.SetOpacity(0xFF);
    window.SetApplicationID(id);

    return window;
}

ResourceFailureException asResourceFailureException(DFBException* const e)
{
    /* TODO: Find out why ++DFB decided to throw exceptions by pointers
     *       and overload the stream operator using a pointer.  Propose
     *       a better solution (throwing by value and catching by ref).
     */

    const boost::scoped_ptr<DFBException> pe(e);

    std::ostringstream ostr;
    ostr << "DirectFB failed: " << e;

    return ResourceFailureException(ostr.str());
}

class ProductionRenderEngine : public RenderEngine
{
public:
    ProductionRenderEngine(unsigned long appId,
                           const std::string& fontPath);

    virtual void prerenderImage(uint8_t ref,
                                const position_t& pos,
                                const box_t& box,
                                const std::string& path);

    virtual void prerenderText(uint8_t ref,
                               const position_t& pos,
                               const box_t& box,
                               uint8_t fontSize,
                               const colours_t& fontColours,
                               const std::string& text);

    virtual void show(uint8_t ref);

    virtual void show(uint8_t ref,
                      const position_t& position);

    virtual void hide(uint8_t ref);

    virtual void dispose();

private:

    struct Identifier
    {
        Identifier(const position_t& pos,
                   const box_t& box,
                   IDirectFB& dfb,
                   unsigned long appId);

        IDirectFBWindow window;
        IDirectFBSurface surface;

        bool visible;
    };

    typedef boost::function<void(IDirectFBSurface&,
                                 const box_t&)> prerender_fn_t;

    void doPrerender(uint8_t ref,
                     const position_t& pos,
                     const box_t& box,
                     const prerender_fn_t& prerender);

    void doPrerenderImage(IDirectFBSurface& srfc,
                          const box_t& box,
                          const std::string& path);

    void doPrerenderText(IDirectFBSurface& srfc,
                         const box_t& box,
                         uint8_t fontSize,
                         const colours_t& fontColours,
                         const std::string& text);

    void doSetVisibility(uint8_t ref,
                         bool visible,
                         const boost::optional<position_t>& pos =
                             boost::optional<position_t>());

    const unsigned long appId;
    const std::string fontPath;

    IDirectFB dfb;
    std::map<uint8_t, Identifier> ids;
};

ProductionRenderEngine::ProductionRenderEngine(const unsigned long appId,
                                               const std::string& fontPath)
try : appId(appId), fontPath(fontPath), dfb(DirectFB::Create())
{
    dfb.SetCooperativeLevel(DFSCL_NORMAL);
}
catch (DFBException* const e)
{
    throw asResourceFailureException(e);
}

void ProductionRenderEngine::prerenderImage(const uint8_t ref,
                                            const position_t& pos,
                                            const box_t& box,
                                            const std::string& path)
{
    doPrerender(ref, pos, box,
                boost::bind(&ProductionRenderEngine::doPrerenderImage,
                            this, _1, _2, path));
}

void ProductionRenderEngine::prerenderText(const uint8_t ref,
                                           const position_t& pos,
                                           const box_t& box,
                                           const uint8_t fontSize,
                                           const colours_t& fontColours,
                                           const std::string& text)
{
    doPrerender(ref, pos, box,
                boost::bind(&ProductionRenderEngine::doPrerenderText,
                            this, _1, _2, fontSize, fontColours, text));
}

void ProductionRenderEngine::show(const uint8_t ref)
{
    doSetVisibility(ref, true);
}

void ProductionRenderEngine::show(const uint8_t ref, const position_t& pos)
{
    doSetVisibility(ref, true, pos);
}

void ProductionRenderEngine::hide(const uint8_t ref)
{
    doSetVisibility(ref, false);
}

void ProductionRenderEngine::dispose()
{
    try
    {
        ids.clear();
    }
    catch (DFBException* const e)
    {
        throw asResourceFailureException(e);
    }
}

ProductionRenderEngine::Identifier::Identifier(const position_t& pos,
                                               const box_t& box,
                                               IDirectFB& dfb,
                                               const unsigned long appId) :
    window(createWindow(dfb,
                        pos.first, pos.second,
                        box.first, box.second,
                        appId)),
    surface(setupTargetSurface(window)),
    visible(false)
{
}

void ProductionRenderEngine::doPrerender(const uint8_t ref,
                                         const position_t& pos,
                                         const box_t& boxRequested,
                                         const prerender_fn_t& prerender)
{
    if (0 != ids.count(ref))
    {
        throw std::invalid_argument("Duplicated reference");
    }

    try
    {
        const box_t box =
            getNormalisedBoundingBox(boxRequested.first, boxRequested.second);

        Identifier id(pos, box, dfb, appId);

        prerender(id.surface, box);

        ids.insert(std::make_pair(ref, id));
    }
    catch (DFBException* const e)
    {
        throw asResourceFailureException(e);
    }
}


void ProductionRenderEngine::doPrerenderImage(IDirectFBSurface& srfc,
                                              const box_t& /*box*/,
                                              const std::string& path)
{
    IDirectFBImageProvider provider = dfb.CreateImageProvider(path.c_str());
    provider.RenderTo(srfc, NULL);
}

void ProductionRenderEngine::doPrerenderText(IDirectFBSurface& srfc,
                                             const box_t& box,
                                             const uint8_t fontSize,
                                             const colours_t& fontColours,
                                             const std::string& text)
{
    const IDirectFBFont font = createMatchingFont(dfb,
                                                  fontPath, fontSize,
                                                  box.first, box.second,
                                                  text);

    const uint32_t posYTop =
        (box.second - std::min<uint16_t>(fontSize, box.second)) / 2;

    const DFBColor fg = argbToColour(fontColours.first);
    const DFBColor bg = argbToColour(fontColours.second);

    drawText(srfc, font, posYTop, fg, bg, text);
}

void ProductionRenderEngine::doSetVisibility(
    const uint8_t ref,
    const bool visible,
    const boost::optional<position_t>& pos)
{
    Identifier& id = ids.at(ref);

    if (visible != id.visible)
    {
        try
        {
            if (pos)
            {
                id.window.MoveTo(pos->first, pos->second);
            }

            id.surface.Flip();
        }
        catch (DFBException* const e)
        {
            throw asResourceFailureException(e);
        }

        id.visible = visible;
    }
    else
    {
        NICKEL_WARN("Trying to show already "
                    << (visible ? "visible" : "invisible") << " identifier "
                    << static_cast<uint32_t>(ref));
    }

}

} // namespace

void initialiseProductionRenderEngine()
{
    try
    {
        DirectFB::Init(NULL, NULL);
    }
    catch (DFBException* const e)
    {
        throw asResourceFailureException(e);
    }
}

boost::shared_ptr<RenderEngine> createProductionRenderEngine(
    unsigned long appId,
    const std::string& fontPath)
{
    return boost::make_shared<ProductionRenderEngine>(appId, fontPath);
}

} // namespace OnScreenId
} // namespace Zinc
