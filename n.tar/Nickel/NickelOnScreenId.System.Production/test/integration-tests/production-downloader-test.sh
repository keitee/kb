#!/bin/bash

##
# An integration test for the production downloader.  Its aim is to prove that
# the downloader created by the production factory (through plugin-config
# mechanism) can be used to download a file.
#
# The purpose is *not* to test the functionality of the downloader exhaustively,
# but rather check whether there are no missing run-time dependencies (e.g.
# unresolved symbols, multiple VTBL instances when using RTTI etc.).
#
# The test loads a library that initialises DirectFB so it has to be run on
# the device.
#
# Author: kris@youview.com
#
# Copyright 2013 YouView TV Ltd.

# Exit immediately if any unexpected error occurs
set -e

function kill_and_wait() {
    local kill_list="$@"

    kill $kill_list &>/dev/null
    wait $kill_list &>/dev/null || true
}

function cleanup() {
    trap - ERR

    [ -n "${tmpdir:-}" ] && rm -rf $tmpdir
    kill_and_wait $DBUS_SESSION_BUS_PID $LAUNCHED_PID $lsr_pid
}

source $(dirname $BASH_SOURCE[0])/../share/config.sh

lsr_config=$final_prefix/tests/nickelonscreenid-system-production/share/copper-system-fake.plugin-config

tmpdir=$(mktemp -d)

trap cleanup ERR

logfile=$tmpdir/log

mongoose_dir=$tmpdir/files
mongoose_log=$tmpdir/mongoose.log

test_file=$mongoose_dir/test.png
result_file=$tmpdir/result.png

mkdir $mongoose_dir
dd if=/dev/urandom of=$test_file bs=4k count=2 >> $logfile 2>&1

export $(dbus-launch)

copperlocalstoragerepod $lsr_config -N >> $logfile 2>&1 &
lsr_pid=$!
dbuswaitbusname --timeout 5 Zinc.System >> $logfile 2>&1

eval $($final_prefix/oss/devel/bin/sd-launch \
    mongoose -a $mongoose_log -r $mongoose_dir -p 0)

echo -n "Running download test ... "

set +e
$final_prefix/devel/bin/yv-osid-download \
    http://127.0.0.1:$LAUNCHED_PORT/$(basename $test_file) \
    $result_file >> $logfile 2>&1 \
&& \
$final_prefix/oss/bin/busybox diff $test_file $result_file >> $logfile 2>&1

status=$?

kill_and_wait $DBUS_SESSION_BUS_PID $LAUNCHED_PID $lsr_pid

if [ $status -eq 0 ] && grep -q "YouView" $mongoose_log; then
    echo "OK"
else
    echo "FAIL"
    cat $logfile
    echo
    cat $mongoose_log
    echo
fi

cleanup
exit $status
