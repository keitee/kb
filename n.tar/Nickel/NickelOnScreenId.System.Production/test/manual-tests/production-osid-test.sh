#!/bin/bash

##
# A manual test for the production OSID service.  Its aim is to prove that
# all components work together on the device.  Requires verifying results
# visually.
#
# Author: kris@youview.com
#
# Copyright 2013 YouView TV Ltd.

# Exit immediately if any unexpected error occurs
set -e

function ask() {
    local question="${1:-Continue}"
    local response="y"

    read -r -p "${question}? [Y/n]: " response
    [[ $response =~ ^[Yy]?$ ]]
}

function kill_and_wait() {
    local pid="$@"

    kill $pid
    wait $pid 2>/dev/null || true
}

function kill_all_instances() {
    local proc_name=$1

    echo -n "Shutting down all $proc_name instances "
    while killall $proc_name &>/dev/null; do
        echo -n "."
        sleep 1
    done
    echo
    echo "done"
}

function cleanup() {
    [ -n "${tmpdir:-}" ] && rm -rf $tmpdir
    [ -n "${LAUNCHED_PID:-}" ] && kill_and_wait $LAUNCHED_PID
    [ -n "${dir_to_unmount:-}" ] && umount $dir_to_unmount

    trap - ERR
}

package_test_dir=$(dirname $BASH_SOURCE[0])/..
source $package_test_dir/share/config.sh

umask 0022

osid_plugin_config=$final_prefix/share/nickelonscreenid-system-dbusserver/nickelonscreenid-system-factory.plugin-config

if ! head -1 $osid_plugin_config | grep -q "Production"; then
    echo "Production implementation not enabled in $osid_plugin_config.  Exiting..."
    exit 1
fi

echo -n "Creating test directory ... "
tmpdir=$(mktemp -d -t)
echo $tmpdir

trap cleanup ERR

logfile=$tmpdir/log

mongoose_dir=$tmpdir/files
mongoose_log=$tmpdir/mongoose.log

mongoose_cert_dir=$tmpdir/server-cert
mongoose_cert=$mongoose_cert_dir/ca-bundle.crt

test_png=$mongoose_dir/youview.png
test_text=$(lsr-config "oem.device.duid" || echo "UID test")

mkdir $mongoose_dir $mongoose_cert_dir

echo "Copying sample PNG image file ..."
cp $package_test_dir/share/youview.png $test_png

echo "Generating server certificate ..."
$final_prefix/tests/bin/gen-server-cert.sh 127.0.0.1 $mongoose_cert

echo "Replacing TLS bundle ..."
dir_to_mount="/opt/youview/pki/tls"
mount $mongoose_cert_dir $dir_to_mount
dir_to_unmount=$dir_to_mount

kill_all_instances onscreenidd

# TODO: starting HTTPS mongoose this way is not supported yet
#eval $($final_prefix/oss/devel/bin/sd-launch \
#    mongoose -a $mongoose_log -r $mongoose_dir -p 0)

kill_all_instances mongoose

echo "Starting HTTPS server ..."
LAUNCHED_PORT=443
mongoose -s $mongoose_cert -a $mongoose_log -r $mongoose_dir \
    -p "${LAUNCHED_PORT}s" &> $logfile &
LAUNCHED_PID=$!

test_url="https://127.0.0.1:$LAUNCHED_PORT/$(basename $test_png)"

sas0_static_img=$tmpdir/sas.0
sas1_dynamic_text=$tmpdir/sas.1

echo "Generating sample SAS extensions ..."
yv-sas-extension-gen --binary \
    --static --reference 0 --url "$test_url" \
    --pos-x 1100 --pos-y 600 \
    > $sas0_static_img

yv-sas-extension-gen --binary \
    --reference 1 --text "$test_text" \
    --pos-x 1000 --pos-y 20 \
    --width 250 --height 20 \
    --font-size 20 \
    > $sas1_dynamic_text

start-service-over-dbus.sh Zinc.OnScreenId &> $logfile

function test_create_session() {
    echo "+ Create session"
    echo "  Nothing should be displayed yet"

    yv-osid-dbus session create $sas0_static_img $sas1_dynamic_text
}

function test_enable_session() {
    echo "+ Enable session"
    echo "  A graphics should appear in the bottom right corner"

    yv-osid-dbus enable
}

function test_show_dynamic_id() {
    echo "+ Show transient ID"
    echo "  A text should appear in the top right corner"

    yv-ecm-extension-gen --reference 1 --binary | yv-osid-dbus trigger
}

function test_show_dynamic_id_changed_position() {
    echo "+ Show transient ID at a different position"
    echo "  A text should appear in the top left corner"

    yv-ecm-extension-gen --reference 1 --pos-x 20 --pos-y 20 --binary | \
        yv-osid-dbus trigger
}

function test_hide_dynamic_id() {
    echo "+ Hide transient ID"
    echo "  The textual identifier should disappear"

    yv-osid-dbus trigger --empty
}

function test_disable_session() {
    echo "+ Disable session"
    echo "  All identifiers should disappear"

    yv-osid-dbus disable
}

function test_destroy_session() {
    echo "+ Destroy session"
    echo "  All identifiers should disappear"

    yv-osid-dbus session destroy
}

function test_http_caching() {
    echo "+ Image caching"
    echo -n "  The image should be requested only once... "

    local requests=$(\
        grep "\"GET /$(basename $test_png) HTTP/1.1\" 200" $mongoose_log | \
        wc -l | cut -d' ' -f 1)

    [ "$requests" = "1" ] && echo "OK" || echo "FAILED"
}

test_sequence=(
    test_create_session
    test_enable_session
    test_show_dynamic_id
    test_hide_dynamic_id
    test_show_dynamic_id
    test_disable_session
    test_enable_session
    test_show_dynamic_id_changed_position
    test_destroy_session
    test_create_session
    test_enable_session
    test_destroy_session
    test_http_caching
)

echo
echo -n "Running the test sequence ... "
echo

set +e

for test in ${test_sequence[@]}; do
    $test
    ask || break
done

kill_all_instances onscreenidd

kill_and_wait $osid_pid $LAUNCHED_PID
unset LAUNCHED_PID

echo "Done."
echo

ask "Show log files (might be a little bit out of order)" && \
    cat $logfile $mongoose_log

cleanup
