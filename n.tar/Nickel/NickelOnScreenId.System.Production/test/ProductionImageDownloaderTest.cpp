/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "../src/ProductionImageDownloader.h"

#include <nickelonscreenid-system-api/nickelonscreenid-system-exceptions.h>
#include <nickelonscreenid-system-api/osid-misc.h>

#include <titanium-utils/ContextCrypto.h>

#include <zinc-common/async/InlineFutureDispatcher.h>
#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>

#include <zinc-testwebserver/zinc-testwebserver.h>

#include <boost/filesystem/convenience.hpp>
#include <boost/format.hpp>

#include <sys/stat.h>

#include <algorithm>
#include <cstdlib>
#include <sstream>
#include <string>
#include <vector>
#include <utility>

namespace {

using namespace ::Zinc::OnScreenId;

std::vector<uint8_t> s2v(const std::string& s)
{
    return std::vector<uint8_t>(s.begin(), s.end());
}

class ImageServer
{
public:
    // <sub-URL, body>
    typedef std::pair<std::string, std::string> image_t;

    ImageServer(const std::vector<image_t>& images,
                const std::string& cert = "");

    std::string getHostUrl(const std::string& hostname = "127.0.0.1") const;

    std::string getLastRequestHeader(const std::string& header) const;

private:
    class ImageCollector
    {
    public:
        ImageCollector(
            const NS_ZINC_TESTWEBSERVER::SimpleResponderPtr& responder);

        void operator()(const image_t& img) const;

    private:
        const NS_ZINC_TESTWEBSERVER::SimpleResponderPtr responder;
    };

    static
    NS_ZINC_TESTWEBSERVER::ManualServerConfigPtr createConfig(
        const std::string& cert);

    static
    NS_ZINC_TESTWEBSERVER::SimpleResponderPtr createResponder(
        const std::vector<image_t>& images);

    const NS_ZINC_TESTWEBSERVER::ManualServerConfigPtr config;
    const NS_ZINC_TESTWEBSERVER::SimpleResponderPtr responder;

    NS_ZINC_TESTWEBSERVER::HttpServer server;
    const NS_ZINC_TESTWEBSERVER::ServerRunner runner;
};

ImageServer::ImageServer(const std::vector<image_t>& images,
                         const std::string& cert) :
    config(createConfig(cert)), responder(createResponder(images)),
    server(config, responder, responder), runner(server)
{
}

std::string ImageServer::getHostUrl(const std::string& hostname) const
{
    const std::string port = config->getPort();
    return 's' == *port.rbegin() ?
        "https://" + hostname + ':' + port.substr(0, port.length() - 1) :
        "http://" + hostname + ':' + port;
}

std::string ImageServer::getLastRequestHeader(const std::string& header) const
{
    return responder->getLastRequest()->getHeader(header);
}

NS_ZINC_TESTWEBSERVER::ManualServerConfigPtr ImageServer::createConfig(
    const std::string& cert)
{
    const NS_ZINC_TESTWEBSERVER::ManualServerConfigPtr config =
        NS_ZINC_TESTWEBSERVER::createManualServerConfig();

    if (!cert.empty())
    {
        config->setPort("s");
        config->setSSLCertificate(cert);
    }

    return config;
}

NS_ZINC_TESTWEBSERVER::SimpleResponderPtr ImageServer::createResponder(
    const std::vector<image_t>& images)
{
    const NS_ZINC_TESTWEBSERVER::SimpleResponderPtr responder =
        NS_ZINC_TESTWEBSERVER::createSimpleResponder();

    std::for_each(images.begin(), images.end(), ImageCollector(responder));

    return responder;
}

ImageServer::ImageCollector::ImageCollector(
    const NS_ZINC_TESTWEBSERVER::SimpleResponderPtr& responder)
    : responder(responder)
{
}

void ImageServer::ImageCollector::operator()(const image_t& img) const
{
    const NS_ZINC_TESTWEBSERVER::HttpResponsePtr r =
        NS_ZINC_TESTWEBSERVER::createHttpResponse();
    r->setVersion("HTTP/1.1");
    r->setStatus(NS_ZINC_TESTWEBSERVER::HttpStatus::OK);
    r->addHeader(NS_ZINC_TESTWEBSERVER::HttpHeaders::ContentType, "image/png");
    r->setBody(img.second);

    responder->addResponseForSubStringInUri(r, img.first);
}

class ProductionImageDownloaderTest :
    NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
public:
    ProductionImageDownloaderTest()
    {
        // safe use of OpenSSL from multiple threads
        NS_TITANIUM::initOnce_CryptoMultiThreading();
    }

    virtual void setUp()
    {
        disp = boost::make_shared<NS_ZINC::InlineFutureDispatcher>();
    }

    virtual void tearDown()
    {
        disp.reset();

        resetFilesystemSandbox();
    }

    void test_that_can_download_single_file()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);

        ImageServer srv(images);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader();

        const uint8_t ref = 0;

        downloader->download(ref, srv.getHostUrl() + images[ref].first);

        CPPUNIT_ASSERT(boost::filesystem::exists(downloader->getPath(ref)));
        CPPUNIT_ASSERT_EQUAL(s2v(images[ref].second),
                             readFilePayload(downloader->getPath(ref).c_str()));
    }

    void test_that_can_download_multiple_files()
    {
        const uint8_t numImages = 4;
        const std::vector<ImageServer::image_t> images = genImages(numImages);

        ImageServer srv(images);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader();

        for (uint8_t ref = 0; ref < numImages; ++ref)
        {
            downloader->download(ref, srv.getHostUrl() + images[ref].first);
        }

        for (uint8_t i = 0; i < numImages; ++i)
        {
            // let's try to refer to the images in the reverse order
            const uint8_t ref = numImages - i - 1;

            CPPUNIT_ASSERT_MESSAGE(
                images[ref].first,
                boost::filesystem::exists(downloader->getPath(ref)));
            CPPUNIT_ASSERT_EQUAL_MESSAGE(
                images[ref].first,
                s2v(images[ref].second),
                readFilePayload(downloader->getPath(ref).c_str()));
        }
    }

    void test_that_can_download_over_https()
    {
        const uint8_t numImages = 2;
        const std::vector<ImageServer::image_t> images = genImages(numImages);

        const std::string serverCert = genServerCert();
        const std::string& caBundle = serverCert; // it contains only one cert

        ImageServer srv(images, serverCert);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader("", "", caBundle);

        for (uint8_t ref = 0; ref < numImages; ++ref)
        {
            downloader->download(ref, srv.getHostUrl() + images[ref].first);
        }

        for (uint8_t ref = 0; ref < numImages; ++ref)
        {
            CPPUNIT_ASSERT_MESSAGE(
                images[ref].first,
                boost::filesystem::exists(downloader->getPath(ref)));
            CPPUNIT_ASSERT_EQUAL_MESSAGE(
                images[ref].first,
                s2v(images[ref].second),
                readFilePayload(downloader->getPath(ref).c_str()));
        }
    }

    void test_that_sets_user_agent()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);
        const std::string userAgent = "TestClient";

        ImageServer srv(images);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader("", userAgent);

        const uint8_t ref = 0;

        downloader->download(ref, srv.getHostUrl() + images[ref].first);

        CPPUNIT_ASSERT(boost::filesystem::exists(downloader->getPath(ref)));
        CPPUNIT_ASSERT_EQUAL(userAgent, srv.getLastRequestHeader("User-Agent"));
    }

    /**
     * This test actually proves that if *anything* goes wrong with TLS
     * handshake, it'll get detected.  There's no point in testing all possible
     * TLS failures as it's actually down to the Zinc.Downloader implementation.
     */
    void test_that_throws_due_to_bad_https_host()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);

        const std::string serverCert = genServerCert("bad.host.com", "srv.pem");
        const std::string caBundle = genServerCert("osid.isp.tv", "bundle.crt");

        ImageServer srv(images, serverCert);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader("", "", caBundle);

        const uint8_t ref = 0;

        downloader->download(ref, srv.getHostUrl() + images[ref].first);

        CPPUNIT_ASSERT_THROW(downloader->getPath(ref),
                             ResourceFailureException);
    }

    /**
     * Again, this is just a sample test for connectivity problems which should
     * actually be down to Zinc.Downloader implementation.
     */
    void test_that_throws_if_cant_connect()
    {
        const std::string urls[] = {
            "http://blah.blah.tld/bad.png?please=fail",
            "bad-protocol://eat.this!"
        };

        const uint8_t numUrls = sizeof urls / sizeof urls[0];

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader();

        for (uint8_t ref = 0; ref < numUrls; ++ref)
        {
            downloader->download(ref, urls[ref]);

            CPPUNIT_ASSERT_THROW_MESSAGE(urls[ref],
                                         downloader->getPath(ref),
                                         ResourceFailureException);
        }
    }

    void test_that_removes_images_on_dispose()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);
        const std::string tmpRootSubdir = "downloader-subdir";

        ImageServer srv(images);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader(tmpRootSubdir);

        const boost::filesystem::path imageDir =
            getDownloaderImageDir(tmpRootSubdir);

        const uint8_t ref = 0;
        downloader->download(ref, srv.getHostUrl() + images[ref].first);
        const boost::filesystem::path imagePath = downloader->getPath(ref);

        CPPUNIT_ASSERT(boost::filesystem::exists(imagePath));
        CPPUNIT_ASSERT(!boost::filesystem::is_empty(imageDir));
        CPPUNIT_ASSERT_EQUAL(imageDir, imagePath.parent_path());

        downloader->dispose();

        CPPUNIT_ASSERT(boost::filesystem::is_empty(imageDir));
    }

    void test_that_can_download_after_dispose()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);

        ImageServer srv(images);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader();

        const uint8_t ref = 0;

        downloader->download(ref, srv.getHostUrl() + images[ref].first);
        downloader->dispose();
        downloader->download(ref, srv.getHostUrl() + images[ref].first);

        CPPUNIT_ASSERT(boost::filesystem::exists(downloader->getPath(ref)));
        CPPUNIT_ASSERT_EQUAL(s2v(images[ref].second),
                             readFilePayload(downloader->getPath(ref).c_str()));
    }

    void test_that_removes_dir_when_destroyed()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);
        const std::string tmpRootSubdir = "downloader-subdir";

        ImageServer srv(images);

        boost::shared_ptr<ImageDownloader> downloader =
            createDownloader(tmpRootSubdir);

        const boost::filesystem::path imageDir =
            getDownloaderImageDir(tmpRootSubdir);

        const uint8_t ref = 0;
        downloader->download(ref, srv.getHostUrl() + images[ref].first);

        CPPUNIT_ASSERT(boost::filesystem::exists(downloader->getPath(ref)));

        downloader.reset();

        CPPUNIT_ASSERT(!boost::filesystem::exists(imageDir));
    }

    void test_that_throws_if_cannot_create_download_dir()
    {
        const boost::shared_ptr<NS_ZINC::HttpDownloader> hd =
            boost::make_shared<NS_ZINC::HttpDownloader>(disp, 1, 15 * 1000);

        std::map<ProductionImageDownloaderParams::Enum, std::string> kwargs;
        kwargs[ProductionImageDownloaderParams::DOWNLOAD_DIR_ROOT] =
            NS_ZINC::getMutableDataPath() + "/oh/yeah";

        CPPUNIT_ASSERT_THROW(createProductionImageDownloader(hd, kwargs),
                             ResourceFailureException);
    }

    void test_that_throws_if_cannot_store_image()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);
        const std::string tmpRootSubdir = "downloader-subdir";

        ImageServer srv(images);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader(tmpRootSubdir);

        const boost::filesystem::path imageDir =
            getDownloaderImageDir(tmpRootSubdir);

        const uint8_t ref = 0;

        // here's a naughty prank - create a dir in place of the intended file
        boost::filesystem::create_directory(
            imageDir /
            (boost::lexical_cast<std::string>(
                static_cast<uint32_t>(ref)) + ".png"));

        const std::string imageUrl = srv.getHostUrl() + images.front().first;

        // Potentially either of the two operations can throw in this naughty
        // scenario so need to capture them both as a combo.
        struct DownloadComboLambda // wink, wink
        {
            static void op(ImageDownloader& d,
                           const uint8_t ref, const std::string& url)
            {
                d.download(ref, url);
                d.getPath(ref);
            }
        };

        CPPUNIT_ASSERT_THROW(DownloadComboLambda::op(*downloader,
                                                     ref, imageUrl),
                             ResourceFailureException);
    }

    void test_that_throws_if_ref_duplicated()
    {
        const std::vector<ImageServer::image_t> images = genImages(1);

        ImageServer srv(images);

        const boost::shared_ptr<ImageDownloader> downloader =
            createDownloader();

        const uint8_t ref = 0;
        const std::string imageUrl = srv.getHostUrl() + images[ref].first;

        downloader->download(ref, imageUrl);
        CPPUNIT_ASSERT_THROW(downloader->download(ref, imageUrl),
                             std::invalid_argument);
        CPPUNIT_ASSERT_THROW(downloader->download(ref, imageUrl + "other.png"),
                             std::invalid_argument);

        CPPUNIT_ASSERT(boost::filesystem::exists(downloader->getPath(ref)));
    }

private:
    CPPUNIT_TEST_SUITE(ProductionImageDownloaderTest);
    CPPUNIT_TEST(test_that_can_download_single_file);
    CPPUNIT_TEST(test_that_can_download_multiple_files);
    CPPUNIT_TEST(test_that_can_download_over_https);
    CPPUNIT_TEST(test_that_sets_user_agent);
    CPPUNIT_TEST(test_that_throws_due_to_bad_https_host);
    CPPUNIT_TEST(test_that_throws_if_cant_connect);
    CPPUNIT_TEST(test_that_removes_images_on_dispose);
    CPPUNIT_TEST(test_that_can_download_after_dispose);
    CPPUNIT_TEST(test_that_removes_dir_when_destroyed);
    CPPUNIT_TEST(test_that_throws_if_cannot_create_download_dir);
    CPPUNIT_TEST(test_that_throws_if_cannot_store_image);
    CPPUNIT_TEST(test_that_throws_if_ref_duplicated);
    CPPUNIT_TEST_SUITE_END();

    static
    std::vector<ImageServer::image_t> genImages(uint8_t n);

    boost::shared_ptr<ImageDownloader> createDownloader(
        const std::string& tmpRootDir = "",
        const std::string& userAgent = "",
        const std::string& caBundle = "");

    std::string genServerCert(const std::string& host = "127.0.0.1",
                              const std::string& cert = "server.pem");

    boost::filesystem::path getDownloaderImageDir(
        const std::string& tmpRootSubdir);

    boost::shared_ptr<NS_ZINC::InlineFutureDispatcher> disp;
};

std::vector<ImageServer::image_t> ProductionImageDownloaderTest::genImages(
    const uint8_t n)
{
    std::vector<ImageServer::image_t> images;
    images.reserve(n);

    for (uint32_t i = 0; i < n; ++i)
    {
        images.push_back(std::make_pair(str(boost::format("/test%1%.png") % i),
                                        "whatever, some PNG stuff goes here"));
    }

    return images;
}

boost::shared_ptr<ImageDownloader>
ProductionImageDownloaderTest::createDownloader(
    const std::string& tmpRootDir,
    const std::string& userAgent,
    const std::string& caBundle)
{
    const boost::shared_ptr<NS_ZINC::HttpDownloader> hd =
        boost::make_shared<NS_ZINC::HttpDownloader>(disp, 1, 15 * 1000);

    std::map<ProductionImageDownloaderParams::Enum, std::string> kwargs;

    const std::string downloaderDir =
        NS_ZINC::getMutableDataPath() + tmpRootDir;
    kwargs[ProductionImageDownloaderParams::DOWNLOAD_DIR_ROOT] = downloaderDir;

    if (!boost::filesystem::exists(downloaderDir))
    {
        CPPUNIT_ASSERT(boost::filesystem::create_directories(downloaderDir));
    }

    if (!userAgent.empty())
    {
        kwargs[ProductionImageDownloaderParams::USER_AGENT] = userAgent;
    }

    if (!caBundle.empty())
    {
        kwargs[ProductionImageDownloaderParams::CA_BUNDLE] = caBundle;
    }

    return createProductionImageDownloader(hd, kwargs);
}

std::string ProductionImageDownloaderTest::genServerCert(
    const std::string& host, const std::string& cert)
{
    const std::string path = NS_ZINC::getMutableDataPath() + cert;

    std::ostringstream ostr;
    ostr << getBinFinder().find("gen-server-cert.sh")
         << ' ' << host << ' ' << path;

    const std::string cmd = ostr.str();

    const int status = std::system(cmd.c_str());
    CPPUNIT_ASSERT_MESSAGE(cmd, WIFEXITED(status));
    CPPUNIT_ASSERT_EQUAL_MESSAGE(cmd, EXIT_SUCCESS, WEXITSTATUS(status));

    return path;
}

boost::filesystem::path ProductionImageDownloaderTest::getDownloaderImageDir(
    const std::string& tmpRootSubdir)
{
    const std::string tmpRoot = NS_ZINC::getMutableDataPath() + tmpRootSubdir;
    CPPUNIT_ASSERT_MESSAGE(tmpRoot, !boost::filesystem::is_empty(tmpRoot));

    return *boost::filesystem::directory_iterator(tmpRoot);
}

CPPUNIT_TEST_SUITE_REGISTRATION(ProductionImageDownloaderTest);

} // namespace
