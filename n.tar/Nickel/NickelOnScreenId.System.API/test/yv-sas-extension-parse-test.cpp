/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "../src/SasExtension.h"

#include <boost/range.hpp>

#include <zinc-common/testsupport/CppUnit.h>

namespace {

using namespace ::Zinc::OnScreenId;

class YvSasExtensionParseTest : public CppUnit::TestFixture
{
public:
    void test_that_parses_all_elements()
    {
        /* This is sort of a low-level test where the payload is hardcoded
         * rather than generated to ensure that the generator part of the
         * SasExtension class doesn't "co-operate" with the parser part to
         * disguise some bugs.
         *
         * Might require updating if the format of the payload changes.
         */

        const char payloadData[] =
            "\x00\x00\x00\x21" // size
            "\x79\x76\x69\x64" // type("yvid")
            "\x01\x6f\x00\x01" // some flags
            "\x06\x68\x05\xc8" // width and height
            "\x01\x90\x01\x2c" // position
            "\x0c"             // font size
            "\x00\xab\x41\x30" // foreground colour
            "\x00\x00\x00\x00" // background colour
            "\x74\x65\x73\x74" // text("test")
            ;

        // need to get rid of the terminating NULL
        std::vector<uint8_t> payload(boost::begin(payloadData),
                                     boost::end(payloadData) - 1);

        SasExtension ext;
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::ok, ext.parse(payload));

        CPPUNIT_ASSERT_EQUAL(true, ext.critical());
        CPPUNIT_ASSERT_EQUAL(111u, static_cast<unsigned>(ext.reference()));
        CPPUNIT_ASSERT_EQUAL(SasExtensionType::text, ext.type());
        CPPUNIT_ASSERT_EQUAL(SasExtensionMode::ecm, ext.mode());
        CPPUNIT_ASSERT_EQUAL(static_cast<uint16_t>(1640), ext.size().first);
        CPPUNIT_ASSERT_EQUAL(static_cast<uint16_t>(1480), ext.size().second);
        CPPUNIT_ASSERT_EQUAL(static_cast<uint16_t>(400), ext.position().first);
        CPPUNIT_ASSERT_EQUAL(static_cast<uint16_t>(300), ext.position().second);
        CPPUNIT_ASSERT_EQUAL(12u, static_cast<unsigned>(ext.fontSize()));
        CPPUNIT_ASSERT_EQUAL(static_cast<uint32_t>(11223344),
                             ext.textColours().first);
        CPPUNIT_ASSERT_EQUAL(static_cast<uint32_t>(0),
                             ext.textColours().second);
        CPPUNIT_ASSERT_EQUAL(std::string("test"), ext.data());
    }

    void test_that_detects_invalid_payload_size()
    {
        SasExtension ext;

        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_size,
                             ext.parse(std::vector<uint8_t>()));
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_size,
                             ext.parse(std::vector<uint8_t>(10)));

        std::vector<uint8_t> payload = createValidPayload();
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::ok,
                             ext.parse(payload));

        // now modify payload size(the first 4 bytes)
        uint32_t& size = *reinterpret_cast<uint32_t*>(payload.data());

        size = ~size;
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_size,
                             ext.parse(payload));

        size = 0;
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_size,
                             ext.parse(payload));

        size = 1;
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_size,
                             ext.parse(payload));
    }

    void test_that_detects_invalid_payload_type()
    {
        SasExtension ext;

        std::vector<uint8_t> payload = createValidPayload();
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::ok,
                             ext.parse(payload));

        // ok, the magician is my name
        // so I know where the type is prone to blame
        payload[4] = 'b'; payload[5] = 'l'; payload[6] = 'a'; payload[7] = 'h';
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_payload_type,
                             ext.parse(payload));
    }

    void test_that_detects_invalid_data()
    {
        /* Currently it's reasonable to say that data(text or URI) should
         * consist of only printable characters.
         */

        SasExtension ext;

        ext.data("\uc39eetta er pr\uc3b3fun");
        std::vector<uint8_t> payload = ext.serialise();
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::ok,
                             ext.parse(payload));

        ext.data("bad UTF-8\xc3");
        payload = ext.serialise();
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_data,
                             ext.parse(payload));

        const std::string null_inside("test\0me", 7);
        ext.data(null_inside);
        payload = ext.serialise();
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_data,
                             ext.parse(payload));
    }

    void test_that_detects_invalid_type()
    {
        SasExtension ext;

        ext.type(static_cast<SasExtensionType::Enum>(0xdeadbeef));
        std::vector<uint8_t> payload = ext.serialise();
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_type,
                             ext.parse(payload));
    }

    void test_that_detects_invalid_mode()
    {
        SasExtension ext;

        ext.mode(static_cast<SasExtensionMode::Enum>(0xdeadbeef));
        std::vector<uint8_t> payload = ext.serialise();
        CPPUNIT_ASSERT_EQUAL(SasExtensionParseResult::bad_mode,
                             ext.parse(payload));
    }

private:
    std::vector<uint8_t> createValidPayload()
    {
        return SasExtension().serialise();
    }

    CPPUNIT_TEST_SUITE(YvSasExtensionParseTest);
    CPPUNIT_TEST(test_that_parses_all_elements);
    CPPUNIT_TEST(test_that_detects_invalid_payload_size);
    CPPUNIT_TEST(test_that_detects_invalid_payload_type);
    CPPUNIT_TEST(test_that_detects_invalid_data);
    CPPUNIT_TEST(test_that_detects_invalid_type);
    CPPUNIT_TEST(test_that_detects_invalid_mode);
    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(YvSasExtensionParseTest);

} // namespace
