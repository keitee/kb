/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "../src/EcmExtension.h"

#include <zinc-common/testsupport/CppUnit.h>

#include <boost/foreach.hpp>
#include <glib.h>

namespace {

using namespace ::Zinc::OnScreenId;

enum Offset8
{
    TAG = 0,
    LENGTH = 1,
    REFERENCE = 2,
    FLAGS = 3
};

enum Offset16
{
    DURATION = 4, // deprecated
    POS_X = 6,
    POS_Y = 8
};

void setField(
    std::vector<uint8_t>& payload, const Offset8 offset, const uint8_t v)
{
    payload[offset] = v;
}

void setField(
    std::vector<uint8_t>& payload, const Offset16 offset, const uint16_t v)
{
    *reinterpret_cast<uint16_t*>(payload.data() + offset) = GUINT16_TO_BE(v);
}

class YvEcmExtensionParseTest : public CppUnit::TestFixture
{
public:
    void test_that_parses_all_elements()
    {
        /* This is sort of a low-level test where the payload is hardcoded
         * rather than generated to ensure that the generator part of the
         * EcmExtension class doesn't "co-operate" with the parser part to
         * disguise some bugs.
         *
         * Might require updating if the format of the payload changes.
         */

        const char payloadData[] =
            "\xe0"     // YouView tag
            "\x08"     // length
            "\x03"     // reference
            "\x80"     // flags
            "\x00\x00" // duration(deprecated)
            "\x00\x0a" // x
            "\x00\x14" // y
            ;

        // need to get rid of the terminating NULL
        const std::vector<uint8_t> payload(boost::begin(payloadData),
                                           boost::end(payloadData) - 1);

        EcmExtension ext;
        CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok, ext.parse(payload));

        CPPUNIT_ASSERT_EQUAL(3u, static_cast<unsigned>(ext.reference()));
        CPPUNIT_ASSERT(ext.hasFlags(EcmExtension::Flags::HasPosition));
        CPPUNIT_ASSERT_EQUAL(static_cast<uint16_t>(10), ext.position().first);
        CPPUNIT_ASSERT_EQUAL(static_cast<uint16_t>(20), ext.position().second);
    }

    void test_that_parses_reference()
    {
        const uint8_t TEST_CASES[] = { 0, 1, 7, 99, 129, 254, 255 };
        std::vector<uint8_t> payload = createPayload();

        EcmExtension ext;

        BOOST_FOREACH(uint8_t ref, TEST_CASES)
        {
            setField(payload, REFERENCE, ref);

            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok,
                                 ext.parse(payload));
            CPPUNIT_ASSERT_EQUAL(unsigned(ref), unsigned(ext.reference()));
        }
    }

    void test_that_parses_flags()
    {
        const uint8_t TEST_CASES[] =
            { 0, 0x1, 0x80, 0x0f, 0xff, 0xaa, 0xa5, 0xcc };

        EcmExtension ext;

        BOOST_FOREACH(uint8_t flags, TEST_CASES)
        {
            std::vector<uint8_t> payload = createPayload(flags);
            setField(payload, FLAGS, flags);

            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok,
                                 ext.parse(payload));
            CPPUNIT_ASSERT(ext.hasFlags(flags));
        }
    }

    void test_that_parses_position()
    {
        typedef std::pair<uint16_t, uint16_t> position_t;

        const position_t TEST_CASES[] = {
            std::make_pair(0, 0),
            std::make_pair(17, 129),
            std::make_pair(255, 256),
            std::make_pair(999, 16383)
        };

        std::vector<uint8_t> payload =
            createPayload(EcmExtension::Flags::HasPosition);

        EcmExtension ext;

        BOOST_FOREACH(const position_t& pos, TEST_CASES)
        {
            setField(payload, POS_X, pos.first);
            setField(payload, POS_Y, pos.second);

            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok,
                                 ext.parse(payload));
            CPPUNIT_ASSERT_EQUAL(pos.first, ext.position().first);
            CPPUNIT_ASSERT_EQUAL(pos.second, ext.position().second);
        }
    }

    void test_that_detects_invalid_payload_type()
    {
        EcmExtension ext;

        std::vector<uint8_t> payload = createPayload();
        CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok,
                             ext.parse(payload));

        payload[TAG] = '\xff';
        CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::bad_payload_type,
                             ext.parse(payload));
    }

    void test_that_detects_invalid_payload_size()
    {
        EcmExtension ext;

        CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::bad_size,
                             ext.parse(std::vector<uint8_t>()));
        CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::bad_size,
                             ext.parse(std::vector<uint8_t>(1)));

        const uint8_t TEST_CASES[] = { 0, EcmExtension::Flags::HasPosition };

        BOOST_FOREACH(uint8_t flags, TEST_CASES)
        {
            std::vector<uint8_t> payload = createPayload(flags);
            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok,
                                 ext.parse(payload));

            payload.push_back('a');
            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::bad_size,
                                 ext.parse(payload));

            payload.pop_back();
            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok,
                                 ext.parse(payload));

            const uint8_t last_byte = payload.back();
            payload.pop_back();
            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::bad_size,
                                 ext.parse(payload));

            payload.push_back(last_byte);
            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::ok,
                                 ext.parse(payload));

            payload[LENGTH] ^= 0xff;
            CPPUNIT_ASSERT_EQUAL(EcmExtensionParseResult::bad_size,
                                 ext.parse(payload));
        }
    }

private:
    std::vector<uint8_t> createPayload(const uint32_t flags = 0)
     {
         EcmExtension ext;
         if (flags & EcmExtension::Flags::HasPosition)
         {
             ext.position(0, 0);
         }

         return ext.serialise();
     }

    CPPUNIT_TEST_SUITE(YvEcmExtensionParseTest);
    CPPUNIT_TEST(test_that_parses_all_elements);
    CPPUNIT_TEST(test_that_parses_reference);
    CPPUNIT_TEST(test_that_parses_flags);
    CPPUNIT_TEST(test_that_parses_position);
    CPPUNIT_TEST(test_that_detects_invalid_payload_type);
    CPPUNIT_TEST(test_that_detects_invalid_payload_size);
    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(YvEcmExtensionParseTest);

} // namespace
