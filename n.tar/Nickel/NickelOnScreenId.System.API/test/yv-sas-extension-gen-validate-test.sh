#!/bin/bash

# Author: kris@youview.com
#
# Copyright 2013 YouView TV Ltd.

# Exit immediately if any unexpected error occurs
set -e

#/ Usage: engine-yv-test.sh [options] [testnames...]
#/
#/        -l      Leave the scratch dir created in /tmp, rather than removing
#/                it during test tear-down (useful for debugging).
#/        -s      Stop on first test failure.
#/        -v      Verbose (don't suppress console output from tests).
#/
#/        If any test names are specified, only those test cases will be run.
while getopts "hlsv" option; do
    case $option in
        l) leave_scratch_dir=true;;
        s) stop_on_failure=true;;
        v) verbose=true;;
        *) grep '^#/' < "$0" | cut -c 4-; exit 1;; # Print above usage comment
    esac
done
shift $(($OPTIND-1))

function setup_suite() {
    tmpdir_suite=$(mktemp -d)
}

function teardown_suite() {
    :
}

function fail() {
    printf "FAILURE: %s\n" "$1" >&2
}

function assert_fail() {
    fail "Assertion failure: $1 (${FUNCNAME[1]}, line ${BASH_LINENO[1]})"
    teardown_suite
    exit 1
}

function setup_test() {
    local let num_params=1
    [ $# == $num_params ] || assert_fail "Required $num_params parameters"

    scratchdir="${tmpdir_suite}/${1}"
    logfile="${scratchdir}/log"

    mkdir "${scratchdir}"
}

function teardown_test() {
    :
}

if [ -n "$srcdir" ]; then
    generator=$PWD/yv-sas-extension-gen
    validator=$PWD/yv-sas-extension-validate
else
    source $(dirname $BASH_SOURCE[0])/../share/config.sh

    generator=$final_prefix/devel/bin/yv-sas-extension-gen
    validator=$final_prefix/devel/bin/yv-sas-extension-validate
fi

setup_suite

function check_prints_help() {
    $1 --help
    [ $? -eq 0 ] && grep -qi "usage" $logfile
}

function test_that_generator_prints_help() {
    check_prints_help $generator
}

function test_that_generator_prints_help_for_bad_option() {
    $generator --bad-bad-bad-option
    [ $? -ne 0 ] && grep -qi "usage" $logfile
}

function test_that_validator_prints_help() {
    check_prints_help $validator
}

function test_that_generator_text_output_is_valid() {
    $generator --text "test" --binary | $validator
}

function test_that_generator_hex_output_is_valid() {
    $generator --text "test" | $validator --hex
}

function test_that_generator_url_output_is_valid() {
    $generator --url "https://test.tld" --binary -a | $validator
}

function test_that_generator_prints_in_hex() {
    $generator --text "test"
    [ $? -eq 0 ] && grep -qi "74657374" $logfile
}

function test_that_generator_uses_default_foreground_for_text() {
    $generator --binary --text "Default foreground colour test" | \
    $validator

    grep -q "fg colour : ff909090" $logfile
}

function test_that_generator_resets_font_fields_for_image_ids() {
    local result=$(
        $generator --binary --url "https://example.tld/1.png" | \
        $validator | \
        egrep "font|colour" | awk -F ':' '{ print $2 }')

    # get rid of white-spacey
    result=$(echo $result)

    # make it visible in the log if the test fails
    echo $result

    [ "$result" = "0 0 0" ]
}

function test_that_validator_reads_hex() {
    echo "         00 00 00 27 79 76 69 64 01 00 00 01
00 80 00 24 00 32 00 0c 0c ff 90
         90 90 00 00 00 00 31 32 33 34 35 36 37 38 39 30
" | $validator --hex

    [ $? -eq 0 ] && grep -qi "1234567890" $logfile
}

function test_that_validator_reads_from_file() {
    local data_file="$scratchdir/data"

    $generator --text "test" --binary > $data_file &&
    $validator $data_file
}

function test_that_validator_doesnt_impose_url_size() {
    $generator --binary \
        --url "https://this.is.pretty.long.url/nothing/fancy.png" | \
    $validator
}

function test_that_validator_detects_bad_size() {
    echo -en "\x01" | $validator
    [ $? -ne 0 ] && grep -q "bad_size" $logfile
}

function test_that_validator_detects_bad_data() {
    local data_file="$scratchdir/data"

    $generator --text "test" --binary > $data_file

    local let f_size=$(stat -c '%s' $data_file)
    local let f_seek=$(($f_size - 4))
    echo -en "\xf4\xff\xff\xff" | dd bs=1 of=$data_file seek=$f_seek

    ! $validator < $data_file && grep -q "bad_data" $logfile
}

function test_that_validator_detects_too_long_text() {
    ! {
        $generator --binary --text \
            "This text is way too long for anyone who's worried about its
            presentation and resources on the device.  So let's assure this gets
            detected by the validation tool before anyone tries to let such
            long text out." | \
        $validator
    } && \
    grep -q "Text data too long" $logfile
}

##
# Run all functions named test_* (or specific tests named on the command line).
#
failed=0
for test in ${*:-$(compgen -A function test_)}; do
    set +e # So that a failing test doesn't terminate this script.
    ( # Run each test in a sub-shell to minimize side-effects.
        echo -n "$test ... "
        # &>> not supported by the bash on the box
        setup_test $test && ( set -e; $test; ) >> "${logfile}" 2>&1
        status=$?

        teardown_test

        [ $status -eq 0 ] && echo "OK" || echo "FAIL" >&2
        [[ "$verbose" = "true" || $status -ne 0 ]] && { cat "${logfile}"; echo; }
        exit $status
    ) || {
        ((++failed))
        [ "$stop_on_failure" != "true" ] || exit 1
    }
done

teardown_suite

[[ "$leave_scratch_dir" = "true" ]] ||
    rm -rf $tmpdir_suite

exit $((failed != 0))
