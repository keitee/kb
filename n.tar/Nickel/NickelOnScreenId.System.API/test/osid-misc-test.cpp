/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "../include/osid-misc.h"

#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>

#include <boost/bind.hpp>
#include <boost/foreach.hpp>
#include <boost/range.hpp>

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <utility>

namespace {

using namespace ::Zinc::OnScreenId;

class OsidMiscTest : NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
public:
    void test_hexToUint32()
    {
        typedef std::pair<std::string, uint32_t> positive_test_case_t;
        const positive_test_case_t good[] = {
            std::make_pair("01234567", 19088743u),
            std::make_pair("abcdef00", 2882400000u),
            std::make_pair("9AbCdEf9", 2596069113u) };

        const std::string bad[] = {
            "abcde", "bad!", "-111", "", "0123456789abcdef", "!!",
            "0x012345", "0x01234567", "0.1234" };

        BOOST_FOREACH(const positive_test_case_t& tc, good)
        {
            CPPUNIT_ASSERT_EQUAL_MESSAGE(tc.first,
                                         tc.second, hexToUint32(tc.first));
        }

        BOOST_FOREACH(const std::string& s, bad)
        {
            CPPUNIT_ASSERT_THROW_MESSAGE(s, hexToUint32(s),
                                         std::invalid_argument);
        }
    }

    void test_readPayload()
    {
        const std::string payload("some payload to read");
        std::istringstream s(payload);

        CPPUNIT_ASSERT_EQUAL(payload, p2s(readPayload(s)));
    }

    void test_readPayload_Hex()
    {
        const std::string expected("this is some payload");
        const std::string payload("   74 68 69 73 20 69 73 20 73 6f 6d 65 20"
                                  "70 6179\n6c \t 6f \n\n \t 61 64");

        std::istringstream s(payload);

        CPPUNIT_ASSERT_EQUAL(expected, p2s(readPayload(s, PayloadFormat::hex)));

        s.str("this is rubbish");
        CPPUNIT_ASSERT_THROW(readPayload(s, PayloadFormat::hex),
                             std::invalid_argument);
    }

    void test_readFilePayload()
    {
        const std::string payload("some payload to read");
        const std::string testFile = NS_ZINC::getMutableDataPath() + "test";

        {
            std::ofstream out(testFile.c_str());
            CPPUNIT_ASSERT(out.is_open());
            out << payload;
        }

        CPPUNIT_ASSERT_EQUAL(payload, p2s(readFilePayload(testFile.c_str())));

        const std::string testFileNonExisting =
            NS_ZINC::getMutableDataPath() + "it/doesnt/exist";
        CPPUNIT_ASSERT_THROW(readFilePayload(testFileNonExisting.c_str()),
                             std::runtime_error);
    }

    void test_readAllPayloads()
    {
        const std::string scratchDir = NS_ZINC::getMutableDataPath();
        const std::string paths[] = {
            scratchDir + "f1", scratchDir + "f2", scratchDir + "f3" };

        std::vector<const char*> pathPtrs;
        BOOST_FOREACH(const std::string& p, paths)
        {
            pathPtrs.push_back(p.c_str());

            std::ofstream out(pathPtrs.back());
            CPPUNIT_ASSERT_MESSAGE(p, out.is_open());

            // make the file's path its content
            out << p;
        }

        const std::vector<std::vector<uint8_t> > payloads =
            readAllPayloads(pathPtrs.data(), pathPtrs.data() + pathPtrs.size());

        CPPUNIT_ASSERT_EQUAL(pathPtrs.size(), payloads.size());
        CPPUNIT_ASSERT(std::equal(payloads.begin(), payloads.end(),
                                  boost::begin(paths),
                                  boost::bind(p2s, _1) == _2));

        const std::string testFileNonExisting =
            NS_ZINC::getMutableDataPath() + "it/doesnt/exist";
        pathPtrs.push_back(testFileNonExisting.c_str());
        CPPUNIT_ASSERT_THROW(
            readAllPayloads(pathPtrs.data(), pathPtrs.data() + pathPtrs.size()),
            std::runtime_error);
    }

    void test_writePayload()
    {
        const std::string payload("this is some payload");

        std::stringstream s;
        writePayload(s, s2p(payload));

        CPPUNIT_ASSERT_EQUAL(payload, p2s(readPayload(s)));
    }

    void test_writePayload_Hex()
    {
        const std::string payload("this is some payload");

        std::stringstream s;
        writePayload(s, s2p(payload), PayloadFormat::hex);

        std::string result;
        s >> result;

        const std::string expected("7468697320697320736f6d65207061796c6f6164");
        CPPUNIT_ASSERT_EQUAL(expected, result);
    }
private:

    static
    std::string p2s(const std::vector<uint8_t>& p)
    {
        return std::string(p.begin(), p.end());
    }

    static
    std::vector<uint8_t> s2p(const std::string& s)
    {
        return std::vector<uint8_t>(s.begin(), s.end());
    }

    CPPUNIT_TEST_SUITE(OsidMiscTest);
    CPPUNIT_TEST(test_hexToUint32);
    CPPUNIT_TEST(test_readPayload);
    CPPUNIT_TEST(test_readPayload_Hex);
    CPPUNIT_TEST(test_readFilePayload);
    CPPUNIT_TEST(test_readAllPayloads);
    CPPUNIT_TEST(test_writePayload);
    CPPUNIT_TEST(test_writePayload_Hex);
    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(OsidMiscTest);

} // namespace
