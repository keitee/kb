/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "../src/EcmExtension.h"
#include "../src/osid-constants.h"
#include "../src/RendererImpl.h"
#include "../src/SasExtension.h"

#include "../include/nickelonscreenid-system-exceptions.h"

#include "mock/MockImageDownloader.h"
#include "mock/MockRenderEngine.h"

#include <zinc-common/testsupport/CppUnit.h>

#include <boost/assign/list_of.hpp>
#include <boost/bind.hpp>
#include <boost/iterator/transform_iterator.hpp>
#include <boost/range.hpp>
#include <boost/typeof/std/utility.hpp>

#include <algorithm>

// It's a hack to require to refer to `s` but it does the job
#define CREATE_TEST_EXT(EXT, NAME, PROPS)                \
    struct NAME ## _Creator {                            \
        static EXT create() { EXT s;  PROPS; return s; } \
    };                                                   \
    const EXT NAME = NAME ## _Creator::create();

#define CREATE_TEST_SAS_EXT(NAME, PROPS) \
    CREATE_TEST_EXT(SasExtension, NAME, PROPS)

#define CREATE_TEST_ECM_EXT(NAME, PROPS) \
    CREATE_TEST_EXT(EcmExtension, NAME, PROPS)

namespace {

using namespace ::testing;
using namespace ::Zinc::OnScreenId;

CREATE_TEST_SAS_EXT(imageStatic1,
                    s.reference(1);
                    s.type(SasExtensionType::image);
                    s.mode(SasExtensionMode::continuous);
                    s.size(200, 200);
                    s.data("https://example.com/1.png");)

CREATE_TEST_SAS_EXT(imageDynamic2,
                    s.reference(2);
                    s.type(SasExtensionType::image);
                    s.mode(SasExtensionMode::ecm);
                    s.size(100, 100);
                    s.data("https://somewhere.tv/2.png");)

CREATE_TEST_SAS_EXT(textStatic3,
                    s.reference(3);
                    s.type(SasExtensionType::text);
                    s.mode(SasExtensionMode::continuous);
                    s.size(110, 20);
                    s.position(10, 10);
                    s.textColours(0xff909090, 0x01010101);
                    s.fontSize(20);
                    s.data("this is a test");)

CREATE_TEST_SAS_EXT(textDynamic4,
                    s.reference(4);
                    s.type(SasExtensionType::text);
                    s.mode(SasExtensionMode::ecm);
                    s.size(40, 10);
                    s.data("some ID");)

CREATE_TEST_ECM_EXT(imageDynamicTriggerWithPosition2,
                    s.reference(2);
                    s.position(1100, 600);)

CREATE_TEST_ECM_EXT(textDynamicTrigger4,
                    s.reference(4);)

const unsigned NUM_DEFINED_IDS = 4;

class RendererImplTest : public CppUnit::TestFixture
{
public:
    RendererImplTest() :
        downloader(boost::make_shared<StrictMock<MockImageDownloader> >()),
        engine(boost::make_shared<StrictMock<MockRenderEngine> >())
    {
    }

    void setUp()
    {
        renderer = createRenderer(NUM_DEFINED_IDS,
                                  downloader,
                                  engine);
    }

    void tearDown()
    {
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(downloader.get()));
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(engine.get()));

        renderer.reset();
    }

    void test_that_prerenders_all_ids_when_creating_session()
    {
        expectPrerenderImage(imageStatic1);
        expectPrerenderImage(imageDynamic2);
        expectPrerenderText(textStatic3);
        expectPrerenderText(textDynamic4);

        const std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of
               (imageStatic1)
               (imageDynamic2)
               (textStatic3)
               (textDynamic4));

        renderer->createSession(payloads).get();
    }

    void test_that_shows_all_static_ids_when_enabling_session()
    {
        expectPrerenderImage(imageStatic1);
        EXPECT_CALL(*engine, show(1));

        expectPrerenderImage(imageDynamic2);
        EXPECT_CALL(*engine, show(2)).Times(0);

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3));

        createEnabledSession(
            boost::assign::list_of
                (imageStatic1)
                (imageDynamic2)
                (textStatic3));
    }

    void test_that_shows_only_once()
    {
        expectPrerenderImage(imageStatic1);
        EXPECT_CALL(*engine, show(1)).Times(1);

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3)).Times(1);

        createEnabledSession(
            boost::assign::list_of
               (imageStatic1)
               (textStatic3));

        // try to enable 2nd time
        renderer->setState(RendererState::enabled).get();
    }

    void test_that_doesnt_show_if_not_created()
    {
        EXPECT_CALL(*engine, show(_)).Times(0);

        renderer->setState(RendererState::enabled).get();
        renderer->setState(RendererState::enabled).get();
    }

    void test_that_throws_when_registering_duplicates()
    {
        EXPECT_CALL(*engine, prerenderImage(_, _, _, _)).Times(0);
        EXPECT_CALL(*engine, show(_)).Times(0);

        expectDisposed();

        const std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of
               (imageStatic1)
               (imageDynamic2)
               (imageStatic1));

        // All the IDs in this test are images so expect requests to download
        // them except for the duplicate which is the last one.
        EXPECT_CALL(*downloader, download(_, _)).Times(payloads.size() - 1);

        CPPUNIT_ASSERT_THROW(renderer->createSession(payloads).get(),
                             ResourceFailureException);
    }

    void test_that_throws_on_invalid_sas_payload()
    {
        expectPrerenderImage(textStatic3, 0); // no prerendering expected
        expectDisposed();

        std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of(textStatic3));
        payloads.push_back(std::vector<uint8_t>(8, 'a')); // invalid payload

        CPPUNIT_ASSERT_THROW(renderer->createSession(payloads).get(),
                             ParseFailureException);
    }

    void test_that_ignores_unknown_sas_extensions()
    {
        const uint8_t yvid[] = { 'y', 'v', 'i', 'd' };

        std::vector<uint8_t> unknownPayload = imageStatic1.serialise();
        const std::vector<uint8_t>::iterator itModify =
            std::search(unknownPayload.begin(), unknownPayload.end(),
                        boost::begin(yvid), boost::end(yvid));

        CPPUNIT_ASSERT(itModify != unknownPayload.end());
        *itModify = 'u'; // keep it valid but make it unknown: "yvid" -> "uvid"

        // Looks like an image but it's unknown because of the identifier field
        // modified above.
        expectPrerenderImage(imageStatic1, 0);

        expectPrerenderText(textStatic3);

        std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of
               (textStatic3));
        payloads.push_back(unknownPayload);

        CPPUNIT_ASSERT_NO_THROW(renderer->createSession(payloads).get());
    }

    void test_that_hides_all_ids_when_disabling_session()
    {
        const std::vector<std::vector<uint8_t> > payloadsEcm =
            serialise<EcmExtension>(boost::assign::list_of
                (imageDynamicTriggerWithPosition2));

        expectPrerenderImage(imageStatic1);
        EXPECT_CALL(*engine, show(1));

        expectPrerenderImage(imageDynamic2);

        createEnabledSession(
            boost::assign::list_of
               (imageStatic1)
               (imageDynamic2));

        expectShowDynamic(imageDynamicTriggerWithPosition2);
        triggerAndVerify(payloadsEcm);

        EXPECT_CALL(*engine, hide(1));
        EXPECT_CALL(*engine, hide(2));

        renderer->setState(RendererState::disabled).get();
    }

    void test_that_hides_only_once()
    {
        expectPrerenderImage(imageStatic1);
        EXPECT_CALL(*engine, show(1));
        EXPECT_CALL(*engine, hide(1)).Times(1);

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3));
        EXPECT_CALL(*engine, hide(3)).Times(1);

        createEnabledSession(
            boost::assign::list_of
               (imageStatic1)
               (textStatic3));

        renderer->setState(RendererState::disabled).get();
        renderer->setState(RendererState::disabled).get();
    }

    void test_that_doesnt_hide_if_not_enabled()
    {
        expectPrerenderImage(imageStatic1);
        EXPECT_CALL(*engine, hide(_)).Times(0);

        const std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of
               (imageStatic1));

        renderer->setState(RendererState::disabled).get();
        renderer->createSession(payloads).get();

        // still not enabled
        renderer->setState(RendererState::disabled).get();
    }

    void test_that_triggers_dynamic_ids()
    {

        const std::vector<std::vector<uint8_t> > payloadsEcm =
            serialise<EcmExtension>(boost::assign::list_of
                (imageDynamicTriggerWithPosition2)
                (textDynamicTrigger4));

        const std::vector<std::vector<uint8_t> > payloadsEcm2 =
            serialise<EcmExtension>(boost::assign::list_of
                (imageDynamicTriggerWithPosition2));

        const std::vector<std::vector<uint8_t> > payloadsEcm4 =
            serialise<EcmExtension>(boost::assign::list_of
                (textDynamicTrigger4));

        const std::vector<std::vector<uint8_t> > payloadsEcmEmpty;

        expectPrerenderImage(imageStatic1);
        EXPECT_CALL(*engine, show(1));

        expectPrerenderImage(imageDynamic2);

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3));

        expectPrerenderText(textDynamic4);

        // create a session
        createEnabledSession(
            boost::assign::list_of
               (imageStatic1)
               (imageDynamic2)
               (textStatic3)
               (textDynamic4));
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(engine.get()));

        // show 2 and 4
        expectShowDynamic(imageDynamicTriggerWithPosition2);
        expectShowDynamic(textDynamic4);
        triggerAndVerify(payloadsEcm);

        // keep 2, hide 4
        EXPECT_CALL(*engine, show(2, _)).Times(0);
        EXPECT_CALL(*engine, hide(4));
        triggerAndVerify(payloadsEcm2);

        // hide 2, show 4
        EXPECT_CALL(*engine, hide(2));
        expectShowDynamic(textDynamic4);
        triggerAndVerify(payloadsEcm4);

        // keep 4
        EXPECT_CALL(*engine, show(4, _)).Times(0);
        triggerAndVerify(payloadsEcm4);

        // hide 4 (both hidden now)
        EXPECT_CALL(*engine, hide(4));
        triggerAndVerify(payloadsEcmEmpty);

        // show 2 and 4
        expectShowDynamic(imageDynamicTriggerWithPosition2);
        expectShowDynamic(textDynamic4);
        triggerAndVerify(payloadsEcm);

        // keep 2 and 4
        EXPECT_CALL(*engine, show(_, _)).Times(0);
        triggerAndVerify(payloadsEcm);

        // hide both
        EXPECT_CALL(*engine, hide(2));
        EXPECT_CALL(*engine, hide(4));
        triggerAndVerify(payloadsEcmEmpty);

        // show 4
        expectShowDynamic(textDynamic4);
        triggerAndVerify(payloadsEcm4);

        // keep 4
        EXPECT_CALL(*engine, show(_, _)).Times(0);
        triggerAndVerify(payloadsEcm4);
    }

    void test_that_doesnt_trigger_unknown_ids()
    {
        std::vector<std::vector<uint8_t> > payloadsEcm4 =
            serialise<EcmExtension>(boost::assign::list_of
                (textDynamicTrigger4));

        CPPUNIT_ASSERT_EQUAL(0xe0u, unsigned(payloadsEcm4[0][0]));
        payloadsEcm4[0][0] = '\xaa'; // set it to something non-YouView

        expectPrerenderText(textDynamic4);
        EXPECT_CALL(*engine, show(4, _)).Times(0);

        createEnabledSession(
            boost::assign::list_of
               (textDynamic4));

        triggerAndVerify(payloadsEcm4);
    }

    void test_that_throws_on_invalid_ecm_payload()
    {
        std::vector<std::vector<uint8_t> > payloads =
            serialise<EcmExtension>(boost::assign::list_of
                (textDynamicTrigger4));

        payloads[0].push_back('a'); // invalid payload

        createEnabledSession(std::vector<SasExtension>());

        CPPUNIT_ASSERT_THROW(renderer->trigger(payloads).get(),
                             ParseFailureException);
    }

    void test_that_throws_when_triggering_non_registered_ids()
    {
        const std::vector<std::vector<uint8_t> > payloadsEcm4 =
            serialise<EcmExtension>(boost::assign::list_of
                (textDynamicTrigger4));

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3));

        EXPECT_CALL(*engine, show(4, _)).Times(0);

        createEnabledSession(boost::assign::list_of(textStatic3));

        CPPUNIT_ASSERT_THROW(renderer->trigger(payloadsEcm4).get(),
                             ResourceFailureException);
    }

    void test_that_throws_when_triggering_duplicates()
    {
        const std::vector<std::vector<uint8_t> > payloadsEcm4 =
            serialise<EcmExtension>(boost::assign::list_of
                (textDynamicTrigger4)
                (textDynamicTrigger4));

        expectPrerenderText(textDynamic4);
        EXPECT_CALL(*engine, show(4, _)).Times(0);

        createEnabledSession(boost::assign::list_of(textDynamic4));

        CPPUNIT_ASSERT_THROW(renderer->trigger(payloadsEcm4).get(),
                             ResourceFailureException);
    }

    void test_that_throws_when_triggering_static_ids()
    {
        EcmExtension e;
        e.reference(textStatic3.reference());

        const std::vector<std::vector<uint8_t> > payloadsEcm(1, e.serialise());

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3)).Times(1);

        createEnabledSession(boost::assign::list_of(textStatic3));

        CPPUNIT_ASSERT_THROW(renderer->trigger(payloadsEcm).get(),
                             ResourceFailureException);
    }

    void test_that_doesnt_trigger_if_not_enabled()
    {
        const std::vector<std::vector<uint8_t> > payloadsEcm4 =
            serialise<EcmExtension>(boost::assign::list_of
                (textDynamicTrigger4));

        expectPrerenderText(textDynamic4);
        EXPECT_CALL(*engine, show(4, _)).Times(0);

        createEnabledSession(
            boost::assign::list_of
               (textDynamic4));

        renderer->setState(RendererState::disabled).get();

        triggerAndVerify(payloadsEcm4);
    }

    void test_that_resources_are_disposed_when_destroying_session()
    {
        expectDisposed();
        renderer->createSession(std::vector<std::vector<uint8_t> >());
        renderer->destroySession();
    }

    void test_that_can_create_session_after_destory()
    {
        expectPrerenderImage(imageStatic1);
        EXPECT_CALL(*engine, show(1));

        createEnabledSession(boost::assign::list_of(imageStatic1));

        expectDisposed();

        renderer->destroySession();

        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(downloader.get()));
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(engine.get()));

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3));

        createEnabledSession(boost::assign::list_of(textStatic3));
    }

    void test_that_throws_when_max_allowed_ids_per_session_exceeded()
    {
        const std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of
               (imageStatic1)
               (imageDynamic2)
               (textStatic3));

        // set the IDs per session limit so it's exceeded
        renderer = createRenderer(payloads.size() - 1,
                                  downloader,
                                  engine);

        CPPUNIT_ASSERT_THROW(renderer->createSession(payloads).get(),
                             ResourceFailureException);
    }

    void test_that_throws_when_max_allowed_text_size_exceeded()
    {
        CREATE_TEST_SAS_EXT(textTooLong,
                            s.reference(1);
                            s.type(SasExtensionType::text);
                            s.mode(SasExtensionMode::ecm);
                            s.size(40, 10);
                            s.data(
                                std::string(MAX_ALLOWED_TEXT_LENGTH + 1, 'x'));)

        const std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of(textTooLong));

        expectDisposed();

        CPPUNIT_ASSERT_THROW(renderer->createSession(payloads).get(),
                             ResourceFailureException);
    }

    void test_that_throws_when_creating_multiple_sessions()
    {
        const std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of(textDynamic4));

        expectPrerenderText(textDynamic4);
        renderer->createSession(payloads).get();
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(engine.get()));

        expectPrerenderText(textDynamic4, 0);
        // previous session not destroyed
        CPPUNIT_ASSERT_THROW(renderer->createSession(payloads).get(),
                             ResourceFailureException);
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(engine.get()));

        expectDisposed();
        renderer->destroySession();

        expectPrerenderText(textDynamic4);
        // now it should be OK
        CPPUNIT_ASSERT_NO_THROW(renderer->createSession(payloads).get());
    }

    void test_that_ignores_calls_when_session_not_created()
    {
        EXPECT_CALL(*engine, show(_)).Times(0);
        EXPECT_CALL(*engine, hide(_)).Times(0);

        CPPUNIT_ASSERT_NO_THROW(
            renderer->setState(RendererState::disabled).get());

        CPPUNIT_ASSERT_NO_THROW(
            renderer->setState(RendererState::enabled).get());

        // now if the all above wasn't ignored, everything below would fail as
        // the renderer would be in a bad state

        expectPrerenderText(textStatic3);
        EXPECT_CALL(*engine, show(3));

        createEnabledSession(boost::assign::list_of(textStatic3));
    }

    void test_that_throws_when_bad_state_requested()
    {
        const RendererState::Enum badState =
            static_cast<RendererState::Enum>(-1);

        // session not created yet, all calls should be ignored
        CPPUNIT_ASSERT_NO_THROW(renderer->setState(badState).get());

        createEnabledSession(std::vector<SasExtension>());

        CPPUNIT_ASSERT_THROW(renderer->setState(badState).get(),
                             ResourceFailureException);

        CPPUNIT_ASSERT_NO_THROW(
            renderer->setState(RendererState::disabled).get());
    }

    void test_that_can_create_session_if_the_previous_one_failed()
    {
        const std::vector<std::vector<uint8_t> > payloads =
            serialise<SasExtension>(boost::assign::list_of
               (textDynamic4)
               (imageStatic1));

        expectPrerenderText(textDynamic4);

        EXPECT_CALL(*downloader,
                    download(imageStatic1.reference(), imageStatic1.data()));

        EXPECT_CALL(*downloader, getPath(imageStatic1.reference()))
            .WillOnce(Throw(ResourceFailureException("No, I won't download!")));

        expectDisposed();

        CPPUNIT_ASSERT_THROW(renderer->createSession(payloads).get(),
                             ResourceFailureException);

        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(downloader.get()));
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(engine.get()));

        // now check that it's recovered
        test_that_prerenders_all_ids_when_creating_session();
    }

private:
    void createEnabledSession(const std::vector<SasExtension>& extensions)
    {
        renderer->createSession(serialise(extensions)).get();
        renderer->setState(RendererState::enabled).get();
    }

    void expectDisposed()
    {
        EXPECT_CALL(*downloader, dispose());
        EXPECT_CALL(*engine, dispose());
    }

    void expectPrerenderImage(const SasExtension& e, const int times = 1)
    {
        // To make it look realistically, replace "https://something" with
        // "/tmp/something"
        std::string path = e.data();
        path.replace(0, path.rfind('/'), "/tmp");

        EXPECT_CALL(*downloader,
                    download(e.reference(), e.data()))
            .Times(times);

        if (times != 0)
        {
            EXPECT_CALL(*downloader,
                        getPath(e.reference()))
                .WillRepeatedly(Return(path));
        }

        EXPECT_CALL(*engine,
                    prerenderImage(e.reference(), e.position(), e.size(), path))
            .Times(times);
    }

    void expectPrerenderText(const SasExtension& e, const int times = 1)
    {
        const RenderEngine::colours_t ENFORCED_COLOURS(
            DEFAULT_TEXT_FOREGROUND_COLOUR_ARGB,
            DEFAULT_TEXT_BACKGROUND_COLOUR_ARGB);

        EXPECT_CALL(*engine,
                    prerenderText(e.reference(), e.position(), e.size(),
                                  e.fontSize(),
                                  ENFORCED_COLOURS /* e.textColours()*/,
                                  e.data()))
            .Times(times);
    }

    template<class Extension>
    void expectShowDynamic(const Extension& e)
    {
        EXPECT_CALL(*engine, show(e.reference(), e.position()));
    }

    template<class Extension>
    std::vector<std::vector<uint8_t> > serialise(
        const std::vector<Extension>& extensions)
    {
        BOOST_AUTO(itTransformer, boost::bind(&Extension::serialise, _1));
        return std::vector<std::vector<uint8_t> >(
            boost::make_transform_iterator(extensions.begin(), itTransformer),
            boost::make_transform_iterator(extensions.end(), itTransformer));
    }

    void triggerAndVerify(const std::vector<std::vector<uint8_t> >& payloads)
    {
        renderer->trigger(payloads).get();
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(engine.get()));
    }

    CPPUNIT_TEST_SUITE(RendererImplTest);
    CPPUNIT_TEST(test_that_prerenders_all_ids_when_creating_session);
    CPPUNIT_TEST(test_that_shows_all_static_ids_when_enabling_session);
    CPPUNIT_TEST(test_that_shows_only_once);
    CPPUNIT_TEST(test_that_doesnt_show_if_not_created);
    CPPUNIT_TEST(test_that_throws_when_registering_duplicates);
    CPPUNIT_TEST(test_that_throws_on_invalid_sas_payload);
    CPPUNIT_TEST(test_that_ignores_unknown_sas_extensions);
    CPPUNIT_TEST(test_that_hides_all_ids_when_disabling_session);
    CPPUNIT_TEST(test_that_hides_only_once);
    CPPUNIT_TEST(test_that_doesnt_hide_if_not_enabled);
    CPPUNIT_TEST(test_that_triggers_dynamic_ids);
    CPPUNIT_TEST(test_that_throws_on_invalid_ecm_payload);
    CPPUNIT_TEST(test_that_doesnt_trigger_unknown_ids);
    CPPUNIT_TEST(test_that_throws_when_triggering_non_registered_ids);
    CPPUNIT_TEST(test_that_throws_when_triggering_duplicates);
    CPPUNIT_TEST(test_that_throws_when_triggering_static_ids);
    CPPUNIT_TEST(test_that_doesnt_trigger_if_not_enabled);
    CPPUNIT_TEST(test_that_resources_are_disposed_when_destroying_session);
    CPPUNIT_TEST(test_that_can_create_session_after_destory);
    CPPUNIT_TEST(test_that_throws_when_max_allowed_ids_per_session_exceeded);
    CPPUNIT_TEST(test_that_throws_when_max_allowed_text_size_exceeded);
    CPPUNIT_TEST(test_that_throws_when_creating_multiple_sessions);
    CPPUNIT_TEST(test_that_ignores_calls_when_session_not_created);
    CPPUNIT_TEST(test_that_throws_when_bad_state_requested);
    CPPUNIT_TEST(test_that_can_create_session_if_the_previous_one_failed);
    CPPUNIT_TEST_SUITE_END();

    boost::shared_ptr<MockImageDownloader> downloader;
    boost::shared_ptr<MockRenderEngine> engine;
    boost::shared_ptr<RendererAsync> renderer;
};

CPPUNIT_TEST_SUITE_REGISTRATION(RendererImplTest);

} // namespace
