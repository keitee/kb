/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_MOCKIMAGEDOWNLOADER_H_
#define NICKEL_ONSCREENID_SYSTEM_API_MOCKIMAGEDOWNLOADER_H_

#include "../include/ImageDownloader.h"

#include <gmock/gmock.h>

namespace Zinc {
namespace OnScreenId {

class MockImageDownloader : public ImageDownloader
{
public:

    virtual ~MockImageDownloader() {}

    MOCK_METHOD2(download, void(uint8_t reference, const std::string& url));

    MOCK_METHOD1(getPath, std::string(uint8_t reference));

    MOCK_METHOD0(dispose, void());
};

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_MOCKIMAGEDOWNLOADER_H_
