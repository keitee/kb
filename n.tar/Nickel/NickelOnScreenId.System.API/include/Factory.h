/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_FACTORY_H_
#define NICKEL_ONSCREENID_FACTORY_H_

#include "ImageDownloader.h"
#include "RendererAsync.h"
#include "RenderEngine.h"

#include <zinc-common/async/FutureDispatcher.h>
#include <zinc-common/Plugin.h>

#include <boost/shared_ptr.hpp>

namespace Zinc {
namespace OnScreenId {

class ZINC_EXPORT Factory : public NS_ZINC::Plugin
{
public:
    virtual ~Factory();

    boost::shared_ptr<RendererAsync> createRenderer(
        const boost::shared_ptr<NS_ZINC::FutureDispatcher>& dispatcher) const;

    virtual boost::shared_ptr<ImageDownloader> createImageDownloader(
        const boost::shared_ptr<NS_ZINC::FutureDispatcher>& disp) const = 0;

    virtual boost::shared_ptr<RenderEngine> createRenderEngine() const = 0;
};

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_FACTORY_H_
