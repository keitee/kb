/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

/**
 * This file is required by non-recursive common makefile for generating API
 * files.
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_MACROS_H_
#define NICKEL_ONSCREENID_SYSTEM_API_MACROS_H_

#endif // NICKEL_ONSCREENID_SYSTEM_API_MACROS_H_
