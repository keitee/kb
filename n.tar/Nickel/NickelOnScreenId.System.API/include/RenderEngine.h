/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_RENDERENGINE_H_
#define NICKEL_ONSCREENID_SYSTEM_API_RENDERENGINE_H_

#include <zinc-common/Polymorphic.h>

#include <stdint.h>

#include <string>
#include <utility>

namespace Zinc {
namespace OnScreenId {

/*
 * An internal API class that provides an abstraction for direct rendering
 * operations.
 *
 * Each on-screen identifier has to be pre-rendered first.  Then it can be shown
 * and hidden by using its unique reference until `dispose()` is called when all
 * identifiers are removed and resources deallocated.
 */
class ZINC_EXPORT RenderEngine : public NS_ZINC::Polymorphic
{
public:
    /* <x, y> position (<0, 0> is the top left corner) */
    typedef std::pair<uint16_t, uint16_t> position_t;

    /* <width, height> bounding box dimensions */
    typedef std::pair<uint16_t, uint16_t> box_t;

    /* <foreground, background> ARGB font colours */
    typedef std::pair<uint32_t, uint32_t> colours_t;

    /*
     * Render image OnScreen identifier but don't make it visible yet.  Acquire
     * any resources required.
     *
     * Throws ResourceFailureException if pre-rendering failed.
     */
    virtual void prerenderImage(uint8_t ref,
                                const position_t& position,
                                const box_t& box,
                                const std::string& path) = 0;

    /*
     * Render textual OnScreen identifier but don't make it visible yet.
     * Acquire any resources required.
     *
     * Throws ResourceFailureException if pre-rendering failed.
     */
    virtual void prerenderText(uint8_t ref,
                               const position_t& position,
                               const box_t& box,
                               uint8_t fontSize,
                               const colours_t& fontColours,
                               const std::string& text) = 0;

    /* Make a static identifier visible. */
    virtual void show(uint8_t ref) = 0;

    /* Make a transient identifier visible and the given position. */
    virtual void show(uint8_t ref,
                      const position_t& position) = 0;

    /* Hide an identifier */
    virtual void hide(uint8_t ref) = 0;

    /* Dispose any resources acquired */
    virtual void dispose() = 0;
};

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_RENDERENGINE_H_
