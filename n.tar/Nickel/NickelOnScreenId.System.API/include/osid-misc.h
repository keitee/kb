/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_OSID_MISC_H_
#define NICKEL_ONSCREENID_SYSTEM_API_OSID_MISC_H_

#include <zinc-common/macros.h>

#include <stdint.h>

#include <iosfwd>
#include <string>
#include <vector>

namespace Zinc {
namespace OnScreenId {

struct PayloadFormat
{
    enum Enum
    {
        bin,
        hex
    };
};

/*
 * Convert 8-character string representing a hexadecimal 32 bit number into
 * `uint32_t` number.
 *
 * Throws `std::invalid_argument` if the string length is not 8 or if any
 * of the characters does not represent a hexadecimal digit.
 */
uint32_t hexToUint32(const std::string& hex) ZINC_EXPORT;

/*
 * Read a payload of an arbitrary size from the input stream, optionally in
 * hexadecimal format.
 */
std::vector<uint8_t> readPayload(
    std::istream& in,
    PayloadFormat::Enum inFormat = PayloadFormat::bin) ZINC_EXPORT;

/*
 * Read a payload of an arbitrary size from a file, optionally in hexadecimal
 * format.
 */
std::vector<uint8_t> readFilePayload(
     const char* const fileName,
     PayloadFormat::Enum inFormat = PayloadFormat::bin) ZINC_EXPORT;

/*
 * Read multiple payloads from files specified as a range of C-style strings,
 * optionally in hexadecimal format.
 */
std::vector<std::vector<uint8_t> > readAllPayloads(
    const char* const* argFrom,
    const char* const* argTo,
    PayloadFormat::Enum inFormat = PayloadFormat::bin) ZINC_EXPORT;

/*
 * Write a payload of an arbitrary size to the output, optionally in hexadecimal
 * format.
 */
void writePayload(
    std::ostream& out,
    const std::vector<uint8_t>& payload,
    PayloadFormat::Enum outFormat = PayloadFormat::bin) ZINC_EXPORT;

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_OSID_MISC_H_
