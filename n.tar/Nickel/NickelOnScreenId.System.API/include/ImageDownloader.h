/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_IMAGEDOWNLOADER_H_
#define NICKEL_ONSCREENID_SYSTEM_API_IMAGEDOWNLOADER_H_

#include <zinc-common/Polymorphic.h>

#include <stdint.h>

#include <string>

namespace Zinc {
namespace OnScreenId {

/*
 * An internal API class that provides an abstraction for image downloading
 * operations.  These operations internally might be asynchronous but this is
 * deliberately not exposed to the client.  The approach chosen is to keep
 * the API asynchronous by design rather than by using specific features.  In
 * this instance it means that the client requests an image to download.  When
 * the image is needed, the client requests a path to it in the file system
 * which guarantees that the operation is completed (either successfully or
 * an exception is thrown in case of an error).
 *
 * A client makes a request to download an image by providing its unique
 * reference and a URL.  Then a path to a downloaded image file can be requested
 * by providing the same reference.
 *
 * The call to `download()` is not blocking but the call to `getPath()` might be
 * blocking until the image downloading is completed.
 *
 * Calling `dispose()` cancels any outstanding download jobs and invalidates
 * paths returned from `getPath()` (e.g. downloaded files are removed).
 */
class ZINC_EXPORT ImageDownloader : public NS_ZINC::Polymorphic
{
public:

    /*
     * Request an OnScreen ID image to download.
     *
     * Returns immediately while the download job is in progress.
     */
    virtual void download(uint8_t ref, const std::string& url) = 0;

    /*
     * Request a path to the OnScreen ID image.
     *
     * This blocks until the download is complete.  It return a path to a file
     * or throws an exception if failed to download the image.
     */
    virtual std::string getPath(uint8_t ref) = 0;

    /* Dispose any resources acquired and cancel any jobs in progress. */
    virtual void dispose() = 0;
};

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_IMAGEDOWNLOADER_H_
