/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_RENDERER_H_
#define NICKEL_ONSCREENID_SYSTEM_API_RENDERER_H_

#include "macros.h"
#include "RendererAsync.h"

namespace Zinc {
namespace OnScreenId {

typedef RendererAsync Renderer;

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_RENDERER_H_
