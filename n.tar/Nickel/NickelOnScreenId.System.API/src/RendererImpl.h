/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "ImageDownloader.h"
#include "RendererAsync.h"
#include "RenderEngine.h"

#include <boost/shared_ptr.hpp>

#ifndef NICKEL_ONSCREENID_SYSTEM_API_RENDERERIMPL_H_
#define NICKEL_ONSCREENID_SYSTEM_API_RENDERERIMPL_H_

namespace Zinc {
namespace OnScreenId {

boost::shared_ptr<RendererAsync> createRenderer(
    unsigned numIdsPerSession,
    const boost::shared_ptr<ImageDownloader>& downloader,
    const boost::shared_ptr<RenderEngine>& engine);

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_RENDERERIMPL_H_
