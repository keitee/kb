/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_SASEXTENSION_H_
#define NICKEL_ONSCREENID_SYSTEM_API_SASEXTENSION_H_

#include "SasExtensionMode.h"
#include "SasExtensionParseResult.h"
#include "SasExtensionType.h"

#include "unique_ptr.h"

#include <boost/utility.hpp>

#include <stdint.h>

#include <string>
#include <utility>
#include <vector>

namespace Zinc {
namespace OnScreenId {

/* TODO: Unspecified??? */
const uint32_t SAS_EXTENSION_TEXT_MAX_SIZE = 256;

/*
 * An API to access YouView specific SAS extension [1][2].
 *
 * The interpretation of the payload is specified in [2] as a structure of a
 * constant size with appended additional data of varying size.  This API gives
 * a much more convenient and stable access to any required data and allows to:
 * - parse and read interpreted data
 * - set data and serialise as a payload.
 *
 * Parsing and serialising needs to take into account endianess which is
 * handled internally.
 *
 * [1] Marlin MS3, section 3.5.2
 * [2] YouView IP Channels(0018-S), Annex F
 */
class SasExtension
{
public:

    /* Create an extension with default data that can be serialised */
    SasExtension();

    /* Allow objects to be stored in containers(copied and assigned) */
    SasExtension(const SasExtension& other);
    SasExtension& operator=(const SasExtension& other);

    /*
     * Read and interpret the payload.
     *
     * After calling this function all "getters" return data extracted from
     * the payload.
     *
     * This function validates the integrity of the payload.  If it fails to
     * parse the payload, it leaves the object intact.
     */
    SasExtensionParseResult::Enum parse(const std::vector<uint8_t>& payload);

    /*
     * Serialise data and produce the payload.
     */
    std::vector<uint8_t> serialise() const;

    /* "getters" and "setters" */

    /* A flag that has the semantics defined in the Marlin MS3 specification. */
    void critical(bool flag);
    bool critical() const;

    /*
     * A unique reference for this identifier within the scope of a single
     * stream and SAS.
     */
    void reference(uint8_t value);
    uint8_t reference() const;

    /* See SasExtentionType::Enum. */
    void type(SasExtensionType::Enum value);
    SasExtensionType::Enum type() const;

    /* See SasExtensionMode::Enum. */
    void mode(SasExtensionMode::Enum value);
    SasExtensionMode::Enum mode() const;

    /* The size of the bounding box. */
    void size(uint16_t width, uint16_t height);
    std::pair<uint16_t, uint16_t> size() const;

    /*
     * The default display position for the top left corner of the identifier
     * (in pixels, 1280x720 co-ordinate system, origin top left).
     */
    void position(uint16_t x, uint16_t y);
    std::pair<uint16_t, uint16_t> position() const;

    /*
     * Text foreground and background colour for a textual identifier expressed
     * as 32-bit ARGB value.
     */
    void textColours(uint32_t foreground, uint32_t background);
    std::pair<uint32_t, uint32_t> textColours() const;

    /* Text font size for a textual identifier. */
    void fontSize(uint8_t value);
    uint8_t fontSize() const;

    /* The data to display(either a text or an URL to an image) */
    void data(const std::string& value);
    std::string data() const;

private:
    struct Impl;
    unique_ptr<Impl> pImpl;
};

} // namespace OnScreenId
} // namespace Zinc

#endif /* NICKEL_ONSCREENID_SYSTEM_API_SASEXTENSION_H_ */
