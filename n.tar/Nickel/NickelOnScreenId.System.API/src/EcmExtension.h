/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_ECMEXTENSION_H_
#define NICKEL_ONSCREENID_SYSTEM_API_ECMEXTENSION_H_

#include "EcmExtensionParseResult.h"

#include "unique_ptr.h"

#include <stdint.h>

#include <vector>
#include <utility>

namespace Zinc {
namespace OnScreenId {

/*
 * An API to access YouView specific ECM Access Criteria Descriptor [1][2].
 *
 * The interpretation of the payload is specified in [2] as a structure of
 * a varying size.  This API gives a much more convenient and stable access to
 * any required data and allows to:
 * - parse and read interpreted data
 * - set data and serialise as a payload.
 *
 * Parsing and serialising needs to take into account endianess which is
 * handled internally.
 *
 * [1] IEC 62455, section 7.2
 * [2] YouView IP Channels (0018-S), Annex F
 */
class EcmExtension
{
public:
    /* Flags that control which of the optional data is available */
    struct Flags
    {
        enum Enum
        {
            /* Position is available and it overrides default ID position */
            HasPosition = 0x80
        };
    };

    /*
     * Create a default valid ECM extension.  It can be serialised and will
     * have all data set to defaults.
     */
    EcmExtension();

    /* Allow objects to be stored in containers (copied and assigned) */
    EcmExtension(const EcmExtension& other);
    EcmExtension&operator=(const EcmExtension& other);

    /*
     * Read and interpret the payload.
     *
     * After calling this function all "getters" return data extracted from
     * the payload.
     *
     * This function can only validate whether the payload has the minimum
     * required size and then match the actual size according to flags read from
     * the payload.  If it fails to parse the payload, it leaves the object
     * intact.
     */
    EcmExtensionParseResult::Enum parse(const std::vector<uint8_t>& payload);

    /*
     * Serialise data and produce the payload.
     */
    std::vector<uint8_t> serialise() const;

    /* "getters" and "setters" */

    /* The reference to an identifier defined in the MS3 SAS. */
    void reference(uint8_t value);

    uint8_t reference() const;

    bool hasFlags(uint8_t flags) const;

    /* optional data */

    /*
     * The display position for the top left corner of the identifier
     * (in pixels, 1280x720 co-ordinate system, origin top left
     * (`Flags::HasPosition` flag is set).
     */
    void position(uint16_t x, uint16_t y);

    std::pair<uint16_t, uint16_t> position() const;

private:
    struct Impl;
    unique_ptr<Impl> pImpl;
};

} // namespace OnScreenId
} // namespace Zinc

#endif /* NICKEL_ONSCREENID_SYSTEM_API_ECMEXTENSION_H_ */
