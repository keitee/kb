/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "EcmExtension.h"

#include "osid-misc.h"

#include <boost/filesystem.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>

namespace po = boost::program_options;

namespace {

po::options_description getProgramOptions()
{
    po::options_description options;
    options.add_options()
        ("help", "Print this message")

        ;

    return options;
}

po::options_description getAdditionalOptions()
{
    po::options_description options("options");
    options.add_options()
        ("binary,i",
         "Print the raw binary result")
        ("reference,r", po::value<uint16_t>()->default_value(0),
         "OnScreen ID reference number")
        ("pos-x,x", po::value<uint16_t>()->default_value(0),
         "X position of the OnScreen ID window")
        ("pos-y,y", po::value<uint16_t>()->default_value(0),
         "Y position of the OnScreen ID window")
        ;

    return options;
}

po::variables_map parseArgs(int argc, char* argv[])
{
    po::options_description cmdOptions =
        getProgramOptions().add(getAdditionalOptions());

    po::variables_map params;
    po::store(po::parse_command_line(argc, argv, cmdOptions), params);
    po::notify(params);

    return params;
}

void usage(const char *const argv0, std::ostream& out)
{
    const boost::filesystem::path execPath(argv0);
    const std::string exec = execPath.leaf();

    out
        << "Usage:\n"
        << "  " << exec << " --help\n"
        << "  " << exec << " [options]\n"
        << "\nGenerate ECM YouView Access Criteria Descriptor payload\n\n"
        << getProgramOptions() << '\n'
        << getAdditionalOptions()
        << "\n\n";

    out
        << "Examples:\n"
        << "  " << exec << " -x 100 -y 200\n"
        ;
}

} // namespace

int main(int argc, char* argv[])
{
    using namespace ::Zinc::OnScreenId;

    try
    {
        const po::variables_map params = parseArgs(argc, argv);

        if (0 != params.count("help"))
        {
            usage(argv[0], std::cout);
            return EXIT_SUCCESS;
        }

        EcmExtension ext;

        ext.reference(params["reference"].as<uint16_t>());

        if (!params["pos-x"].defaulted() || !params["pos-y"].defaulted())
        {
            ext.position(params["pos-x"].as<uint16_t>(),
                         params["pos-y"].as<uint16_t>());
        }

        const PayloadFormat::Enum outFormat = 0 != params.count("binary") ?
            PayloadFormat::bin : PayloadFormat::hex;

        writePayload(std::cout, ext.serialise(), outFormat);

        return EXIT_SUCCESS;

    }
    catch(const po::error& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
        usage(argv[0], std::cerr);
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
        // TODO: oddly on MIPSEL despite the catch clause for po::error above we
        // end up here
        usage(argv[0], std::cerr);
    }
    catch(...)
    {
        std::cerr << "Unknown error\n";
    }

    return EXIT_FAILURE;
}
