/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_UNIQUEPTR_H_
#define NICKEL_ONSCREENID_SYSTEM_API_UNIQUEPTR_H_

#include <boost/utility.hpp>
#include <utility>

/* A temporary replacement for a unique_ptr proposal - see DEVARCH-6384 */
namespace Zinc {
namespace OnScreenId {

/**
 * A simple replacement for C++11 `std::unique_ptr`.
 *
 * This is a very useful and lightweight RAII utility especially important for
 * object handles with custom deleters.  It can also be used with pImpl idiom
 * and forward-declared types (`boost::scoped_ptr` doesn't allow this).  Unlike
 * C++11 `std::unique_ptr` it doesn't support move semantics but this can be
 * addressed (to some extent) with the `swap()` member function.
 *
 * Technically custom deleters and forward-declared types are supported by C++11
 * `std::shared_ptr` (and `boost::shared_ptr`) but this implies some overhead
 * and shared ownership which in many situations is not intended.
 *
 * This utility is an interim solution (before adopting C++11) and it's
 * intentionally kept simple because full implementation is provided in C++11
 * standard library.  Any missing features should be added as needed
 * (e.g. supporting arrays, checking for non-empty types etc.).
 *
 * Examples:
 * // 1. Typical RAII
 * const unique_ptr<X509> p (X509_new (), X509_free);
 * // use `p` or `p.get ()` but don't worry about freeing it
 *
 * // 2. pImpl
 * class Foo
 * {
 * public:
 *     Foo ();
 *     // some methods
 * private:
 *    struct Impl;
 *    const unique_ptr<Impl> pImpl;
 * };
 *
 * struct Foo::Impl
 * {
 *     // implementation details
 * };
 *
 * Foo::Foo () : pImpl (new Impl) {}
 */

template<typename T>
class unique_ptr : boost::noncopyable
{
public:
    typedef T element_type;
    typedef element_type* pointer;
    typedef void(*deleter_type) (pointer);

    explicit
    unique_ptr(pointer const p = 0, const deleter_type d = default_deleter)
        : ptr(p), deleter(d) {}

    ~unique_ptr()
    {
        if (ptr)
        {
            deleter(ptr);
        }
    }

    pointer get() const { return ptr; }

    element_type& operator*() const { return *get(); }

    pointer operator->() const { return get(); }

    operator bool() const { return ptr; }

    pointer release()
    {
        pointer p = ptr;
        ptr = 0;
        return p;
    }

    void reset(pointer p = 0)
    {
        unique_ptr(p, deleter).swap(*this);
    }

    void swap(unique_ptr& other)
    {
        using std::swap;
        swap(other.ptr, ptr);
        swap(other.deleter, deleter);
    }

private:

    static
    void default_deleter(pointer ptr) { delete ptr; }

    pointer ptr;
    deleter_type deleter;
};

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_UNIQUEPTR_H_
