/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "EcmExtension.h"

#include <glib.h>

#include <cstring>

namespace Zinc {
namespace OnScreenId {

namespace {

/*
 * YouView ECM Access Criteria Descriptor tag.
 * See IEC 62455, section 7.2.1, table 8.
 */
const uint8_t YV_ECM_ACD_TAG = '\xe0';

/* These functions can be generic (templates) provided that it can choose the
 * right `htobe` and `betoh` functions (eg. based on overloaded wrappers).
 * Currently there's only `uint16_t` to handle so let's save us the hassle.
 */
void pushBytes16(std::vector<uint8_t>& payload, const uint16_t value)
{
    union
    {
        uint16_t value;
        uint8_t bytes[2];
    } u;

    u.value = GUINT16_TO_BE(value);

    payload.push_back(u.bytes[0]);
    payload.push_back(u.bytes[1]);
}

template<class It>
uint16_t readBytes16(It& it)
{
    union
    {
        uint16_t value;
        uint8_t bytes[2];
    } u;

    u.bytes[0] = *it++;
    u.bytes[1] = *it++;

    return GUINT16_FROM_BE(u.value);
}

} // namespace

struct EcmExtension::Impl
{

    /*
     * Plain Old Data structure that represents the payload definition as in
     * 0018-S spec (with it's field naming convention).
     */
    struct Pod
    {
        uint8_t tag;
        uint8_t length;

        uint8_t identifier_ref;
        uint8_t flags;

        // deprecated
        uint16_t display_duration;

        // optional
        uint16_t display_x;
        uint16_t display_y;

        /* Extension length based on flags */
        static
        uint8_t extensionLength(uint8_t flags = 0);

        /* Expected payload size based on flags (optional fields) */
        static
        uint32_t payloadSize(uint8_t flags = 0);

    } pod;

};

uint8_t EcmExtension::Impl::Pod::extensionLength(const uint8_t flags)
{
    return payloadSize(flags) - (sizeof tag + sizeof length);
}

uint32_t EcmExtension::Impl::Pod::payloadSize(const uint8_t flags)
{
    uint32_t size =
        sizeof tag +
        sizeof length +
        sizeof identifier_ref +
        sizeof flags +
        sizeof display_duration;

    if (flags & Flags::HasPosition)
    {
        size += sizeof display_x + sizeof display_y;
    }

    return size;
}

EcmExtension::EcmExtension() : pImpl(new Impl)
{
    std::memset(&pImpl->pod, 0, sizeof(Impl::Pod));
    pImpl->pod.tag = YV_ECM_ACD_TAG;
    pImpl->pod.length = Impl::Pod::extensionLength();
}

EcmExtension::EcmExtension(const EcmExtension& other) :
    pImpl(new Impl(*other.pImpl))
{
}

EcmExtension& EcmExtension::operator=(const EcmExtension& other)
{
    *pImpl = *other.pImpl;
    return *this;
}

EcmExtensionParseResult::Enum EcmExtension::parse(
    const std::vector<uint8_t>& payload)
{
  // check whether it's at least of the minimum size
    if (payload.size() < Impl::Pod::payloadSize())
    {
        return EcmExtensionParseResult::bad_size;
    }

    Impl::Pod pod;
    std::memset(&pod, 0, sizeof(Impl::Pod));

    std::vector<uint8_t>::const_iterator it = payload.begin();
    pod.tag = *it++;
    if (YV_ECM_ACD_TAG != pod.tag)
    {
        return EcmExtensionParseResult::bad_payload_type;
    }
    pod.length = *it++;
    pod.identifier_ref = *it++;
    pod.flags = *it++;
    if (Impl::Pod::payloadSize(pod.flags) != payload.size () ||
        Impl::Pod::extensionLength(pod.flags) != pod.length)
    {
        return EcmExtensionParseResult::bad_size;
    }
    pod.display_duration = readBytes16(it);
    if (pod.flags & Flags::HasPosition)
    {
        pod.display_x = readBytes16(it);
        pod.display_y = readBytes16(it);
    }

    pImpl->pod = pod;

    return EcmExtensionParseResult::ok;
}

std::vector<uint8_t> EcmExtension::serialise() const
{
    const Impl::Pod& pod = pImpl->pod;

    std::vector<uint8_t> payload;
    payload.reserve(Impl::Pod::payloadSize(pod.flags));

    payload.push_back(pod.tag);
    payload.push_back(pod.length);
    payload.push_back(pod.identifier_ref);
    payload.push_back(pod.flags);
    pushBytes16(payload, pod.display_duration);
    if (pod.flags & Flags::HasPosition)
    {
        pushBytes16(payload, pod.display_x);
        pushBytes16(payload, pod.display_y);
    }

    return payload;
}

void EcmExtension::reference(const uint8_t value)
{
    pImpl->pod.identifier_ref = value;
}

uint8_t EcmExtension::reference() const
{
    return pImpl->pod.identifier_ref;
}

bool EcmExtension::hasFlags(const uint8_t flags) const
{
    return flags == (pImpl->pod.flags & flags);
}

void EcmExtension::position(const uint16_t x, const uint16_t y)
{
    pImpl->pod.display_x = x;
    pImpl->pod.display_y = y;

    pImpl->pod.flags |= Flags::HasPosition;
    pImpl->pod.length = Impl::Pod::extensionLength(pImpl->pod.flags);
}

std::pair<uint16_t, uint16_t> EcmExtension::position() const
{
    return std::make_pair(pImpl->pod.display_x, pImpl->pod.display_y);
}

} // namespace OnScreenId
} // namespace Zinc
