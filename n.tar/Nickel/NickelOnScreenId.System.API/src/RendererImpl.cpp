/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "RendererImpl.h"

#include "RendererAsync.h"

#include "EcmExtension.h"
#include "SasExtension.h"

#include "nickelonscreenid-system-exceptions.h"
#include "osid-constants.h"

#include <nickel-common/NickelLogger.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/ScopeExitHook.h>

#include <boost/assert.hpp>
#include <boost/bind.hpp>
#include <boost/foreach.hpp>
#include <boost/make_shared.hpp>

#include <algorithm>
#include <set>
#include <sstream>
#include <stdexcept>
#include <vector>

#define THROW_ERROR(ERROR, MSG) { \
  std::ostringstream ostr;        \
  ostr << MSG;                    \
  throw ERROR (ostr.str ());      \
}

namespace Zinc {
namespace OnScreenId {

class RendererImpl : public RendererAsync
{
public:
    RendererImpl(unsigned numIdsPerSession,
                 const boost::shared_ptr<ImageDownloader>& downloader,
                 const boost::shared_ptr<RenderEngine>& engine);

    virtual ~RendererImpl();

    virtual NS_ZINC::Future<void> createSession(
        const std::vector<std::vector<uint8_t> >& extensions);

    virtual NS_ZINC::Future<void> setState(
        const RendererState::Enum state);

    virtual NS_ZINC::Future<void> trigger(
        const std::vector<std::vector<uint8_t> >& descriptors);

    virtual NS_ZINC::Future<void> destroySession();

private:


    void addId(const std::vector<uint8_t>& payload);

    void cleanupSession();

    void disableId(uint8_t ref);

    void enableStaticId(const SasExtension& id);

    void enableDynamicId(
        const SasExtension& id,
        const std::pair<uint16_t, uint16_t>& position);

    std::vector<SasExtension>::const_iterator findId(uint8_t ref);

    bool hasId(uint8_t ref);

    void doTrigger(const std::vector<std::vector<uint8_t> >& descriptors);

    void prerender(const SasExtension& id);

    const unsigned numIdsPerSession;

    bool sessionCreated;
    RendererState::Enum state;
    std::vector<SasExtension> registeredIds;
    std::vector<uint8_t> enabledDynamicIds;

    boost::shared_ptr<ImageDownloader> downloader;
    boost::shared_ptr<RenderEngine> engine;
};

RendererImpl::RendererImpl(
    const unsigned numIdsPerSession,
    const boost::shared_ptr<ImageDownloader>& downloader,
    const boost::shared_ptr<RenderEngine>& engine)
    : numIdsPerSession(numIdsPerSession),
      sessionCreated(false),
      state(RendererState::disabled),
      downloader(downloader),
      engine(engine)
{
}

RendererImpl::~RendererImpl()
{
}

void RendererImpl::addId(const std::vector<uint8_t>& payload)
{
    SasExtension id;
    const SasExtensionParseResult::Enum res = id.parse(payload);
    if (SasExtensionParseResult::bad_payload_type == res)
    {
        NICKEL_WARN("Ignoring non-YouView SAS extension type");
        return;
    }
    else if (SasExtensionParseResult::ok != res)
    {
        THROW_ERROR(ParseFailureException,
                    "Cannot parse SAS extension: " << enum_to_string(res));
    }

    if (hasId(id.reference()))
    {
        THROW_ERROR(ResourceFailureException,
                    "Duplicate ID: " << static_cast<uint32_t>(id.reference()));
    }
    else
    {
        registeredIds.push_back(id);
    }

    if (SasExtensionType::image == id.type())
    {
        downloader->download(id.reference(), id.data());
        NICKEL_DEBUG("Scheduled image download: " << id.data());
    }
    else if (SasExtensionType::text == id.type() &&
             MAX_ALLOWED_TEXT_LENGTH < id.data().size())
    {
        THROW_ERROR(ResourceFailureException,
                    "Text data too long: "
                        << id.data().size()
                        << " (" << MAX_ALLOWED_TEXT_LENGTH << " allowed)");
    }

    NICKEL_DEBUG("Registered on-screen ID: "
                 << static_cast<uint16_t>(id.reference()));
}

void RendererImpl::cleanupSession()
{
    downloader->dispose();
    engine->dispose();

    enabledDynamicIds.clear();
    registeredIds.clear();

    sessionCreated = false;
    state = RendererState::disabled;
}

void RendererImpl::disableId(const uint8_t ref)
{
    BOOST_ASSERT(hasId(ref));
    engine->hide(ref);

    NICKEL_DEBUG("Disabled on-screen ID: " << static_cast<uint16_t>(ref));
}

void RendererImpl::enableStaticId(const SasExtension& id)
{
    engine->show(id.reference());
    NICKEL_DEBUG("Enabled on-screen ID: "
                 << static_cast<uint16_t>(id.reference()));
}

void RendererImpl::enableDynamicId(
    const SasExtension& id,
    const std::pair<uint16_t, uint16_t>& position)
{
    engine->show(id.reference(), position);
    NICKEL_DEBUG("Enabled on-screen ID "
                 << static_cast<uint16_t>(id.reference())
                 << " at position ["
                 << position.first << ", " << position.second << "]");
}

std::vector<SasExtension>::const_iterator RendererImpl::findId(
    const uint8_t ref)
{
    return std::find_if(registeredIds.begin(), registeredIds.end(),
                        boost::bind(&SasExtension::reference, _1) == ref);
}

bool RendererImpl::hasId(const uint8_t ref)
{
    return findId(ref) != registeredIds.end();
}

void RendererImpl::doTrigger(
    const std::vector<std::vector<uint8_t> >& descriptors)
{
    std::vector<EcmExtension> parsed; // parsed descriptors
    std::set<uint8_t> refs; // requested IDs references for quick look-up

    BOOST_FOREACH(const std::vector<uint8_t>& payload, descriptors)
    {
        EcmExtension trigger;

        const EcmExtensionParseResult::Enum res = trigger.parse(payload);
        // first ignore all descriptors that are not YouView related
        if (EcmExtensionParseResult::bad_payload_type == res)
        {
            NICKEL_WARN("Ignoring non-YouView descriptor type");
        }
        // see if parsing the payload failed for any other reason
        else if (EcmExtensionParseResult::ok != res)
        {
            THROW_ERROR(ParseFailureException,
                        "Cannot parse ECM ACD: " << enum_to_string(res));
        }
        // check whether we've seen this extension reference already
        else if (!refs.insert(trigger.reference()).second)
        {
            THROW_ERROR(ResourceFailureException,
                        "Duplicate trigger: "
                            << static_cast<uint32_t>(trigger.reference()));
        }
        // OK
        else
        {
            parsed.push_back(trigger);
        }
    }

    // disable all IDs that are not triggered and remove them from the list
    // of enabled IDs
    std::vector<uint8_t>::iterator itEnabledEnd = enabledDynamicIds.end();
    const std::vector<uint8_t>::iterator itToRemove =
        std::partition(
            enabledDynamicIds.begin(), itEnabledEnd,
            boost::bind(&std::set<uint8_t>::count, refs, _1) != 0);

    std::for_each(
        itToRemove, itEnabledEnd,
        boost::bind(&RendererImpl::disableId, this, _1));
    itEnabledEnd = enabledDynamicIds.erase(itToRemove, itEnabledEnd);

    // iterate over parsed descriptors and enable those that aren't enabled
    const std::vector<uint8_t>::iterator itEnabledBegin =
        enabledDynamicIds.begin();

    std::vector<uint8_t> enabled;
    BOOST_FOREACH(const EcmExtension& e, parsed)
    {
        // enable the ID if it's not enabled yet
        if (std::find(itEnabledBegin, itEnabledEnd, e.reference()) ==
            itEnabledEnd)
        {
            const std::vector<SasExtension>::const_iterator it =
                findId(e.reference());

            // check whether it's registered
            if (registeredIds.end() == it)
            {
                THROW_ERROR(ResourceFailureException,
                            "Triggering non-registered ID: "
                                << static_cast<uint32_t>(e.reference()));
            }
            // check whether it's registered as dynamic ID
            else if (SasExtensionMode::ecm != it->mode())
            {
                THROW_ERROR(ResourceFailureException,
                            "Triggering non-transient ID: "
                                << static_cast<uint32_t>(e.reference()));
            }
            // OK, enable it
            else
            {
                enableDynamicId(
                    *it,
                    e.hasFlags(EcmExtension::Flags::HasPosition) ?
                    e.position() : it->position());
                enabled.push_back(e.reference());
            }
        }
    }

    // add new enabled IDs to the list of enabled IDs
    enabledDynamicIds.insert(itEnabledEnd, enabled.begin(), enabled.end());
}

void RendererImpl::prerender(const SasExtension& id)
{
    switch (id.type())
    {
    case SasExtensionType::image:
        engine->prerenderImage(id.reference(),
                               id.position(),
                               id.size(),
                               downloader->getPath(id.reference()));
        break;

    case SasExtensionType::text:
        engine->prerenderText(id.reference(),
                              id.position(),
                              id.size(),
                              id.fontSize(),
                              /* TODO: will be id.textColours() */
                              RenderEngine::colours_t(
                                  DEFAULT_TEXT_FOREGROUND_COLOUR_ARGB,
                                  DEFAULT_TEXT_BACKGROUND_COLOUR_ARGB),
                              id.data());
        break;

    default:
        // Les impossibles (SAS parser should catch this)
        THROW_ERROR(ResourceFailureException,
                    "Unknown ID type requested: " << id.type());
    }

    NICKEL_DEBUG("Prerendered on-screen ID: "
                 << static_cast<uint16_t>(id.reference()));
}

NS_ZINC::Future<void> RendererImpl::createSession(
    const std::vector<std::vector<uint8_t> >& extensions)
{
    if (sessionCreated)
    {
        THROW_ERROR(ResourceFailureException, "The session is already created");
    }

    if (numIdsPerSession < extensions.size())
    {
        THROW_ERROR(ResourceFailureException,
                    "The number of allowed IDs per session exceeded: "
                        << extensions.size()
                        << " (" << numIdsPerSession << " allowed)");
    }

    // roll back if anything below fails
    NS_ZINC::ScopeExitHook cleanupIfFailed(
        boost::bind(&RendererImpl::cleanupSession, this));

    std::for_each(
        extensions.begin(), extensions.end(),
        boost::bind(&RendererImpl::addId, this, _1));

    std::for_each(
        registeredIds.begin(), registeredIds.end(),
        boost::bind(&RendererImpl::prerender, this, _1));

    sessionCreated = true;

    // phew! we made it through!
    cleanupIfFailed.cancel();

    return NS_ZINC::completedFuture();
}

NS_ZINC::Future<void> RendererImpl::setState(const RendererState::Enum state_)
{
    if (!sessionCreated)
    {
        NICKEL_WARN("Ignoring state change. Session not created");
    }
    else if (state_ != state)
    {
        switch (state_)
        {
        case RendererState::enabled :
            BOOST_FOREACH(const SasExtension& id, registeredIds)
            {
                if (SasExtensionMode::continuous == id.mode())
                {
                    enableStaticId(id);
                }
            }

            break;

        case RendererState::disabled :
            BOOST_FOREACH(const SasExtension& id, registeredIds)
            {
                if (SasExtensionMode::continuous == id.mode())
                {
                    disableId(id.reference());
                }
            }

            std::for_each(
                enabledDynamicIds.begin(), enabledDynamicIds.end(),
                boost::bind(&RendererImpl::disableId, this, _1));

            enabledDynamicIds.clear();
            break;

        default:
            THROW_ERROR(ResourceFailureException,
                        "Unknown state requested: " << state_);
            break;
        }

        state = state_;
    }

    return NS_ZINC::completedFuture();
}

NS_ZINC::Future<void> RendererImpl::trigger(
    const std::vector<std::vector<uint8_t> >& descriptors)
{
    // no need to check for session, checking the state suffices
    if (RendererState::enabled == state)
    {
        doTrigger(descriptors);
    }
    else
    {
        NICKEL_WARN("Ignoring trigger call. Session not enabled");
    }

    return NS_ZINC::completedFuture();
}

NS_ZINC::Future<void> RendererImpl::destroySession()
{
    // no need to check for session
    cleanupSession();
    return NS_ZINC::completedFuture();
}

boost::shared_ptr<RendererAsync> createRenderer(
    const unsigned numIdsPerSession,
    const boost::shared_ptr<ImageDownloader>& downloader,
    const boost::shared_ptr<RenderEngine>& engine)
{
    return boost::make_shared<RendererImpl>(numIdsPerSession,
                                            downloader,
                                            engine);
}

} // namespace OnScreenId
} // namespace Zinc
