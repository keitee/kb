/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "SasExtension.h"

#include "osid-misc.h"

#include <boost/algorithm/string/predicate.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/program_options.hpp>

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>

namespace po = boost::program_options;

namespace {

po::options_description getProgramOptions()
{
    po::options_description options;
    options.add_options()
        ("help", "Print this message")

        ("text,t", po::value<std::string>(),
         "Text ID")
        ("url,u", po::value<std::string>(),
         "Unescaped URL of the image ID")
        ;

    return options;
}

po::options_description getAdditionalOptions()
{
    po::options_description options("options");
    options.add_options()
        ("binary,i",
         "Print the raw binary result")
        ("critical,k",
         "Whether the extension is critical")
        ("reference,r", po::value<uint16_t>()->default_value(0),
         "OnScreen ID reference number")
        ("static,a",
         "Whether OnScreen ID should be displayed continuously")
        ("pos-x,x", po::value<uint16_t>()->default_value(0),
         "X position of the OnScreen ID window")
        ("pos-y,y", po::value<uint16_t>()->default_value(0),
         "Y position of the OnScreen ID window")
        ("width,w", po::value<uint16_t>()->default_value(100),
         "OnScreen ID window width")
        ("height,h", po::value<uint16_t>()->default_value(100),
         "OnScreen ID window height")
        ("font-size,s", po::value<uint16_t>()->default_value(12),
         "Font size(in points) of the rendered text")
        ("fg-colour,c", po::value<std::string>()->default_value("FF909090"),
         "Foreground colour(<AARRGGBB> hex) of the displayed text")
        ("bg-colour,b", po::value<std::string>()->default_value("00000000"),
         "Background colour(<AARRGGBB> hex) of the displayed text")
        ;

    return options;
}

po::variables_map parseArgs(int argc, char* argv[])
{
    po::options_description cmdOptions =
        getProgramOptions().add(getAdditionalOptions());

    po::variables_map params;
    po::store(po::parse_command_line(argc, argv, cmdOptions), params);
    po::notify(params);

    return params;
}

void usage(const char *const argv0, std::ostream& out)
{
    const boost::filesystem::path execPath(argv0);
    const std::string exec = execPath.leaf();

    out
        << "Usage:\n"
        << "  " << exec << " --help\n"
        << "  " << exec << " --text <text> [options]\n"
        << "  " << exec << " --url <URL> [options]\n"
        << "\nGenerate SAS YouView extension payload\n\n"
        << getProgramOptions() << '\n'
        << getAdditionalOptions()
        << "\n\n";

    out
        << "Examples:\n"
        << "  " << exec << " -t \"Test ID\"\n"
        << "  " << exec
        << " --url https://example.tld/1.png --width 40 --height 40\n"
        ;
}

bool validateUrl(const std::string& url)
{
    // TODO: Do proper URL validation if possible
    return boost::starts_with(url, "https://");
}

} // namespace

int main(int argc, char* argv[])
{
    using namespace ::Zinc::OnScreenId;

    try
    {
        const po::variables_map params = parseArgs(argc, argv);

        if (0 != params.count("help"))
        {
            usage(argv[0], std::cout);
            return EXIT_SUCCESS;
        }

        const bool hasText = 0 != params.count("text");
        const bool hasUrl = 0 != params.count("url");

        if (!(hasText ^ hasUrl))
        {
            std::cerr << "Error: Either --text or --url must be specified\n\n";
            usage(argv[0], std::cerr);
            return EXIT_FAILURE;
        }

        std::string data;
        SasExtensionType::Enum idType;

        if (hasUrl)
        {
            data = params["url"].as<std::string>();
            idType = SasExtensionType::image;

            if (!validateUrl(data))
            {
                std::cerr << "Error: The --url argument must be a valid "
                             "https URL\n";
                return EXIT_FAILURE;
            }
        }
        else
        {
            data = params["text"].as<std::string>();
            idType = SasExtensionType::text;

            if (data.size() > SAS_EXTENSION_TEXT_MAX_SIZE)
            {
                std::cerr << "Error: The --text argument exceeds "
                          << SAS_EXTENSION_TEXT_MAX_SIZE << " characters\n";
                return EXIT_FAILURE;
            }
        }

        SasExtension ext;

        ext.critical(0 != params.count("critical"));

        ext.reference(params["reference"].as<uint16_t>());
        ext.type(idType);
        ext.mode(0 != params.count("static") ?
                 SasExtensionMode::continuous : SasExtensionMode::ecm);

        ext.size(params["width"].as<uint16_t>(),
                 params["height"].as<uint16_t>());
        ext.position(params["pos-x"].as<uint16_t>(),
                     params["pos-y"].as<uint16_t>());

        if (SasExtensionType::text == idType)
        {
            ext.fontSize(params["font-size"].as<uint16_t>());
            ext.textColours(hexToUint32(params["fg-colour"].as<std::string>()),
                            hexToUint32(params["bg-colour"].as<std::string>()));
        }

        ext.data(data);

        const PayloadFormat::Enum outFormat = 0 != params.count("binary") ?
            PayloadFormat::bin : PayloadFormat::hex;

        writePayload(std::cout, ext.serialise(), outFormat);

        return EXIT_SUCCESS;

    }
    catch(const po::error& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
        usage(argv[0], std::cerr);
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
        // TODO: oddly on MIPSEL despite the catch clause for po::error above we
        // end up here
        usage(argv[0], std::cerr);
    }
    catch(...)
    {
        std::cerr << "Unknown error\n";
    }

    return EXIT_FAILURE;
}
