/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_API_OSID_CONSTANTS_H_
#define NICKEL_ONSCREENID_SYSTEM_API_OSID_CONSTANTS_H_

#include <stdint.h>

namespace Zinc {
namespace OnScreenId {

/*
 * See YouView "IP Channels" (rev. 0.6), Annex F, section F.2:
 *
 *     The YouView Device shall be able to processes up to two
 *     YouViewIDExtension structures in a single SAS. This allows the
 *     association of 0, 1 or 2 OSIDs with a particular IP Channel as made
 *     accessible to a particular user.
 */
const unsigned MAX_ALLOWED_IDS_PER_SESSION = 2;

/*
 * See YouView "IP Channels" (rev. 0.6), Annex F, section F.3:
 *
 *     [...] text string shall have a maximum length of 30 characters.
 */

const unsigned MAX_ALLOWED_TEXT_LENGTH = 30;

/*
 * See YouView "IP Channels" (rev. 0.6), Annex F, section F.3:
 *
 *     Text shall be rendered by the YouView Device onto a RGBA 32-bit surface
 *     using the fixed foreground colour #FF909090 (ARGB) "safe white", the
 *     fixed background colour #00000000 (ARGB) "transparent" [...]
 */

const uint32_t DEFAULT_TEXT_FOREGROUND_COLOUR_ARGB = 0xFF909090;
const uint32_t DEFAULT_TEXT_BACKGROUND_COLOUR_ARGB = 0x00000000;

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_API_OSID_CONSTANTS_H_
