/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "SasExtension.h"

#include "osid-constants.h"
#include "osid-misc.h"

#include <boost/filesystem/path.hpp>
#include <boost/program_options.hpp>

#include <cstdlib>
#include <iostream>
#include <stdexcept>

namespace po = boost::program_options;

po::options_description getProgramOptions()
{
    po::options_description options("options");
    options.add_options()
        ("help", "Print this message")

        ("hex,h", "Whether the input is in hexadecimal format")
        ;

    return options;
}

po::variables_map parseArgs(int argc, char* argv[])
{
    po::options_description cmdOptions = getProgramOptions();
    cmdOptions.add_options()
        ("input-file", po::value<std::vector<std::string> >(), "input file");

    po::positional_options_description p;
    p.add("input-file", -1);

    po::variables_map params;
    po::store(po::command_line_parser(argc, argv).
              options(cmdOptions).positional(p).run(), params);
    po::notify(params);

    return params;
}

void usage(const char* const argv0, std::ostream& out)
{
    const boost::filesystem::path execPath(argv0);
    const std::string exec = execPath.leaf();

    out
        << "Validate SAS YouView extension payload\n\n"
        << "Usage:\n"
        << "  " << exec << " [options] [<file>]\n\n"
        << getProgramOptions() << '\n'
        << "\n\n";

    out
        << "Examples:\n"
        << "  <other tool> | " << exec << " --hex\n"
        << "  " << exec << " /tmp/sas-ext1\n"
        ;
}

int main(int argc, char* argv[])
{
    using namespace ::Zinc::OnScreenId;

    try
    {
        const po::variables_map params = parseArgs(argc, argv);

        if (0 != params.count("help"))
        {
            usage(argv[0], std::cout);
            return EXIT_SUCCESS;
        }

        const PayloadFormat::Enum inFormat = 0 != params.count("hex") ?
            PayloadFormat::hex : PayloadFormat::bin;

        const std::vector<uint8_t> payload = 0 != params.count("input-file") ?
            readFilePayload(
                params["input-file"].as<std::vector<std::string> >()
                                    .at(0).c_str(),
                inFormat) :
            readPayload(std::cin, inFormat);

        SasExtension ext;
        SasExtensionParseResult::Enum result = ext.parse(payload);
        if (SasExtensionParseResult::ok != result)
        {
            std::cerr << "Parsing failed: "
                      << enum_to_string(result) << '\n';
            return EXIT_FAILURE;
        }

        std::cout
            << "critical  : " << ext.critical() << '\n'
            << "reference : " << static_cast<uint16_t>(ext.reference()) << '\n'
            << "type      : " << enum_to_string(ext.type()) << '\n'
            << "mode      : " << enum_to_string(ext.mode()) << '\n'
            << "size      : " << ext.size().first << " x "
            << ext.size().second << '\n'
            << "position  : " << ext.position().first << " x "
            << ext.position().second << '\n'

            << "fg colour : " << std::hex << ext.textColours().first << '\n'
            << "bg colour : " << std::hex << ext.textColours().second << '\n'
            << std::dec

            << "font size : " << static_cast<uint16_t>(ext.fontSize()) << '\n'
            << "data      : " << ext.data() << '\n'
            ;

        if (SasExtensionType::text == ext.type() &&
            MAX_ALLOWED_TEXT_LENGTH < ext.data().size())
        {
            std::cerr
                << "\nError: Text data too long: " << ext.data().size()
                << " (" << MAX_ALLOWED_TEXT_LENGTH << " allowed)\n";
            return EXIT_FAILURE;
        }

        return EXIT_SUCCESS;

    }
    catch(const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
    }
    catch(...)
    {
        std::cerr << "Unknown error\n";
    }

    return EXIT_FAILURE;
}
