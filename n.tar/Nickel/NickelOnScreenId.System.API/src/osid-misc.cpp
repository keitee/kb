/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "osid-misc.h"

#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/bind.hpp>

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <sstream>
#include <stdexcept>

namespace Zinc {
namespace OnScreenId {

namespace {

inline bool isHex(const std::string& s)
{
    return boost::all(s, boost::is_xdigit());
}

uint8_t htoi(const char c)
{
    if ('0' <= c && c <= '9') { return c - '0'; }
    else if ('a' <= c && c <= 'f') { return 10 + c - 'a'; }
    else if ('A' <= c && c <= 'A') { return 10 + c - 'A'; }

    throw std::invalid_argument("Not hexadecimal data");
}

template<typename T>
std::vector<T> readPayloadAny(std::istream& in)
{
    std::vector<T> payload;
    std::copy(
        std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>(),
        std::back_inserter(payload));

    return payload;
}

std::vector<uint8_t> readPayloadHex(std::istream& in)
{
    std::vector<char> payload = readPayloadAny<char>(in);

    // get rid of spaces first
    payload.erase(std::remove_if(payload.begin(), payload.end(),
                                 boost::is_space()),
                  payload.end());

    // complain if not hex input
    if (!boost::all(payload, boost::is_xdigit()))
    {
        throw std::invalid_argument("Not a hex input");
    }

    // ignore odd byte, this is consistent with `xxd -r -p`
    if (0 != payload.size() % 2)
    {
        payload.pop_back();
    }

    // convert
    std::vector<uint8_t> result;
    for (std::vector<uint8_t>::size_type i = 0, end = payload.size();
         i < end; i += 2)
    {
        result.push_back(htoi(payload[i]) << 4 | htoi(payload[i + 1]));
    }

    return result;
}

} // namespace

uint32_t hexToUint32(const std::string& s)
{
    if (8 != s.size() || !isHex(s))
    {
        throw std::invalid_argument(
            "The value is not of the AARRGGBB hexadecimal format: " + s);
    }

    std::istringstream istr(s);
    istr.exceptions(std::ios::failbit | std::ios::badbit);

    uint32_t v;
    istr >> std::hex >> v;

    return v;
}

std::vector<uint8_t> readPayload(std::istream& in,
                                 const PayloadFormat::Enum inFormat)
{
    return PayloadFormat::hex == inFormat ?
        readPayloadHex(in) : readPayloadAny<uint8_t>(in);
}

std::vector<uint8_t> readFilePayload(const char* const fileName,
                                     const PayloadFormat::Enum inFormat)
{
    std::ifstream istr(fileName, std::ios::binary);
    if (!istr.is_open())
    {
        throw std::runtime_error(
            "Cannot open file for reading: " + std::string(fileName));
    }

    return PayloadFormat::hex == inFormat ?
        readPayloadHex(istr) : readPayload(istr);
}

std::vector<std::vector<uint8_t> > readAllPayloads(
    const char* const* argFrom, const char* const* argTo,
    const PayloadFormat::Enum inFormat)
{
    std::vector<std::vector<uint8_t> > payloads;

    if (argFrom == argTo)
    {
        payloads.push_back(readPayload(std::cin));
    }
    else
    {
        std::transform(
            argFrom, argTo, std::back_inserter(payloads),
            boost::bind(readFilePayload, _1, inFormat));
    }

    return payloads;
}

void writePayload(
    std::ostream& out, const std::vector<uint8_t>& payload,
    const PayloadFormat::Enum outFormat)
{
    if (PayloadFormat::hex == outFormat)
    {
        const std::ios::fmtflags fmt = out.flags(std::ios::hex);
        const std::ostream::char_type c = out.fill('0');

        for (size_t i = 0; i < payload.size(); ++i)
        {
            out << std::setw(2) << static_cast<uint32_t>(payload[i]);
        }

        out.fill(c);
        out.flags(fmt);
    }
    else
    {
        out.write(
            reinterpret_cast<const char*>(payload.data()), payload.size());
    }
}

} // namespace OnScreenId
} // namespace Zinc
