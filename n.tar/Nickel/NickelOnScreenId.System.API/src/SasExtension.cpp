/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include "SasExtension.h"

#include <glib.h>

#include <cstring>
#include <stdexcept>
#include <sstream>

namespace Zinc {
namespace OnScreenId {

namespace {

// as specified in 0018-S, Annex F
const char YV_SAS_EXT_TYPE[] = { 'y', 'v', 'i', 'd' };
const uint32_t YV_SAS_EXT_TYPE_SIZE =
    sizeof YV_SAS_EXT_TYPE / sizeof YV_SAS_EXT_TYPE[0];

// use function overloading to pick the right function
void htobe(uint16_t& v) { v = GUINT16_TO_BE(v); }
void htobe(uint32_t& v) { v = GUINT32_TO_BE(v); }

void betoh(uint16_t& v) { v = GUINT16_FROM_BE(v); }
void betoh(uint32_t& v) { v = GUINT32_FROM_BE(v); }

} // namespace

struct SasExtension::Impl
{

  /*
   * Plain Old Data structure that represents the definition of the SAS
   * extension payload structure in 0018-S, Annex F.
   *
   * Since this structure doesn't have any optional fields and despite the last
   * chunk of data is of varying size, it's tempting to map it directly onto the
   * payload and apply endianess conversions where required.  For this reason we
   * need to ensure there's no additional alignment applied.  Unfortunately the
   * definition in the spec doesn't introduced some misalignment(see
   * `textFontSize` field bumped in between nicely aligned fields) and we have
   * to enforce 1-byte alignment.
   */
#pragma pack(push, 1)
    struct Pod
    {
        template<typename T>
        struct Field
        {
            typedef T Pod::*type;
        };

        uint32_t size;
        int8_t type[YV_SAS_EXT_TYPE_SIZE];

        int8_t criticalFlag;

        uint8_t identifierReference;
        uint8_t identifierType;
        uint8_t displayMode;

        uint16_t displayWidth;
        uint16_t displayHeight;
        uint16_t defaultDisplayX;
        uint16_t defaultDisplayY;

        uint8_t textFontSize;
        uint32_t textFgColour;
        uint32_t textBgColour;

        template<typename T, size_t N> void toBe(T(&fields)[N])
        {
            for (size_t i = 0; i < sizeof fields / sizeof fields[0]; ++i)
            {
                htobe(this->*fields[i]);
            }
        }

        template<typename T, size_t N> void fromBe(T(&fields)[N])
        {
            for (size_t i = 0; i < sizeof fields / sizeof fields[0]; ++i)
            {
                betoh(this->*fields[i]);
            }
        }

    } pod;
#pragma pack(pop)

    std::string data;

    static
    Pod::Field<uint16_t>::type fields16[];

    static
    Pod::Field<uint32_t>::type fields32[];
};

SasExtension::Impl::Pod::Field<uint16_t>::type
SasExtension::Impl::fields16[] = {
    &Pod::displayWidth,
    &Pod::displayHeight,
    &Pod::defaultDisplayX,
    &Pod::defaultDisplayY
};

SasExtension::Impl::Pod::Field<uint32_t>::type
SasExtension::Impl::fields32[] = {
    &Pod::size,
    &Pod::textFgColour,
    &Pod::textBgColour
};

SasExtension::SasExtension() : pImpl(new Impl)
{
    std::memset(&pImpl->pod, 0, sizeof(Impl::Pod));

    pImpl->pod.size = sizeof(Impl::Pod);
    std::memcpy(pImpl->pod.type, YV_SAS_EXT_TYPE, YV_SAS_EXT_TYPE_SIZE);
}

SasExtension::SasExtension(const SasExtension& other) :
    pImpl(new Impl(*other.pImpl))
{
}

SasExtension& SasExtension::operator=(const SasExtension& other)
{
    *pImpl = *other.pImpl;
    return *this;
}

SasExtensionParseResult::Enum SasExtension::parse(
    const std::vector<uint8_t>& payload)
{
    // see if it makes sense to look into this payload at all
    if (payload.size() < sizeof(Impl::Pod))
    {
        return SasExtensionParseResult::bad_size;
    }

    // ok, let's give it a try
    Impl::Pod pod(*reinterpret_cast<const Impl::Pod*>(payload.data()));
    pod.fromBe(Impl::fields16);
    pod.fromBe(Impl::fields32);

    // the size of the payload should match
    if (pod.size != payload.size())
    {
        return SasExtensionParseResult::bad_size;
    }

    // the type of the payload should be as expected
    if (0 != std::memcmp(pod.type, YV_SAS_EXT_TYPE, YV_SAS_EXT_TYPE_SIZE))
    {
        return SasExtensionParseResult::bad_payload_type;
    }

    if (!NS_ZINC::validate<SasExtensionType::Enum>(pod.identifierType))
    {
        return SasExtensionParseResult::bad_type;
    }

    if (!NS_ZINC::validate<SasExtensionMode::Enum>(pod.displayMode))
    {
        return SasExtensionParseResult::bad_mode;
    }

    // see if it's a valid UTF-8 string
    if (!g_utf8_validate(reinterpret_cast<const gchar*>(payload.data() +
                                                        sizeof(Impl::Pod)),
                         payload.size() - sizeof(Impl::Pod), NULL))
    {
        return SasExtensionParseResult::bad_data;
    }

    // now deal with the attached data
    const std::string text(payload.begin() + sizeof(Impl::Pod), payload.end());

    // accept the attached data
    data(text);

    // accept the extension
    pImpl->pod = pod;

    return SasExtensionParseResult::ok;
}

std::vector<uint8_t> SasExtension::serialise() const
{
    std::vector<uint8_t> payload(pImpl->pod.size);

    Impl::Pod &pod = *new(payload.data()) Impl::Pod(pImpl->pod);
    pod.toBe(Impl::fields16);
    pod.toBe(Impl::fields32);

    std::copy(
        pImpl->data.begin(), pImpl->data.end(),
        payload.begin() + sizeof(Impl::Pod));

    return payload;
}

void SasExtension::critical(const bool flag)
{
    pImpl->pod.criticalFlag = flag;
}

bool SasExtension::critical() const
{
    return pImpl->pod.criticalFlag;
}

void SasExtension::reference(const uint8_t value)
{
    pImpl->pod.identifierReference = value;
}

uint8_t SasExtension::reference() const
{
    return pImpl->pod.identifierReference;
}

void SasExtension::type(const SasExtensionType::Enum value)
{
    pImpl->pod.identifierType = value;
}

SasExtensionType::Enum SasExtension::type() const
{
    return static_cast<SasExtensionType::Enum>(pImpl->pod.identifierType);
}

void SasExtension::mode(SasExtensionMode::Enum value)
{
    pImpl->pod.displayMode = value;
}

SasExtensionMode::Enum SasExtension::mode() const
{
    return static_cast<SasExtensionMode::Enum>(pImpl->pod.displayMode);
}

void SasExtension::size(const uint16_t width, const uint16_t height)
{
    pImpl->pod.displayWidth = width;
    pImpl->pod.displayHeight = height;
}

std::pair<uint16_t, uint16_t> SasExtension::size() const
{
  return std::make_pair(pImpl->pod.displayWidth, pImpl->pod.displayHeight);
}

void SasExtension::position(const uint16_t x, const uint16_t y)
{
    pImpl->pod.defaultDisplayX = x;
    pImpl->pod.defaultDisplayY = y;
}

std::pair<uint16_t, uint16_t> SasExtension::position() const
{
    return
        std::make_pair(pImpl->pod.defaultDisplayX, pImpl->pod.defaultDisplayY);
}

void SasExtension::textColours(
    const uint32_t foreground, const uint32_t background)
{
    pImpl->pod.textFgColour = foreground;
    pImpl->pod.textBgColour = background;
}

std::pair<uint32_t, uint32_t> SasExtension::textColours() const
{
    return std::make_pair(pImpl->pod.textFgColour, pImpl->pod.textBgColour);
}

void SasExtension::fontSize(const uint8_t value)
{
    pImpl->pod.textFontSize = value;
}

uint8_t SasExtension::fontSize() const
{
    return pImpl->pod.textFontSize;
}

void SasExtension::data(const std::string& value)
{
    pImpl->data = value;
    pImpl->pod.size = sizeof(Impl::Pod) + value.size();
}

std::string SasExtension::data() const
{
    return pImpl->data;
}

} // namespace OnScreenId
} // namespace Zinc
