/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "Factory.h"

#include "osid-constants.h"
#include "RendererImpl.h"

namespace Zinc {
namespace OnScreenId {

Factory::~Factory()
{
}

boost::shared_ptr<RendererAsync> Factory::createRenderer(
    const boost::shared_ptr<NS_ZINC::FutureDispatcher>& dispatcher) const
{
    return Zinc::OnScreenId::createRenderer(MAX_ALLOWED_IDS_PER_SESSION,
                                            createImageDownloader(dispatcher),
                                            createRenderEngine());
}

} // namespace OnScreenId
} // namespace Zinc
