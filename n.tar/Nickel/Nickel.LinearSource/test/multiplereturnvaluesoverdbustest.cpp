/*
 * MultipleReturnValuesOverDBus.cpp
 *
 *  Created on: 4 Oct 2012
 *      Author: mariusz.buras@youview.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#include "../include/macros.h"
#include "test/testbank.h"
#include "../src/LinearSourceFactoryImpl.h"
#include "../src/LinearSourceFactoryDBusClient.h"
#include "src/FactoryDBusToSyncAndAsync.h"
#include "src/ControlDBusToSyncAndAsync.h"
#include "src/FactoryAsyncToDBus.h"
 
#include "src/bus-name.h"

#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/CppUnit.h>

#include <zinc-binding-runtime/dbus/NonInheritingAdaptorFactory.h>
#include <zinc-binding-runtime/dbus/RefCountedAdaptor.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>
#include <zinc-common/testsupport/TestRunner.h>

#include <dbus-c++/connection.h>
#include <dbus-c++/dispatcher.h>
#include <dbus-c++/eventloop-integration.h>

#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/make_shared.hpp>

#include <gst/gst.h>

/**
 */

// keep test bank global until I can figure out a better way of passing it into tests
TestBank::Sources sources;

int main(int argc, char* argv[]) 
{
    std::string mediaSources;
    NS_ZINC::TestRunner runner;

    boost::program_options::options_description suiteOpts("Test suite options");
    suiteOpts.add_options()
        ("media-sources", boost::program_options::value<std::string>(&mediaSources),
                       "File from which to load the test media URLs");

    runner.parseOptions(argc, argv, suiteOpts);

    sources = TestBank::loadTestBankFromFileOrDefaults ( mediaSources ) ;

    return runner.run();
}


NS_NICKEL_LINEARSOURCE_OPEN

/**
 */

using NS_ZINC_DBUS_BINDING::TestUsingDbus;
using namespace NS_ZINC;

class ZINC_LOCAL MultipleReturnValuesOverDBus : public IntegrationTestSandbox, public TestUsingDbus, public CppUnit::TestFixture
{
public:

    boost::thread t;
    boost::shared_ptr<DBus::BusDispatcher> busDispatcher;
    DBus::Connection conn1;
    DBus::Connection conn2;

    boost::shared_ptr< Zinc::Media::LinearSource::FactoryAsync > factoryAsync;
    boost::shared_ptr<NS_ZINC_DBUS_BINDING::BusNameMonitor> bnm;

    GMainLoop*      loop;
    boost::thread   gstThread;

    MultipleReturnValuesOverDBus()
    {

    }

    // TODO: create a mock system implementation instead of the real one

    virtual void setUp()
    {
        busDispatcher = boost::make_shared<DBus::BusDispatcher>();

        DBus::StandardConnectionFactory fact(busDispatcher);
        conn1 = fact.connectToSessionBus();
        bnm = boost::make_shared<NS_ZINC_DBUS_BINDING::BusNameMonitor> (conn1);

        // It's not usually a good idea to use an inline dispatcher but in this case the dispatcher passed to LauncherImpl
        // will never be used as the only client of LauncherImpl is DBus and our bindings take pains to ensure all callbacks
        // happen on the DBus dispatcher thread anyway.
        boost::shared_ptr<NS_ZINC::Dispatcher> futureDispatcher = boost::make_shared<NS_ZINC::SingleThreadDispatcher>();

        boost::shared_ptr<Factory> factory = createLinearSourceFactory(
            *futureDispatcher, 200000000, "YouView",32000);

        Zinc::Media::LinearSource::expose(conn1, NS_NICKEL_LINEARSOURCE::OBJECT_PATH_FACTORY, factory,
            boost::make_shared<NS_ZINC_DBUS_BINDING::NonInheritingAdaptorFactory<Zinc::Media::LinearSource::Control> >(
                NS_ZINC_DBUS_BINDING::RefCountedAdaptorFactory<Zinc::Media::LinearSource::Control>(*bnm), conn1, NS_NICKEL_LINEARSOURCE::OBJECT_PATH_CONTROL));

        conn1.request_name(NS_NICKEL_LINEARSOURCE::BUS_NAME);

        // --------------------------------------------------------------------------

        conn2 = fact.connectToSessionBus();
        factoryAsync = createLinearSourceFactoryDBusClient( futureDispatcher, conn2);

        // --------------------------------------------------------------------------

        t = boost::thread( boost::bind( &DBus::BusDispatcher::run, busDispatcher ) );

        gst_init ( NULL, NULL );
        loop = g_main_loop_new (NULL, FALSE);
        boost::thread(g_main_loop_run, loop).swap(gstThread);
    }

    virtual void tearDown()
    {
        busDispatcher->leave();
        t.join();
        conn1.close();
        conn2.close();

        gst_deinit();
    }

    void test_IfCanReceiveFileDescriptorsAsMultipleReturnValue()
    {
        boost::tuple< boost::shared_ptr<Zinc::Media::LinearSource::Control>, ::DBus::UnixFD, ::DBus::UnixFD > ret;
        ret = factoryAsync->create( sources.TS_LICENCE_FREE , 0 ).get();
        CPPUNIT_ASSERT(ret.get<1>().get() >= 0);
        CPPUNIT_ASSERT(ret.get<2>().get() >= 0);
    }


private:

    CPPUNIT_TEST_SUITE(MultipleReturnValuesOverDBus);
    CPPUNIT_TEST(test_IfCanReceiveFileDescriptorsAsMultipleReturnValue);
    CPPUNIT_TEST_SUITE_END();

};


CPPUNIT_TEST_SUITE_REGISTRATION(MultipleReturnValuesOverDBus);

NS_NICKEL_LINEARSOURCE_CLOSE

