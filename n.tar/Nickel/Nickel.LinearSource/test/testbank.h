/*
 * testbank.h
 *
 *  Created on: 5 Nov 2012
 *      Author: mariusz.buras@youview.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_TESTBANK_H_
#define NICKEL_TESTBANK_H_


#include <string>

namespace TestBank
{
// Will be filled in from a configuration file or by defaults
struct Sources {

    std::string TS_5_SECS;
    std::string TS_30_SECS;
    std::string TS_10_MINS;
    std::string MPG_10_MINS;
    std::string TS_15_MINS;
    std::string TS_10_MINS_ENCRYPTED;
    std::string TS_2_HOURS;
    std::string RTMP_30_SECS;
    std::string RTMP_5_SECS;
    std::string RTMP_15_MINS;
    std::string RTMP_ABR_800;
    std::string RTMP_ABR_1500;
    std::string RTMP_ABR_2800;
    std::string RTMP_TIMING_APP;
    std::string RTMP_AAC_AUDIO;
    std::string ASSET_MISSING;
    std::string HTTP_400_ERROR_RESPONSE;
    std::string HTTP_504_ERROR_RESPONSE;
    std::string MALFORMANT_URL;
    std::string TTML_EN_10_MINS;
    std::string TTML_EN;
    std::string TTML_CY;
    std::string TTML_GD;
    std::string TTML_GA;
    std::string TS_LICENCE_FREE;
    std::string SDP_CLOUD_GEO;
};

/*
 * Return an struct containg URL's of the test assets.
 * mediaSourcesFile points to an optional file with test assets URL's.
 * This way it's possible to change test assets without actually 
 * altering the test code. Can be handy in certain cases.
 * 
 */

Sources loadTestBankFromFileOrDefaults ( const std::string& mediaSourcesFile  ) ;

} // namespace TestBank

#endif // NICKEL_TESTBANK_H_
