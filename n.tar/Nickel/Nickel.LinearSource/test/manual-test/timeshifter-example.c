#include <gst/gst.h>

#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct {
  GMainLoop *loop;
  GstElement *pipeline;
} AppData;

static GstElement *
yv_get_element_by_name (GstElement *pipeline,
                        gchar      *name)
{
  GstElement *element = gst_bin_get_by_name (GST_BIN (pipeline), name);
  if (!element) {
    g_warning ("Failed to get '%s' element by name\n", name);
  }

  return element;
}

static gboolean
yv_set_sink_decoders (GstElement   *pipeline,
                      const GValue *streams)
{
  guint i, nbstreams;

  guint video = 0;
  guint audio = 0;

  nbstreams = gst_value_list_get_size (streams);
  for (i = 0; i < nbstreams && (!video || !audio); ++i) {
    guint type;
    const GValue *value = gst_value_list_get_value (streams, i);
    GstStructure *stream = g_value_get_boxed (value);

    if (!gst_structure_get_uint (stream, "stream-type", &type)) {
      continue;
    }

    // Yes, it's primitive. This part is a toy for testing anyway
    // so first stream is assumed to be video and the second one audio.
    // Left as a loop if someone fancies to put more discovery logic here.
    if (!gst_structure_get_uint (stream, "pid", !video ? &video : &audio)) {
      continue;
    }
  }

  if (audio && video) {
    GstElement *nx;

    g_message ("Found audio/video streams (primitive method): %u, %u",
               audio,
               video);

    // It's still possible to set audio/video PIDs on the command line as long
    // as the nexussink element is *not* named "nexus" (otherwise it's picked up
    // by the code below).
    nx = gst_bin_get_by_name (GST_BIN (pipeline), "nexus");
    if (!nx) {
      g_warning ("Could not find nexussink element, name=nexus");
      g_warning ("Will skip setting audio/video PIDs");

      return TRUE;
    }

    g_object_set (nx, "audiopid", audio, "videopid", video, NULL);
    gst_object_unref (GST_OBJECT (nx));
  } else {
    g_warning ("No audio/video streams detected");
  }

  return TRUE;
}

static gboolean
yv_tune_programme (GstElement *pipeline,
                   GstMessage *msg)
{
  guint pcr_pid;

  const GstStructure *gs = gst_message_get_structure (msg);
  const GValue *streams = NULL;

  if (!gst_structure_has_field (gs, "streams")) {
    g_printerr ("Missing streams structure in PMT\n");
    return FALSE;
  }

  streams = gst_structure_get_value (gs, "streams");
  if (!streams) {
    g_printerr ("Cannot get streams structure from PMT\n");
    return FALSE;
  }

  if (!yv_set_sink_decoders (pipeline, streams)) {
    g_printerr ("Failed to set up sink decoder streams\n");
    return FALSE;
  }

  return TRUE;
}

static gboolean
bus_call (GstBus     *bus,
          GstMessage *msg,
          gpointer    data)
{
  AppData *app_data = (AppData *) data;

  switch (GST_MESSAGE_TYPE (msg)) {

    case GST_MESSAGE_EOS:
      g_message ("End of stream");
      g_main_loop_quit (app_data->loop);
      break;

    case GST_MESSAGE_ERROR: {
      gchar  *debug;
      GError *error;

      gst_message_parse_error (msg, &error, &debug);

      g_printerr ("Error: %s\n\t%s\n",
                  GST_STR_NULL (error->message),
                  GST_STR_NULL (debug));
      g_error_free (error);
      g_free (debug);

      g_main_loop_quit (app_data->loop);
      break;
    }

    case GST_MESSAGE_ELEMENT:
      if (gst_message_has_name (msg, "pmt") &&
            !yv_tune_programme (app_data->pipeline, msg)) {

          g_printerr ("Failed to tune programme\n");
          g_main_loop_quit (app_data->loop);
      }
      break;

    default:
      break;
  }

  return TRUE;
}

static gboolean
yv_seek (GstElement *pipeline,
         gint64      seek_to)
{
  gint64 position;
  if (gst_element_query_position (pipeline,
                                  GST_FORMAT_TIME,
                                  &position)) {
    g_message ("Position: %" GST_TIME_FORMAT, GST_TIME_ARGS (position));
  }

  g_message ("Seeking to %" GST_TIME_FORMAT, GST_TIME_ARGS (seek_to));
  return gst_element_seek (pipeline,
                           1.0, GST_FORMAT_TIME,
                           GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE,
                           GST_SEEK_TYPE_SET, seek_to,
                           GST_SEEK_TYPE_NONE, 0);
}

static gboolean
yv_io_callback (GIOChannel   *io,
                GIOCondition  condition,
                gpointer      data)
{
  gchar in;

  AppData *app_data = (AppData *) data;
  GError *error = NULL;

  switch (g_io_channel_read_chars (io, &in, 1, NULL, &error)) {

    case G_IO_STATUS_NORMAL:
      if ('0' <= in && in <= '9') {
        if (!yv_seek (app_data->pipeline, (in - '0') * GST_SECOND * 60)) {
          g_warning ("Seek failed");
        }
      } else if ('q' == in) {
        g_main_loop_quit (app_data->loop);
        return FALSE;
      } else if ('p' == in) {
        gst_element_set_state (app_data->pipeline, GST_STATE_PAUSED);
        return TRUE;
      } else if ('r' == in) {
        gst_element_set_state (app_data->pipeline, GST_STATE_PLAYING);
        return TRUE;
      }

      return TRUE;

    case G_IO_STATUS_ERROR:
      g_printerr ("IO error: %s\n", error->message);
      g_error_free (error);

      return FALSE;

    case G_IO_STATUS_EOF:
      g_warning ("No input data available");
      return TRUE;

    case G_IO_STATUS_AGAIN:
      return TRUE;

    default:
      break;
  }

  g_return_val_if_reached (FALSE);
  return FALSE; // suppress the warning
}

static gboolean
yv_options_parse (int              *argc,
                  char           ***argv,
                  GOptionEntry     *entries,
                  GOptionContext  **ctx)
{
  GError *error;

  *ctx = g_option_context_new ("timeshifter example");
  g_option_context_add_main_entries (*ctx, entries, NULL);
  g_option_context_add_group (*ctx, gst_init_get_option_group ());

  error = NULL;
  if (!g_option_context_parse (*ctx, argc, argv, &error)) {
    g_printerr ("Failed to initialize: %s\n", error->message);

    g_error_free (error);
    g_option_context_free (*ctx);
    *ctx = NULL;

    return FALSE;
  }

  return TRUE;
}

int
main (int   argc,
      char *argv[])
{
  GOptionContext *ctx = NULL;
  
  guint64 ring_buffer_size = 32 * 1024 * 1024;
  gchar *allocator_file_template = "/tmp/file-mem-alloc-XXXXXX";
  
  GOptionEntry entries[] = {
    { "cache-size", 'c', 0, G_OPTION_ARG_INT64, &ring_buffer_size,
      "a ring buffer size used in the timeshifter", NULL },
    { "temp-template", 't', 0, G_OPTION_ARG_STRING, &allocator_file_template,
      "a template for a temporary file name to use "
      "as a storage for the ring buffer", NULL },
    { NULL }
  };

  GError *error = NULL;

  AppData data = { NULL, NULL };

  GIOChannel *io = NULL;

  GstBus *bus = NULL;
  guint bus_watch_id = -1, io_watch_id = -1;

  int ret = EXIT_FAILURE;

  gchar **argvn = NULL;

  /* we must initialise the threading system before using any
   * other GLib function, such as g_option_context_new() */
  if (!g_thread_supported ()) {
    g_thread_init (NULL);
  }

  g_return_val_if_fail (
    yv_options_parse (&argc, &argv, entries, &ctx),EXIT_FAILURE);
  gst_init (&argc, &argv);

  /* make a null-terminated version of argv */
  argvn = g_new0 (char *, argc);
  memcpy (argvn, argv + 1, sizeof (char *) * (argc - 1));
  {
    data.pipeline =
        (GstElement *) gst_parse_launchv ((const gchar **) argvn, &error);
  }
  g_free (argvn);

  if (!data.pipeline) {
    g_printerr ("ERROR: pipeline could not be constructed: %s\n",
                error ? GST_STR_NULL (error->message) : "(unknown error)");
    goto untergang;
  } else if (error) {
    g_printerr ("Erroneous pipeline: %s\n", GST_STR_NULL (error->message));
    goto untergang;
  }

  data.loop = g_main_loop_new (NULL, FALSE);

  // bus callback
  bus = gst_pipeline_get_bus (GST_PIPELINE (data.pipeline));
  bus_watch_id = gst_bus_add_watch (bus, bus_call, &data);
  gst_object_unref (GST_OBJECT (bus));

  // standard input callback
  io = g_io_channel_unix_new (STDIN_FILENO);
  io_watch_id = g_io_add_watch (io, G_IO_IN, yv_io_callback, &data);
  g_io_channel_unref (io);

  g_message ("Running...");
  if (GST_STATE_CHANGE_FAILURE == gst_element_set_state (data.pipeline,
                                                         GST_STATE_PLAYING)) {
    g_printerr ("Failed to play the pipeline\n");
    goto untergang;
  }

  g_main_loop_run (data.loop);

  g_message ("Returned, stopping playback");
  if (GST_STATE_CHANGE_FAILURE == gst_element_set_state (data.pipeline,
                                                         GST_STATE_NULL)) {
    g_printerr ("Failed to stop the pipeline\n");
    goto untergang;
  }

  ret = EXIT_SUCCESS;

untergang:
  if (-1 != bus_watch_id) g_source_remove (bus_watch_id);
  if (data.pipeline) gst_object_unref (GST_OBJECT (data.pipeline));
  if (error) g_error_free (error);
  if (data.loop) g_main_loop_unref (data.loop);

  return ret;
}

