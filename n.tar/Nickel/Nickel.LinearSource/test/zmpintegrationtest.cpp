/*
 * zmpintegrationtest.cpp
 *
 *  Created on: 4 Oct 2012
 *      Author: mariusz.buras@youview.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#include "test/testbank.h"
#include "../include/macros.h"
#include "Control.h"
#include "src/LinearSourceFactoryImpl.h"
#include "../include/MockControlEventListener.h"
#include "../src/LinearSourceFactoryDBusClient.h"
#include <zinc-common/testsupport/TestRunner.h>

#include "src/bus-name.h"
#include "../zmp/zmp.h"

#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/async/Promise.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>

#include <zinc-binding-runtime/dbus/NonInheritingAdaptorFactory.h>
#include <zinc-binding-runtime/dbus/RefCountedAdaptor.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>
#include <zinc-binding-runtime/dbus/detail/SingletonDBusErrorConverter.h>
#include <dbus-c++/connection.h>
#include <dbus-c++/dispatcher.h>
#include <dbus-c++/eventloop-integration.h>
#include <dbus-c++/testsupport/ScopedPid.h>
#include <zinc-common/testsupport/TestRunner.h>

#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <stdexcept>
#include <algorithm>

#include <boost/assert.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/function.hpp>
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/filesystem.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/format.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <gst/gst.h>
#include <glib.h>

using NS_ZINC_DBUS_BINDING::TestUsingDbus;
using namespace NS_ZINC;
using namespace Zinc::Media::LinearSource;
using Zinc::Media::ErrorEventValue;
using Zinc::Media::ErrorEventContext;
using boost::tuple;
using boost::tie;
using boost::lexical_cast;
using boost::shared_ptr;
using boost::bind;
using std::string;
using std::map;
using NS_ZINC::Future;
using NS_ZINC::FutureValue;

/**
 */

#define MB (1024*1024)

// keep test bank global until I can figure out a better way of passing it
// into tests

TestBank::Sources sources;

/*
 * Download a test asset.
 *
 * Because we need to get rid of the file after the test
 * it has to be external to the test because there's now clean
 * way to delete the file after all tests were executed.
 * At least I don't know of any. That's why I prefered to keep
 * downloadTestAsset and deleteTestAsset external to the test
 * itself event if I could download the asset in the test setup
 * once.
 */

std::string sourceAssetPath;

void downloadTestAsset();
void deleteTestAsset( );
int soakTest(const std::vector<std::string>& soakTestSDPFiles,
             const uint32_t flags);

#define LOG(x, ...) if (getenv("ZMP_TEST_VERBOSE")) {fprintf(stderr, x "\n", ##__VA_ARGS__ ); }
#define LOG_OSTREAM(...) if (getenv("ZMP_TEST_VERBOSE")) { std::cerr << __VA_ARGS__ << "\n"; }

int main(int argc, char* argv[])
{
    std::string mediaSources;
    std::string localAsset;
    NS_ZINC::TestRunner runner;
    std::vector<std::string> soakTestSDPFiles;
    bool soakBufering = false;
    int ret = 0;

    boost::program_options::options_description suiteOpts("Test suite options");
    suiteOpts.add_options()
        ("vqe-soak-test",
            boost::program_options::value<std::vector<std::string> >(
                &soakTestSDPFiles )->multitoken(),
            "Run VQE soak test")
        ("soak-buffering", boost::program_options::bool_switch(&soakBufering),
            "Whether to use timeshifter buffering when running soak tests")
        ("media-sources",
            boost::program_options::value<std::string>(&mediaSources),
            "File from which to load the test media URLs")
        ("local-asset", boost::program_options::value<std::string>(&localAsset),
            "A local asset to be used (useful when running/analysing tests by "
            "hand)");

    runner.parseOptions(argc, argv, suiteOpts);

    if ( !soakTestSDPFiles.empty() )
    {
        uint32_t soakFlags = 0;
        if (soakBufering)
        {
            soakFlags |= CONTROL_FLAG_WITH_TIMESHIFTER;
        }

        ret = soakTest( soakTestSDPFiles, soakFlags );
    }
    else
    {
        sources = TestBank::loadTestBankFromFileOrDefaults(mediaSources);

        if (localAsset.empty())
        {
            downloadTestAsset();
        }
        else
        {
            sourceAssetPath = localAsset;
        }

        ret = runner.run();

        if (localAsset.empty())
        {
            deleteTestAsset( );
        }
    }
    return ret;
}

void downloadTestAsset()
{
    char templ[] = "/tmp/zmp-XXXXXX";
    BOOST_VERIFY(mkdtemp(templ));
    sourceAssetPath = std::string(templ) + "/source.ts";

    std::ostringstream acquireAssetCommandBuilder;

    acquireAssetCommandBuilder << "wget -q -O "
                        << sourceAssetPath
                        << " "
                        << sources.TS_LICENCE_FREE;

    const std::string acquireAssetCommand = acquireAssetCommandBuilder.str();

    fprintf(stderr, "Acquiring test asset:\n %s\n",
            acquireAssetCommand.c_str());

    if ( system ( acquireAssetCommand.c_str() ) )
    {
        fprintf(stderr, "Couldn't acquire test asset: %s\n",
                acquireAssetCommand.c_str());
        exit(EXIT_FAILURE);
    }
}

void deleteTestAsset( )
{
    fprintf( stderr, "removing: %s\n", sourceAssetPath.c_str() );
    boost::filesystem::remove( sourceAssetPath );
}

NS_NICKEL_LINEARSOURCE_OPEN

struct ZINC_LOCAL ZmpCallbacks
{
public:

    ZmpCallbacks ( boost::function<void()> stop_,
                     const std::string& outputPath_,
                        const size_t expectedFileSize_ ) :
        fileno ( 0 ),
            total_bytes_consumed ( 0 ),
                stop ( stop_ ),
                    outputPath ( outputPath_ ),
                        expectedFileSize ( expectedFileSize_ ),
                            pauseAtOffset ( 0 )
    {
        using namespace ::testing;

        ON_CALL(*this, onEvent(_, _, _, _))
            .WillByDefault(Invoke(this, &ZmpCallbacks::onEventDefault));
        ON_CALL(*this, onData(_, _))
            .WillByDefault(Invoke(this, &ZmpCallbacks::onDataDefault));
        ON_CALL(*this, onError(_, _, _))
            .WillByDefault(Invoke(this, &ZmpCallbacks::onErrorDefault));
    }

    static void on_event_cb(void *user_data, ZMPStream * stream,
                            ZMPEventHeader *header, size_t payload_bytes,
                            void *payload)
    {
        static_cast<ZmpCallbacks*>(user_data)->onEvent(
            stream, header, payload_bytes, payload);
    }

    MOCK_METHOD4(onEvent, void(ZMPStream *, ZMPEventHeader *, size_t, void *));

    void onEventDefault( ZMPStream *, ZMPEventHeader *header,
                 size_t, void *)
    {
        switch (header->event_type)
        {
        /* After receiving FLUSH_START we are guaranteed to not receive any data
           until NEW_SEGMENT */
        case ZMP_EVENT_FLUSH_START:
            LOG("ZMP_EVENT_FLUSH_START");
            break;
        case ZMP_EVENT_FLUSH_STOP:
            LOG("ZMP_EVENT_FLUSH_STOP");
            break;
        case ZMP_EVENT_SEGMENT:
        {
            if (!outputPath.empty())
            {
                std::stringstream new_filename;
                new_filename << outputPath << "segment-" << fileno++
                             << ".ts";
                out.reset(new std::ofstream(new_filename.str().c_str(),
                                            std::ios::binary));
                LOG("ZMP_EVENT_SEGMENT file: %s",
                    new_filename.str().c_str());
            }
            else
            {
                out.reset(new std::ofstream("/dev/null", std::ios::binary));
                LOG("ZMP_EVENT_SEGMENT file to /dev/null");
            }
        }
        break;

        case ZMP_EVENT_PORTION:
            LOG("ZMP_EVENT_PORTION");
            break;
        case GST_EVENT_EOS:
            LOG("GST_EVENT_EOS");
            out.reset ();
            stopOnce();

            break;
        default:
            fprintf(stderr, "Warning: Received unknown event %i (%i, %x).  "
                    "Ignoring.\n", header->event_type, header->event_type >> 8,
                    header->event_type & 0xFF);
        };
    }

    /*
     * Read as much data as you can without blocking (on either reading or
     * writing).  Return the number of bytes transferred or -errno on failure.
     */
    static ssize_t on_data_cb (void *user_data, ZMPStream *stream, int infd)
    {
        return static_cast<ZmpCallbacks*>(user_data)->onData( stream, infd );
    }

    MOCK_METHOD2(onData, ssize_t(ZMPStream *, int));

    ssize_t onDataDefault( ZMPStream *, int infd)
    {
        char buf[4096];
        int err;

        // stop receiving data from LSD

        if ( pauseAtOffset != 0 && pauseAtOffset <= total_bytes_consumed )
        {
            if ( pauseCallback )
            {
                pauseCallback();
                pauseCallback.clear();
            }

            errno = EAGAIN;
            return -1;
        }

        ssize_t bytes_read = read(infd, buf, sizeof(buf));
        err = errno;
        if (bytes_read > 0 && out)
        {
            out->write(buf, bytes_read);
            total_bytes_consumed += bytes_read;

            if ( isatty(2 /*stderr*/) && getenv("ZMP_TEST_VERBOSE") )
            {
                fprintf(stderr, "\e[s%zu\e[u", total_bytes_consumed);
            }
        }
        errno = err;

        if ( expectedFileSize != 0 && total_bytes_consumed >= expectedFileSize )
        {
            LOG("##### ZmpCallbacks: fetched %zu in total.",
                    total_bytes_consumed);

            out.reset ();
            stopOnce();
        }

        return bytes_read;
    }

    static void on_error_cb(void *user_data, ZMPStream *stream, int error,
                            char* desc)
    {
         static_cast<ZmpCallbacks*>(user_data)->onError( stream, error, desc );
    }


    MOCK_METHOD3(onError, void(ZMPStream *, int, char *));

    void onErrorDefault( ZMPStream *, int error, char* desc)
    {
        if (error == EPIPE)
        {
            LOG("EOF: exiting");
        }
        else
        {
            LOG("Received unexpected error %i - %s: %s", error,
                    strerror(error), desc);
        }
        stopOnce();
    }

    void stopOnce()
    {
        /* We reset the stop function here but we want to allow it to be set
           again from within the callback */
        boost::function<void()> sstop;
        sstop.swap(stop);
        if (sstop) {
            sstop();
        }
    }

    int                             fileno;
    boost::scoped_ptr<std::ofstream> out;
    size_t                          total_bytes_consumed;
    boost::function<void()>         stop;
    const std::string               outputPath;
    const size_t                    expectedFileSize;
    size_t                          pauseAtOffset;
    boost::function<void()>         pauseCallback;
};

// ---------------------------------------------------------------------------

class ZINC_LOCAL ZincMainloopDispatcher : public NS_ZINC::Dispatcher
{
public:
    explicit ZincMainloopDispatcher(DBus::DefaultMainLoop& d_) : d(d_) {}

    void post(boost::function<void (void)> fn)
    {
        d.post_function(fn);
    }

private:

    void onWorkAdded()
    {
        d.add_external_work();
    }
    void onWorkRemoved()
    {
        d.remove_external_work();
    }

    DBus::DefaultMainLoop& d;
};

// ---------------------------------------------------------------------------

static void nullDeletor(void*) {}

struct ZINC_LOCAL ZmpClient : boost::noncopyable
{
    DBus::DefaultMainLoop& mainloop;
    DBus::Connection conn;
    boost::shared_ptr<DBus::Dispatcher> dbusDispatcher;
    boost::shared_ptr<NS_ZINC::Dispatcher> zincDispatcher;
    boost::shared_ptr<ZmpCallbacks> zmpCallbacks;
    boost::shared_ptr<Control> control;

    ZMPStream* stream;
    DBus::UnixFD serialized_event_fd;
    DBus::UnixFD immediate_event_fd;
    DBus::DefaultWatch* watch;

    boost::shared_ptr<ControlEventListener> listenerMock;

    // call this when ZmpClient is destroyed
    boost::function<void()> onDestroyedCallback;

    ZmpClient(DBus::BusDispatcher& d, const std::string& dataPath,
              const size_t expectedFileSize,
              boost::shared_ptr<ControlEventListener> listenerMock_
                 = boost::shared_ptr<ControlEventListener>())
     : mainloop(d),
       dbusDispatcher(boost::shared_ptr<DBus::BusDispatcher>(&d, nullDeletor)),
       zincDispatcher(boost::make_shared<ZincMainloopDispatcher>(
           boost::ref(mainloop))), stream(NULL), watch(NULL),
       listenerMock(listenerMock_)
    {
        zmpCallbacks =
            boost::make_shared< ::testing::NiceMock<ZmpCallbacks> >(
                boost::bind(&ZmpClient::stop, this), dataPath,
                expectedFileSize);
        conn = DBus::StandardConnectionFactory(
            dbusDispatcher,
            NS_ZINC_DBUS_BINDING::SingletonDBusErrorConverter::get())
                .connectToSessionBus();
    }

    /*
     * start
     * =====
     *
     * Call start to create Control object in linear source and start
     * streaming the data into ZmpClient. uri and linearSourceFlags are
     * arguments for the LinearSource.Factory.create and onStart is an optional
     * callback called when we get through all async hoops and we are finally
     * ready.
     */
    void start(const std::string& uri, uint32_t linearSourceFlags)
    {
        boost::shared_ptr<FactoryAsync> factory =
            createLinearSourceFactoryDBusClient(zincDispatcher, conn);
        factory->create(uri, linearSourceFlags)
            .setCallback(*zincDispatcher,
                         boost::bind(&ZmpClient::onCreatedCallback, this, _1));
    }

    void start2(const std::string& uri,
                const std::map<std::string, DBus::Variant>& params)
    {
        createLinearSourceFactoryDBusClient(zincDispatcher, conn)
            ->create2(uri, params).setCallback(
                *zincDispatcher,
                boost::bind(&ZmpClient::onCreatedCallback, this, _1));
    }

    /*
     * onCreatedCallback
     * =================
     *
     * Called when async call to LinearSource.Factory.create is compleated.
     * In which case we want to start() the LinearSource.Control object.
     * But most importantly, zmp client stuff is initialised here.
     * Eventually LinearSource.Control.start() is called.
     */
    void onCreatedCallback(
        const FutureValue<tuple<shared_ptr<Control>, DBus::UnixFD,
                                DBus::UnixFD> >& v)
    {
        if (v.getError())
        {
            // TODO Fixme
            abort();
        }
        else
        {
            tie(control, serialized_event_fd, immediate_event_fd) = v.get();

            if ( listenerMock )
            {
                control->addListener( listenerMock );
            }

            stream = zmp_stream_new(serialized_event_fd.get(),
                                    immediate_event_fd.get());
            zmp_stream_set_callbacks(
                stream, zmpCallbacks.get(), &ZmpCallbacks::on_event_cb,
                &ZmpCallbacks::on_data_cb, &ZmpCallbacks::on_error_cb);
            const int zmp_fd = zmp_stream_get_listen_fd(stream);

            watch = mainloop.add_watch(zmp_fd, POLLIN,
                                       boost::bind(zmp_stream_notify, stream));

            control->start();
        }
    }

    NS_ZINC::Future<void> createControlOnly(const std::string& uri)
    {
        boost::shared_ptr<FactoryAsync> factory
            = createLinearSourceFactoryDBusClient(zincDispatcher, conn);
        return factory->create(uri, 0).then(
            *zincDispatcher,
            boost::bind(&ZmpClient::onCreatedControlOnlyCallback, this, _1));
    }

    void onCreatedControlOnlyCallback(
        const FutureValue<tuple<shared_ptr<Control>, DBus::UnixFD,
                                DBus::UnixFD> >& v)
    {
        if (v.getError())
        {
            // TODO Fixme
            abort();
        }
        else
        {
            boost::tie(control, serialized_event_fd, immediate_event_fd)
                = v.get();
            if ( listenerMock )
            {
                control->addListener( listenerMock );
            }
        }
    }

    ~ZmpClient()
    {
        destroy();
    }

    void stop()
    {
        if (control)
        {
            control->destroy()
                .setCallback(*zincDispatcher,
                             boost::bind(&ZmpClient::onDestroyed, this, _1));
        }
    }

    void onDestroyed (const NS_ZINC::FutureValue<void>&)
    {
        destroy();
        if (onDestroyedCallback)
        {
            onDestroyedCallback();
        }
    }


    void destroy()
    {
        control.reset();

        conn.close();

        if (watch)
        {
            watch->remove();
            watch=NULL;
        }
        if (stream)
        {
            zmp_stream_free(stream);
            stream = NULL;
        }
        serialized_event_fd.reset();
        immediate_event_fd.reset();
    }

    void pauseAtByteStreamOffset(
        size_t offset, boost::function<void(ZmpClient*)> pauseCallback)
    {
        zmpCallbacks->pauseAtOffset = offset;
        zmpCallbacks->pauseCallback = boost::bind(pauseCallback, this);
    }

    void unpause()
    {
        zmpCallbacks->pauseAtOffset = 0;
        zmp_stream_notify_read_ready(stream);
    }
};

// ---------------------------------------------------------------------------

static std::string errnoToMessage(const char* context, int err)
{
    char errstrbuf[256];
    std::stringstream ss;
    ss << context << " error: " << strerror_r(err, errstrbuf, 256);
    return ss.str().c_str();
}

struct SystemException : std::runtime_error
{
    SystemException(const char* context, int err)
     : std::runtime_error(errnoToMessage(context, err)) {}
};

static std::string mkTempMutableDir(
        const std::string& templat = getMutableDataPath() + "/XXXXXX")
{
    char temp[templat.size() + 1];
    memcpy(temp, templat.c_str(), templat.size() + 1);
    if (mkdtemp(temp) != temp)
    {
        throw SystemException("mkdtemp", errno);
    }
    else
    {
        return std::string(temp);
    }
}

/*
 * Convenience wrapper around the C "sd-launch" program which will fork and
 * exec a program passing a listening socket (on localhost) to it.
 *
 * This is used to conveniently launch the mongoose HTTP server on a random
 * port.
 *
 * @returns tuple of (pid, port)
 */
static boost::tuple<int, int> sdLaunch(const std::string& cmd)
{
    int pid = 0, port = 0, exitStatus;

    char key[20];
    int value;
    FILE* f = popen((MACRO__prefix "/oss/devel/bin/sd-launch "
                      + cmd).c_str(), "r");
    while (fscanf(f, "%20[^=]=%i\n", key, &value) == 2)
    {
        if (strcmp(key, "LAUNCHED_PORT") == 0)
        {
            port = value;
        }
        else if (strcmp(key, "LAUNCHED_PID") == 0)
        {
            pid = value;
        }
        else
        {
            std::clog << "Warning: unknown key/value pair (" << key
                      << "=" << value << ") when parsing sd-launch "
                      << "output\n";
        }
    }
    exitStatus = pclose(f);
    if (exitStatus != 0 || !port || !pid)
    {
        std::stringstream reason;
        reason << "sd-launch " << cmd << " failed: ";
        if (exitStatus != 0)
        {
            reason << "sd-launch exited with a non-zero exit status ("
                   << exitStatus << ")";
        }
        if (!port)
        {
            reason << "PORT was not printed";
        }
        if (!pid)
        {
            reason << "PID was not printed";
        }
        throw std::runtime_error(reason.str());
    }
    return boost::tuple<int, int>(pid, port);
}

/**
 * Will serve the contents of getMutableDataPath() on a random port on
 * localhost.  Used for serving local SDP files over HTTP with the
 * appropriate "application/sdp" MIME type.
 * 
 * It used ScopedPid but it turned out it doesn't work for our purpose because
 * setpgid used by ScopedPid doen't work if the daemon runs in a different
 * session. As we don't really care here whether mongoose is gracefuly terminated
 * we just shoot it in the head.
 */
struct ScopedWebServer
{
    explicit ScopedWebServer(const std::string& documentRoot = NS_ZINC::getMutableDataPath())
     : port(0), pid (0)
    {
        boost::tie(pid, port) = sdLaunch(
            MACRO__prefix "/oss/bin/mongoose "
                "-p 0 "
                "-extra_mime_types .sdp=application/sdp "
                "-document_root " + documentRoot +
                " -a " + NS_ZINC::getMutableDataPath() + "mongoose.log" );
    }
    ~ScopedWebServer()
    {
        kill(pid, SIGTERM);
    }

    std::string getUrl() const
    {
        std::stringstream ss;
        ss << "http://localhost:" << port << "/";
        return ss.str();
    }

    std::string getLogPath() const
    {
        return NS_ZINC::getMutableDataPath();
    }
    std::string url;
    int port,pid;
};

class ZINC_LOCAL ScopedRtpServer
{
public:
    ScopedRtpServer(const std::string& uri, 
                uint64_t startPcr_ = 0, 
                int64_t speed_ = 16, 
                bool autostart = true, 
                bool nostamper = false)
        : watchID(0), startPcr( startPcr_ ), speed(speed_)
    {
        // randomise multicast address and port
        random.seed( static_cast<unsigned int>(std::time(0)) ^ reinterpret_cast<size_t>( this ));
        ip = generateRandomMulticastIp();
        port = generateRandomMulticastPort();

        // TODO: I don't like the fact that initialisation happens here all the
        // time.  I wonder why other tests are not affected??
        gst_init ( NULL, NULL );
        loop = g_main_loop_new (NULL, FALSE);
        boost::thread(g_main_loop_run, loop).swap(gstThread);

        GError* err(NULL);
        std::stringstream desc;
        std::stringstream stamper;

        if ( !nostamper ) 
        {
            stamper << "! tsstamper pcr-min=" << startPcr;
        }

        desc << "filesrc blocksize=752 location=" << uri << " ! tspacer playback-rate=" << speed << " "
                        "! queue max-size-buffers=1 ! identity " << stamper.str() <<
                        " ! video/mpegts "
                        "! rtpmp2tpay ! identity name=id ! udpsink port=" <<
                        port << " host=" << ip << " force-ipv4=true "
                        "multicast-iface=eth0";
        LOG("ScopedRtpServer: Creating gstreamer pipeline:\n"
                "%s", desc.str().c_str());

        pipeline = gst_parse_launch(desc.str().c_str(), &err);

        if (!pipeline || err )
        {
            LOG("ScopedRtpServer: Failed to create multicast "
                    "server due to: %s", err->message);
            //TODO: Report this error
            abort();
        }

        GstBus *const bus = gst_pipeline_get_bus (GST_PIPELINE (pipeline));
        watchID = gst_bus_add_watch(bus, busCallback,
                                    static_cast<gpointer>(this));
        gst_object_unref(bus);

        if ( autostart )
            startPlayback();
    }

    void startPlayback() 
    {
            gst_element_set_state (pipeline, GST_STATE_PLAYING);
    }

    gboolean static busCallback(GstBus *bus, GstMessage *msg, gpointer data)
    {
        ScopedRtpServer* mr = static_cast<ScopedRtpServer*>(data);
        return mr->handleBusCallback(bus, msg) ? TRUE : FALSE;
    }

    bool handleBusCallback(GstBus*, GstMessage* msg)
    {
        switch (GST_MESSAGE_TYPE (msg))
        {
            case GST_MESSAGE_ERROR:
            {
                gchar  *debug;
                GError *error;

                gst_message_parse_error (msg, &error, &debug);

                LOG("ScopedRtpServer: pipeline failed: %s",
                        error->message);
                abort();
            }
        }

        return true;
    }

    std::string generateRandomMulticastIp ()
    {
        std::stringstream ip;
        ip << "239.192." << ( random() & 0x7f ) << "." << ( random() & 0xff );
        return ip.str();
    }

    int generateRandomMulticastPort ()
    {
        return random() & 0xffff;
    }

    void dropPackets(double dropProbability)
    {
        GstElement* identity = gst_bin_get_by_name(GST_BIN(pipeline), "id");
        assert(identity);
        g_object_set(G_OBJECT(identity),
                     "drop-probability", dropProbability,
                     NULL);
        gst_object_unref(identity);
    }

    ~ScopedRtpServer()
    {
        if (watchID != 0)
        {
            g_source_remove(watchID);
            watchID = 0;
        }

        gst_element_set_state(pipeline, GST_STATE_NULL);
        g_object_unref(G_OBJECT(pipeline));

        // join gst main loop thread
        g_main_loop_quit(loop);
        gstThread.join();
    }

    const std::string getSdpFile() const
    {
        std::stringstream sdp;

        sdp <<
            "v=0\n"
            "o=- 1204356725683 1206682758241 IN IP4 ist\n"
            "s=Channel " << ip << "\n"
            "i=Channel configuration for Channel " << ip << "\n"
            "t=0 0\n"
            "a=rtcp-unicast:rsi\n"
            "a=group:FID 1 3\n"
            "m=video " << port << " RTP/AVPF 33\n"
            "i=Original Source Stream\n"
            "c=IN IP4 " << ip << "/255\n"
            "b=AS:4000\n"
            "b=RS:53\n"
            "b=RR:530000\n"
            "a=fmtp:33 rtcp-per-rcvr-bw=53\n"
            "a=recvonly\n"
            "a=source-filter: incl IN IP4 " << ip << " 5.11.1.7\n"
            "a=rtpmap:33 MP2T/90000\n"
            "a=rtcp:10101 IN IP4 8.166.1.11\n"
            "a=rtcp-fb:33 nack\n"
            "a=mid:1\n"
            "m=video " << port << " RTP/AVPF 33\n"
            "i=Re-sourced Stream\n"
            "c=IN IP4 " << ip << "/255\n"
            "a=inactive\n"
            "a=source-filter: incl IN IP4 " << ip << " 8.166.1.11\n"
            "a=rtpmap:98 MP2T/90000\n"
            "a=rtcp:10101 IN IP4 8.166.1.11\n"
            "a=mid:2\n"
            "m=video " << port << " RTP/AVPF 33\n"
            "i=Unicast Retransmission Stream\n"
            "c=IN IP4 " << ip << "/255\n"
            "b=RS:53\n"
            "b=RR:53\n"
            "a=inactive\n"
            "a=rtpmap:33 MP2T/90000\n"
            "a=rtcp:10103\n"
            "a=mid:3\n";

        return sdp.str();
    }

    std::string serveSDP()
    {
        if (sdpUrl.empty())
        {
            std::string sdpDir = mkTempMutableDir();
            std::string filename = sdpDir + "/ScopedRtpServer.sdp";

            webServer.reset(new ScopedWebServer(sdpDir));

            std::string sdp = getSdpFile();
            if (!std::ofstream(filename.c_str()).write(
                    sdp.c_str(), sdp.size()).good())
            {
                throw std::runtime_error("Failed to write SDP file");
            }
            std::ostringstream ss;
            ss << webServer->getUrl() << "/"
               << boost::filesystem::path(filename).filename();
            sdpUrl = ss.str();
        }
        return sdpUrl;
    }

    int64_t getCurrentStreamingPosition() const
    {
        // Have to be in state PLAYING for this to make sense.  Avoid races
        // with startup:
        GstState state, pending;
        GstStateChangeReturn r =
            gst_element_get_state(pipeline, &state, &pending, 0);
        if (r == GST_STATE_CHANGE_SUCCESS && state == GST_STATE_PLAYING)
        {
            gint64 cur;
            if (gst_element_query_position(pipeline, GST_FORMAT_TIME, &cur))
            {
                return cur;
            }
            else
            {
                throw std::runtime_error("Could not query position");
            }
        }
        else
        {
            return 0;
        }
    }
private:
    std::string     ip;
    uint32_t        port;
    GstElement*     pipeline;
    GMainLoop*      loop;
    boost::thread   gstThread;
    boost::mt19937  random;
    guint           watchID;
    uint64_t        startPcr;
    int64_t         speed;

    boost::scoped_ptr<ScopedWebServer> webServer;
    std::string sdpUrl;
};

// ---------------------------------------------------------------------------

struct ZINC_LOCAL VQETestHarness : boost::noncopyable
{
    ScopedRtpServer multicastServer;
    const std::string mutableTestPath;
    ZmpClient t;
    const size_t testAssetSize;

    VQETestHarness(std::string assetURI,
                   DBus::BusDispatcher& mainloop, std::string /*mutablePath*/,
                   const size_t testAssetSize_)
     : multicastServer(assetURI),
       mutableTestPath(mkTempMutableDir()),
       t(mainloop, mutableTestPath, testAssetSize_),
       testAssetSize(testAssetSize_)
    {
        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(&ZmpClient::start, &t, multicastServer.serveSDP(), 0));
    }

    void verifyAndReset()
    {
        /*
         * I'm not sure how to verify the content of the retrived stream.  If
         * done just with byte by byte comparision it might be prone to races
         * because there is no guarantee that the server would be at t=0 when
         * we will be ready to receive data on client end. A possible solution
         * could be to use some sort of a tool like vlc (or gstreamer) to give
         * us approx. duration of the final stream in a file.
         */
        CPPUNIT_ASSERT(
            testAssetSize
            <= boost::filesystem::file_size(mutableTestPath + "segment-0.ts"));
        CPPUNIT_ASSERT(boost::filesystem::remove(mutableTestPath));
    }
};

// ---------------------------------------------------------------------------

/*
 * BusyBox doens't support -n option for cmp command hence I had to implement
 * file comparision with limit in c++.  For more explanation read the comment
 * for test_ifCanPauseAndResume test.
 */

static int fileCompare(const std::string a, const std::string b,
                       const size_t bufferSize = 0x10000)
{
    std::ifstream fa (a.c_str(), std::ios_base::binary );
    std::ifstream fb (b.c_str(), std::ios_base::binary );

    uint8_t buffer1[bufferSize];
    uint8_t buffer2[bufferSize];

    size_t n = std::min(boost::filesystem::file_size(a),
                        boost::filesystem::file_size(b));

    while ( n != 0 )
    {
        size_t bytesToRead = n;

        if ( n > bufferSize )
        {
            bytesToRead = bufferSize;
        }

        CPPUNIT_ASSERT(fa.read( (char*)buffer1, bytesToRead ));
        CPPUNIT_ASSERT(fb.read( (char*)buffer2, bytesToRead ));

        if ( memcmp( buffer1, buffer2, bytesToRead ) != 0 )
        {
            return 1;
        }

        n -= bytesToRead;
    }

    return 0;
}

static void ASSERT_FILE_CONTENTS_EQUAL(
    const std::string& a, const std::string& b, size_t bufferSize = 0x10000)
{
    if (fileCompare(a, b, bufferSize) != 0)
    {
        std::stringstream msg;
        msg << " Files '" << a << "' and '" << b << "' differ in the first "
            << bufferSize << " bytes\n";
        CPPUNIT_FAIL(msg.str());
    }
}

size_t countFileDescriptorsForPid ( int pid )
{
    return std::distance(
        boost::filesystem::directory_iterator(std::string("/proc/") +
            boost::lexical_cast<std::string>(pid) + std::string("/fd")),
        boost::filesystem::directory_iterator());
}

#define TEST_FILE_SIZE (128*1024*10)

class ZINC_LOCAL SourcePlaybackControlTest : public IntegrationTestSandbox,
                                             public TestUsingDbus,
                                             public CppUnit::TestFixture

{
    boost::shared_ptr<MockControlEventListener> mockControlEvent;
    std::string mutablePath;

    NS_ZINC_DBUS_BINDING::TestUsingServiceDaemon lsdService;
    NS_ZINC_DBUS_BINDING::TestUsingServiceDaemon lsrService;

    DBus::BusDispatcher mainloop;

    GMainLoop* loop;
    boost::thread gstThread;

public:

    SourcePlaybackControlTest() :
        lsdService("", "linearsource-launch", BUS_NAME),
        lsrService("copper-system-fake.plugin-config",
                   "copperlocalstoragerepod", "Zinc.System"),
        mainloop(NS_ZINC_DBUS_BINDING::SingletonDBusErrorConverter::get())
    {
    }

    ~SourcePlaybackControlTest()
    {
    }

    virtual void setUp()
    {
        mutablePath = NS_ZINC::getMutableDataPath();
        mockControlEvent = boost::make_shared<MockControlEventListener>();

        // On production box configuration comes from the LSR.  But during
        // development, especially on SL6, these entries are not available so
        // in order to increase the number of vqec tuners to something useful
        // (i.e. >1) this semi-ugly hack was conveived. It would be nice to
        // have a better way of doing that, sadly VQEC config is global for all
        // instances.
        //  setenv("GSTVQE_CFG_PATH",
        //         getDataFinder().find("vqectest.cfg").c_str(), 1);
        lsrService.startService();
        lsdService.startService();
    }

    virtual void tearDown()
    {
        lsdService.stopService();
        lsrService.stopService();

        resetFilesystemSandbox();
        using ::testing::Mock;
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(
            mockControlEvent.get()));
    }

    void test_ifFileComesThroughVerbatim()
    {
        ZmpClient t(mainloop, mutablePath, TEST_FILE_SIZE, mockControlEvent);
        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(&ZmpClient::start, &t, sources.TS_LICENCE_FREE, 0));

        mainloop.run();

        // we're only expecting one segment
        CPPUNIT_ASSERT(boost::filesystem::exists(mutablePath + "segment-0.ts"));

        ASSERT_FILE_CONTENTS_EQUAL(
            mutablePath + "segment-0.ts", sourceAssetPath);
    }

    void assertUrlCausesErrorEvent(const std::string& url,
            ErrorEventValue::Enum expectedValue,
            ErrorEventContext::Enum expectedContext)
    {
        ZmpClient t(mainloop, mutablePath, TEST_FILE_SIZE, mockControlEvent);
        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(&ZmpClient::start, &t, url, 0 ));

        using ::testing::_;
        using ::testing::InvokeWithoutArgs;

        // TODO: figure out why error enum values aren't passed correctly
        EXPECT_CALL(
            *mockControlEvent, ErrorEvent( expectedValue, expectedContext, _))
            .WillOnce(InvokeWithoutArgs(&t, &ZmpClient::stop));

        mainloop.run();
    }

    void test_ifThrowsOnInvalidUrl()
    {
        assertUrlCausesErrorEvent("bla://invalid.url",
            ErrorEventValue::locator, ErrorEventContext::source);
    }

    void test_thatNetworkSourceErrorEventIsRaisedOnDNSResolutionFailure()
    {
        // server is unreachable
        assertUrlCausesErrorEvent("http://invalidserver.url",
            ErrorEventValue::network, ErrorEventContext::source);
    }

    void test_ifServerErrorEventIsGeneratedOn404HttpError()
    {
        // file on the server doesn't exist
        assertUrlCausesErrorEvent(
            "http://filegateway.youview.co.uk/test_assets/licence_free/"
            "not-expected-to-find-that-file.sdp",
            ErrorEventValue::server, ErrorEventContext::source);
    }

    void test_thatSdpFileErrorEventIsRaisedWhenSDPFileContentsIsInvalid()
    {
        assertUrlCausesErrorEvent(
            "file://" + getDataFinder().find( "test_corrupted.sdp" ),
            ErrorEventValue::data, ErrorEventContext::sdp_file);
        ScopedWebServer ws;
        boost::filesystem::copy_file(
            NS_ZINC::PackageDataFinder().find("test_corrupted.sdp"),
            getMutableDataPath() + "test_corrupted.sdp");
        assertUrlCausesErrorEvent(
            ws.getUrl() + "test_corrupted.sdp",
            ErrorEventValue::data, ErrorEventContext::sdp_file);

        /* test_not_sdp.sdp doesn't even look like an SDP file and the
           Gstreamer typefind elements wouldn't consider it as such but it will
           be served with the MIME type application/sdp */
        boost::filesystem::copy_file(
            NS_ZINC::PackageDataFinder().find("test_not_sdp.sdp"),
            getMutableDataPath() + "test_not_sdp.sdp");
        assertUrlCausesErrorEvent(
            ws.getUrl() + "test_not_sdp.sdp",
            ErrorEventValue::data, ErrorEventContext::sdp_file);
    }

    void test_ifThrowsWhenStartWasCalledAfterDestroy()
    {
        struct Callbacks
        {
            static void start_cb(const FutureValue<void>&, ZmpClient* t)
            {
                t->control->start().setCallback(
                    *t->zincDispatcher, bind(&Callbacks::destroy_cb, _1, t));
            }

            static void destroy_cb(const FutureValue<void>&, ZmpClient* t)
            {
                t->control->destroy().setCallback(
                    *t->zincDispatcher, bind(&Callbacks::start2_cb, _1, t));
            }

            static void start2_cb(const FutureValue<void>&, ZmpClient* t)
            {
                t->control->start().setCallback(
                    *t->zincDispatcher, bind(&Callbacks::error_cb, _1, t));
            }

            static void error_cb(const FutureValue<void>& v, ZmpClient* t)
            {
                // It shouldn't be possible to call start after destroy was
                // called
                CPPUNIT_ASSERT_THROW(v.get(), std::runtime_error);
                t->destroy();
            }
        };

        ZmpClient t(mainloop, mutablePath, TEST_FILE_SIZE, mockControlEvent);
        t.createControlOnly(sources.TS_LICENCE_FREE).setCallback(
            *t.zincDispatcher, bind(&Callbacks::start_cb, _1, &t));
        mainloop.run();
    }

    void test_ifThrowsWhenDestroyWasCalledBeforeStart()
    {
        struct Callbacks
        {
            static void start_cb(const FutureValue<void>&, ZmpClient* t)
            {
                t->control->destroy().setCallback(
                    *t->zincDispatcher, bind(&Callbacks::error_cb, _1, t));
            }

            static void error_cb(const FutureValue<void>& v, ZmpClient* t)
            {
                // It shouldn't be possible to call destroy before start.
                CPPUNIT_ASSERT_NO_THROW ( v.get() );
                t->destroy();
            }
        };

        ZmpClient t(mainloop, mutablePath, TEST_FILE_SIZE, mockControlEvent);
        t.createControlOnly(sources.TS_LICENCE_FREE).setCallback(
            *t.zincDispatcher, bind(&Callbacks::start_cb, _1, &t));
        mainloop.run();
    }

    void test_ifCanPauseAndResume()
    {
        struct Callbacks
        {
            static void nowPaused(ZmpClient* t)
            {
                LOG("******************* zmp is now now paused");

                sleep(5);
                t->unpause();

                LOG("******************* zmp is now unpaused");
            }
        };

        // Note that there are many possible error conditions like over-running
        // pause buffer etc. This test should focus on testing output buffers
        // recreation reliability so the input asset should be small enough.
        const boost::uintmax_t expecetdAssetSize = 24 * 1024 * 1024;

        ZmpClient client(
            mainloop, mutablePath, expecetdAssetSize, mockControlEvent);
        client.pauseAtByteStreamOffset(
            expecetdAssetSize / 2,
            boost::bind(&Callbacks::nowPaused, &client));

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(
                &ZmpClient::start,
                &client,
                sources.TS_LICENCE_FREE,
                CONTROL_FLAG_WITH_TIMESHIFTER));

        mainloop.run();

        // we're only expecting one segment
        CPPUNIT_ASSERT(
            boost::filesystem::exists(mutablePath + "segment-0.ts"));

        CPPUNIT_ASSERT(
            expecetdAssetSize <=
            boost::filesystem::file_size(mutablePath + "segment-0.ts"));

        ASSERT_FILE_CONTENTS_EQUAL(
            sourceAssetPath, mutablePath + "segment-0.ts");
    }

    void test_ifEmitsOverrun()
    {
        const boost::uintmax_t expecetdAssetSize = 24 * MB;

        struct Callbacks
        {
            static void nowPaused(ZmpClient* /*client*/ )
            {
                LOG("******************* zmp is now now paused");
            }

            static void timeout(ZmpClient* client, DBus::DefaultTimeout& )
            {
                client->stop();
            }
        };

        ZmpClient client(
            mainloop, mutablePath, expecetdAssetSize, mockControlEvent);
        client.pauseAtByteStreamOffset( 1024,
            boost::bind(&Callbacks::nowPaused, _1));
        
        using ::testing::InvokeWithoutArgs;
        EXPECT_CALL(*mockControlEvent, Overrun())
            .WillOnce(InvokeWithoutArgs(&client, &ZmpClient::stop));
        
        std::map<std::string, DBus::Variant> kwargs;
        kwargs["use-buffering"] = DBus::Variant(true);
        kwargs["buffer-size"] = DBus::Variant(uint64_t(1 * MB));

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(
                &ZmpClient::start2,
                &client,
                sources.TS_LICENCE_FREE,
                kwargs));

        mainloop.DBus::DefaultMainLoop::add_timeout(
            5000, false, boost::bind(&Callbacks::timeout, &client, _1 ));

        mainloop.run();
    }

    void test_ifFileDescriptorsAreProperlyClosedWhenControlObjectIsDestroyed()
    {
        /*
         * You may notice that the daemon is called twice in this test where it
         * should be possible to know if we've leaked any FDs just after one
         * run. This is sadly not possible because there's a singleton clock
         * object in gstreamer that creates a socket pair that will live as
         * long as gstreamer.
         *
         * It's not known yet whether this is a bug or design choice.  For time
         * being the workaround is measure the second run where we know that
         * gstreamer won't leave anything behind.
         */
        {
            ZmpClient t(mainloop, mutablePath, TEST_FILE_SIZE,
                        mockControlEvent);
            mainloop.DBus::DefaultMainLoop::post_function(
                bind(&ZmpClient::start, &t, sources.TS_LICENCE_FREE, 0));
            mainloop.run();
            boost::filesystem::remove(mutablePath + "segment-0.ts");
        }
        /*
         * Second run should be good.
         */
        int beforeFDs = countFileDescriptorsForPid(
            lsdService.getServicePid(""));
        {
            ZmpClient t(mainloop, mutablePath, TEST_FILE_SIZE, mockControlEvent);
            mainloop.DBus::DefaultMainLoop::post_function(
                bind(&ZmpClient::start, &t, sources.TS_LICENCE_FREE, 0));
            mainloop.run();
            boost::filesystem::remove( mutablePath + "segment-0.ts" );
        }
        int afterFDs = countFileDescriptorsForPid(lsdService.getServicePid(""));
        LOG("used file descriptors in LSD - before: %d, after %d",
                afterFDs, beforeFDs);
        CPPUNIT_ASSERT_MESSAGE("It appears that the LSD daemon is leaking FDs!",
                               afterFDs == beforeFDs );
    }

    void test_ifCanHaveConcurentStreamsPlayingAtTheSameTime()
    {
        std::string mutable1 = mutablePath + "t1/";
        std::string mutable2 = mutablePath + "t2/";
        boost::filesystem::create_directory(mutable1);
        boost::filesystem::create_directory(mutable2);

        ZmpClient t1(mainloop, mutable1, TEST_FILE_SIZE, mockControlEvent);
        mainloop.DBus::DefaultMainLoop::post_function(
            bind(&ZmpClient::start, &t1, sources.TS_LICENCE_FREE, 0));
        ZmpClient t2(mainloop, mutable2, TEST_FILE_SIZE, mockControlEvent);
        mainloop.DBus::DefaultMainLoop::post_function(
            bind(&ZmpClient::start, &t2, sources.TS_LICENCE_FREE, 0));

        mainloop.run();

        // we're only expecting one segment
        CPPUNIT_ASSERT(boost::filesystem::exists( mutable1 + "segment-0.ts"));
        ASSERT_FILE_CONTENTS_EQUAL(
            sourceAssetPath, mutable1 + "segment-0.ts");

        // we're only expecting one segment
        CPPUNIT_ASSERT(boost::filesystem::exists( mutable2 + "segment-0.ts"));
        ASSERT_FILE_CONTENTS_EQUAL(
            sourceAssetPath, mutable2 + "segment-0.ts");
    }

    void test_forNoFdLeaksWithConcurentStreams()
    {
        /*
         * You may notice that the daemon is called twice in this test
         * where it should be possible to know if we've leaked any FDs
         * just after one run. This is sadly not possible because
         * there's a singleton clock object in gstreamer that creates
         * a socket pair that will live as long as gstreamer.
         *
         * It's not known yet whether this is a bug or design choice.
         * For time being the workaround is measure the second run
         * where we know that gstreamer won't leave anything behind.
         */
        {
            ZmpClient t(mainloop, mutablePath, TEST_FILE_SIZE, mockControlEvent);
            mainloop.DBus::DefaultMainLoop::post_function(
                bind(&ZmpClient::start, &t, sources.TS_LICENCE_FREE, 0 ));
            mainloop.run();
            boost::filesystem::remove( mutablePath + "segment-0.ts" );
        }

        int beforeFDs = countFileDescriptorsForPid(
            lsdService.getServicePid(""));

        std::string mutable1 = mutablePath + "t1/";
        std::string mutable2 = mutablePath + "t2/";
        boost::filesystem::create_directory(mutable1);
        boost::filesystem::create_directory(mutable2);

        ZmpClient t1(mainloop, mutable1, TEST_FILE_SIZE, mockControlEvent);
        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(&ZmpClient::start, &t1, sources.TS_LICENCE_FREE, 0));
        ZmpClient t2(mainloop, mutable2, TEST_FILE_SIZE, mockControlEvent);
        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(&ZmpClient::start, &t2, sources.TS_LICENCE_FREE, 0));

        mainloop.run();

        // we're only expecting one segment
        CPPUNIT_ASSERT(boost::filesystem::exists(mutable1 + "segment-0.ts"));
        ASSERT_FILE_CONTENTS_EQUAL(
            sourceAssetPath, mutable1 + "segment-0.ts");

        // we're only expecting one segment
        CPPUNIT_ASSERT(boost::filesystem::exists(mutable2 + "segment-0.ts"));
        ASSERT_FILE_CONTENTS_EQUAL(
            sourceAssetPath, mutable2 + "segment-0.ts");

        int afterFDs = countFileDescriptorsForPid(lsdService.getServicePid(""));
        LOG("used file descriptors in LSD - before: %d, after %d",
                afterFDs, beforeFDs);
        CPPUNIT_ASSERT_MESSAGE("It appears that the LSD daemon is leaking FDs!",
                               afterFDs == beforeFDs);
    }

    void test_ifSingleVqeMulticastStreamWorks()
    {
        VQETestHarness t1( sourceAssetPath,
            mainloop, mutablePath, TEST_FILE_SIZE*1);
        mainloop.run();
        t1.verifyAndReset();
    }

    void test_ifCanDoMultipleVQEStreams( )
    {
        std::string asset = sourceAssetPath;
        {
            VQETestHarness t1(asset, mainloop, mutablePath, TEST_FILE_SIZE * 1);
            VQETestHarness t2(asset, mainloop, mutablePath, TEST_FILE_SIZE * 2);
            mainloop.run();
            t1.verifyAndReset();
            t2.verifyAndReset();
        }
        {
            VQETestHarness t1(asset, mainloop, mutablePath, TEST_FILE_SIZE * 2);
            VQETestHarness t2(asset, mainloop, mutablePath, TEST_FILE_SIZE * 1);
            mainloop.run();
            t2.verifyAndReset();
            t1.verifyAndReset();
        }
        {
            VQETestHarness t1(asset, mainloop, mutablePath, TEST_FILE_SIZE * 1);
            VQETestHarness t2(asset, mainloop, mutablePath, TEST_FILE_SIZE * 2);
            VQETestHarness t3(asset, mainloop, mutablePath, TEST_FILE_SIZE * 3);
            mainloop.run();
            t3.verifyAndReset();
            t2.verifyAndReset();
            t1.verifyAndReset();
        }
        {
            VQETestHarness t1(asset, mainloop, mutablePath, TEST_FILE_SIZE * 3);
            VQETestHarness t2(asset, mainloop, mutablePath, TEST_FILE_SIZE * 2);
            VQETestHarness t3(asset, mainloop, mutablePath, TEST_FILE_SIZE * 1);
            mainloop.run();
            t3.verifyAndReset();
            t2.verifyAndReset();
            t1.verifyAndReset();
        }
    }

    struct test_ifgetSourceInformationWorks_Helper
    {
        VQETestHarness& client;
        size_t pauseAt;
        std::vector<size_t> inputs;
        const std::string paramName;

        test_ifgetSourceInformationWorks_Helper(VQETestHarness& client_,
                                                const std::string& paramName_)
         : client ( client_ ), pauseAt ( TEST_FILE_SIZE/2 ),
           paramName( paramName_ )
        {
            client.t.pauseAtByteStreamOffset(
              pauseAt,
              bind(&test_ifgetSourceInformationWorks_Helper::nowPaused, this));
        }

        void nowPaused()
        {
            client.t.control->getSourceInformation().setCallback(
                *client.t.zincDispatcher,
                bind(&test_ifgetSourceInformationWorks_Helper::informationReady,
                     this, _1));

            client.t.unpause();
        }

        void informationReady(const FutureValue<map<string, string> >& info_)
        {
            std::map< std::string, std::string > info = info_.get();

            std::map< std::string, std::string >::iterator it =
                info.find(paramName);
            if (it != info.end())
            {
                LOG("info: %s = %s", it->first.c_str(),
                        it->second.c_str());
                const size_t statVal = boost::lexical_cast<size_t>(it->second);

                if (inputs.empty() || statVal > inputs.back())
                {
                    inputs.push_back ( statVal );
                }
            }
            else
            {
                 CPPUNIT_FAIL(
                    "GstVQE is not able to return sane stats via "
                    "getSourceInformation LSD call\n"
                    "This is weird because we're receiving data from it.");
            }

            pauseAt += TEST_FILE_SIZE/2;
            if ( pauseAt < client.testAssetSize )
            {
                client.t.pauseAtByteStreamOffset(pauseAt,
                    bind(&test_ifgetSourceInformationWorks_Helper::nowPaused,
                         this));
                LOG("probing source information after %zu bytes "
                        "received.", pauseAt);
            }
        }

        void verify()
        {
            CPPUNIT_ASSERT_MESSAGE("Too few source information samples "
                                   "collected!", inputs.size() > 2);
            for (size_t i = 0; i < inputs.size() - 1; i++)
            {
                // expect packet count to increase
                CPPUNIT_ASSERT_MESSAGE("We expect the count to increase!",
                                       inputs[i+1] > inputs[i]);
            }
        }
    };

    void test_ifgetSourceInformationWorks( )
    {
        VQETestHarness t1 ( sourceAssetPath,
            mainloop, mutablePath, TEST_FILE_SIZE * 4);
        test_ifgetSourceInformationWorks_Helper client(
            t1, "PRIMARY_RTP_INPUTS");
        mainloop.run();
        t1.verifyAndReset();
        client.verify();
    }

    void test_ifTr135StatsAreLive()
    {
        VQETestHarness t1 ( sourceAssetPath,
            mainloop, mutablePath, TEST_FILE_SIZE * 4);
        test_ifgetSourceInformationWorks_Helper client(
            t1, "TR135_PACKETS_RECEIVED");
        mainloop.run();
        t1.verifyAndReset();
        client.verify();
    }

    void test_ifGetSourceInformationThrowsIfCalledAfterDestroy()
    {
        struct Helper
        {
            static void nowPaused(ZmpClient* t)
            {
                t->control->destroy().setCallback(
                    *t->zincDispatcher, bind(&callGetSourceInformation, _1, t));
            }
            static void callGetSourceInformation(
                    const FutureValue<void>&, ZmpClient* t)
            {
                t->control->getSourceInformation().setCallback(
                    *t->zincDispatcher,
                    bind(&getSourceInformationReturned, _1, t));
            }
            static void getSourceInformationReturned (
                    const FutureValue<map<string, string> >& info, ZmpClient* t)
            {
                CPPUNIT_ASSERT_THROW(info.get(), std::runtime_error);
                t->stop();
            }
        };

        ZmpClient client( mainloop, mutablePath, 1024*1024, mockControlEvent);
        client.pauseAtByteStreamOffset(
            128 * 1024, boost::bind(&Helper::nowPaused, &client));

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(
                &ZmpClient::start,
                &client,
                sources.TS_LICENCE_FREE,
                0));

        mainloop.run();
    }

    void test_ifGetPositionReturnsValidPositions()
    {
        struct TestPauseCallback
        {
            static
            void afterSeek(ZmpClient& client, NS_ZINC::Future<Position>& pos)
            {
                LOG("******************* zmp after seek");
                pos = client.control->getPosition( 0 );
            }

            static
            void nowPaused(
                ZmpClient& client,
                NS_ZINC::Future<Position>& pos_pause,
                NS_ZINC::Future<Position>& pos_seek,
                NS_ZINC::Future<void>& seek)
            {
                using namespace testing;
                LOG("******************* zmp is now now paused");

                // for kicks and giggles report the current position to be 1s
                pos_pause = client.control->getPosition( 1 * GST_SECOND );

                LOG("******************* zmp is seeking...");
                seek = client.control->seekPosition(
                    SeekReference::current,
                    -200,
                    SeekMode::prioritise_accuracy,
                    1 * GST_SECOND );

                ON_CALL(*client.zmpCallbacks, onEvent(
                    _, Field(&ZMPEventHeader::event_type, ZMP_EVENT_PORTION), _, _))
                    .WillByDefault(Invoke(boost::bind(
                        afterSeek, boost::ref(client), boost::ref(pos_seek))));

                client.unpause();

                LOG("******************* zmp is now unpaused");
            }
        };

        const boost::uintmax_t expecetedAssetSize = 5 * 1024 * 1024;

        NS_ZINC::Future<Position> pos_pause, pos_seek;
        NS_ZINC::Future<void> seek;

        ZmpClient client(
            mainloop, mutablePath, expecetedAssetSize, mockControlEvent);
        client.pauseAtByteStreamOffset(
            expecetedAssetSize / 2,
            boost::bind(
                &TestPauseCallback::nowPaused,
                boost::ref(client),
                boost::ref(pos_pause),
                boost::ref(pos_seek),
                boost::ref(seek)));

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(
                &ZmpClient::start,
                &client,
                sources.SDP_CLOUD_GEO,
                CONTROL_FLAG_WITH_TIMESHIFTER));

        mainloop.run();

        CPPUNIT_ASSERT(!pos_pause.isEmpty() && pos_pause.isComplete());
        Zinc::Media::Position p1 = pos_pause.get();

        // this is what we know for sure for the live stream
        CPPUNIT_ASSERT_EQUAL(0, p1.end);
        // ... and since we paused ...
        CPPUNIT_ASSERT( p1.current < 0 );
        CPPUNIT_ASSERT( p1.start < p1.current );

        CPPUNIT_ASSERT( !seek.isEmpty() && seek.isComplete() );
        seek.get();

        CPPUNIT_ASSERT( !pos_seek.isEmpty() && pos_seek.isComplete() );
        Zinc::Media::Position p0 = pos_seek.get();
        CPPUNIT_ASSERT_EQUAL( 0, p0.end );
        CPPUNIT_ASSERT( p0.current < p1.current );
    }

    void test_ifGetPosition2ReturnsValidPositionsAndBufferLevel()
    {
        struct TestPauseCallback
        {
            static
            void afterSeek(ZmpClient& client, NS_ZINC::Future<Position>& pos)
            {
                LOG("******************* zmp after seek");
                pos = client.control->getPosition( 0 );
            }

            static
            void nowPaused(
                ZmpClient& client,
                NS_ZINC::Future<boost::tuple<Position,uint64_t> >& pos_pause,
                NS_ZINC::Future<Position>& pos_seek,
                NS_ZINC::Future<void>& seek)
            {
                using namespace testing;
                LOG("******************* zmp is now now paused");

                // for kicks and giggles report the current position to be 1s
                pos_pause = client.control->getPosition2( 1 * GST_SECOND );

                LOG("******************* zmp is seeking...");
                seek = client.control->seekPosition(
                    SeekReference::current,
                    -200,
                    SeekMode::prioritise_accuracy,
                    1 * GST_SECOND );

                ON_CALL(*client.zmpCallbacks, onEvent(
                    _, Field(&ZMPEventHeader::event_type, ZMP_EVENT_PORTION), _, _))
                    .WillByDefault(Invoke(boost::bind(
                        afterSeek, boost::ref(client), boost::ref(pos_seek))));

                client.unpause();

                LOG("******************* zmp is now unpaused");
            }
        };

        const boost::uintmax_t expecetedAssetSize = 5 * 1024 * 1024;

        NS_ZINC::Future<boost::tuple<Position,uint64_t> > pos_pause;
        NS_ZINC::Future< Position > pos_seek;
        NS_ZINC::Future<void> seek;

        ZmpClient client(
            mainloop, mutablePath, expecetedAssetSize, mockControlEvent);
        client.pauseAtByteStreamOffset(
            expecetedAssetSize / 2,
            boost::bind(
                &TestPauseCallback::nowPaused,
                boost::ref(client),
                boost::ref(pos_pause),
                boost::ref(pos_seek),
                boost::ref(seek)));

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(
                &ZmpClient::start,
                &client,
                sources.SDP_CLOUD_GEO,
                CONTROL_FLAG_WITH_TIMESHIFTER));

        mainloop.run();

        CPPUNIT_ASSERT(!pos_pause.isEmpty() && pos_pause.isComplete());
        Zinc::Media::Position p1 = pos_pause.get().get<0>();

        // this is what we know for sure for the live stream
        CPPUNIT_ASSERT_EQUAL(0, p1.end);
        // ... and since we paused ...
        CPPUNIT_ASSERT( p1.current < 0 );
        CPPUNIT_ASSERT( p1.start < p1.current );

        CPPUNIT_ASSERT( !seek.isEmpty() && seek.isComplete() );
        seek.get();

        CPPUNIT_ASSERT( !pos_seek.isEmpty() && pos_seek.isComplete() );
        Zinc::Media::Position p0 = pos_seek.get();
        CPPUNIT_ASSERT_EQUAL( 0, p0.end );
        CPPUNIT_ASSERT( p0.current < p1.current );

        uint64_t bytePosition = pos_pause.get().get<1>();
        LOG("buffer level bytes %" G_GUINT64_FORMAT " > %llu?\n",
                bytePosition,
                static_cast<long long unsigned>(expecetedAssetSize/2)
        );
        CPPUNIT_ASSERT( bytePosition > expecetedAssetSize / 2 );
    }

    void test_ifPushesFlushEvents()
    {
        using namespace ::testing;

        const boost::uintmax_t expectedAssetSize = 1 * 1024 * 1024;

        struct Callbacks
        {
            static
            void seek(ZmpClient& client)
            {
                client.unpause();

                LOG("**** Seeking ****");
                client.control->seekPosition(
                    SeekReference::start, 0, SeekMode::prioritise_accuracy,
                    1 * GST_SECOND);
            }
        };

        ZmpClient client(
            mainloop, mutablePath, expectedAssetSize, mockControlEvent);
        client.pauseAtByteStreamOffset(
            expectedAssetSize / 2, bind(Callbacks::seek, boost::ref(client)));

        EXPECT_CALL(*client.zmpCallbacks,
            onEvent(_, _, _, _))
            .Times(AnyNumber());

        EXPECT_CALL(*client.zmpCallbacks, onEvent(
            _, Field(&ZMPEventHeader::event_type, ZMP_EVENT_SEGMENT), _, _))
            .Times(2);
        EXPECT_CALL(*client.zmpCallbacks, onEvent(
            _, Field(&ZMPEventHeader::event_type, ZMP_EVENT_PORTION), _, _))
            .Times(2);

        EXPECT_CALL(*client.zmpCallbacks, onEvent(
            _, Field(&ZMPEventHeader::event_type, ZMP_EVENT_FLUSH_START), _, _))
            .Times(1);
        EXPECT_CALL(*client.zmpCallbacks, onEvent(
            _, Field(&ZMPEventHeader::event_type, ZMP_EVENT_FLUSH_STOP), _, _))
            .Times(1);

        std::map<std::string, DBus::Variant> kwargs;
        kwargs["use-buffering"] = DBus::Variant(true);
        kwargs["buffer-size"] = DBus::Variant(uint64_t(1 * 1024 * 1024));

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(
                &ZmpClient::start2,
                &client,
                sources.TS_LICENCE_FREE,
                kwargs));

        mainloop.run();

        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(
            client.zmpCallbacks.get()));
    }


    void test_ifHttpUserAgentStringIsCorretlyCustomised()
    {
        ScopedWebServer ws;
        ScopedRtpServer multicastServer ( sourceAssetPath );

        {
            std::string ofn( NS_ZINC::getMutableDataPath() + "test.sdp" );
            std::ofstream writeSdpFile ( ofn.c_str(), std::ios_base::trunc );
            writeSdpFile << multicastServer.getSdpFile();
        }

        ZmpClient t(mainloop, mutablePath, 10000, mockControlEvent);
        mainloop.DBus::DefaultMainLoop::post_function(
            bind(&ZmpClient::start, &t, ws.getUrl() + "test.sdp", 0));

        mainloop.run();

        std::string logline, log_path(ws.getLogPath()+"mongoose.log");
        std::ifstream mongoose_log( log_path.c_str() );
        std::getline( mongoose_log, logline, '\0' );
        CPPUNIT_ASSERT_MESSAGE (
            "GstSoupHttpSrc HTTP user-agent string not set to \"YouView\".",
            logline.find("YouView") != std::string::npos);
    }

    void test_thatGetSourceInformationPerformanceIsUnaffectedByPacketLoss()
    {
        struct Helper
        {
            static void nowPaused(
                ZmpClient* t,
                boost::posix_time::time_duration* longest_duration)
            {
                t->control->getSourceInformation().setCallback(
                    *t->zincDispatcher, boost::bind(
                        &getSourceInformationReturned, _1, t,
                        boost::posix_time::microsec_clock::local_time(),
                        longest_duration));
            }

            static void getSourceInformationReturned (
                    const NS_ZINC::FutureValue< std::map< std::string,
                    std::string > >& /*info*/, ZmpClient* t,
                    boost::posix_time::ptime start,
                    boost::posix_time::time_duration* longest_duration )
            {
                const boost::posix_time::time_duration elapsed =
                    boost::posix_time::microsec_clock::local_time() - start;

                if ( elapsed > *longest_duration )
                {
                    *longest_duration = elapsed;
                }
                LOG_OSTREAM("getSource took: " << elapsed);
                t->stop();
            }
        };

        boost::posix_time::time_duration longest_duration =
            boost::posix_time::milliseconds(0);

        const size_t number_of_samples = 100;

        for ( size_t i=0; i<number_of_samples; ++i )
        {
            ScopedRtpServer multicastServer(sourceAssetPath,0,64);

            const boost::posix_time::ptime startTime =
                boost::posix_time::microsec_clock::local_time();

            multicastServer.dropPackets( double(i)/double(number_of_samples) );

            ZmpClient client(mainloop, mutablePath, 512*1024, mockControlEvent);
            client.pauseAtByteStreamOffset(
                64 * 1024,
                bind(&Helper::nowPaused, &client, &longest_duration));

            mainloop.DBus::DefaultMainLoop::post_function(
                boost::bind(
                    &ZmpClient::start,
                    &client,
                    multicastServer.serveSDP(),
                    0));

            mainloop.run();

            LOG_OSTREAM("iteration took: "
                << boost::posix_time::microsec_clock::local_time() - startTime)
        }

        LOG_OSTREAM("longest getSource took: " << longest_duration);
        CPPUNIT_ASSERT(longest_duration < boost::posix_time::milliseconds(500));

        boost::filesystem::remove(mutablePath + "segment-0.ts");
    }
    /*
     * It has been noticed that when getSourceInformation is called when there
     * was a prior error condition an excessive number of async error messages
     * is produced. This poses a major problem to the UI because they have not
     * enough capacity to deal with so many events, which was basically slowing
     * the UI down. This test checks for a regression against a fix to the
     * above problem.
     */
    void test_ifCallingGetSourceInformationWhileInErrorStateByMalformedSDPCausesErrors()
    {
        struct Callbacks
        {
            static void timeout(ZmpClient* client,  DBus::DefaultTimeout&)
            {
                client->control->getSourceInformation().setCallback(
                    *client->zincDispatcher,
                    bind(&Callbacks::informationReady, _1, client));
            }
            static void informationReady(
                const NS_ZINC::FutureValue< std::map< std::string,
                std::string > >& /*info_*/, ZmpClient* client )
            {
                client->stop();
            }
        };

        ScopedWebServer ws;
        boost::filesystem::copy_file(
            NS_ZINC::PackageDataFinder().find("test_corrupted.sdp"),
            getMutableDataPath() + "test_corrupted.sdp");

        ZmpClient client( mainloop, mutablePath, 1512*1024, mockControlEvent);

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(
                &ZmpClient::start,
                &client,
                ws.getUrl() + "test_corrupted.sdp",
                0));
        client.zmpCallbacks->stop = NULL;

        mainloop.DBus::DefaultMainLoop::add_timeout(
            1000, false, boost::bind(&Callbacks::timeout, &client, _1));

        using ::testing::_;
        EXPECT_CALL(*mockControlEvent,
            ErrorEvent(ErrorEventValue::data, ErrorEventContext::sdp_file, _));
        EXPECT_CALL(*mockControlEvent,
            ErrorEvent(ErrorEventValue::network, ErrorEventContext::source, _));
        EXPECT_CALL(*mockControlEvent,
            ErrorEvent(ErrorEventValue::locator, ErrorEventContext::source, _));

        mainloop.run();

        VERIFY_AND_CLEAR_MOCK(mockControlEvent);
    }

    /* Equivalent to sleep() but gets the time from ScopedRtpServer so the test
     * will not fail if we cannot stream data in fast enough due to box load.
     */
    static void sleepStreamTime(const ScopedRtpServer& s, int64_t durationNs)
    {
        int64_t initial = s.getCurrentStreamingPosition();
        while (initial + durationNs >= s.getCurrentStreamingPosition())
        {
            usleep(durationNs / 1000 / 4);
        }
    }

    /* It's difficult to prove that exactly the right data has come through
       every time we seek, but we can prove a lesser property: identical seeks
       produce identical data. */
    void test_thatSeekingToTheSamePointConsistentlyGivesTheSameData()
    {
        ScopedRtpServer multicastServer(sourceAssetPath);
        ZmpClient client(mainloop, mutablePath, 0);

        std::map<std::string, DBus::Variant> kwargs;
        kwargs["use-buffering"] = DBus::Variant(true);
        kwargs["buffer-size"] = DBus::Variant(uint64_t(128 * 1024 * 1024));

        mainloop.post(bind(
            &ZmpClient::start2, &client, multicastServer.serveSDP(), kwargs));
        boost::thread(bind(&DBus::Dispatcher::run, &mainloop));
        LOG("Wait for timeshift buffer to fill: sleep 30");
        sleepStreamTime(multicastServer, 30 * GST_SECOND);

        for (int i = 0; i <= 10; ++i)
        {
            LOG("Seeking for the %ith time", i+1);
            client.control->seekPosition(
                SeekReference::current, -15000 /*ms*/,
                SeekMode::prioritise_accuracy, 30 * ZMP_SECOND);
            sleepStreamTime(
                multicastServer,
                (2 + 8 * ((double) rand() / (double) RAND_MAX)) * GST_SECOND);
        }

        std::string expected = getMutableDataPath() + "/segment-1.ts";
        for (unsigned n = 2; n <= 10; n++) {
            std::string path = getMutableDataPath() + "/segment-" +
                boost::lexical_cast<std::string>(n) + ".ts";
            ASSERT_FILE_CONTENTS_EQUAL(expected, path, 4096);
        }
    }

    /* Regression test for DEVARCH-6322 */
    void test_thatIntensiveSeekingDoesntCauseEPIPEError()
    {
        using namespace testing;
        ScopedRtpServer multicastServer(sourceAssetPath);
        ZmpClient client(mainloop, mutablePath, 0);

        std::map<std::string, DBus::Variant> kwargs;
        kwargs["use-buffering"] = DBus::Variant(true);
        kwargs["buffer-size"] = DBus::Variant(uint64_t(128 * 1024 * 1024));

        mainloop.post(bind(
            &ZmpClient::start2, &client, multicastServer.serveSDP(), kwargs));
        boost::thread(bind(&DBus::Dispatcher::run, &mainloop));
        LOG("Wait for timeshift buffer to fill: sleep 30");
        sleepStreamTime(multicastServer, 5 * GST_SECOND);

        boost::shared_ptr<MockControlEventListener> mock
            = boost::make_shared<MockControlEventListener>();
        client.control->addListener(mock);
        EXPECT_CALL(*mock, ErrorEvent(_, _, _)).Times(0);

        for (int i = 0; i <= 100; ++i)
        {
            LOG("Seeking for the %ith time", i+1);
            client.control->seekPosition(
                SeekReference::current, rand() % 2000 - 1000 /*ms*/,
                SeekMode::prioritise_accuracy, 2 * ZMP_SECOND);
            sleepStreamTime(
                multicastServer,
                rand() % GST_SECOND);
        }
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mock.get()));
    }

    void test_thatTimeshiftingAcrossPcrWrapWorks()
    {
        ScopedRtpServer multicastServer( sourceAssetPath, 0x1fff00000ULL, 1 );
        ZmpClient client(mainloop, mutablePath, 0);

        std::map<std::string, DBus::Variant> kwargs;
        kwargs["use-buffering"] = DBus::Variant(true);
        kwargs["buffer-size"] = DBus::Variant(uint64_t(128 * 1024 * 1024));

        mainloop.post(bind(
            &ZmpClient::start2, &client, multicastServer.serveSDP(), kwargs));

        struct Helper
        {
            static void  timer( 
                ZmpClient* t, DBus::DefaultTimeout&, 
                std::vector<uint64_t>& bufLevels )
            {
                t->control->getBufferLevelTime().setCallback(
                    *t->zincDispatcher, 
                    bind(&Helper::timer_cb, _1, t, boost::ref(bufLevels)));
            }
            static void  timer_cb( 
                zinc::FutureValue<uint64_t> val, ZmpClient* /*t*/,
                std::vector<uint64_t>& bufLevels )
            {
                bufLevels.push_back( val.get() );
                LOG( "buf: %llus (%lluns)",
                    GST_TIME_AS_SECONDS(static_cast<long long unsigned>(val.get())), static_cast<long long unsigned>(val.get()) );
            }
        };

        std::vector<uint64_t> bufferLevels;

        DBus::DefaultTimeout* timer = mainloop.DBus::DefaultMainLoop::add_timeout(
             500, true, boost::bind(
                &Helper::timer, &client, _1, boost::ref(bufferLevels)));

        mainloop.DBus::DefaultMainLoop::add_timeout(
             20000, false, boost::bind(&DBus::DefaultTimeout::cancel, timer));

        mainloop.DBus::DefaultMainLoop::add_timeout(
             21000, false, boost::bind(&ZmpClient::stop, &client));

        mainloop.run();

        CPPUNIT_ASSERT_MESSAGE(
            "It appears that we couldn't collect enough samples",
             bufferLevels.size() > 10 );

        for ( size_t i = 0; i < bufferLevels.size()-1; ++i)
        {
            int64_t diff = bufferLevels[i+1] - bufferLevels[i];
            CPPUNIT_ASSERT_MESSAGE("It appears that PCR reset/wrap causes " 
                "timeshifter to stop accumulating buffers!",
                bufferLevels[i] <= bufferLevels[i+1]  );
            CPPUNIT_ASSERT_MESSAGE("It appears that PCR jumped ahead which is" 
                " unexpected in this test", 
                diff < GST_SECOND*20 );
        }
    }

    void test_thatSeekingTimeshiftingAcrossPcrWrapWorks()
    {
        ScopedRtpServer multicastServer( sourceAssetPath, 0x1fff00000ULL, 1 );
        ZmpClient client(mainloop, mutablePath, 0);

        std::map<std::string, DBus::Variant> kwargs;
        kwargs["use-buffering"] = DBus::Variant(true);
        kwargs["buffer-size"] = DBus::Variant(uint64_t(128 * 1024 * 1024));

        mainloop.post(bind(
            &ZmpClient::start2, &client, multicastServer.serveSDP(), kwargs));

        struct Helper
        {
            static void  timer( 
                ZmpClient* t, DBus::DefaultTimeout&, 
                std::vector<uint64_t>& bufLevels )
            {
                t->control->getPosition(0).setCallback(
                    *t->zincDispatcher, 
                    bind(&Helper::timer_cb, _1, t, boost::ref(bufLevels)));
            }
            static void  timer_cb(
                zinc::FutureValue<Position> val, ZmpClient* t,
                std::vector<uint64_t>& bufLevels )
            {
                bufLevels.push_back( -val.get().start );
                LOG("start: %d", -val.get().start );
                t->control->getBufferLevelTime().setCallback(
                    *t->zincDispatcher, bind(&Helper::timer_cb2, _1, t));
            }

            static void  timer_cb2( 
                zinc::FutureValue<uint64_t> val, ZmpClient* /*t*/ )
            {
                LOG( "buf: %llus (%lluns)",
                    GST_TIME_AS_SECONDS(static_cast<long long unsigned>(val.get())), static_cast<long long unsigned>(val.get()) );
            }

            static void seek(ZmpClient* t, DBus::DefaultTimeout& )
            {
                LOG("seek");
                t->control->seekPosition( 
                    SeekReference::start, 0, 
                    SeekMode::prioritise_accuracy,0).setCallback( 
                        *t->zincDispatcher, 
                        bind(&Helper::seek_cb, _1, t)) ;
            }

            static void seek_cb( zinc::FutureValue<void>, ZmpClient* /*t*/ )
            {
            }
        };

        std::vector<uint64_t> bufferStart;

        DBus::DefaultTimeout* timer = mainloop.DBus::DefaultMainLoop::add_timeout(
             500, true, boost::bind(
                &Helper::timer, &client, _1, boost::ref(bufferStart)));


        for ( size_t i=1; i<11; ++i ) {
            mainloop.DBus::DefaultMainLoop::add_timeout(
                 i* 21000, false, boost::bind(&Helper::seek, &client, _1));
        }
        
        mainloop.DBus::DefaultMainLoop::add_timeout(
            24000 * 10, false, boost::bind(&DBus::DefaultTimeout::cancel, timer));            

        mainloop.DBus::DefaultMainLoop::add_timeout(
             25000 * 10, false, boost::bind(&ZmpClient::stop, &client));

        mainloop.run();

        CPPUNIT_ASSERT_MESSAGE(
            "It appears that we couldn't collect enough samples",
             bufferStart.size() > 50 );

        for ( size_t i = 0; i < bufferStart.size()-1; ++i)
        {
            CPPUNIT_ASSERT_MESSAGE("It appears that PCR reset/wrap causes " 
                "timeshifter to stop accumulating buffers!",
                bufferStart[i] <= bufferStart[i+1]);
        }

        std::string expected = getMutableDataPath() + "/segment-1.ts";
        for (unsigned n = 2; n <= 10; n++) {
            std::string path = getMutableDataPath() + "/segment-" +
                boost::lexical_cast<std::string>(n) + ".ts";
            ASSERT_FILE_CONTENTS_EQUAL(expected, path, 4096);
        }
    }

private:

    CPPUNIT_TEST_SUITE(SourcePlaybackControlTest);

        CPPUNIT_TEST(test_ifFileComesThroughVerbatim);
        CPPUNIT_TEST(test_ifServerErrorEventIsGeneratedOn404HttpError);
        CPPUNIT_TEST(test_ifThrowsOnInvalidUrl);
        CPPUNIT_TEST(test_thatNetworkSourceErrorEventIsRaisedOnDNSResolutionFailure);
        CPPUNIT_TEST(test_thatSdpFileErrorEventIsRaisedWhenSDPFileContentsIsInvalid);
        CPPUNIT_TEST(test_ifThrowsWhenStartWasCalledAfterDestroy);
        CPPUNIT_TEST(test_ifThrowsWhenDestroyWasCalledBeforeStart);
        CPPUNIT_TEST(test_ifCanPauseAndResume);
        CPPUNIT_TEST(test_ifEmitsOverrun);
        CPPUNIT_TEST(test_ifFileDescriptorsAreProperlyClosedWhenControlObjectIsDestroyed);
        CPPUNIT_TEST(test_ifCanHaveConcurentStreamsPlayingAtTheSameTime);
        CPPUNIT_TEST(test_forNoFdLeaksWithConcurentStreams);
        CPPUNIT_TEST(test_ifSingleVqeMulticastStreamWorks);
        CPPUNIT_TEST(test_ifCanDoMultipleVQEStreams);
        CPPUNIT_TEST(test_ifgetSourceInformationWorks);
        CPPUNIT_TEST(test_ifTr135StatsAreLive);
        CPPUNIT_TEST(test_ifGetSourceInformationThrowsIfCalledAfterDestroy);
        CPPUNIT_TEST(test_ifGetPositionReturnsValidPositions);
        CPPUNIT_TEST(test_ifGetPosition2ReturnsValidPositionsAndBufferLevel);
        CPPUNIT_TEST(test_ifPushesFlushEvents);
        CPPUNIT_TEST(test_ifHttpUserAgentStringIsCorretlyCustomised);
        CPPUNIT_TEST(test_thatGetSourceInformationPerformanceIsUnaffectedByPacketLoss);
        CPPUNIT_TEST(test_ifCallingGetSourceInformationWhileInErrorStateByMalformedSDPCausesErrors);

//  This test has been disabled because after recent chages to timeshifter this
// test is no longer reliable. In the past timeshifter could only seek into 
// blocks aligned to 32K boundary. This has been changed (blocks/slots were removed
// to help with reduce memory usage). After that change test can't rely on the fact
// that certain seek will yeald the same data because it's much more sensitive to
// timings. 
//        CPPUNIT_TEST(test_thatSeekingToTheSamePointConsistentlyGivesTheSameData);
        CPPUNIT_TEST(test_thatIntensiveSeekingDoesntCauseEPIPEError);
        CPPUNIT_TEST(test_thatTimeshiftingAcrossPcrWrapWorks);
        CPPUNIT_TEST(test_thatSeekingTimeshiftingAcrossPcrWrapWorks);

    // this doesn't quite work, I blame gstreamer udpsink
    // it fails to deliver remaining few kilobytes of the stream
    //  CPPUNIT_TEST(test_ifUdpMulticastComesThroughVerbatim);

        // TODO:
        // CPPUNIT_TEST(test_ifDaemonCrashesClientReceivesAnError);
        // CPPUNIT_TEST(test_ifClientCrashesDaemonSendsAnError);
        // CPPUNIT_TEST(test_ifCallingDestroyCausesEPIPEonTheZmpClientErrorCallback);
        // CPPUNIT_TEST(test_ifSeekGetsPropagatedUpstreamAndSegmentEventIsGenerated);

    CPPUNIT_TEST_SUITE_END();

};

CPPUNIT_TEST_SUITE_REGISTRATION(SourcePlaybackControlTest);

NS_NICKEL_LINEARSOURCE_CLOSE

// ---------------------------------------------------------------------------

size_t soakNumRuns = 0;

struct ZINC_LOCAL SoakTestChannel : public ControlEventListener
{
    boost::shared_ptr<ZmpClient>    client;
    DBus::BusDispatcher&            mainloop;
    static boost::mt19937           random;
    std::string                     uri;

    SoakTestChannel(DBus::BusDispatcher& mainloop_, std::string uri_,
                    const uint32_t flags)
     : mainloop(mainloop_), uri(uri_)
    {
        startStreaming ( flags );
    }

    void startStreaming ( const uint32_t flags )
    {
        // introduce size variation
        const size_t variableSize = 2 * MB + ( random() % MB );

        client = boost::make_shared<ZmpClient> (
            boost::ref(mainloop), std::string(""), variableSize,
            shared_ptr<ControlEventListener>(this, nullDeletor));

        mainloop.DBus::DefaultMainLoop::post_function(
            boost::bind(&ZmpClient::start, client.get(), uri, flags));

        client->onDestroyedCallback =
            boost::bind (&SoakTestChannel::startStreaming, this, flags);

        soakNumRuns++;
        LOG("++++++++ Soaktest, num chan. changes: %zu",
                soakNumRuns);
    }

    void ErrorEvent(const Zinc::Media::ErrorEventValue::Enum,
                    const Zinc::Media::ErrorEventContext::Enum,
                    const std::string& message)
    {
        LOG("LinearSource ErrorEvent:\n%s", message.c_str());
        mainloop.leave();
    }

    void Overrun() {}

    virtual ~SoakTestChannel() { };
};

boost::mt19937  SoakTestChannel::random;

int soakTest(const std::vector<std::string>& soakTestSDPFiles,
             const uint32_t flags)
{
    NS_ZINC_DBUS_BINDING::TestUsingServiceDaemon lsd(
        "", "linearsource-launch", BUS_NAME);
    lsd.startService();

    DBus::BusDispatcher mainloop;

    SoakTestChannel::random.seed( static_cast<unsigned int>(std::time(0)) );

    std::vector< boost::shared_ptr< SoakTestChannel> > clients;

    for ( size_t a = 0; a < soakTestSDPFiles.size(); a++ )
    {
        printf ( "Using sdp file:\t%s\n", soakTestSDPFiles[a].c_str() );
        clients.push_back(boost::make_shared<SoakTestChannel>(
            boost::ref(mainloop), soakTestSDPFiles[a], flags));
    }

    mainloop.run();

    return 0;
}
