/*
 * linearsourcetest.cpp
 *
 *  Created on: 28 Oct 2012
 *      Author: mariusz.buras@youview.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#include "test/testbank.h"
#include "../include/macros.h"
#include "Control.h"
#include "src/LinearSourceFactoryImpl.h"
#include "../src/LinearSourceFactoryDBusClient.h"
#include "../include/MockControlEventListener.h"
#include "src/FactoryAsyncToDBus.h"

#include "src/bus-name.h"
#include "../zmp/zmp.h"

#include <zinc-common/testsupport/VerifyAndClearDispatcher.h>
#include <zinc-common/testsupport/TestRunner.h>
#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/assert_within_timeout.h>
#include <zinc-common/testsupport/AtomicBool.h>
#include <cppunit/extensions/HelperMacros.h>

#include <zinc-binding-runtime/dbus/NonInheritingAdaptorFactory.h>
#include <zinc-binding-runtime/dbus/RefCountedAdaptor.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>

#include <dbus-c++/eventloop-integration.h>

#include <boost/thread.hpp>
#include <boost/make_shared.hpp>

#include <gst/gst.h>

using NS_ZINC_DBUS_BINDING::TestUsingDbus;
using namespace NS_ZINC;
using namespace testing;
using namespace Zinc::Media::LinearSource;

// keep test bank global until I can figure out a better way of passing it
// into tests
TestBank::Sources sources;

int main(int argc, char* argv[])
{
    std::string mediaSources;
    NS_ZINC::TestRunner runner;

    boost::program_options::options_description suiteOpts("Test suite options");
    suiteOpts.add_options()
        ("media-sources", boost::program_options::value<std::string>(&mediaSources),
                       "File from which to load the test media URLs");

    runner.parseOptions(argc, argv, suiteOpts);

    sources = TestBank::loadTestBankFromFileOrDefaults ( mediaSources ) ;

    return runner.run();
}

NS_NICKEL_LINEARSOURCE_OPEN

/**
 */

class ZINC_LOCAL LinearSourceControlTest : public IntegrationTestSandbox,
                                           public TestUsingDbus,
                                           public CppUnit::TestFixture
{

    boost::thread t;
    boost::shared_ptr<DBus::BusDispatcher> busDispatcher;
    DBus::Connection conn1;
    boost::shared_ptr< Zinc::Media::LinearSource::FactoryAsync > factoryAsync;
    boost::shared_ptr<NS_ZINC_DBUS_BINDING::BusNameMonitor> bnm;
    boost::shared_ptr<NS_ZINC::Dispatcher> futureDispatcher;
    GMainLoop* loop;
    boost::thread gstThread;
    boost::shared_ptr<ControlAsync> control, control2;
    DBus::UnixFD ser, imm;
    boost::shared_ptr<MockControlEventListener> mockControlEvent;

public:

    LinearSourceControlTest()
    {
    }

    virtual void setUp()
    {
        AtomicBool  loopReady;
        gst_init ( NULL, NULL );
        loop = g_main_loop_new (NULL, FALSE);
        boost::thread(g_main_loop_run, loop).swap(gstThread);
        // wait until loop starts
        g_idle_add(loopStarted, &loopReady);
        CPPUNIT_ASSERT(loopReady.waitUntilEqual(true, 5000));

        busDispatcher = boost::make_shared<DBus::BusDispatcher>();
        DBus::StandardConnectionFactory fact(busDispatcher);
        conn1 = fact.connectToSessionBus();
        bnm = boost::make_shared<NS_ZINC_DBUS_BINDING::BusNameMonitor> (conn1);
        futureDispatcher = boost::make_shared<NS_ZINC::SingleThreadDispatcher>();

        boost::shared_ptr<Factory> factory = createLinearSourceFactory(
            *futureDispatcher, 2 * 1024 * 1024, "YouView",32000);

        expose(conn1, NS_NICKEL_LINEARSOURCE::OBJECT_PATH_FACTORY, factory,
            boost::make_shared<NS_ZINC_DBUS_BINDING::NonInheritingAdaptorFactory<Control> >(
                NS_ZINC_DBUS_BINDING::RefCountedAdaptorFactory<Control>(*bnm),
                conn1, NS_NICKEL_LINEARSOURCE::OBJECT_PATH_CONTROL));

        conn1.request_name(NS_NICKEL_LINEARSOURCE::BUS_NAME);

        // --------------------------------------------------------------------------

        factoryAsync = createLinearSourceFactoryDBusClient(futureDispatcher, conn1);

        mockControlEvent = boost::make_shared<MockControlEventListener>();

        // --------------------------------------------------------------------------

        t = boost::thread(boost::bind(&DBus::BusDispatcher::run, busDispatcher));

    }

    virtual void tearDown()
    {
        try
        {
            if ( control )
            {
                control->destroy().get();
            }
        }
        catch (...) {/* ignore errors: it might be 'destroy() called twice' exception */}
        try
        {

            if ( control2 )
            {
                control2->destroy().get();
            }
        }
        catch (...){/* ignore errors: it might be 'destroy() called twice' exception */}

        VERIFY_AND_CLEAR_DISPATCHER(busDispatcher, 5000);
        busDispatcher->leave();
        t.join();
        busDispatcher.reset();

        VERIFY_AND_CLEAR_DISPATCHER(futureDispatcher, 5000);
        futureDispatcher.reset();

        bnm.reset();
        conn1.close();

        control.reset();
        control2.reset();
        factoryAsync.reset();

        using ::testing::Mock;

        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockControlEvent.get()));

            // join gst main loop thread
        g_main_loop_quit(loop);

        gstThread.join();
    }

    static gboolean loopStarted(gpointer data)
    {
        CPPUNIT_ASSERT(data);

        reinterpret_cast<AtomicBool*>(data)->set(true);

        return FALSE;
    }

    void createControl(const std::string uri = sources.TS_LICENCE_FREE,
                       bool buffered = false )
    {
        boost::tie (control, ser, imm) =
            factoryAsync->create (uri, buffered).get();
        CPPUNIT_ASSERT ( control.get() );
        //control->addListener( mockControlEvent );
    }

    void createControlFailBeforeStartCalled()
    {
        boost::tie(control, ser, imm) =
            factoryAsync->create("please_fail://224.7.1.1:60000", 0).get();
        CPPUNIT_ASSERT ( control.get() );
        control->addListener( mockControlEvent );
    }

    void test_ifDestroyCanBeCalledWithoutStart()
    {
        createControl();
        CPPUNIT_ASSERT_NO_THROW( control->destroy().get()  );
    }
    void test_ifDestroyThrowsIfCalledTwiceAfterStart()
    {
        createControl();
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW( control->destroy().get() );
        CPPUNIT_ASSERT_THROW( control->destroy().get(), std::runtime_error );
    }
    void test_ifStartThrowsIfCalledAfterDestroy()
    {
        createControl();
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW( control->destroy().get() );
        CPPUNIT_ASSERT_THROW( control->start().get(), std::runtime_error );
    }
    void test_ifGetSourceInformationThrowsIfCalledBeforeStart()
    {
        createControl();
        CPPUNIT_ASSERT_THROW(control->getSourceInformation().get(),
                             std::runtime_error);
    }
    void test_ifGetSourceInformationDeadlocksRegression()
    {
        /*
         * In certain cases this test was deadlocking GstVqe.
         * This exposed a problem with GstVqe and was fixed.
         */

        createControl(std::string("file://") +
                      getDataFinder().find( "test.sdp"));
        CPPUNIT_ASSERT_NO_THROW(control->start().get());
        std::map< std::string, std::string > sourceinfo;

        /*
         *   TODO:
         * work out API change to get ride of this
         * ugly loop.
         */
        while ( true )
        {
            sourceinfo = control->getSourceInformation().get();
            if ( sourceinfo[ "TYPE" ] == "RTP" )
            {
                break;
            }
        }
        CPPUNIT_ASSERT_EQUAL ( std::string("RTP"), sourceinfo[ "TYPE" ] );
    }

    void test_ifGetBufferLevelTimeThrowsIfCalledBeforeStart()
    {
        createControl();
        CPPUNIT_ASSERT_THROW(control->getBufferLevelTime().get(),
                             std::runtime_error);
    }
    void test_ifGetBufferLevelTimeThrowsIfCalledAfterDestroy()
    {
        createControl();
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW( control->destroy().get() );
        CPPUNIT_ASSERT_THROW(control->getBufferLevelTime().get(),
                             std::runtime_error );
    }

    void test_ifGetBufferLevelTimeReturnsIfCalledAfterStart()
    {
        createControl(sources.TS_LICENCE_FREE, true);
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW( control->getBufferLevelTime().get() );
    }

    void test_ifGetPositionThrowsIfCalledBeforeStart()
    {
        createControl();
        CPPUNIT_ASSERT_THROW(
            control->getPosition( 0 ).get(), std::runtime_error );
    }

    void test_ifGetPositionThrowsIfCalledAfterDestroy()
    {
        createControl();
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW( control->destroy().get() );
        CPPUNIT_ASSERT_THROW(
            control->getPosition( 0 ).get(), std::runtime_error );
    }

    void test_ifGetPositionReturnsIfCalledAfterStart()
    {
        createControl(sources.TS_LICENCE_FREE, true);
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW( control->getPosition( 0 ).get() );
    }

    void test_ifSeekPositionThrowsIfCalledBeforeStart()
    {
        createControl();
        CPPUNIT_ASSERT_THROW(
            control->seekPosition(
                SeekReference::end, 0, SeekMode::prioritise_accuracy, 0 )
            .get(),
            std::runtime_error );
    }

    void test_ifSeekPositionThrowsIfCalledAfterDestroy()
    {
        createControl();
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW( control->destroy().get() );
        CPPUNIT_ASSERT_THROW(
            control->seekPosition(
                SeekReference::end, 0, SeekMode::prioritise_accuracy, 0 )
            .get(),
            std::runtime_error );
    }

    void test_ifSeekPositionReturnsIfCalledAfterStart()
    {
        createControl(sources.TS_LICENCE_FREE, true);
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT_NO_THROW(
            control->seekPosition(
                SeekReference::end, 0, SeekMode::prioritise_accuracy, 0 )
            .get() );
    }

    void test_ifErrorsAreNotThrownBeforeStartIsCalled ()
    {
        createControlFailBeforeStartCalled();
    }

    void test_ifErrorIsThrownBeforeAfterStartIsCalled ()
    {
        using ::testing::_;
        AtomicBool done1;
        EXPECT_CALL( *mockControlEvent, ErrorEvent( _, _, _ ) )
            .WillOnce(Assign(&done1, true));
        createControlFailBeforeStartCalled();
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        CPPUNIT_ASSERT(done1.waitUntilEqual(true, 10000));
    }
    void test_ifErrorsAreCorrectlyDeliveredWithMultipleControlObjectsActive()
    {
        boost::shared_ptr<MockControlEventListener> listener1, listener2;
        DBus::UnixFD ser1,imm1,ser2,imm2;

        boost::tie(control, ser1, imm1) =
            factoryAsync->create( "please_fail://224.7.1.1:666",0 ).get();
        boost::tie(control2, ser2, imm2) =
            factoryAsync->create ( "please_fail://224.7.1.1:666",0 ).get();

        CPPUNIT_ASSERT ( control.get() );
        CPPUNIT_ASSERT ( control2.get() );

        listener1 = boost::make_shared<MockControlEventListener>();
        listener2 = boost::make_shared<MockControlEventListener>();

        AtomicBool done1;
        AtomicBool done2;

        using ::testing::_;
        using ::testing::Return;
        EXPECT_CALL(*listener1, ErrorEvent( _, _, _ ))
            .WillOnce(Assign(&done1, true));
        EXPECT_CALL(*listener2, ErrorEvent( _, _, _ ))
            .WillOnce(Assign(&done2, true));

        control->addListener( listener1 );
        control2->addListener( listener2 );

        zinc::Future<void> f1 = control->start();
        zinc::Future<void> f2 = control2->start();

        CPPUNIT_ASSERT(done1.waitUntilEqual(true, 10000));
        CPPUNIT_ASSERT(done2.waitUntilEqual(true, 10000));

        f1.get();
        f2.get();

        using ::testing::Mock;
        CPPUNIT_ASSERT ( Mock::VerifyAndClearExpectations(listener1.get() ) ) ;
        CPPUNIT_ASSERT ( Mock::VerifyAndClearExpectations(listener2.get() ) ) ;
    }
    void test_ifNoErrorEventsWillArriveOverDBusAfterDestroyWasCalled()
    {
        using ::testing::_;
        EXPECT_CALL( *mockControlEvent, ErrorEvent( _, _, _ ) ).Times(0);
        createControl();
        control->addListener( mockControlEvent );
        CPPUNIT_ASSERT_NO_THROW( control->start().get() );
        sleep(1);
        CPPUNIT_ASSERT_NO_THROW( control->destroy().get() );
        sleep(1);       // allow for the potential error events to arrive
    }
private:

    CPPUNIT_TEST_SUITE(LinearSourceControlTest);

        CPPUNIT_TEST(test_ifDestroyCanBeCalledWithoutStart);
        CPPUNIT_TEST(test_ifDestroyThrowsIfCalledTwiceAfterStart);
        CPPUNIT_TEST(test_ifStartThrowsIfCalledAfterDestroy);

        CPPUNIT_TEST(test_ifGetSourceInformationThrowsIfCalledBeforeStart);
        CPPUNIT_TEST(test_ifGetSourceInformationDeadlocksRegression);

        CPPUNIT_TEST(test_ifGetBufferLevelTimeThrowsIfCalledBeforeStart);
        CPPUNIT_TEST(test_ifGetBufferLevelTimeThrowsIfCalledAfterDestroy);
        CPPUNIT_TEST(test_ifGetBufferLevelTimeReturnsIfCalledAfterStart);

        CPPUNIT_TEST(test_ifGetPositionThrowsIfCalledBeforeStart);
        CPPUNIT_TEST(test_ifGetPositionThrowsIfCalledAfterDestroy);
        CPPUNIT_TEST(test_ifGetPositionReturnsIfCalledAfterStart);

        CPPUNIT_TEST(test_ifSeekPositionThrowsIfCalledBeforeStart);
        CPPUNIT_TEST(test_ifSeekPositionThrowsIfCalledAfterDestroy);
        CPPUNIT_TEST(test_ifSeekPositionReturnsIfCalledAfterStart);

        CPPUNIT_TEST(test_ifErrorsAreNotThrownBeforeStartIsCalled);
        CPPUNIT_TEST(test_ifErrorIsThrownBeforeAfterStartIsCalled);
        CPPUNIT_TEST(test_ifErrorsAreCorrectlyDeliveredWithMultipleControlObjectsActive);
        CPPUNIT_TEST(test_ifNoErrorEventsWillArriveOverDBusAfterDestroyWasCalled);

    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(LinearSourceControlTest);

NS_NICKEL_LINEARSOURCE_CLOSE
