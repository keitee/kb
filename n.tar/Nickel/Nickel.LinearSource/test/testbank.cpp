/*
 * testbank.cpp
 *
 *  Created on: 5 Nov 2012
 *      Author: mariusz.buras@youview.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#include "testbank.h"

#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <boost/program_options.hpp>

using namespace std;
using namespace boost;
using namespace NS_ZINC;

namespace po = boost::program_options;

#define TESTBANK_SOURCE(desc, name, url) \
    ( #name, po::value<std::string>(&sources. name )->default_value(url), desc )

namespace TestBank
{

Sources loadTestBankFromFileOrDefaults ( const std::string& mediaSourcesFile ) 
{
    Sources sources;

    po::options_description testbankOpts("Test-bank sources");
    testbankOpts.add_options()
        TESTBANK_SOURCE("Transport stream 5 seconds",
            TS_5_SECS, "http://pmd.youview.co.uk/VA-504.ts")
        TESTBANK_SOURCE("transport stream - length 30 secs - embedded subtitles",
            TS_30_SECS, "http://pmd.youview.co.uk/VA-503.ts")
        TESTBANK_SOURCE("MPG asset - length 10 minutes",
            TS_10_MINS, "http://pmd.youview.co.uk/VA-301.mpg")
        TESTBANK_SOURCE("mpg stream - length  - no subtitles",
            MPG_10_MINS,    "http://pmd.youview.co.uk/VA-301.mpg")
        TESTBANK_SOURCE("MPG asset - length 15 minutes",
            TS_15_MINS, "http://pmd.youview.co.uk/VA-501.mpg")
        TESTBANK_SOURCE("",
            TS_10_MINS_ENCRYPTED,   "https://testdrm.youview.com/sas/b00jw8y6?bt=_wAAMgAAASMAAAAATVQ2qAAAAAAAAAAAAB5HEeivE3P2wauo3xCdLTT9Ia_eAABwAAAAB_8BC63R9cwhdVH-pSbYmGRNAm1-_Vc#http://filegateway.youview.co.uk/test_assets/licence_free/VA-306.mpg")
        TESTBANK_SOURCE("MPG asset - length 2 hours",
            TS_2_HOURS, "http://filegateway.youview.co.uk/test_assets/restricted/VA-237.mpg")
        TESTBANK_SOURCE("RTMP stream - length 30 secs",
            RTMP_30_SECS,   "rtmp://cp114711.edgefcs.net/ondemand/mp4:VA-507_rtmp.mp4")
        TESTBANK_SOURCE("RTMP stream - length 5 secs",
            RTMP_5_SECS,    "rtmp://cp114711.edgefcs.net/ondemand/mp4:VA-508_rtmp.mp4")
        TESTBANK_SOURCE("RTMP stream - length 15 minutes",
            RTMP_15_MINS,   "rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_1500_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 800kbps",
            RTMP_ABR_800,   "rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_800_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 1500kbps",
            RTMP_ABR_1500,  "rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_1500_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 2800kbps",
            RTMP_ABR_2800,  "rtmp://cp114711.edgefcs.net/ondemand/mp4:S003_2800_rtmp.mp4")
        TESTBANK_SOURCE("RTMP ABR stream - 2800kbps",
            RTMP_TIMING_APP,    "rtmp://cp114711.edgefcs.net/ondemand/mp4:TimingApp.mp4")
        TESTBANK_SOURCE("RTMP AAC audio-only mp4",
            RTMP_AAC_AUDIO, "rtmp://cp114711.edgefcs.net/ondemand/mp4:RBN2_radio_4_fm_-_tuesday_2040_b014q043_2011_09_20_20_35_00.mp4")
        TESTBANK_SOURCE("valid locator but missing asset (404)",
            ASSET_MISSING,  "http://filegateway.youview.co.uk/test_assets/licence_free/VA-503_nonavailable.ts")
        TESTBANK_SOURCE("a server error is returned",
            HTTP_400_ERROR_RESPONSE,    "http://testdrm.youview.com/400badrequest.php")
        TESTBANK_SOURCE("a server error is returned",
            HTTP_504_ERROR_RESPONSE,    "http://testdrm.youview.com/504_error.php")
        TESTBANK_SOURCE("malformat Source URL",
            MALFORMANT_URL, "https://testdrm.youview.com/sas/b00jw8y6?bt=_wAAMgAAASMAAAAATVQ2qAAAAAAAAAAAAB5HEeivE3P2wauo3xCdLTT9Ia_eAABwAAAAB_8BC63R9cwhdVH-pSbYmGRNAm1-_Vc#httpilegateway.youview.co.uk/test_assets/licence_free/VA-306.mpg")
        TESTBANK_SOURCE("Original 10 minute file that runs with Elephants Dream",
            TTML_EN_10_MINS,    "http://filegateway.youview.co.uk/test_assets/licence_free/VA-303.ttml")
        TESTBANK_SOURCE("Language - en",
            TTML_EN,    "http://pmd.youview.co.uk/YV-TTML-9-4.4.9-AnotherLang-en.ttml")
        TESTBANK_SOURCE("Language - cy",
            TTML_CY,    "http://pmd.youview.co.uk/YV-TTML-10-4.4.9-AnotherLang-cy.ttml")
        TESTBANK_SOURCE("Language - gd",
            TTML_GD,    "http://pmd.youview.co.uk/YV-TTML-11-4.4.9-AnotherLang-gd.ttml")
        TESTBANK_SOURCE("Language - ga",
            TTML_GA,    "http://pmd.youview.co.uk/YV-TTML-13-4.4.9-AnotherLang-ga.ttml")
        TESTBANK_SOURCE("licence free TS stream",
            TS_LICENCE_FREE,    "http://filegateway.youview.co.uk/test_assets/licence_free/VA-305.mpg")
        TESTBANK_SOURCE("Cloud Geographic",
            SDP_CLOUD_GEO, "http://54.225.86.153/INT01_LCN_551.sdp");

    if (!mediaSourcesFile.empty()) {
        po::variables_map vm;
        po::store(po::parse_config_file<char>(mediaSourcesFile.c_str(), testbankOpts, false), vm);
        notify(vm);
    }
    else
    {   
        // MB: So at this point we don't have a config file and we want to use default
        // values.
        // This is a bit ugly, but for the time being I don't know of any other way to get 
        // defaults in set when  mediaSourcesFile file is not provided.
        po::variables_map vm;
        po::store(parse_command_line(0, (char**) NULL, testbankOpts), vm);  
        notify(vm);
    }
    return sources;
}

} // namespace TestBank