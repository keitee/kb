#ifndef ZMP_ZMP_H__
#define ZMP_ZMP_H__

#include "events.h"
#include "unistd.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct ZMPStream_ ZMPStream;

#define ZMP_EXPORT __attribute__ ((visibility("default")))

/****************************************
 * Lifetime management:
 ****************************************/

/**
 * Create a ZMPStream object.
 *
 * The two file descriptors should be UNIX domain sockets created with
 * SOCK_SEQPACKET.  The other ends of the file descriptors should be connected
 * to the write end.
 */
ZMP_EXPORT ZMPStream* zmp_stream_new(int serialized_events_fd,
                                     int immediate_events_fd);

/**
 * Destroy a ZMPStream object.
 *
 * This function must not be called from within any of the stream's callback
 * functions.
 */
ZMP_EXPORT void zmp_stream_free(ZMPStream* stream);

/****************************************
 * Integration:
 ****************************************/

/* 
 * Integration Overview
 * ====================
 *
 * ZMP models a communications channel over which data and events can be sent.
 * Some of these events are sent upstream and some downstream.  The downstream
 * events can be synchronised with the data stream.  Events and data are sent
 * to the user via callbacks.  See zmp_stream_set_callbacks.
 *
 * ZMP is intended to integrate with existing systems without requiring
 * additional threads.  All I/O is non-blocking and ZMP provides a file-
 * descriptor for integration with existing main-loops.  The user is expected
 * to listen for events on the file descriptor returned by
 * zmp_stream_get_listen_fd() and call zmp_stream_notify() when they occur.
 * This will do I/O and call the appropriate user callbacks as required.
 */

/*
 * Events Overview
 * ===============
 *
 * The events are identical to Gstreamer events.  See the Gstreamer reference
 * documentation[1] and plugin writers guide[2] for in depth information.  For
 * our purposes the important incoming events are:
 *
 *  * FLUSH_START - All buffers should be dropped immediately
 *  * FLUSH_STOP - Handled by ZMP, it may not be necessary for users to use
 *                 this.
 *  * SEGMENT - Sent before some data such that the PTS can be calculated, etc.
 *              See gst_event_new_segment[3] for more information.
 *
 * All other incoming events should be ignored.
 *
 * [1]:http://gstreamer.freedesktop.org/data/doc/gstreamer/head/gstreamer/html/gstreamer-GstEvent.html
 * [2]:http://gstreamer.freedesktop.org/data/doc/gstreamer/head/pwg/html/section-events-definitions.html
 * [3]:http://gstreamer.freedesktop.org/data/doc/gstreamer/head/gstreamer/html/gstreamer-GstEvent.html#gst-event-new-segment
 */

typedef void (*zmp_event_callback)(void *user_data, ZMPStream *stream,
                                   ZMPEventHeader *header, size_t payload_bytes,
                                   void *payload);
typedef ssize_t (*zmp_data_callback)(void *user_data, ZMPStream *stream,
                                     int input_fd);
typedef void (*zmp_error_callback)(void *user_data, ZMPStream *stream,
                                   int error, char* desc);

/**
 * Register user functions to handle events and errors and read data
 *
 * user_data:
 *     This pointer will be passed as the first parameter to each user function
 *     set here.
 * on_event:
 *     Called when an event arrives.  See "Events Overview" above.
 * on_data:
 *     Called when data should be transferred.  Data should be read from
 *     input_fd.  This callback is intended to behave like the standard UNIX
 *     function read() when called on a non-blocking file-descriptor.
 *
 *     When data is available libzmp will call this callback repeatedly until
 *     it either returns 0 (to indicate EOF on input_fd) or -1 (to indicate an
 *     an error.  This function should behave like read in that:
 *      * If any data was successfully consumed it should return the number of
 *        bytes that had been consumed.
 *      * If reading data from the pipe would cause the function to block it
 *        should return -1 and set errno to EAGAIN.
 *      * If consuming the data would otherwise require on_data to block it
 *        should return -1 and set errno to EAGAIN.  This might happen if the
 *        decoder buffer that on_data is feeding were full.
 *        zmp_stream_notify_read_ready should be called once you are again
 *        ready to consume data.  zmp_stream_notify_read_ready can be called
 *        from any thread.
 *      * If no data could be consumed because of an error it should return -1
 *        and errno set appropriately.  This will put libzmp into an error
 *        state and no further data will be available.
 *
 *     The input_fd argument must not be used outside this function.
 * on_error:
 *     Called when an error occurs.  This stream will enter an error state and
 *     subsequent calls to zmp_stream_request_seek will fail by returning 1.
 *     zmp_stream_free must *not* be called from this callback.
 *
 *     If the remote end closes the stream this callback will be called with
 *     error==EPIPE
 */
ZMP_EXPORT void zmp_stream_set_callbacks(ZMPStream *stream, void *user_data,
                                         zmp_event_callback on_event,
                                         zmp_data_callback on_data,
                                         zmp_error_callback on_error);

/* The file descriptor returned from the following call should be poll()ed and
   when an event happens zmp_stream_on_event should be called. */
ZMP_EXPORT int zmp_stream_get_listen_fd(ZMPStream* stream);

/* This function should be called when the file-descriptor returned by
   zmp_stream_get_listen_fd() becomes ready for reading.  Returns 0 on success
   and non-zero if the stream is in an error state.  It is not possible to
   return from an error state and the user should destroy the stream with
   zmp_stream_free. */
ZMP_EXPORT int zmp_stream_notify(ZMPStream *stream);

/* Call to notify that you are ready to read.  It is safe to call from any
   thread. */
ZMP_EXPORT void zmp_stream_notify_read_ready(ZMPStream *stream);

/****************************************
 * Sending Events:
 ****************************************/

/**
 * Request a seek from upstream.  See the Gstreamer documentation for
 * gst_event_new_seek[1] for the meanings of the arguments.
 *
 * Returns 0 on success.  Returns EAGAIN if sending the seek request would
 * require blocking on I/O.  Returns ECONNRESET if stream is in the error
 * state.
 *
 * [1]:http://developer.gnome.org/gstreamer/unstable/gstreamer-GstEvent.html#gst-event-new-seek
 */
ZMP_EXPORT int zmp_stream_request_seek(ZMPStream* stream, double rate,
                                       ZMPFormat format, ZMPSeekFlags flags,
                                       ZMPSeekType start_type, int64_t start,
                                       ZMPSeekType stop_type, int64_t stop);

/**
 * Get the current position stream time.
 *
 * The function calculates the current position in the stream in nanoseconds.
 * The stream time counts from 0.
 *
 * The segment and portion payload arguments are supposed to be saved when
 * segment and portion events are received.
 * The portionStreamTime argument is a difference between the first timestamp
 * (e. g. PTS) available in the portion and the current one in nanoseconds.
 */
ZMP_EXPORT uint64_t zmp_portion_time_to_stream_time(ZMPSegmentEventPayload* s,
                                                    ZMPPortionEventPayload* p,
                                                    uint64_t portionStreamTime);
#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* ZMP_ZMP_H__ */
