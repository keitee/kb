/* GstZMPSink
 * Copyright (C) 2012 YouView TV Ltd. <william.manley@youview.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/**
 * SECTION:element-zmpsink
 *
 *
 */

#include <gst/gst.h>
#include "events.h"

#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <fcntl.h>
#include <assert.h>

#define GST_TYPE_ZMP_SINK \
  (gst_zmp_sink_get_type())
#define GST_ZMP_SINK(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_ZMP_SINK,GstZMPSink))
#define GST_ZMP_SINK_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_ZMP_SINK,GstZMPSinkClass))
#define GST_IS_ZMP_SINK(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_ZMP_SINK))
#define GST_IS_ZMP_SINK_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_ZMP_SINK))
#define GST_ZMP_SINK_CAST(obj) ((GstZMPSink *) (obj))

typedef struct _GstZMPSink GstZMPSink;
typedef struct _GstZMPSinkClass GstZMPSinkClass;

#define GST_ZMP_SINK_GET_LOCK(zmp) (((GstZMPSink*)(zmp))->lock)
#define GST_ZMP_SINK_LOCK(zmp) (g_mutex_lock(GST_ZMP_SINK_GET_LOCK(zmp)))
#define GST_ZMP_SINK_UNLOCK(zmp) (g_mutex_unlock(GST_ZMP_SINK_GET_LOCK(zmp)))

// We used to use -1 as a dummy file descriptor. This is
// not correct because replace_data_fd function will try to set this value
// as a g_object property and because it is in incorrect range for an FD it
// will print a scary error message. This is now fixed by dummyFD.
const static int dummyFD = 1;

struct _GstZMPSink
{
  GstBin parent_instance;

  GstElement * sink;
  gboolean new_segment;

  GstTask * immediate_event_task;
  GRecMutex task_mutex;
  GstPoll * immediate_event_poll;
  GstPollFD immediate_event_fd;

  GstPollFD serialized_event_fd;

  GMutex fd_mutex;
};

struct _GstZMPSinkClass
{
  GstBinClass parent_class;
};

GST_DEBUG_CATEGORY_STATIC (gst_zmp_sink_debug);
#define GST_CAT_DEFAULT gst_zmp_sink_debug

/* properties */
#define DEFAULT_SERIALIZED_EVENT_FD  3
#define DEFAULT_IMMEDIATE_EVENT_FD   4

enum
{
  PROP_0,
  PROP_SERIALIZED_EVENT_FD,
  PROP_IMMEDIATE_EVENT_FD,
  PROP_LAST
};

GType gst_zmp_sink_get_type (void);
G_DEFINE_TYPE (GstZMPSink, gst_zmp_sink, GST_TYPE_BIN);

static void gst_zmp_sink_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec);
static void gst_zmp_sink_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec);
static void gst_zmp_sink_dispose (GObject * obj);
static void gst_zmp_sink_finalize (GObject * obj);

static void handle_message (GstBin * bin, GstMessage * msg);

static void immediate_event_task (gpointer user_data);
static GstStateChangeReturn gst_zmp_sink_change_state (GstElement *
    element, GstStateChange transition);
static void handle_upstream_event(GstZMPSink * zmp, void * buf,
    size_t bufsize);
static void
replace_data_fd(GstZMPSink* sink, int newfd);
static gboolean
gst_zmp_pad_on_event(GstPad *pad, GstObject *parent, GstEvent *event);
static GstFlowReturn
gst_zmp_pad_chain(GstPad *pad, GstObject *parent, GstBuffer *buffer);

static void
gst_zmp_sink_base_init (gpointer g_class)
{
  GstElementClass *gstelement_class = GST_ELEMENT_CLASS (g_class);

  gst_element_class_set_details_simple (gstelement_class,
      "ZMP Sink", "Generic/Sink",
      "Send data and events to another process",
      "William Manley <william.manley@youview.com>");
}

static void
gst_zmp_sink_class_init (GstZMPSinkClass * klass)
{
  GObjectClass *gobject_class;
  GstElementClass *gstelement_class;
  GstBinClass *gstbin_class;

  gobject_class = G_OBJECT_CLASS (klass);
  gstelement_class = GST_ELEMENT_CLASS (klass);
  gstbin_class = GST_BIN_CLASS (klass);

  gobject_class->set_property = gst_zmp_sink_set_property;
  gobject_class->get_property = gst_zmp_sink_get_property;
  gobject_class->dispose = gst_zmp_sink_dispose;
  gobject_class->finalize = gst_zmp_sink_finalize;

  g_object_class_install_property (gobject_class, PROP_SERIALIZED_EVENT_FD,
      g_param_spec_uint ("serialized-events-fd", "Serialized Events FD",
          "File descriptor of socket over which serialized events and data "
          "pipes will be sent",
          0, G_MAXINT, DEFAULT_SERIALIZED_EVENT_FD,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  g_object_class_install_property (gobject_class, PROP_IMMEDIATE_EVENT_FD,
      g_param_spec_uint ("immediate-events-fd", "Immediate Events FD",
          "File descriptor of socket over which immediate events will be "
          "received and sent",
          0, G_MAXINT, DEFAULT_IMMEDIATE_EVENT_FD,
          G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

  gstelement_class->change_state =
      GST_DEBUG_FUNCPTR (gst_zmp_sink_change_state);

  gstbin_class->handle_message = GST_DEBUG_FUNCPTR (handle_message);
}

static void
gst_zmp_sink_init (GstZMPSink * zmp)
{
  gboolean success;
  GstPad *pad = NULL, *ghost_pad = NULL;

  gst_poll_fd_init(&zmp->serialized_event_fd);
  gst_poll_fd_init(&zmp->immediate_event_fd);

  zmp->serialized_event_fd.fd = DEFAULT_SERIALIZED_EVENT_FD;
  zmp->immediate_event_fd.fd = DEFAULT_IMMEDIATE_EVENT_FD;

  zmp->immediate_event_poll = gst_poll_new(TRUE);
  if (!zmp->immediate_event_poll) {
    /* TODO: Handle this error */
    abort();
  }
  zmp->immediate_event_task = gst_task_new(immediate_event_task, zmp, NULL);
  if (!zmp->immediate_event_task) {
    /* TODO: Handle this error */
    abort();
  }
  g_rec_mutex_init(&zmp->task_mutex);
  gst_task_set_lock(zmp->immediate_event_task, &zmp->task_mutex);

  zmp->sink = gst_element_factory_make ("fdsink", "sink");
  if (!zmp->sink) {
    /* TODO: Handle this error */
    abort();
  }
  /* We don't want fdsink to wait for pre-roll as the pipeline we use it in
     in production (and most of the test cases) is live.  The difficulty is
     that the element that makes the pipeline live is added dynamically through
     type-finding and currently there's no way in GStreamer to handle it.

     We don't care too much about pre-roll and synchronisation here as it's not
     a genuine sink and all we want it to do is to push data into the pipe as
     quickly as possible.  The receiver on the other side of the pipeline is
     responsible for synchronisation when redering the stream.

     See DEVARCH-5875 for more details. */
  g_object_set (G_OBJECT (zmp->sink), "async", FALSE, "sync", FALSE, NULL);

  /* We must hold a seperate reference to the fdsink than our GstBin base class
     as we have a member that points to it */
  g_object_ref(zmp->sink);
  gst_bin_add (GST_BIN (zmp), zmp->sink);

  pad = gst_element_get_static_pad (zmp->sink, "sink");
  ghost_pad = gst_ghost_pad_new ("sink", pad);
  gst_pad_set_event_function(ghost_pad, gst_zmp_pad_on_event);
  gst_pad_set_chain_function(ghost_pad, gst_zmp_pad_chain);
  gst_element_add_pad (GST_ELEMENT (zmp), ghost_pad);
  gst_object_unref (pad);
  pad = NULL;

  zmp->new_segment = FALSE;
  g_mutex_init(&zmp->fd_mutex);
}

static void
gst_zmp_sink_dispose (GObject * obj)
{
  GstZMPSink *zmp = GST_ZMP_SINK (obj);

  if (zmp->sink) {
    g_object_unref(zmp->sink);
    zmp->sink = NULL;
  }

  G_OBJECT_CLASS (gst_zmp_sink_parent_class)->dispose (obj);
}


static void
gst_zmp_sink_finalize (GObject * obj)
{
  GstZMPSink *zmp = GST_ZMP_SINK (obj);

  gst_object_unref(zmp->immediate_event_task);
  zmp->immediate_event_task = NULL;
  g_rec_mutex_clear(&zmp->task_mutex);
  gst_poll_free(zmp->immediate_event_poll);
  zmp->immediate_event_poll = NULL;

  g_mutex_clear(&zmp->fd_mutex);

  G_OBJECT_CLASS (gst_zmp_sink_parent_class)->finalize (obj);
}

static gboolean
gst_zmp_sink_start(GstZMPSink * zmp)
{
  gboolean success = TRUE;
  success &= gst_poll_add_fd(zmp->immediate_event_poll,
                             &zmp->immediate_event_fd);
  success &= gst_poll_fd_ctl_read(zmp->immediate_event_poll,
                                  &zmp->immediate_event_fd, TRUE);
  success &= gst_task_start(zmp->immediate_event_task);

  /* make sure to not send any data until segment event arived */
  replace_data_fd ( zmp, dummyFD);
  return success;
}

static gboolean
gst_zmp_sink_stop(GstZMPSink * zmp)
{
  /* Innocent until proven guilty: */
  gboolean success = TRUE;

  gst_task_stop(zmp->immediate_event_task);
  gst_poll_set_flushing(zmp->immediate_event_poll, TRUE);
  gst_task_join(zmp->immediate_event_task);
  success &= gst_poll_remove_fd(zmp->immediate_event_poll,
                                &zmp->immediate_event_fd);

  replace_data_fd ( zmp, dummyFD);

  return TRUE;
}

static void
gst_zmp_sink_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstZMPSink *zmp = GST_ZMP_SINK (object);

  switch (prop_id) {
    case PROP_SERIALIZED_EVENT_FD:
      GST_OBJECT_LOCK (zmp);
      if (GST_STATE(zmp) == GST_STATE_NULL
            || GST_STATE(zmp) == GST_STATE_READY) {
        zmp->serialized_event_fd.fd = g_value_get_uint(value);
      }
      else {
        GST_WARNING_OBJECT(zmp, "Cannot change serialized event FD in state "
          "%i", GST_STATE(zmp));
      }
      GST_OBJECT_UNLOCK (zmp);
      break;
    case PROP_IMMEDIATE_EVENT_FD:
      GST_OBJECT_LOCK (zmp);
      if (GST_STATE(zmp) == GST_STATE_NULL) {
        zmp->immediate_event_fd.fd = g_value_get_uint(value);
      }
      else {
        GST_WARNING_OBJECT(zmp, "Cannot change serialized event FD in state "
          "%i", GST_STATE(zmp));
      }
      GST_OBJECT_UNLOCK (zmp);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

static void
gst_zmp_sink_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  GstZMPSink *zmp = GST_ZMP_SINK (object);

  switch (prop_id) {
    case PROP_SERIALIZED_EVENT_FD:
      GST_OBJECT_LOCK (zmp);
      g_value_set_uint (value, zmp->serialized_event_fd.fd);
      GST_OBJECT_UNLOCK (zmp);
      break;
    case PROP_IMMEDIATE_EVENT_FD:
      GST_OBJECT_LOCK (zmp);
      g_value_set_uint (value, zmp->immediate_event_fd.fd);
      GST_OBJECT_UNLOCK (zmp);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

static void
handle_message (GstBin * bin, GstMessage * msg)
{
  GST_BIN_CLASS (gst_zmp_sink_parent_class)->handle_message (bin, msg);
}

static GstStateChangeReturn
gst_zmp_sink_change_state (GstElement * element,
    GstStateChange transition)
{
  GstStateChangeReturn ret;
  GstZMPSink *zmp = GST_ZMP_SINK (element);

  switch (transition) {
    case GST_STATE_CHANGE_READY_TO_PAUSED:
      if (!gst_zmp_sink_start(zmp)) {
        goto failure;
      }
      break;
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      if (!gst_zmp_sink_stop(zmp)) {
        GST_WARNING_OBJECT(zmp, "failed to stop");
      }
      break;
    default:
      break;
  }

  ret = GST_ELEMENT_CLASS (gst_zmp_sink_parent_class)->change_state (element, transition);

  return ret;

  /* ERRORS */
failure:
  return GST_STATE_CHANGE_FAILURE;
}

static void
clear_fd(int* fd)
{
  assert(fd);
  if (*fd != -1) {
    int err = close(*fd);
    if (err) {
      GST_WARNING("Error closing fd %i: %s\n", *fd, strerror(errno));
    }
    *fd = -1;
  }
}

static void
immediate_event_task (gpointer user_data)
{
  GstZMPSink * zmp = (GstZMPSink*) user_data;
  char buf[ZMP_MAX_EVENT_SIZE_BYTES];
  ssize_t bytes_read;

  int fd = gst_poll_wait(zmp->immediate_event_poll, GST_CLOCK_TIME_NONE);
  if (fd == -1) {
    if (errno == EBUSY) {
      /* This means that gst_poll_set_flushing has been called from the other
         thread, we needn't do anything */
      GST_INFO_OBJECT(zmp, "immediate_event_task flushing");
      goto out;
    }
    else {
      GST_ELEMENT_ERROR(zmp, RESOURCE, READ, (NULL),
        ("Polling immediate event fd failed"));
      goto error;
    }
  }
  bytes_read = read(zmp->immediate_event_fd.fd, buf, sizeof(buf));
  if (bytes_read == 0) {
    GST_ELEMENT_ERROR(zmp, RESOURCE, READ, (NULL), GST_ERROR_SYSTEM);
    goto error;
  }
  else if (bytes_read < 0) {
    if (errno == EAGAIN || errno == EWOULDBLOCK) {
      /* This is fine, we don't want to block */
      goto out;
    }
    else {
      GST_ELEMENT_ERROR(zmp, RESOURCE, READ, (NULL), GST_ERROR_SYSTEM);
      goto error;
    }
  }
  handle_upstream_event(zmp, buf, bytes_read);
out:
  return;
error:
  gst_task_stop(zmp->immediate_event_task);
}

static void
handle_upstream_event(GstZMPSink * zmp, void * buf, size_t bufsize)
{
  ZMPEventHeader * header = buf;
  void * payload = buf + sizeof(ZMPEventHeader);
  size_t payload_bytes = bufsize - sizeof(ZMPEventHeader);
  GstEvent * event = NULL;

  /* Validation */
  if (bufsize < sizeof(ZMPEventHeader)
      || header->magic_number != ZMP_MAGIC_NUMBER
      || header->packet_size != bufsize
      || !(header->event_type & GST_EVENT_TYPE_UPSTREAM)) {
    GST_ELEMENT_WARNING(zmp, RESOURCE, READ, (NULL),
      ("Received invalid upstream event on immediate event fd %i",
      zmp->immediate_event_fd));
    goto err;
  }
  switch (header->event_type) {
  case GST_EVENT_SEEK: {
    ZMPSeekEventPayload * seek_payload = (ZMPSeekEventPayload*) payload;
    if (payload_bytes < sizeof(ZMPSeekEventPayload)) {
      GST_ELEMENT_WARNING(zmp, RESOURCE, READ, (NULL), ("Received invalid "
        "seek event on immediate event fd: payload is too small (%i < %i)",
        payload_bytes, sizeof(ZMPSeekEventPayload)));
      goto err;
    }
    event = gst_event_new_seek(seek_payload->rate, seek_payload->format,
                               seek_payload->flags, seek_payload->start_type,
                               seek_payload->start, seek_payload->stop_type,
                               seek_payload->stop);
    break;
  }
  default:
    GST_ELEMENT_INFO(GST_ELEMENT(zmp), STREAM, NOT_IMPLEMENTED, (NULL),
      ("Received upstream event of type %s (%i): ignoring",
      gst_event_type_get_name(header->event_type), header->event_type));
    break;
  };
  if (event) {
    gst_element_send_event(zmp->sink, event);
  }
err:
  return;
}

static void
gst_zmpsink_fill_header(ZMPEventHeader * header, GstEvent * event)
{
  assert(header && event);
  header->magic_number = ZMP_MAGIC_NUMBER;
  header->packet_size = sizeof(ZMPEventHeader);
  header->event_type = GST_EVENT_TYPE(event);
  header->timestamp = GST_EVENT_TIMESTAMP(event);
  header->seq_num = GST_EVENT_SEQNUM(event);
}

static ssize_t
send_with_fd(int sockfd, struct iovec *iov, size_t iovlen, int fd)
{
  struct msghdr msg = {0};
  char buf[CMSG_SPACE(sizeof(int))];  /* ancillary data buffer */

  msg.msg_iov = iov;
  msg.msg_iovlen = iovlen;

  if (fd >= 0) {
    msg.msg_control = buf;
    msg.msg_controllen = sizeof(buf);

    struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);

    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    cmsg->cmsg_len = CMSG_LEN(sizeof(int));

    /* Initialize the payload: */
    *((int *) CMSG_DATA(cmsg)) = fd;

    /* Sum of the length of all control messages in the buffer: */
    msg.msg_controllen = cmsg->cmsg_len;
  }
  else {
    msg.msg_control = NULL;
    msg.msg_controllen = 0;
  }
  return sendmsg(sockfd, &msg, MSG_EOR);
}

static void
replace_data_fd(GstZMPSink* sink, int newfd)
{
  int oldfd = -1;
  g_mutex_lock(&sink->fd_mutex);
  g_object_get(G_OBJECT(sink->sink), "fd", &oldfd, NULL);
  if (oldfd != newfd) {
    g_object_set(G_OBJECT(sink->sink), "fd", newfd, NULL);
    if (oldfd != 1) {
      clear_fd(&oldfd);
    }
  }
  g_mutex_unlock(&sink->fd_mutex);
}

static gboolean
data_follows_event(int eventid)
{
  switch(eventid) {
  case GST_EVENT_FLUSH_START:
  case GST_EVENT_FLUSH_STOP:
  case GST_EVENT_EOS:
  case GST_EVENT_SEGMENT:
  case GST_EVENT_SEGMENT_DONE:
    return FALSE;
  default:
    return TRUE;
  };
}

static void
gst_zmp_on_event_generic(GstZMPSink * sink, GstEvent * event)
{
  ZMPEventHeader header;
  GstSegment segment;
  int err;
  int newfd = -1;
  int iovlen = 1;
  int fd = GST_EVENT_IS_SERIALIZED(event)
               ? sink->serialized_event_fd.fd : sink->immediate_event_fd.fd;
  ssize_t bytes_written;

  gst_zmpsink_fill_header(&header, event);
  struct iovec msg[2] = { { &header, sizeof(header) }, { NULL, 0 } };
  if (GST_EVENT_TYPE(event) == GST_EVENT_SEGMENT) {
    GstPad * pad;
    gint64 duration = 0;

    // /* create pipe and send data fd only on segment */
    // if (!data_follows_event(GST_EVENT_TYPE(event))) {
    //   replace_data_fd(sink, dummyFD);
    // }
    // else if (GST_EVENT_IS_SERIALIZED(event)) {
    //   int fds[2] = {-1, -1};
    //   err = pipe2(fds, O_NONBLOCK | O_CLOEXEC);
    //   if (err) {
    //     GST_ELEMENT_ERROR(sink, RESOURCE, OPEN_READ_WRITE, (NULL),
    //       ("pipe failed: %s", strerror(errno)));
    //     goto out;
    //   }
    //   replace_data_fd(sink, fds[1]);
    //   newfd = fds[0];
    // }

    gst_event_copy_segment(event, &segment);

    /* Not sure if this is the best thing to do.  We want to give the client
       a chance to manipulate its PCR synchronisation based on some heuristics
       around buffer "fullness".  The duration might be required for this.

       Note that we ignore duratoin query result as we can't do much about
       the failure (it'll be set to 0). */
    gst_element_query_duration (sink->sink, GST_FORMAT_TIME, &duration);
    if (GST_CLOCK_TIME_IS_VALID (duration)) {
      segment.duration = duration;
    }

    GST_DEBUG_OBJECT(sink, "Sending segment "
      "start: %llu, base: %llu, time: %llu",
      segment.start, segment.base, segment.time);

    msg[1].iov_base = (void*) &segment;
    msg[1].iov_len = sizeof(segment);
    iovlen = 2;

    sink->new_segment = TRUE;
  }
  header.packet_size = msg[0].iov_len + msg[1].iov_len;
  GST_DEBUG_OBJECT(sink, "Sending from : gst_zmp_on_event_generic");
  bytes_written = send_with_fd(fd, msg, iovlen, newfd);
  if (bytes_written == header.packet_size) {
    /* SUCCESS: pass */
  }
  else {
    if (bytes_written == -1) {
      GST_ELEMENT_ERROR(sink, RESOURCE, WRITE, (NULL), ("Writing event to fd "
        "%i failed: %s", fd, strerror(errno)));
    }
    else {
      GST_ELEMENT_ERROR(sink, RESOURCE, WRITE, (NULL), ("Writing full event to "
        "fd %i failed: This should not happens the socket should be a "
        "SOCK_SEQPACKET socket with message boundaries", fd));
    }
    goto out;
  }
out:
  clear_fd(&newfd);
}

static gboolean
gst_zmp_pad_on_event(GstPad *pad, GstObject *parent, GstEvent *event)
{
  gboolean ret;
  GstZMPSink * zmp = GST_ZMP_SINK(parent);

  ret = gst_pad_event_default(pad, parent, event);
  gst_zmp_on_event_generic(zmp, event);
  return ret;
}

static GstFlowReturn
gst_zmp_pad_chain(GstPad *pad, GstObject *parent, GstBuffer *buffer)
{
  GstZMPSink * zmp = GST_ZMP_SINK(parent);
  if (G_UNLIKELY(zmp->new_segment)) {
    zmp->new_segment = FALSE;

    ZMPEventHeader header;
    ZMPPortionEventPayload payload;

    ssize_t bytes_written;

    int iovlen = 2;
    struct iovec msg[2] = { { &header, sizeof(header) }, { NULL, 0 } };

    int fds[2] = {-1, -1};
    if (pipe2(fds, O_NONBLOCK | O_CLOEXEC) != 0) {
      GST_ELEMENT_ERROR(zmp, RESOURCE, OPEN_READ_WRITE, (NULL),
        ("pipe failed: %s", strerror(errno)));
      goto out;
    }

    replace_data_fd(zmp, fds[1]);
    fds[1] = -1;

    header.magic_number = ZMP_MAGIC_NUMBER;
    header.packet_size = sizeof(ZMPEventHeader);
    header.event_type = ZMP_EVENT_PORTION;
    header.timestamp = -1;
    header.seq_num = -1;

    payload.pts = buffer->pts;
    payload.dts = buffer->dts;
    payload.duration = buffer->duration;
    payload.offset = buffer->offset;
    payload.offset_end = buffer->offset_end;

    msg[1].iov_base = &payload;
    msg[1].iov_len = sizeof(payload);

    header.packet_size = msg[0].iov_len + msg[1].iov_len;
    bytes_written = send_with_fd(zmp->serialized_event_fd.fd, msg, iovlen, fds[0]);
    if (bytes_written == header.packet_size) {
      /* SUCCESS: pass */
      GST_DEBUG_OBJECT(zmp, "Sending payload: "
        "PTS: %llu, DTS: %llu, duration: %llu, offset: %llu",
        payload.pts, payload.dts, payload.duration, payload.offset);
    }
    else {
      if (bytes_written == -1) {
        GST_ELEMENT_ERROR(zmp, RESOURCE, WRITE, (NULL), ("Writing event to fd "
          "%i failed: %s", zmp->serialized_event_fd.fd, strerror(errno)));
      }
      else {
        GST_ELEMENT_ERROR(zmp, RESOURCE, WRITE, (NULL), ("Writing full event to "
          "fd %i failed: This should not happens the socket should be a "
          "SOCK_SEQPACKET socket with message boundaries",
          zmp->serialized_event_fd.fd));
      }
      goto out;
    }
out:
    clear_fd(&fds[0]);
    clear_fd(&fds[1]);
  }
  return gst_proxy_pad_chain_default(pad, parent, buffer);
}

static gboolean
gst_zmp_sink_plugin_init (GstPlugin * plugin)
{
  GST_DEBUG_CATEGORY_INIT (gst_zmp_sink_debug, "zmpsink", 0,
      "ZMP Sink");

  return gst_element_register (plugin, "zmpsink", GST_RANK_NONE,
      GST_TYPE_ZMP_SINK);
}

static gboolean
plugin_init (GstPlugin * plugin)
{
  if (!gst_zmp_sink_plugin_init (plugin))
    return FALSE;

  return TRUE;
}

GST_PLUGIN_DEFINE (GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    zmpsink,
    "ZMP sink", plugin_init, "1.0", "LGPL", "ZMP",
    "http://youview.com")
