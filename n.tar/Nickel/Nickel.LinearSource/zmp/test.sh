#!/bin/sh

if [ -e ~/Downloads/VA-509.ts ]
then
	test_asset_filename=/home/william.manley/Downloads/VA-509.ts
	test_asset_url=file://$test_asset_filename
else
	test_asset_url=http://filegateway.youview.co.uk/test_assets/licence_free/VA-509.ts
fi

orig_dir="$PWD"
export LD_LIBRARY_PATH="$orig_dir:${LD_LIBRARY_PATH-/usr/lib:/lib:}"

scratch_space=$(mktemp --tmpdir -d zmp-test.XXXXXXX)
cd "$scratch_space"

"$orig_dir/gst-zmp-server" "$test_asset_url" &
server_pid=$!

sleep 1

"$orig_dir/zmp-file-client"

if [ "$test_asset_filename" == "" ]
then
	wget -O pristine.ts "$test_asset_url"
else
	ln -s "$test_asset_filename" pristine.ts
fi

cmp segment-0.ts pristine.ts
success=$?

kill "$server_pid"

echo rm -Rf "$scratch_space"

if [ "$success" == "0" ]
then
	echo "SUCCESS"
else
	echo "FAIL: videos don't match"
fi

exit "$success"
