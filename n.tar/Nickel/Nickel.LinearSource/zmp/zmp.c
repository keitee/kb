#include "zmp.h"
#include "events.h"

#include <stdint.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <string.h>
#include <stdarg.h>

enum {
	/* UNIX domain socket used to send and recieve events which are not
	   serialised with the data stream */
	FD_IMMEDIATE_EVENTS = 0,

	/* UNIX domain socket used to receive events which are serialised with the
	   data stream.  This socket is also used to send file-descriptors with
	   UNIX pipes to be used as the data stream. */
	FD_SERIALIZED_EVENTS,

	/* eventfd which the user can use to signal that they are ready to read.
	   This is stimulated by notify_read_ready which must be called if to get
	   us to call the user's data_ready callback. */
	FD_READ_READY,

	/* UNIX pipe from which the data stream can be read.  This may be -1 if
	   we are not currently transferring a segment. */
	FD_DATA,

	ZMP_MAX_FDS
};

static const char* fd_name(int fd)
{
	switch (fd) {
	case FD_IMMEDIATE_EVENTS:
		return "Immediate events";
	case FD_SERIALIZED_EVENTS:
		return "Serialized events";
	case FD_READ_READY:
		return "Read ready notify";
	case FD_DATA:
		return "Data";
	default:
		return "Other";
	};
}

typedef enum {
	STATE_UNINITIALIZED = 0,
	STATE_OK,
	STATE_ERROR
} ZMPState;

struct ZMPStream_ {
	ZMPState state;

	struct {
		int fd;
		struct epoll_event event;
	} fd[ZMP_MAX_FDS];

	/* epoll fd which multiplexes the above fds together such that a user can
	   poll on it and inform us of events on any of the above fds. */
	int multiplex_fd;

	zmp_event_callback on_event;
	zmp_data_callback on_data;
	zmp_error_callback on_error;

	void *user_data;

	/* Every ZMP_EVENT_FLUSH_START is accompanied by a ZMP_EVENT_FLUSH_END.
	   We wish to drop all data and data serialized events until we receive the
	   FLUSH_END so this is the count of FLUSH_STARTS which have not yet been
	   accompanied by a FLUSH_END */
	int flushing;
};

static void zmp_stream_reset(ZMPStream *s);
static void zmp_raise_error(ZMPStream* stream, int err, char *format, ...);

#if 0
#define INFO(x, ...) \
	do { \
		int zmp_debug_old_errno_ = errno; \
		fprintf(stderr, "INFO: libzmp: " x "\n", ##__VA_ARGS__); \
		errno = zmp_debug_old_errno_; \
	} while (0);
#else
#define INFO(x, ...)
#endif
#define DEBUG(x, ...) \
	do { \
		int zmp_debug_old_errno_ = errno; \
		fprintf(stderr, "DEBUG: libzmp: " x "\n", ##__VA_ARGS__); \
		errno = zmp_debug_old_errno_; \
	} while (0);
#define FATAL(x, ...) \
	fprintf(stderr, "ERROR: libzmp: " x "\n", ##__VA_ARGS__); abort();

static void default_event_callback(void *user_data, ZMPStream *stream,
                                   ZMPEventHeader *header, size_t payload_size,
                                   void *payload)
{
	FATAL("Event received when no callback set.  Use "
	      "zmp_stream_set_callbacks() to set callbacks");
}
static ssize_t default_data_callback(void *user_data, ZMPStream *stream,
                                  int input_fd)
{
	FATAL("Data received when no callback set.  Use "
	      "zmp_stream_set_callbacks() to set callbacks");
}
static void default_error_callback(void *user_data, ZMPStream *stream,
                                   int error, char* desc)
{
	FATAL("ERROR: Error received when no callback set.  Use "
	      "zmp_stream_set_callbacks() to set callbacks");
}

static void clear_fd(int* fd) {
	assert(fd);
	if (*fd != -1) {
		int err = close(*fd);
		INFO("close(%i)", *fd);
		if (err) {
			DEBUG("Error closing fd %i: %s", *fd, strerror(errno));
		}
		*fd = -1;
	}
}

static void zmp_stream_clear(ZMPStream *s)
{
	int i = 0;
	assert(s);
	memset(s, 0, sizeof(ZMPStream));
	for (i = 0; i < ZMP_MAX_FDS; ++i) {
		s->fd[i].fd = -1;
	}
	s->multiplex_fd = -1;
	s->on_event = default_event_callback;
	s->on_data = default_data_callback;
	s->on_error = default_error_callback;
}

static int is_seqpacket_socket(int fd)
{
	int type = 0;
	socklen_t l = sizeof(type);

	return getsockopt(fd, SOL_SOCKET, SO_TYPE, &type, &l) == 0
	    && l == sizeof(type)
	    && type == SOCK_SEQPACKET;
}

static int zmp_stream_init(ZMPStream *s, int serialized_events_fd,
                           int immediate_events_fd)
{
	int err = 0;
	int i = 0;

	zmp_stream_clear(s);

	if (!is_seqpacket_socket(serialized_events_fd)
	    || !is_seqpacket_socket(immediate_events_fd)) {
		DEBUG("File descriptors passed to libzmp (%i and %i) do not both "
		      "correspond to SEQPACKET sockets", serialized_events_fd,
		      immediate_events_fd);
		goto errout;
	}

	s->multiplex_fd = epoll_create1(EPOLL_CLOEXEC);
	if (s->multiplex_fd == -1) {
		perror("epoll_create1");
		goto errout;
	}

	s->fd[FD_IMMEDIATE_EVENTS].fd = immediate_events_fd;
	s->fd[FD_IMMEDIATE_EVENTS].event.events = EPOLLIN | EPOLLOUT | EPOLLET | EPOLLRDHUP;

	s->fd[FD_SERIALIZED_EVENTS].fd = serialized_events_fd;
	s->fd[FD_SERIALIZED_EVENTS].event.events = EPOLLIN | EPOLLET | EPOLLRDHUP;

	s->fd[FD_READ_READY].fd = eventfd(0, EFD_CLOEXEC | EFD_NONBLOCK);
	if (s->fd[FD_READ_READY].fd == -1) {
		perror("eventfd");
		goto errout;
	}
	s->fd[FD_READ_READY].event.events = EPOLLIN | EPOLLET;

	s->fd[FD_DATA].event.events = EPOLLIN | EPOLLET | EPOLLRDHUP;

	for (i = 0; i < ZMP_MAX_FDS; i++) {
		s->fd[i].event.data.u32 = i;
		if (s->fd[i].fd >= 0) {
			err = epoll_ctl(s->multiplex_fd, EPOLL_CTL_ADD, s->fd[i].fd,
			                &s->fd[i].event);
			if (err) {
				DEBUG("Error adding read ready FD to epollfd: %s",
				      strerror(errno));
				goto errout;
			}
		}
	}

	s->state = STATE_OK;

	return 0;
errout:
	/* We only want to take ownership of the user's FDs if we succeed: */
	s->fd[FD_IMMEDIATE_EVENTS].fd = -1;
	s->fd[FD_SERIALIZED_EVENTS].fd = -1;
	zmp_stream_reset(s);
	return -1;
}

static void zmp_stream_reset(ZMPStream *s)
{
	int i = 0;
	assert(s);
	for (i = 0; i < ZMP_MAX_FDS; i++) {
		clear_fd(&s->fd[i].fd);
	}
	clear_fd(&s->multiplex_fd);

	zmp_stream_clear(s);
}

ZMPStream* zmp_stream_new(int serialized_events_fd, int immediate_events_fd)
{
	int err;
	ZMPStream* s = malloc(sizeof(ZMPStream));
	if (!s) {
		goto errout;
	}
	err = zmp_stream_init(s, serialized_events_fd, immediate_events_fd);
	if (err) {
		goto mallocerrout;
	}
	return s;
mallocerrout:
	free(s);
errout:
	return NULL;
}

void zmp_stream_free(ZMPStream* stream)
{
	if (stream) {
		zmp_stream_reset(stream);
		free(stream);
	}
}

void zmp_stream_notify_read_ready(ZMPStream *stream)
{
	int64_t inc = 1;
	ssize_t b = write(stream->fd[FD_READ_READY].fd, &inc, sizeof(inc));
	INFO("Wakeup");
	if (b<0) {
		/* This should never happen if stream points to a valid zmp stream. */
		FATAL("error: libzmp: failed to wake up zmp\n");
	}
}
static void zmp_replace_data_fd(ZMPStream* stream, int fd)
{
	if (stream->fd[FD_DATA].fd != -1) {
		if (epoll_ctl(stream->multiplex_fd, EPOLL_CTL_DEL,
		          stream->fd[FD_DATA].fd, NULL) != 0) {
			zmp_raise_error(stream, errno, "error: Couldn't remove data fd "
			    "(%i) from epoll group (%i)", stream->fd[FD_DATA].fd,
			    stream->multiplex_fd);
			goto err;
		}
		clear_fd(&stream->fd[FD_DATA].fd);
	}
	stream->fd[FD_DATA].fd = fd;
	fd = -1;
	if (stream->fd[FD_DATA].fd != -1) {
		if (epoll_ctl(stream->multiplex_fd, EPOLL_CTL_ADD,
		          stream->fd[FD_DATA].fd, &stream->fd[FD_DATA].event) != 0) {
			zmp_raise_error(stream, errno, "error: Couldn't add data fd "
			    "(%i) from epoll group (%i)", stream->fd[FD_DATA].fd,
			    stream->multiplex_fd);
			goto err;
		}
	}
	return;
err:
	clear_fd(&fd);
	clear_fd(&stream->fd[FD_DATA].fd);
}

static void zmp_raise_error(ZMPStream* stream, int err, char *format, ...)
{
	char buf[256];
	char* msg;
	va_list ap;
	int bytes_written;

	/* Report the error to the user */
	va_start(ap, format);
	bytes_written = vsnprintf(buf, sizeof(buf), format, ap);
	va_end(ap);
	if (bytes_written < sizeof(buf) && bytes_written >= 0) {
		stream->on_error(stream->user_data, stream, err, buf);
	}
	else {
		stream->on_error(stream->user_data, stream, err,
		    "libzmp message composition error: composition failed");
	}

	/* Enter the error state.  We cannot tear the stream down at this point as
	   there would then be a race with zmp_stream_notify_read_ready() */
	stream->state = STATE_ERROR;
}

static void zmp_handle_event(ZMPStream* stream, char* buf, size_t size, int socket)
{
	ZMPEventHeader *header = (ZMPEventHeader*) buf;
	if (size < sizeof(ZMPEventHeader)) {
		zmp_raise_error(stream, EBADMSG, "Malformed event received.  Received "
		                "packet is too small to contain full ZMP event header "
		                "(%zd < %zd)", size, sizeof(ZMPEventHeader));
		goto err;
	}
	if (header->magic_number != ZMP_MAGIC_NUMBER) {
		zmp_raise_error(stream, EBADMSG, "Malformed event received.  Magic "
		                "number should be  %x, received %x", ZMP_MAGIC_NUMBER,
		                header->magic_number);
		goto err;
	}
	if (header->packet_size != size) {
		zmp_raise_error(stream, EBADMSG, "Malformed event received: event "
		                "header size differs from size of packet read from "
		                "SEQPACKET socket.  header size = %zd, read size = %zd",
		                size, header->packet_size);
		goto err;
	}
	if (socket == FD_IMMEDIATE_EVENTS
		&& (header->event_type & ZMP_EVENT_TYPE_SERIALIZED)) {
		DEBUG("Received serialized event %i on immediate event socket.  "
		      "Perhaps they are wired up the wrong way round?",
		      header->event_type);
	}
	else if (socket == FD_SERIALIZED_EVENTS
		&& !(header->event_type & ZMP_EVENT_TYPE_SERIALIZED)) {
		DEBUG("Received immediate event %i on serialized event socket.  "
		      "Perhaps they are wired up the wrong way round?",
		      header->event_type);
	}
	INFO("Received event %i flags %x", header->event_type >> 8,
	     header->event_type & 0xFF);
	switch(header->event_type) {
	case ZMP_EVENT_FLUSH_START:
		if (++stream->flushing > 0) {
			/* May cause us to enter the error state: */
			zmp_replace_data_fd(stream, -1);
			if (stream->state == STATE_ERROR) {
				goto err;
			}
		}
		break;
	case ZMP_EVENT_FLUSH_STOP:
		--stream->flushing;
		break;
	default:
		INFO("Ignoring uninteresting event %i", header->event_type);
	}
	if (header->event_type & ZMP_EVENT_TYPE_SERIALIZED && 0 < stream->flushing) {
		// pass (flushing)
	}
	else {
		stream->on_event(stream->user_data, stream, header,
		                 header->packet_size - sizeof(*header),
		                 buf + sizeof(*header));
	}
err:
	return;
};

static int read_with_fd(int *fd_out, int fd, void* buf, size_t count)
{
	/* Room to receive a single file descriptor with each message: */
	char control_buf[CMSG_SPACE(sizeof(int))];
	ssize_t bytes_read;
	int err = 0;
	struct iovec iov[1] = { { buf, count } };
	struct msghdr msg = {
		NULL, 0, iov, 1, control_buf, sizeof(control_buf), 0
	};

	*fd_out = -1;

	bytes_read = recvmsg(fd, &msg, MSG_CMSG_CLOEXEC);
	err = errno;
	if (bytes_read > 0) {
		struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);
		while (cmsg) {
			if (cmsg->cmsg_level == SOL_SOCKET
			 && cmsg->cmsg_type  == SCM_RIGHTS) {
				clear_fd(fd_out);
				*fd_out = *(int *) CMSG_DATA(cmsg);
				INFO("Received FD %i", *fd_out);
			}
			cmsg = CMSG_NXTHDR(&msg, cmsg);
		}
	}
	errno = err;
	return bytes_read;
}

static void zmp_drain_read_ready(ZMPStream* stream)
{
	int64_t buf;
	ssize_t bytes_read;
	/* Don't care if this succeeds or not, we just want to reset it. */
	for (;;) {
		bytes_read = read(stream->fd[FD_READ_READY].fd, &buf, sizeof(buf));
		if (bytes_read > 0) {
			/* pass: let's go round again */
		}
		else if (bytes_read == -1 && errno == EAGAIN) {
			/* Fully drained now */
			break;
		}
		else {
			DEBUG("Draining eventfd: Something went wrong!");
			break;
		}
	}
}

static int zmp_handle_serial(ZMPStream* stream)
{
	int work_done = 0;

	zmp_drain_read_ready(stream);
	INFO("Serial data...");
	if (stream->state == STATE_ERROR) {
		/* pass */
	}
	else if (stream->fd[FD_DATA].fd == -1) {
		char buf[ZMP_MAX_EVENT_SIZE_BYTES];
		ssize_t bytes_read;
		int fd = -1;
		INFO("event");

		/* Waiting for ZMP_EVENT_SEGMENT */
		bytes_read = read_with_fd(&fd, stream->fd[FD_SERIALIZED_EVENTS].fd,
		                          buf, sizeof(buf));
		if (bytes_read > 0) {
			/* If we've received a fd it should replace the one we're currently
			   got which must have been either emptied or destroyed otherwise
			   we'd be in the else branch below.  This is the means by which we
			   create an ordering between messages and data without having to
			   do payloading */
			if (fd != -1) {
				/* May cause us to enter error state: */
				zmp_replace_data_fd(stream, fd);
			}
			if (stream->state != STATE_ERROR) {
				zmp_handle_event(stream, buf, bytes_read, FD_SERIALIZED_EVENTS);
				work_done++;
			}
		}
		else if (bytes_read == -1 && (errno == EAGAIN
		                           || errno == EWOULDBLOCK)) {
			INFO("not really, EAGAIN");
			/* pass */
		}
		else if (bytes_read == 0) {
			/* EOF */
			DEBUG("Received EOF on serialised event socket %i",
			      stream->fd[FD_SERIALIZED_EVENTS].fd);
			zmp_raise_error(stream, EPIPE, "Remote end closed the serial "
			                "event socket");
		}
		else {
			DEBUG("Received unexpected error on serialised event socket %i: %s",
			      stream->fd[FD_SERIALIZED_EVENTS].fd, strerror(errno));
			zmp_raise_error(stream, errno, "Unexpected error received reading "
			                "from serialized event socket: %s",
			                strerror(errno));
		}
	}
	else {
		ssize_t bytes_read;
		while ((bytes_read = stream->on_data(stream->user_data, stream,
		                                     stream->fd[FD_DATA].fd)) > 0) {
			INFO("Received data: %zdB", bytes_read);
			work_done++;
		}
		if (bytes_read == 0) { /* EOF */
			INFO("Received EOF on data fd %i", stream->fd[FD_DATA].fd);
			clear_fd(&stream->fd[FD_DATA].fd);
			/* We count this as doing work as there might be some more work to
			   do next iteration from the events pipe. */
			work_done++;
		}
		else if (errno == EAGAIN) {
			/* Reading would have blocked: do nothing.  We expect that the user
			   will call zmp_stream_notify_read_ready when they are ready for
			   more */
		}
		else {
			/* A real error */
			zmp_raise_error(stream, errno, "Unexpected error returned from "
			                "on_data callback: %s", strerror(errno));
		}
	}
	INFO("zmp_handle_serial: Returning %i", work_done);
	return work_done;
}

static int zmp_handle_immediate_event(ZMPStream* stream)
{
	char buf[ZMP_MAX_EVENT_SIZE_BYTES];
	ssize_t bytes_read;
	INFO("Immediate event\n");

	bytes_read = read(stream->fd[FD_IMMEDIATE_EVENTS].fd, buf,
	                  ZMP_MAX_EVENT_SIZE_BYTES);
	if (bytes_read > 0) {
		zmp_handle_event(stream, buf, bytes_read, FD_IMMEDIATE_EVENTS);
		return 0;
	}
	else if (bytes_read < 0 && (errno == EWOULDBLOCK || errno == EAGAIN)) {
		/* No work available: pass */
		INFO("Immediate event socket: no work available");
		return EAGAIN;
	}
	else if (bytes_read == 0) {
		/* EOF of immediate event socket is not EOF of the stream wheras EOF of
		   the serialized event socket and related data sockets is as even
		   after EOF of the immediate event socket there still may be data
		   available for reading */
		DEBUG("Immediate event socket: EOF");
		return EPIPE;
	}
	else {
		DEBUG("Immediate event socket: Error reading from %i: %s",
		      stream->fd[FD_IMMEDIATE_EVENTS].fd, strerror(errno));
		zmp_raise_error(stream, errno, "Unexpected error when reading from "
		                "immediate event socket: %s", strerror(errno));
		return errno;
	}
}

int zmp_stream_notify(ZMPStream *stream)
{
	struct epoll_event events[ZMP_MAX_FDS];
	int n;
	int i;

	if (stream->state != STATE_OK) {
		goto out;
	}

	n = epoll_wait(stream->multiplex_fd, events, ZMP_MAX_FDS, 0);
	if (n < 0) {
		zmp_raise_error(stream, errno, "epoll_wait failed: %s",
		                strerror(errno));
		goto out;
	}
	for (i=0; i<n && stream->state == STATE_OK; ++i) {
		INFO("%s fd ready", fd_name(events[i].data.u32));
		switch (events[i].data.u32) {
		case FD_IMMEDIATE_EVENTS:
			zmp_handle_immediate_event(stream);
			break;
		case FD_SERIALIZED_EVENTS:
		case FD_DATA:
		case FD_READ_READY:
			while (stream->state == STATE_OK && zmp_handle_serial(stream)) {
				/* pass */
			};
			break;
		default:
			FATAL("Impossible: Received event on unknown FD %i!",
			      events[i].data.fd);
		}
	}
out:
	return (stream->state == STATE_OK) ? 0 : 1;
}

void zmp_stream_set_callbacks(ZMPStream *stream, void *user_data,
                              zmp_event_callback on_event,
                              zmp_data_callback on_data,
                              zmp_error_callback on_error)
{
	assert(stream && on_event && on_data && on_error);
	stream->user_data = user_data;
	stream->on_event = on_event;
	stream->on_data = on_data;
	stream->on_error = on_error;
}

int zmp_stream_get_listen_fd(ZMPStream* stream)
{
	assert(stream && stream->multiplex_fd > 0);
	return stream->multiplex_fd;
}

int zmp_stream_request_seek(ZMPStream* stream, double rate,
                            ZMPFormat format, ZMPSeekFlags flags,
                            ZMPSeekType start_type, int64_t start,
                            ZMPSeekType stop_type, int64_t stop)
{
	ssize_t bytes_written;
	struct {
		ZMPEventHeader header;
		ZMPSeekEventPayload payload;
	} event = {
		{ ZMP_MAGIC_NUMBER, sizeof(event), ZMP_EVENT_SEEK, -1, -1 },
		{ rate, format, flags, start_type, start, stop_type, stop }
	};

	assert(stream);
	if (stream->state != STATE_OK) {
		return ECONNRESET;
	}

	bytes_written = write(stream->fd[FD_IMMEDIATE_EVENTS].fd, &event,
	                      sizeof(event));
	if (bytes_written > 0) {
		return 0;
	}
	else {
		return errno;
	}
}

uint64_t zmp_portion_time_to_stream_time(ZMPSegmentEventPayload* s,
                                         ZMPPortionEventPayload* p,
                                         uint64_t portionStreamTime)
{
	assert(s && p);
	return p->pts + portionStreamTime - s->start + s->time;
}

