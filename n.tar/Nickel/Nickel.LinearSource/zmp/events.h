#ifndef ZMP_EVENTS_H__
#define ZMP_EVENTS_H__

#include <stdint.h>
#include <stddef.h>

static const uint32_t ZMP_MAGIC_NUMBER = 0xd7dbc621;
static const size_t ZMP_MAX_EVENT_SIZE_BYTES = 256;

#define ZMP_EVENT_NUM_SHIFT     (8)
#define ZMP_EVENT_MAKE_TYPE(num,flags) \
    (((num) << ZMP_EVENT_NUM_SHIFT) | (flags))

#define ZMP_EVENT_TYPE_BOTH (ZMP_EVENT_TYPE_UPSTREAM | ZMP_EVENT_TYPE_DOWNSTREAM)

#define ZMP_FLAG(name) ZMP_EVENT_TYPE_##name

#define	ZMP_NSECOND 1ll
#define	ZMP_USECOND (1000ll * ZMP_NSECOND)
#define	ZMP_MSECOND (1000ll * ZMP_USECOND)
#define	ZMP_SECOND  (1000ll * ZMP_MSECOND)

typedef enum {
	ZMP_EVENT_TYPE_UPSTREAM       = 1 << 0,
	ZMP_EVENT_TYPE_DOWNSTREAM     = 1 << 1,
	ZMP_EVENT_TYPE_SERIALIZED     = 1 << 2,
	ZMP_EVENT_TYPE_STICKY         = 1 << 3,
	ZMP_EVENT_TYPE_STICKY_MULTI   = 1 << 4
} ZMPEventTypeFlags;

typedef enum {
	/* bidirectional events */
	ZMP_EVENT_FLUSH_START           = ZMP_EVENT_MAKE_TYPE (10, ZMP_FLAG(BOTH)),
	ZMP_EVENT_FLUSH_STOP            = ZMP_EVENT_MAKE_TYPE (20, ZMP_FLAG(BOTH) | ZMP_FLAG(SERIALIZED)),

	/* downstream serialized events */
	ZMP_EVENT_SEGMENT               = ZMP_EVENT_MAKE_TYPE (70, ZMP_FLAG(DOWNSTREAM) | ZMP_FLAG(SERIALIZED) | ZMP_FLAG(STICKY)),

	/* upstream events */
	ZMP_EVENT_SEEK                  = ZMP_EVENT_MAKE_TYPE (200, ZMP_FLAG(UPSTREAM)),

	/* zmp events start here */
	ZMP_EVENT_PORTION               = ZMP_EVENT_MAKE_TYPE (1000, ZMP_FLAG(DOWNSTREAM) | ZMP_FLAG(SERIALIZED)),
} ZMPEventType;

typedef enum {
	/* one of these */
	ZMP_SEEK_TYPE_NONE            = 0,
	ZMP_SEEK_TYPE_SET             = 1,
	ZMP_SEEK_TYPE_END             = 2
} ZMPSeekType;

typedef enum {
	ZMP_SEEK_FLAG_NONE            = 0,
	ZMP_SEEK_FLAG_FLUSH           = (1 << 0),
	ZMP_SEEK_FLAG_ACCURATE        = (1 << 1),
	ZMP_SEEK_FLAG_KEY_UNIT        = (1 << 2),
	ZMP_SEEK_FLAG_SEGMENT         = (1 << 3),
	ZMP_SEEK_FLAG_SKIP            = (1 << 4),
	ZMP_SEEK_FLAG_SNAP_BEFORE     = (1 << 5),
	ZMP_SEEK_FLAG_SNAP_AFTER      = (1 << 6),
	ZMP_SEEK_FLAG_SNAP_NEAREST    = ZMP_SEEK_FLAG_SNAP_BEFORE | ZMP_SEEK_FLAG_SNAP_AFTER,
	/* Careful to restart next flag with 1<<7 here */
} ZMPSeekFlags;

typedef enum {
	ZMP_SEGMENT_FLAG_NONE            = ZMP_SEEK_FLAG_NONE,
	ZMP_SEGMENT_FLAG_RESET           = ZMP_SEEK_FLAG_FLUSH,
	ZMP_SEGMENT_FLAG_SKIP            = ZMP_SEEK_FLAG_SKIP,
	ZMP_SEGMENT_FLAG_SEGMENT         = ZMP_SEEK_FLAG_SEGMENT
} ZMPSegmentFlags;

typedef enum {
	ZMP_FORMAT_UNDEFINED  =  0, /* must be first in list */
	ZMP_FORMAT_DEFAULT    =  1,
	ZMP_FORMAT_BYTES      =  2,
	ZMP_FORMAT_TIME       =  3,
	ZMP_FORMAT_BUFFERS    =  4,
	ZMP_FORMAT_PERCENT    =  5
} ZMPFormat;

typedef struct { /* 48B in total */
/*  0 */    double rate;
/*  8 */    ZMPFormat format;
/* 12 */    ZMPSeekFlags flags; /* Set ZMP_SEEK_FLAG_FLUSH = 1.
                                    Optionally also set ZMP_SEEK_FLAG_SKIP = (1 << 4) */
/* 16 */    ZMPSeekType start_type; /* Always set to ZMP_SEEK_TYPE_NONE = 0 */
/* 24 */    int64_t start; /* Always set to 0 */
/* 32 */    ZMPSeekType stop_type; /* Always set to ZMP_SEEK_TYPE_NONE = 0 */
/* 40 */    int64_t stop; /* Always set to 0 */
} ZMPSeekEventPayload;

typedef struct {
	ZMPSegmentFlags  flags;

	double           rate;
	double           applied_rate;

	ZMPFormat        format;
	uint64_t         base;
	uint64_t         offset;
	uint64_t         start;
	uint64_t         stop;
	uint64_t         time;

	uint64_t         position;
	uint64_t         duration;
} ZMPSegmentEventPayload;

typedef struct {
	/* timestamp */
	int64_t          pts;
	int64_t          dts;
	int64_t          duration;

	/* media specific offset */
	uint64_t         offset;
	uint64_t         offset_end;
} ZMPPortionEventPayload;

typedef struct ZMPEventHeader_ {
	uint32_t magic_number;
	uint32_t packet_size;
	int32_t event_type;
	int64_t timestamp;
	int32_t seq_num;
} ZMPEventHeader;

#endif /* ZMP_EVENTS_H__ */

