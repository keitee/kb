#define _GNU_SOURCE
#include "zmp.h"
#include "events.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <poll.h>
#include <stdlib.h>

static const char filename_template[] = "segment-%i.ts";

enum {
	STATE_CONTINUE = -1
};

typedef struct Ctx_ {
	const char *filename_template;
	int fileno;
	int outfd;
	int state;
	size_t total_bytes_consumed;
} Ctx;

static void on_event(void *user_data, ZMPStream *stream, ZMPEventHeader *header,
                     size_t payload_bytes, void *payload)
{
	Ctx *ctx = (Ctx*) user_data;
	switch (header->event_type) {
	/* After receiving FLUSH_START we are guaranteed to not receive any data
	   until NEW_SEGMENT */
	case ZMP_EVENT_FLUSH_START:
		if (ctx->outfd != -1) {
			close(ctx->outfd);
			ctx->outfd = -1;
		}
		break;
	case ZMP_EVENT_FLUSH_STOP:
		break;
	case ZMP_EVENT_SEGMENT: {
			if (ctx->outfd != -1) {
				close(ctx->outfd);
				ctx->outfd = -1;
			}
			char new_filename[128];
			snprintf(new_filename, 128, ctx->filename_template, ctx->fileno);
			/* TODO: deal with errors */
			ctx->outfd = open(new_filename, O_CREAT | O_WRONLY /* | O_NONBLOCK */,
			                  0644);
			/* TODO: deal with errors */
			ctx->fileno++;
		}
		break;
	case ZMP_EVENT_PORTION:
	  break;
	default:
		fprintf(stderr, "Warning: Received unknown event %i (%i, %x).  Ignoring.\n",
		        header->event_type, header->event_type >> 8,
		        header->event_type & 0xFF);
	};
}

size_t seek_point = 100*1024*1024;

/*
 * Read as much data as you can without blocking (on either reading or
 * writing).  Return the number of bytes transferred or -errno on failure.
 */
static ssize_t on_data(void *user_data, ZMPStream *stream, int infd)
{
	Ctx *ctx = (Ctx*) user_data;
	char buf[4096];
	int err;
	ssize_t bytes_read = read(infd, buf, sizeof(buf));
	err = errno;
	write(ctx->outfd, buf, bytes_read);
	if (bytes_read > 0
	    && ctx->total_bytes_consumed + bytes_read > seek_point
	    && ctx->total_bytes_consumed < seek_point) {
		fprintf(stderr, "Doing seek...\n");
		int err2 = zmp_stream_request_seek(stream, 1, ZMP_FORMAT_BYTES,
		                                   ZMP_SEEK_FLAG_FLUSH, ZMP_SEEK_TYPE_SET,
		                                   0, ZMP_SEEK_TYPE_NONE, 0);
		if (err2) {
			fprintf(stderr, "Seek failed!\n");
		}
	}
	ctx->total_bytes_consumed += bytes_read;
	errno = err;
	return bytes_read;
}

static void on_error(void *user_data, ZMPStream *stream, int error, char* desc)
{
	Ctx *ctx = (Ctx*) user_data;
	if (error == EPIPE) {
		fprintf(stderr, "EOF: exiting\n");
		ctx->state = EXIT_SUCCESS;
	}
	else {
		fprintf(stderr, "Received unexpected error %i - %s: %s\n", error,
		        strerror(error), desc);
		ctx->state = EXIT_FAILURE;
	}
}

static void handle_input(Ctx *ctx, ZMPStream *stream)
{
	char input;
	while (read(0, &input, 1) > 0) {
		if (input >= '0' && input <= '9') {
			int minutes = input - '0';
			zmp_stream_request_seek(stream, 1, ZMP_FORMAT_TIME,
			    ZMP_SEEK_FLAG_FLUSH | ZMP_SEEK_FLAG_ACCURATE,
			    ZMP_SEEK_TYPE_SET, minutes * ZMP_SECOND * 60,
			    ZMP_SEEK_TYPE_NONE, 0);
		}
		if (input == 'q') {
			ctx->state = EXIT_SUCCESS;
		}
	}
}

enum {
	WFD_USER_INPUT,
	WFD_ZMP,
	WFD_OUTPUT
};

int main(int argc, char* argv[])
{
	ZMPStream *stream = NULL;
	int serialized_event_fd = -1, immediate_event_fd = -1;
	int zmp_fd = -1;
	Ctx ctx = {NULL, 0, -1, 1, 0};
	int err = 0;

	ctx.filename_template = filename_template;
	ctx.state = STATE_CONTINUE;

	serialized_event_fd = socket(AF_UNIX,
	                             SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
	immediate_event_fd = socket(AF_UNIX,
	                            SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
	struct sockaddr_un path = { AF_UNIX, "zmp_listening_socket" };
	err = connect(serialized_event_fd, &path, sizeof(path));
	if (err) {
		perror("connect");
		return 1;
	}
	err = connect(immediate_event_fd, &path, sizeof(path));
	if (err) {
		perror("connect");
		return 1;
	}

	stream = zmp_stream_new(serialized_event_fd, immediate_event_fd);
	zmp_stream_set_callbacks(stream, &ctx, on_event, on_data, on_error);
	zmp_fd = zmp_stream_get_listen_fd(stream);

	while (ctx.state == STATE_CONTINUE) {
		struct pollfd pollfds[3];
		memset(pollfds, 0, sizeof(pollfds));
		int nfds = ctx.outfd == -1 ? 2 : 3;

		pollfds[WFD_USER_INPUT].fd = 0; /* STDIN */
		pollfds[WFD_USER_INPUT].events = POLLIN;
		pollfds[WFD_ZMP].fd = zmp_fd;
		pollfds[WFD_ZMP].events = POLLIN;
		pollfds[WFD_OUTPUT].fd = ctx.outfd;
		pollfds[WFD_OUTPUT].events = /* POLLOUT | */ POLLERR | POLLHUP;

		poll(pollfds, nfds, -1);
		if (pollfds[WFD_USER_INPUT].revents) {
			handle_input(&ctx, stream);
		}
		if (pollfds[WFD_OUTPUT].revents) {
			zmp_stream_notify_read_ready(stream);
		}
		if (pollfds[WFD_ZMP].revents) {
			zmp_stream_notify(stream);
		}
	}

	zmp_stream_free(stream);
	close(immediate_event_fd);
	close(serialized_event_fd);
	return ctx.state;
}

