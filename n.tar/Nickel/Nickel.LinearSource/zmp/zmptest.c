#include "zmp.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <errno.h>

#include <sys/socket.h>

struct Test;

static struct Test* last_test = NULL;
static struct Test* first_test = NULL;

struct Test {
	const char * name;
	void (*fn)(void);
	struct Test * next;
};

#define ASSERT(x) \
	do { \
		if (!(x)) { \
			fprintf(stderr, "%s:%i: Test Error: %s failed\n", __FILE__, __LINE__, #x ); \
			exit(RESULT_ERROR); \
		}; \
	} while (0);
#define CHECK(x) \
	do { \
		if (!(x)) { \
			fprintf(stderr, "%s:%i: Test Failure: %s failed\n", __FILE__, __LINE__, #x ); \
			exit(RESULT_FAILURE); \
		}; \
	} \
	while (0);
#define TEST(x) \
	static void x (void); \
	struct Test test_##x = { #x , &x, NULL }; \
	static void register_##x (void) __attribute__((constructor)); \
	static void register_##x (void) { \
		if (!first_test) { \
			first_test = &test_##x; \
			last_test = &test_##x; \
		} else { \
			last_test->next = &test_##x; \
			last_test = &test_##x; \
		} \
	} \
	static void x (void)

typedef enum TestResult_t {
	RESULT_SUCCESS = 0,
	RESULT_FAILURE,
	RESULT_ERROR
} TestResult;

struct test_result_aggregation {
	int successes;
	int failures;
	int errors;
};

static void print_file(int fd)
{
	ASSERT(lseek(fd, 0, SEEK_SET) == 0);
	char buf[4096];
	ssize_t bytes_read;
	while ((bytes_read = read(fd, buf, sizeof(buf))) > 0) {
		ssize_t off = 0, bytes_written;
		while ((bytes_written = write(2, buf + off, bytes_read - off)) > 0) {
			off += bytes_written;
		}
		ASSERT(bytes_written == 0);
	}
	ASSERT(bytes_read == 0);
}

static void run_test(struct test_result_aggregation * out,
                    struct Test * test)
{
	pid_t pid;
	fprintf(stderr, "Running test %s...", test->name);
	fflush(stderr);

	char buf[] = "/tmp/test-output.XXXXXX";
	int fd = mkstemp(buf);
	ASSERT(fd >= 0);
	ASSERT(unlink(buf) == 0);

	pid = fork();
	ASSERT(!(pid < 0));
	if (pid == 0) {
		/* Child */
		ASSERT(dup2(fd, 1) == 1);
		ASSERT(dup2(fd, 2) == 2);
		ASSERT(close(fd) == 0);
		test->fn();
		exit(EXIT_SUCCESS);
	}
	else {
		/* Parent */
		int status, dead_pid, print_output = 0;
		dead_pid = wait(&status);
		ASSERT(dead_pid == pid);
		if (WIFEXITED(status) && WEXITSTATUS(status) == EXIT_SUCCESS) {
			fprintf(stderr, "SUCCESS\n");
			out->successes++;
		}
		else if (WIFEXITED(status) && WEXITSTATUS(status) == EXIT_FAILURE) {
			fprintf(stderr, "FAILURE\n");
			out->failures++;
			print_output = 1;
		}
		else {
			fprintf(stderr, "ERROR\n");
			out->errors++;
			print_output = 1;
		}
		if (print_output) {
			fprintf(stderr, "===================== Test output begin:\n");
			print_file(fd);
			fprintf(stderr, "===================== Test output end\n");
		}
	}
}

int run_all_tests(int argc, char * argv[])
{
	struct test_result_aggregation agg = {0, 0, 0};
	struct Test * i;
	ASSERT(argc > 0);
	fprintf(stderr, "%s: Start test suite\n", argv[0]);
	for (i=first_test; i != NULL; i = i->next) {
		run_test(&agg, i);
	}
	fprintf(stderr, "%s: %i Successes %i Failures %i Errors\n", argv[0],
	        agg.successes, agg.failures, agg.errors);
	return (agg.failures == 0 && agg.errors == 0) ? 0 : 1;
}

/* =========== Begin tests: */

#define UNUSED(x) (void)(x);

static void noop_event_callback(void *user_data, ZMPStream *stream,
                                ZMPEventHeader *header, size_t payload_size,
                                void *payload)
{
	UNUSED(user_data); UNUSED(stream); UNUSED(header); UNUSED(payload_size);
	UNUSED(payload);
}
static ssize_t noop_data_callback(void *user_data, ZMPStream *stream,
                                  int input_fd)
{
	UNUSED(user_data); UNUSED(stream); UNUSED(input_fd);
	errno = EAGAIN;
	return -1;
}
static void noop_error_callback(void *user_data, ZMPStream *stream,
                                int error, char* desc)
{
	UNUSED(user_data); UNUSED(stream); UNUSED(error); UNUSED(desc);
}

static void create_zmp_stream (ZMPStream ** p, int * serialized_event_socket,
                               int * immediate_event_socket)
{
	int err[2];
	int fds[4] = { -1, -1, -1, -1 };

	err[0] = socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC, 0, &fds[0]);
	err[1] = socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC, 0, &fds[2]);

	ASSERT(!err[0] && !err[1]);

	*p = zmp_stream_new(fds[0], fds[2]);
	ASSERT(*p);

	zmp_stream_set_callbacks(*p, NULL, noop_event_callback, noop_data_callback,
	                         noop_error_callback);

	*serialized_event_socket = fds[1];
	*immediate_event_socket = fds[3];
}

TEST(test_that_zmp_stream_notify_returns_error_if_immediate_event_has_problems) {
	ZMPStream * s;
	int s_fd, i_fd;
	create_zmp_stream(&s, &s_fd, &i_fd);

	CHECK(zmp_stream_notify(s) == 0);

	char buf[] = "This is not a valid immediate event!";
	ssize_t bytes_written = write(i_fd, buf, sizeof(buf));
	/* All bytes must be written at once as this is a SEQPACKET socket: */
	ASSERT(bytes_written == sizeof(buf));

	CHECK(zmp_stream_notify(s) == 1);
}

TEST(that_zmp_stream_request_seek_returns_ECONNRESET_if_zmp_is_in_error_state) {
	ZMPStream * s;
	int s_fd, i_fd;
	create_zmp_stream(&s, &s_fd, &i_fd);

	/* Cause error state */
	close(i_fd);
	close(s_fd);
	CHECK(zmp_stream_notify(s) == 1);

	CHECK(zmp_stream_request_seek(s, 1.0,
	                              ZMP_FORMAT_UNDEFINED, ZMP_SEEK_FLAG_NONE,
	                              ZMP_SEEK_TYPE_NONE, 0,
	                              ZMP_SEEK_TYPE_NONE, 0) == ECONNRESET);
}

static void count_event_callbacks(void *user_data, ZMPStream *stream,
                                  ZMPEventHeader *header, size_t payload_size,
                                  void *payload)
{
	int * event_counts = (int*)user_data;
	UNUSED(stream); UNUSED(header); UNUSED(payload_size); UNUSED(payload);

	event_counts[(header->event_type & ZMP_EVENT_TYPE_SERIALIZED) ? 1 : 0]++;
}

TEST(that_when_flushing_serialized_events_are_suppressed)
{
	ZMPStream * s;
	int s_fd, i_fd;
	create_zmp_stream(&s, &s_fd, &i_fd);

	enum { EV_IMM = 0, EV_SER };
	int event_counts[2] = {0, 0};
	zmp_stream_set_callbacks(s, event_counts, count_event_callbacks,
	                         noop_data_callback, noop_error_callback);

	ZMPEventHeader h = {ZMP_MAGIC_NUMBER, sizeof(h),
	    ZMP_EVENT_MAKE_TYPE (25, ZMP_FLAG(DOWNSTREAM) | ZMP_FLAG(SERIALIZED)), 0, 0};
	CHECK(write(s_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_SER] == 1);

	h.event_type = ZMP_EVENT_FLUSH_START;
	CHECK(write(i_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_IMM] == 1);

	/* Now we're flushing this should be suppressed: */
	h.event_type = ZMP_EVENT_MAKE_TYPE (25, ZMP_FLAG(DOWNSTREAM) | ZMP_FLAG(SERIALIZED));
	CHECK(write(s_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_SER] == 1);

	/* But immediate events should not be */
	h.event_type = ZMP_EVENT_MAKE_TYPE (25, ZMP_FLAG(DOWNSTREAM));
	CHECK(write(i_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_IMM] == 2);

	/* Every FLUSH_START event has to be cancelled by
	   a paired FLUSH_STOP */
	h.event_type = ZMP_EVENT_FLUSH_START;
	CHECK(write(i_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_IMM] == 3);

	h.event_type = ZMP_EVENT_FLUSH_STOP;
	CHECK(write(s_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_SER] == 1);

	h.event_type = ZMP_EVENT_FLUSH_STOP;
	CHECK(write(s_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_SER] == 2);

	h.event_type = ZMP_EVENT_MAKE_TYPE (25, ZMP_FLAG(DOWNSTREAM) | ZMP_FLAG(SERIALIZED));
	CHECK(write(s_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_SER] == 3);
}

TEST(that_when_flush_events_out_of_order)
{
	ZMPStream * s;
	int s_fd, i_fd;
	create_zmp_stream(&s, &s_fd, &i_fd);

	enum { EV_IMM = 0, EV_SER };
	int event_counts[2] = {0, 0};
	zmp_stream_set_callbacks(s, event_counts, count_event_callbacks,
	                         noop_data_callback, noop_error_callback);

	ZMPEventHeader h = {ZMP_MAGIC_NUMBER, sizeof(h), 0, 0, 0};

	h.event_type = ZMP_EVENT_FLUSH_STOP;
	CHECK(write(i_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_SER] == 1);

	/* Even though FLUSH_STOP was first, it should be
	   paired with the forthcoming FLUSH_START */
	h.event_type = ZMP_EVENT_FLUSH_START;
	CHECK(write(i_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_IMM] == 1);

	h.event_type = ZMP_EVENT_MAKE_TYPE (25, ZMP_FLAG(DOWNSTREAM) | ZMP_FLAG(SERIALIZED));
	CHECK(write(s_fd, &h, sizeof(h)) == sizeof(h));
	CHECK(zmp_stream_notify(s) == 0);
	CHECK(event_counts[EV_SER] == 2);
}

TEST(test_that_zmp_create_succeeds_if_given_seqpacket_sockets) {
	ZMPStream * s;
	int s_fd, i_fd;
	create_zmp_stream(&s, &s_fd, &i_fd);
	CHECK(s);
}

TEST(test_that_zmp_create_fails_if_given_non_seqpacket_sockets) {
	int err[2];
	int fds[4] = { -1, -1, -1, -1 };

	err[0] = socketpair(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0, &fds[0]);
	err[1] = socketpair(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0, &fds[2]);

	ASSERT(!err[0] & !err[1]);

	CHECK(zmp_stream_new(fds[0], fds[2]) == NULL);
}

TEST(test_that_zmp_can_convert_portion_to_stream_time) {
	ZMPSegmentEventPayload segment;
	ZMPPortionEventPayload portion;

	/* init structures with some garbage so it's more likely detected if
	   the tested function touches something it shouldn't */
	memset(&segment, 0xCC, sizeof(segment));
	memset(&portion, 0xCC, sizeof(portion));

	segment.start = 0;
	portion.pts = 0;

	segment.time = 0;
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 0) == 0);
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 777) == 777);

	segment.time = 1000;
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 0) == 1000);
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 777) == 1777);

	segment.start = 400;
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 0) == 600);
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 777) == 1377);

	portion.pts = 100;
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 0) == 700);
	CHECK(zmp_portion_time_to_stream_time(&segment, &portion, 777) == 1477);
}

int main(int argc, char * argv[])
{
	return run_all_tests(argc, argv);
}
