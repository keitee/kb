#include <gst/gst.h>

#include <stdio.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

static const char * pipeline_desc = "uridecodebin name=src caps=video/mpegts"
    " ! queue2 name=buffer temp-template=/tmp/live-buffer-XXXXXX"
    " ! zmpsink name=sink";

static int zmp_create(GstElement ** pipeline_out,
                      int serialized_event_fd, int immediate_event_fd)
{
  GstElement * sink = NULL;
  GError * gerr = NULL;

  GstElement * pipeline = gst_parse_launch(pipeline_desc, &gerr);
  if (!pipeline) {
    fprintf(stderr, "Error creating pipeline\n");
    /* TODO: deal with this error */
    abort();
  }
  sink = gst_bin_get_by_name(GST_BIN(pipeline), "sink");

  if (!sink) {
    /* TODO: deal with this error */
    fprintf(stderr, "No element \"sink\" found in pipeline\n");
    abort();
  }

  g_object_set(G_OBJECT(sink),
               "serialized-events-fd", serialized_event_fd,
               "immediate-events-fd", immediate_event_fd, NULL);

  *pipeline_out = pipeline;
  return 0;
}

static int listen_for_sockets(int *serialized_event_fd,
                              int *immediate_event_fd)
{
  int err = 0;
  int listening_socket = socket(AF_UNIX, SOCK_SEQPACKET, 0);
  if (listening_socket < 0) {
    err = errno;
    perror("socket");
    goto out;
  }
  struct sockaddr_un iepath = { AF_UNIX, "zmp_listening_socket" };
  err = bind(listening_socket, (const struct sockaddr*) &iepath,
             sizeof(iepath));
  if (err) {
    err = errno;
    perror("bind");
    goto out;
  }
  err = listen(listening_socket, 2);
  if (err) {
    err = errno;
    perror("listen");
    goto out;
  }
  *serialized_event_fd = accept(listening_socket, NULL, NULL);
  *immediate_event_fd = accept(listening_socket, NULL, NULL);
  if (*serialized_event_fd < 0 || *immediate_event_fd < 0) {
    err = errno ? errno : EFAULT;
    fprintf(stderr, "error in accept\n");
    close(*serialized_event_fd);
    close(*immediate_event_fd);
    goto out;
  }
out:
  close(listening_socket);
  return err;
}

static gboolean
bus_call (GstBus     *bus,
          GstMessage *msg,
          gpointer    data)
{
  GMainLoop *loop = (GMainLoop *) data;

  switch (GST_MESSAGE_TYPE (msg)) {

    case GST_MESSAGE_EOS:
      g_print ("End of stream\n");
      g_main_loop_quit (loop);
      break;

    case GST_MESSAGE_ERROR: {
      gchar  *debug;
      GError *error;

      gst_message_parse_error (msg, &error, &debug);

      g_printerr ("Error: %s\n\t%s\n", error->message, debug);
      g_error_free (error);
      g_free(debug);

      g_main_loop_quit (loop);
      break;
    }
    default:
      break;
  }

  return TRUE;
}

int main(int argc, char* argv[])
{
  GstElement *pipeline = NULL, *src = NULL;
  int serialized_event_fd = -1, immediate_event_fd = -1;
  int err = 0;
  char *uri = NULL;
  guint bus_watch_id;
  GMainLoop *loop = NULL;
  GstBus *bus = NULL;

  if (argc != 2) {
    fprintf(stderr, "Error: incorrect arguments\n\tUsage: %s uri\n", argv[0]);
    goto err;
  }
  else {
    uri = argv[1];
  }

  /* We will be creating and destroying pipes.  SIGPIPE make this all rather
     inconvenient, disable it. */
  signal(SIGPIPE, SIG_IGN);
  struct sigaction action;
  memset(&action, 0, sizeof(action));
  action.sa_handler = SIG_IGN;
  sigaction(SIGPIPE, &action, NULL);
  sigset_t sigset;
  sigemptyset(&sigset);
  sigaddset(&sigset, SIGPIPE);
  sigprocmask(SIG_BLOCK, &sigset, NULL);

  gst_init(NULL, NULL);
  loop = g_main_loop_new(NULL, FALSE);
  if (!loop) {
    fprintf(stderr, "Error creating main loop!\n");
    goto err;
  }

  fprintf(stderr, "Awaiting connection...");
  err = listen_for_sockets(&serialized_event_fd, &immediate_event_fd);
  if (err) {
    perror("listen_for_sockets");
    goto err;
  }
  fprintf(stderr, " connections received.\n");

  err = zmp_create(&pipeline, serialized_event_fd, immediate_event_fd);
  if (err) {
    perror("zmp_create");
    goto err;
  }

  bus = gst_pipeline_get_bus (GST_PIPELINE (pipeline));
  bus_watch_id = gst_bus_add_watch (bus, bus_call, loop);
  gst_object_unref (bus);

  src = gst_bin_get_by_name(GST_BIN(pipeline), "src");
  if (!src) {
    goto errsock;
  }
  g_object_set(src, "uri", uri, NULL);

  gst_element_set_state(pipeline, GST_STATE_PLAYING);

  g_main_loop_run(loop);
  
  return EXIT_SUCCESS;
errsock:
  unlink("immediate_event_socket");
  unlink("serialized_event_socket");
  g_source_remove (bus_watch_id);
err:
  close(immediate_event_fd);
  close(serialized_event_fd);
  if (gst_is_initialized()) {
    gst_deinit();
  }
  return EXIT_FAILURE;
}
