/*
 * LinearSourceFactory.h
 *
 *  Created on: 3 Oct 2012
 *      Author: mariusz.buras@gmail.com
 *
 *  Copyright (C) 2012 YouView TV Ltd
 *
 */

#ifndef SOURCE_CONTROL_FACTORY_H_
#define SOURCE_CONTROL_FACTORY_H_

#include "macros.h"
#include "Factory.h"

#include <zinc-common/async/Dispatcher.h>
#include <stdint.h>

namespace Zinc {
namespace Media {
namespace LinearSource {

boost::shared_ptr<Factory> createLinearSourceFactory(
    NS_ZINC::Dispatcher& dispatcher_, uint64_t bufferSizeCap,
     const std::string& userAgent, const size_t vqeBufferSize) ZINC_LOCAL;

} // namespace LinearSource {
} // namespace Media {
} // namespace Zinc {


#endif /* SOURCE_CONTROL_FACTORY_H_ */
