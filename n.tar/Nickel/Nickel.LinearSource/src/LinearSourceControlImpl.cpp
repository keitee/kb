/*
 * LinearSourceControlImpl.cpp
 *
 *  Created on: 3 Oct 2012
 *      Author: mariusz.buras@gmail.com
 *
 *  Copyright (C) 2012 YouView TV Ltd
 *
 */

#include "LinearSourceControlImpl.h"
#include "ControlEventListener.h"

#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/async/Promise.h>
#include <zinc-common/async/async-helpers.h>
#include <zinc-common/ScopeExitHook.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <dbus-c++/types.h>

#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/thread.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread/locks.hpp>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/tuple/tuple.hpp>

#include <gst/gst.h>

#include <sys/types.h>

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>

#include <fstream>
#include <iterator>
#include <utility>

// TODO: ScopedExitHook seems a little heavyweight here.  Define it as a
//       dedicated dead-simple anonymous structure with ctor, dtor etc.
#define SCOPED_OBJ(OBJ, FUN) \
    NS_ZINC::ScopeExitHook OBJ ## _scoped( \
        OBJ ? boost::bind(FUN, OBJ) : NS_ZINC::ScopeExitHook::function_type())

#define SCOPED_OBJ_RELEASE(OBJ) \
    OBJ ## _scoped.cancel()

namespace Zinc {
namespace Media {
namespace LinearSource {
namespace {

struct ControlState
{
    enum State
    {
        NotStarted = 0,
        Started,
        Destroyed
    };
};

const char* enum_to_string(const ControlState::State value)
{
    switch (value)
    {
        case ControlState::NotStarted : return "not started";
        case ControlState::Started    : return "started";
        case ControlState::Destroyed  : return "destroyed";
        default                       :
            std::cerr
                << "Invalid ControlState enum value: " << value
                << ". Aborting.\n";
            std::abort();
    }
}

std::string read_pipeline_desc(const std::string& which)
{
    const std::string path = NS_ZINC::PackageDataFinder().find(which);

    std::ifstream in(path.c_str());
    if (!in)
    {
        throw std::runtime_error ("Cannot open file: " + path);
    }

    return std::string(
        std::istreambuf_iterator<char>(in),
        std::istreambuf_iterator<char>());
}

GstElement* create_pipeline(const std::string& description)
{
    GError *error = NULL;
    GstElement *const p = gst_parse_launch(description.c_str(), &error);
    const SCOPED_OBJ(error, g_error_free);

    if (!p)
    {
        throw std::runtime_error(
            std::string("Pipeline could not be constructed: ") +
            (error ? GST_STR_NULL (error->message) : "(unknown error)"));
    }
    else if (error)
    {
        throw std::runtime_error(
            std::string("Erroneous pipeline: ") +
            GST_STR_NULL(error->message));
    }

    return p;
}

GstElement* get_element_by_name(GstElement *const pipeline, const char* const name)
{
    if (GstElement *const e = gst_bin_get_by_name(GST_BIN(pipeline), name))
    {
        return e;
    }

    throw std::runtime_error(std::string("Cannot get element by name: ") + name);
}

void source_setup_cb(GstElement *bin, GstElement *object, gpointer user_data);
void overrun_cb(GstElement *timeshifter, gpointer user_data);
void child_added_cb(GstChildProxy *proxy,GObject *obj,gchar *name,gpointer data);

class ControlImpl : public Control, public boost::enable_shared_from_this<ControlImpl>
{
public:
                                    ControlImpl         ( NS_ZINC::Dispatcher& dispatcher_,
                                                          GstElement* pipelineElem_,
                                                          const ControlParams& params_ );

    virtual                         ~ControlImpl        ( );

    virtual zinc::Future<void>      start               ( );
    virtual zinc::Future<void>      destroy             ( );

    virtual
    zinc::Future< uint64_t >        getBufferLevelTime  ( ) const;
    zinc::Future< std::map< std::string, std::string > >
                                    getSourceInformation( ) const ;

    virtual
    zinc::Future< Position >        getPosition( const uint64_t presentationTime );

    virtual
    zinc::Future< boost::tuple<Position,uint64_t> >  
                                    getPosition2( const uint64_t presentationTime );

    virtual
    zinc::Future< void >            seekPosition( const SeekReference::Enum whence,
                                                  const int32_t offsetMilliseconds,
                                                  const SeekMode::Enum mode,
                                                  const uint64_t presentationStreamTime );

    const std::string&              getUserAgent() const;
    size_t                          getVqeBufferSize() const;

    void                            overrun();

    using NS_ZINC::DispatchingEventProducer<ControlEventListener>::produceEvent;
private:

    std::pair< uint64_t, uint64_t > getBufferPosition_unlocked ( GstFormat) const;
    void                            checkState_unlocked ( const ControlState::State stateExpected ) const;
    Position                        getPosition_unlocked (const uint64_t presentationStreamTime) const;

    static gboolean                 busCallback         ( GstBus *bus,
                                                          GstMessage *msg,
                                                          gpointer data );
    bool                            handleBusCallback   ( GstBus* bus, GstMessage* msg );
    void                            realDestroy         ( );

    NS_ZINC::Dispatcher&            dispatcher;
    guint                           watchID;
    GstElement*                     pipelineElem;
    const int32_t                   flags;
    ::DBus::UnixFD                  serialized_fd;
    ::DBus::UnixFD                  immediate_fd;

    mutable boost::recursive_mutex  ctrlLock;

    ControlState::State             state;

    const std::string               userAgent;
    const size_t                    vqeBufferSize;
};


} // anon namespace

struct ScopedCString
{
    explicit ScopedCString(char* str_)
     : str(str_)
    {
    }
    ~ScopedCString()
    {
        free(str);
    }
    char* str;
};

boost::shared_ptr<Control>  createLinearSourceControl ( NS_ZINC::Dispatcher& dispatcher_,
                                                        const ControlParams& params_ )
{
    const char *const pipelineDescFile =
        params_.flags & CONTROL_FLAG_WITH_TIMESHIFTER ?
            "gst-pipeline-pausing" : "gst-pipeline-non-pausing";

    const std::string pipelineDesc = read_pipeline_desc(pipelineDescFile);

    GstElement *const pipelineElem = create_pipeline(pipelineDesc);
    SCOPED_OBJ(pipelineElem, gst_object_unref);

    GstElement *const sinkElem = get_element_by_name(pipelineElem, "sink");
    const SCOPED_OBJ(sinkElem, gst_object_unref);

    GstElement *const srcElem = get_element_by_name(pipelineElem, "src");
    const SCOPED_OBJ(srcElem, gst_object_unref);

    GstElement *const bufferElem = get_element_by_name(pipelineElem, "buffer");
    const SCOPED_OBJ(bufferElem, gst_object_unref);

    g_object_set(G_OBJECT (srcElem), "uri", params_.uri.c_str(), NULL);

    g_object_set(G_OBJECT(sinkElem),
               "serialized-events-fd", params_.fds.serialised,
               "immediate-events-fd", params_.fds.immediate, NULL);

    if ( params_.flags & CONTROL_FLAG_WITH_TIMESHIFTER )
    {
        /* Use a temporary file which will be automatically cleaned up by the
           kernel when there are no longer any users of it. */
        ScopedCString filename(strdup(params_.buffer.path.c_str()));
        if (filename.str == NULL) {
            throw std::bad_alloc();
        }
        DBus::UnixFD timeshiftFile(mkstemp(filename.str));
        if (timeshiftFile.get() < 0) {
            throw std::runtime_error("Couldn't create temporary timeshift "
                                     "file");
        }
        unlink(filename.str);

        if (ftruncate(timeshiftFile.get(), params_.buffer.size) != 0) {
            throw std::runtime_error("Unable to allocate space in timeshift "
                                     "file");
        }

        // Buffer takes ownership of this file descriptor
        g_object_set(G_OBJECT (bufferElem),
                     "backing-store-fd", timeshiftFile.release(),
                     NULL);

        ScopedCString indexFilename(strdup(params_.buffer.path.c_str()));
        if (indexFilename.str == NULL) {
            throw std::bad_alloc();
        }

        DBus::UnixFD indexFile(mkstemp(indexFilename.str));
        if (indexFile.get() < 0) {
            throw std::runtime_error("Couldn't create temporary index "
                                     "file");
        }
        unlink(indexFilename.str);

        // index takes ownership of this file descriptor
        g_object_set(G_OBJECT (bufferElem),
                     "index-store-fd", indexFile.release(),
                     NULL);
    }

    boost::shared_ptr<Control> ctrl =
        boost::make_shared<ControlImpl>( boost::ref(dispatcher_), pipelineElem, params_ ) ;

    SCOPED_OBJ_RELEASE(pipelineElem);

    // We need to set the user-agent property on the souphttpsrc element when
    // it's instantiated by the uridecodebin.
    //
    // This looks suspicious when a raw pointer is extracted from the
    // shared_ptr.  But don't worry--the Control object owns the pipeline.  If
    // the signal is emitted it means that the object exists.  Otherwise the
    // pipeline would be destroyed already and the signal not emitted.
    g_signal_connect(srcElem, "source-setup",
                     G_CALLBACK(source_setup_cb), static_cast<gpointer>(ctrl.get()));

    // Discover GstVQESrc to set vqe-buffer-size
    g_signal_connect( srcElem, "child-added", 
                 G_CALLBACK(child_added_cb), static_cast<gpointer>(ctrl.get()) );

    if ( params_.flags & CONTROL_FLAG_WITH_TIMESHIFTER )
    {
        GstElement *const timeshifter = get_element_by_name(pipelineElem, "timeshifter");
        const SCOPED_OBJ(timeshifter, gst_object_unref);

        g_signal_connect(timeshifter, "overrun",
                         G_CALLBACK(overrun_cb), static_cast<gpointer>(ctrl.get()));

    }

    return ctrl;
}

namespace {

// ------------------------------------------------------------------------------------------------------------

ControlImpl::ControlImpl( NS_ZINC::Dispatcher& dispatcher_,
                          GstElement* pipelineElem_,
                          const ControlParams& params_ )
    : dispatcher ( dispatcher_ ),
      watchID ( 0 ),
      pipelineElem ( pipelineElem_ ),
      flags ( params_.flags),
      serialized_fd ( params_.fds.serialised ),
      immediate_fd ( params_.fds.immediate ),
      ctrlLock (),
      state ( ControlState::NotStarted ),
      userAgent ( params_.user_agent ),
      vqeBufferSize( params_.vqeBufferSize )
{
    // ---------------------------------------------------------
    // setup gstreamer message bus

    GstBus *const bus = gst_pipeline_get_bus (GST_PIPELINE (pipelineElem));
    SCOPED_OBJ(bus, gst_object_unref);

    watchID = gst_bus_add_watch (bus, busCallback, static_cast<gpointer>(this));
}

// --------------------------------------------------------------------------------------------------------------------

ControlImpl::~ControlImpl()
{
    boost::lock_guard<boost::recursive_mutex>  lock( ctrlLock );
    realDestroy ( );
}

// --------------------------------------------------------------------------------------------------------------------

zinc::Future<void> ControlImpl::start ()
{
    // TODO: we're have not really entered a state when we leave this function

    boost::lock_guard<boost::recursive_mutex>  lock( ctrlLock );

    switch ( state  )
    {
        case  ControlState::NotStarted:
            gst_element_set_state ( pipelineElem, GST_STATE_PLAYING);
            state = ControlState::Started;
            return  NS_ZINC::completedFuture( dispatcher );
        case ControlState::Started:
            // I'm not sure about that
            return  NS_ZINC::completedFuture( dispatcher );
        case ControlState::Destroyed:
            throw std::runtime_error ("LinearSourceControl: start() called after destroy()");
        default:
            throw std::runtime_error ("LinearSourceControl: start() impossible state.");
    }

}

// --------------------------------------------------------------------------------------------------------------------

void ControlImpl::realDestroy()
{
    if (watchID != 0) {
        g_source_remove(watchID);
        watchID = 0;
    }
    if (pipelineElem) {
        gst_element_set_state( pipelineElem, GST_STATE_NULL );

        gst_object_unref(GST_OBJECT (pipelineElem));
        pipelineElem = NULL;
    }

    serialized_fd.reset();
    immediate_fd.reset();

    state = ControlState::Destroyed;
}

// --------------------------------------------------------------------------------------------------------------------


zinc::Future<void> ControlImpl::destroy ()
{
    boost::lock_guard<boost::recursive_mutex>  lock( ctrlLock );

    // TODO: we're have not really entered a state when we leave this function
    // TODO: do actually destroy the pipeline

    switch ( state  )
    {
        case ControlState::NotStarted:
        case ControlState::Started:
            realDestroy ();
            return  NS_ZINC::completedFuture( dispatcher );
        case ControlState::Destroyed:
            throw std::runtime_error ("LinearSourceControl: destroy() called more then once");
        default:
            throw std::runtime_error ("LinearSourceControl: destroy() impossible state.");
    }
    return  NS_ZINC::completedFuture( dispatcher );
}

// --------------------------------------------------------------------------------------------------------------------

std::pair< uint64_t, uint64_t > ControlImpl::getBufferPosition_unlocked ( GstFormat format ) const
{
    std::pair< gint64, gint64 > pos( 0, 0 );

    GstQuery *const q = gst_query_new_buffering( format );
    const SCOPED_OBJ(q, gst_query_unref);

    if (!q)
    {
        throw std::runtime_error( "Failed to create buffering query" );
    }

    if (!gst_element_query( pipelineElem, q ))
    {
        return pos;
    }

    gst_query_parse_buffering_range( q, NULL, &pos.first, &pos.second, NULL );

    return
        GST_CLOCK_TIME_IS_VALID( pos.first ) &&
            GST_CLOCK_TIME_IS_VALID( pos.second ) ?
        pos : std::pair< gint64, gint64 >( 0, 0 );
}

zinc::Future< uint64_t > ControlImpl::getBufferLevelTime ( ) const
{
    boost::lock_guard<boost::recursive_mutex>  lock( ctrlLock );
    checkState_unlocked( ControlState::Started );

    const std::pair< uint64_t, uint64_t > bufPos = getBufferPosition_unlocked(GST_FORMAT_TIME);
    return NS_ZINC::completedFuture( dispatcher, bufPos.second - bufPos.first );
}

void ControlImpl::checkState_unlocked ( const ControlState::State stateExpected ) const
{
    if (state != stateExpected)
    {
        const std::string stateValue = enum_to_string( state );
        throw std::runtime_error(
            "LinearSourceControl - invalid state: " + stateValue );
    }
}

// ------------------------------------------------------------------------------------------------------------

void filterPropertiesForGetSourceInformation ( std::map< std::string, std::string >& siMap,
                                               GstElement* vqecElem )
{
    gboolean hasproperties(false);
    g_object_get (G_OBJECT (vqecElem), "stats-are-valid", &hasproperties, NULL);

    if ( hasproperties == false )
    {
        // we can't get valid properties because of some prior error condition
        return;
    }

    guint num_properties;
    GParamSpec **const property_specs =
        g_object_class_list_properties (G_OBJECT_GET_CLASS (vqecElem), &num_properties);
    const SCOPED_OBJ(property_specs, g_free);

    for (guint i = 0; i < num_properties; i++)
    {
        GValue value = G_VALUE_INIT;

        GValue *const value_ptr = &value;
        const SCOPED_OBJ(value_ptr, g_value_unset);

        GParamSpec *param = property_specs[i];
        g_value_init ( &value, G_PARAM_SPEC_VALUE_TYPE(param) );

        std::string propName ( g_param_spec_get_name (param) );
        
        if ( ((param->flags & G_PARAM_READABLE) && !(param->flags & G_PARAM_WRITABLE))
            ||  propName.find("TR135") != std::string::npos )
        {
            uint64_t rawValue = 0;
            g_object_get_property (G_OBJECT (vqecElem), param->name, &value);

            if  ( G_VALUE_TYPE (&value) == G_TYPE_UINT64  )
            {
                rawValue = g_value_get_uint64 ( &value );
            }
            else if ( G_VALUE_TYPE (&value) == G_TYPE_ULONG )
            {
                rawValue = (uint64_t) g_value_get_ulong ( &value );
            }            

            // normalise prop name to more what mediarouter expects
            std::replace( propName.begin(), propName.end(), '-', '_');
            boost::to_upper(propName);

            siMap[ propName ] = boost::lexical_cast<std::string>( rawValue ) ;
        }
    }
}

zinc::Future< std::map< std::string, std::string > >  ControlImpl::getSourceInformation() const
{
    boost::lock_guard<boost::recursive_mutex>  lock( ctrlLock );

    switch ( state  )
    {
        case  ControlState::NotStarted:
            throw std::runtime_error ("LinearSourceControl: getSourceInformation() called before start()");
        case ControlState::Started:
        {
            std::map< std::string, std::string > si;

            si["CONFIGURATION"] = "LINEAR.MULTICAST";

            if (GstElement *const elem = gst_bin_get_by_name(GST_BIN(pipelineElem), "vqesrc"))
            {
                const SCOPED_OBJ(elem, gst_object_unref);

                si["TYPE"] = "RTP";
                filterPropertiesForGetSourceInformation( si, elem );
            }
            else
            {
                // This means that connection type is not VQE
                si["TYPE"] = "UNKNOWN";
            }

            return  NS_ZINC::completedFuture( dispatcher, si );
        }
        case ControlState::Destroyed:
            throw std::runtime_error ("LinearSourceControl: getSourceInformation() called after destroy()");
    }

    throw std::runtime_error ("LinearSourceControl: getSourceInformation() impossible state.");
}

Position ControlImpl::getPosition_unlocked (const uint64_t presentationStreamTime) const
{
    checkState_unlocked( ControlState::Started );

    const std::pair<uint64_t, uint64_t> bufPos = getBufferPosition_unlocked(GST_FORMAT_TIME);

    // clamp the given presentation time to be between buffer start and end
    const uint64_t currentTime =
        presentationStreamTime < bufPos.first ? bufPos.first :
        presentationStreamTime > bufPos.second ? bufPos.second :
        presentationStreamTime;

    // note there's time conversion from ns (GStreamer) to ms (Zinc.Media)
    return Position(
            -int32_t((bufPos.second - bufPos.first) / 1000000),
            -int32_t((bufPos.second - currentTime) / 1000000),
            0);

}

zinc::Future< Position > ControlImpl::getPosition (const uint64_t presentationStreamTime)
{
    boost::lock_guard<boost::recursive_mutex> lock( ctrlLock );
    Position pos = getPosition_unlocked( presentationStreamTime );
    return NS_ZINC::completedFuture( dispatcher, pos);
}

zinc::Future< boost::tuple<Position,uint64_t> >  ControlImpl::getPosition2( const uint64_t presentationStreamTime )
{
    boost::lock_guard<boost::recursive_mutex> lock( ctrlLock );
    Position pos = getPosition_unlocked( presentationStreamTime );
    const std::pair<uint64_t, uint64_t> bufPos = getBufferPosition_unlocked(GST_FORMAT_BYTES);
    return NS_ZINC::completedFuture(dispatcher, boost::make_tuple( pos, bufPos.second) );
}

GstSeekFlags getSeekFlags( const SeekMode::Enum mode )
{
    switch (mode)
    {
    case SeekMode::prioritise_accuracy : return GST_SEEK_FLAG_ACCURATE;
    case SeekMode::prioritise_speed    : return GST_SEEK_FLAG_NONE;
    default                            : return GST_SEEK_FLAG_NONE;
    }
}

zinc::Future< void > ControlImpl::seekPosition (
    const SeekReference::Enum whence,
    const int32_t offsetMilliseconds,
    const SeekMode::Enum mode,
    const uint64_t presentationStreamTime)
{
    boost::lock_guard<boost::recursive_mutex> lock( ctrlLock );
    checkState_unlocked( ControlState::Started );

    const std::pair<uint64_t, uint64_t> bufPos = getBufferPosition_unlocked(GST_FORMAT_TIME);

    int64_t offsetNanoseconds = offsetMilliseconds * GST_MSECOND;
    int64_t where = -1;

    // Note that there's no range check.  It makes it dead simple.
    // Either the pipeline handles out of range requests somehow or
    // a seek simply fails in which case the failure should be reported (signalled).
    switch (whence)
    {
    case SeekReference::start:
        where = bufPos.first + offsetNanoseconds;
        break;

    case SeekReference::current:
        where = presentationStreamTime + offsetNanoseconds;
        break;

    case SeekReference::end:
        where = bufPos.second + offsetNanoseconds;
        break;

    default:
        throw std::runtime_error( "Unexpected seek reference" );
    }

    // TODO: Signal seek failures
    (void)gst_element_seek_simple(
        pipelineElem,
        GST_FORMAT_TIME,
        static_cast<GstSeekFlags>(getSeekFlags(mode) | GST_SEEK_FLAG_FLUSH),
        where);

    return NS_ZINC::completedFuture( dispatcher );
}

const std::string& ControlImpl::getUserAgent() const
{
    return userAgent;
}

size_t ControlImpl::getVqeBufferSize() const
{
    return vqeBufferSize;
}

void ControlImpl::overrun()
{
    produceEvent(boost::bind(&ControlEventListener::Overrun, _1));
}

// ------------------------------------------------------------------------------------------------------------

gboolean ControlImpl::busCallback ( GstBus *bus, GstMessage *msg, gpointer data )
{
    ControlImpl* mr = static_cast<ControlImpl*>(data);
    return mr->handleBusCallback(bus, msg) ? TRUE : FALSE;
}

// ---------------------------------------------------------------------------------
// map error for src (VQE) element

std::pair<ErrorEventValue::Enum, ErrorEventContext::Enum>
mapGStreamerToMediaRouterError_src ( GError *const error, const std::string& extendedMessage )
{
    ErrorEventValue::Enum value;
    ErrorEventContext::Enum context = ErrorEventContext::source;

    if ( error->domain == GST_CORE_ERROR )
    {
        value = ErrorEventValue::locator;
    }
    else if ( error->domain == GST_RESOURCE_ERROR )
    {
        // NOTE:
        //
        // This is a hack until we can get error messages a bit more
        // descriptive in GstSoupHTTPSrc
        //
        // The strings below  are  needed  because  libsoup  will always
        // return  504  error  code for  things  that are not covered in
        // the  http  specs. That's  why  we  need  to match for strings
        // in the  error  message. This is a  smelly solution especially
        // that we can't really  test for  "Network is unreachable" case
        // as this required unplugging the cable or bringing the network
        // down. Long term solution would be to change GstSoupHTTPSrc to
        // allow it to return  some sort  of non  ambiguous error codes.
        // The  strings  below  were  picked  up  via  experiment  where
        // different error conditions were simulated such as DNS failure,
        // or refused connection. As it can be seen below error messages
        // are not  exactly descriptive and do not corespond to commonly
        // adhered standsrd, for example "Cannot connect to destination"
        // is generated when connection is refused.
        if ( extendedMessage.find("Host not found") != std::string::npos ||
             extendedMessage.find("Cannot resolve hostname") != std::string::npos ||
             extendedMessage.find("Cannot connect to destination") != std::string::npos ||
             extendedMessage.find("Network is unreachable") != std::string::npos
            )
        {
            value = ErrorEventValue::network;
        }
        // This isn't very good either. Match for fractions
        // of the error codes and assume that error was in the 4xx
        // or 5xx range. 504 exception is taken care of above.
        else if ( ( extendedMessage.find(" (5") != std::string::npos ) ||
                ( extendedMessage.find(" (4") != std::string::npos ) )
        {
            value = ErrorEventValue::server;
        }
        else
        {
            value = ErrorEventValue::network;
        }
    }
    else if (extendedMessage.find("Failed to parse SDP file") != std::string::npos ||
             extendedMessage.find("Could not determine type of stream") != std::string::npos )
    {
        value = ErrorEventValue::data;
        context = ErrorEventContext::sdp_file;
    }
    else if ( error->domain == GST_STREAM_ERROR)
    {
        switch ( error->code )
        {
            case GST_STREAM_ERROR_WRONG_TYPE:
            case GST_STREAM_ERROR_DECODE:
            case GST_STREAM_ERROR_ENCODE:
            case GST_STREAM_ERROR_DEMUX:
            case GST_STREAM_ERROR_MUX:
            case GST_STREAM_ERROR_FORMAT:
            case GST_STREAM_ERROR_DECRYPT:
            case GST_STREAM_ERROR_DECRYPT_NOKEY:

                value = ErrorEventValue::data;
                break;

            default:

                value = ErrorEventValue::locator;
                break;
        }
    }
    else
    {
        value = ErrorEventValue::locator;
    }

    return std::make_pair(value, context);
}

// ---------------------------------------------------------------------------------
// map error for buffer

std::pair<ErrorEventValue::Enum, ErrorEventContext::Enum>
mapGStreamerToMediaRouterError_buffer ( GError *const error )
{
    ErrorEventValue::Enum value;
    ErrorEventContext::Enum context = ErrorEventContext::other;

    if ( error->domain == GST_CORE_ERROR )
        value = ErrorEventValue::other;
    else if ( error->domain == GST_RESOURCE_ERROR )
        value = ErrorEventValue::network;
    else if ( error->domain == GST_STREAM_ERROR)
        value = ErrorEventValue::data;
    else
        value = ErrorEventValue::other;

    return std::make_pair(value, context);
}

// ---------------------------------------------------------------------------------
// map error for sink (zmp)

std::pair<ErrorEventValue::Enum, ErrorEventContext::Enum>
mapGStreamerToMediaRouterError_sink ( GError *const error )
{
    ErrorEventValue::Enum value;
    ErrorEventContext::Enum context = ErrorEventContext::other;

    if ( error->domain == GST_RESOURCE_ERROR )
        value = ErrorEventValue::data;
    else if ( error->domain == GST_STREAM_ERROR)
        value = ErrorEventValue::data;
    else
        value = ErrorEventValue::other;

    return std::make_pair(value, context);
}

// ------------------------------------------------------------------------------------------------------------

bool ControlImpl::handleBusCallback(GstBus*, GstMessage* msg)
{
    boost::lock_guard<boost::recursive_mutex>  lock( ctrlLock );

    switch (GST_MESSAGE_TYPE (msg))
    {

    case GST_MESSAGE_EOS:
        /*
            This is a tricky sitation. In principle we shoudn't get here
            because EOS is impossible with IP channels. Error conditions
            will be signaled by other means, so the only way we could
            end up here is an error in the Control element or somewhere
            else. We don't know how to recover from a situation like this
            so for now we will just ignore it.
        */
        break;

    case GST_MESSAGE_ERROR: {
        gchar  *debug;
        GError *error;

        gst_message_parse_error (msg, &error, &debug);
        const SCOPED_OBJ(error, g_error_free);
        const SCOPED_OBJ(debug, g_free);

        std::string text_msg = error->message;

        text_msg += "\nAdditional debug:\n";
        text_msg += debug;

        ErrorEventValue::Enum errVal;
        ErrorEventContext::Enum errContext;

        if ( ( strcmp( G_OBJECT_TYPE_NAME( msg->src ), "GstSoupHTTPSrc" ) == 0 ) ||
             ( strcmp( G_OBJECT_TYPE_NAME( msg->src ), "GstVQESrc" ) == 0 ) ||
             ( strcmp( G_OBJECT_TYPE_NAME( msg->src ), "GstTypeFindElement" ) == 0 ) ||
               strcmp( GST_MESSAGE_SRC_NAME(msg), "src" ) == 0 )
        {
            boost::tie(errVal, errContext) =
                mapGStreamerToMediaRouterError_src( error, text_msg ) ;
        }
        else if ( strcmp( GST_MESSAGE_SRC_NAME( msg ), "buffer" ) == 0 )
        {
            boost::tie(errVal, errContext) =
                mapGStreamerToMediaRouterError_buffer( error ) ;
        }
        else if ( strcmp( GST_MESSAGE_SRC_NAME( msg ), "sink" ) == 0  )
        {
            boost::tie(errVal, errContext) =
                mapGStreamerToMediaRouterError_sink( error ) ;
        }
        else
        {
            // At this point we're hitting unknown. It could be anything
            // most likely something from uridecodebin. But we don't know.
            errVal = ErrorEventValue::other;
            errContext = ErrorEventContext::other;
        }

        produceEvent(boost::bind(&ControlEventListener::ErrorEvent, _1, errVal, errContext, text_msg));

        break;
    }

    case GST_MESSAGE_STATE_CHANGED: {

        GstState oldstate, newstate, pending;
        gst_message_parse_state_changed (msg, &oldstate, &newstate, &pending);

        break;
    }

    default:
        break;
    }

    return true;
}

// --------------------------------------------------------------------------------------------------------------------

void source_setup_cb(GstElement*, GstElement *object, gpointer user_data)
{
    const ControlImpl *const ctrl = static_cast<ControlImpl*>(user_data);

    /*
     * We need to set HTTP user-agent string to comply with YV specs.
     */
    if ( strcmp( G_OBJECT_TYPE_NAME( object ), "GstSoupHTTPSrc" ) == 0 )
    {
        g_object_set(G_OBJECT (object), "user-agent", ctrl->getUserAgent().c_str(), NULL);
    }
}

bool providesIface ( GType type,  const gchar* iface_name )
{
    guint n_ifaces;
    GType *iface, *ifaces = g_type_interfaces (type, &n_ifaces);

    if (ifaces && n_ifaces) 
    {
        iface = ifaces;
        while (*iface) 
        {
            if ( strcmp ( g_type_name (*iface), iface_name  ) == 0  )
            {
                return true;
            }
            iface++;
        }
        g_free (ifaces);
    }
    return false;
}

void child_added_cb(GstChildProxy *proxy, GObject *obj, gchar * /*name*/,
                    gpointer data)
{
    if ( strcmp( G_OBJECT_TYPE_NAME( obj ), "GstVQESrc" ) == 0 )
    {
    /*
     * Set the VQE buffer size. The defaults set in GstVqe are good enough
     * but in case we'd wanted to tweak it the value set below comes from LSR
     */
        ControlImpl* ctrl = static_cast<ControlImpl*>(data);
        g_object_set(G_OBJECT (obj), "buffer-size", ctrl->getVqeBufferSize(), NULL);
        const bool ok = g_signal_handlers_disconnect_by_data(GST_ELEMENT(proxy), data) != 0;
        assert(ok);
    }
    else if ( providesIface ( G_OBJECT_TYPE (obj) , "GstChildProxy" ) )
    {
        const bool ok = g_signal_handlers_disconnect_by_data(GST_ELEMENT(proxy), data) != 0;
        assert(ok);
        g_signal_connect( obj, "child-added", 
            G_CALLBACK(child_added_cb), static_cast<gpointer>(data) );
    }
}

void overrun_cb(GstElement *, gpointer user_data)
{
    static_cast<ControlImpl*>(user_data)->overrun();
}

} // anon namespace
} // namespace LinearSource
} // namespace Media
} // namespace Zinc
