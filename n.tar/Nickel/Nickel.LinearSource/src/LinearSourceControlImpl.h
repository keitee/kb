/*
 * LinearSourceControlImpl.h
 *
 *  Created on: 3 Oct 2012
 *      Author: mariusz.buras@gmail.com
 * 
 *  Copyright (C) 2012 YouView TV Ltd
 */

#ifndef SOURCE_PLAYBACK_CONTROL_H_
#define SOURCE_PLAYBACK_CONTROL_H_

#include "macros.h"
#include "Control.h"
#include <zinc-common/async/Dispatcher.h>
#include <boost/shared_ptr.hpp>
#include <string>
#include <stdint.h>

namespace Zinc {
namespace Media {
namespace LinearSource {

struct ZINC_LOCAL ControlParams
{
    std::string uri;
    std::string user_agent;
    size_t vqeBufferSize;

    struct
    {
        int serialised;
        int immediate;
    } fds;

    int32_t flags;

    struct
    {
        std::string path;
        uint64_t size;
    } buffer;
};

boost::shared_ptr<Control> createLinearSourceControl(
    NS_ZINC::Dispatcher& dispatcher_, const ControlParams& params_ ) ZINC_LOCAL;

} // namespace LinearSource
} // namespace Media
} // namespace Zinc

#endif /* SOURCE_PLAYBACK_CONTROL_H_ */
