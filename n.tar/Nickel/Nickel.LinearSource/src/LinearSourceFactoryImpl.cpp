/*
 * LinearSourceFactoryImpl.cpp
 *
 *  Created on: 3 Oct 2012
 *      Author: mariusz.buras@gmail.com
 */

#include "LinearSourceFactoryImpl.h"
#include "LinearSourceControlImpl.h"

#include <zinc-common/async/Promise.h>

#include <boost/make_shared.hpp>

#include <map>
#include <string>
#include <vector>

#include <gst/gst.h>

#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdexcept>

namespace Zinc {
namespace Media {
namespace LinearSource {
namespace {

const char* const PAUSE_BUFFER_DIR_DEFAULT = "/tmp";

// TODO: This is OEM specific path hard-coded.
// The timeshift buffer allocator is created only when the buffer is requested
// (atm only one OEM will request it) so it should be fine. If this directory
// doesn't exist the default one will be used. It's still a kludge though.
const char* const PAUSE_BUFFER_DIR_OEM = "/mnt/hd7/nickel-linear-source";

std::string getDefaultPauseBufferPathTemplate()
{
    return
        (g_file_test(PAUSE_BUFFER_DIR_OEM, G_FILE_TEST_EXISTS) ?
            PAUSE_BUFFER_DIR_OEM : PAUSE_BUFFER_DIR_DEFAULT) +
        std::string("/yv-pausebuffer-XXXXXX");
}

template< class T >
T
getParam(const std::map< std::string, ::DBus::Variant >& parameters,
             const std::string& name)
{
    return ::DBus::variant_cast< T >(parameters.at(name));
}

template< class T >
T
getParamOrDefault(const std::map< std::string, ::DBus::Variant >& parameters,
                      const std::string& name, const T& v)
{
    return parameters.count(name) ? getParam< T >(parameters, name) : v;
}

class ZINC_LOCAL FactoryImpl : public Factory
{
public:
                                                FactoryImpl     ( NS_ZINC::Dispatcher& dispatcher_,
                                                                        uint64_t bufferSizeCap,
                                                                            const std::string& userAgent,
                                                                                 const size_t vqeBufferSize);
    virtual                                     ~FactoryImpl    ( );

    virtual
    NS_ZINC::Future<
            boost::tuple< boost::shared_ptr< Control >,
                 ::DBus::UnixFD, ::DBus::UnixFD > >
                                                create          (const std::string& uri_in,
                                                                    const int32_t flags_in );

    virtual
    NS_ZINC::Future<
            boost::tuple< boost::shared_ptr< Control >,
                 ::DBus::UnixFD, ::DBus::UnixFD > >
                                                create2         (const std::string& uri,
                                                                    const std::map< std::string, ::DBus::Variant >& parameters_in);

private:
    NS_ZINC::Dispatcher&                        dispatcher;
    uint64_t                                    bufferSizeCap;
    const std::string                           userAgent;
    const size_t                                vqeBufferSize;
};


FactoryImpl::FactoryImpl ( NS_ZINC::Dispatcher& dispatcher_,
                                uint64_t bufferSizeCap_,
                                    const std::string& userAgent_,
                                        const size_t vqeBufferSize_ ) :
    dispatcher ( dispatcher_ ),
    bufferSizeCap ( bufferSizeCap_ ),
    userAgent( userAgent_ ),
    vqeBufferSize ( vqeBufferSize_ )
{
}

// --------------------------------------------------------------------------------------------------------------------

FactoryImpl::~FactoryImpl()
{
}

// --------------------------------------------------------------------------------------------------------------------

NS_ZINC::Future< boost::tuple< boost::shared_ptr<Zinc::Media::LinearSource::Control>,
                         ::DBus::UnixFD,
                             ::DBus::UnixFD > > FactoryImpl::create( const std::string& uri_in,
                                                        const int32_t flags_in )
{
    std::map<std::string, ::DBus::Variant> kwargs;

    kwargs["use-buffering"] = ::DBus::Variant(bool(flags_in & CONTROL_FLAG_WITH_TIMESHIFTER));
    kwargs["buffer-size"] = ::DBus::Variant(uint64_t(bufferSizeCap));

    return create2(uri_in, kwargs);
}

NS_ZINC::Future< boost::tuple< boost::shared_ptr< Control >,
                     ::DBus::UnixFD,
                         ::DBus::UnixFD > > FactoryImpl::create2(const std::string& uri,
                                                                     const std::map< std::string, ::DBus::Variant >& parameters_in)
{
    int fds[4] = { -1, -1, -1, -1 };

    const int socketDomain = AF_UNIX;
    const int socketType = SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC;

    if (socketpair(socketDomain, socketType, 0, &fds[0]) != 0 ||
            socketpair(socketDomain, socketType, 0, &fds[2]) != 0)
    {
        throw std::runtime_error(
            std::string("Could not create a socket pair: ") +
            std::strerror(errno));
    }

    const ControlParams params = {
        uri,
        userAgent,
        vqeBufferSize,

        { fds[0], fds[2] },

        getParamOrDefault<bool>(parameters_in, "use-buffering", false),

        {
            getParamOrDefault<std::string>(parameters_in, "temp-template",
                getDefaultPauseBufferPathTemplate()),
            getParamOrDefault<uint64_t>(parameters_in, "buffer-size",
                bufferSizeCap)
        }
    };

    boost::tuple<boost::shared_ptr<Control>, ::DBus::UnixFD, ::DBus::UnixFD> t;

    t.get<0>() = createLinearSourceControl(boost::ref(dispatcher), params);
    t.get<1>().reset(fds[1]);
    t.get<2>().reset(fds[3]);

    NS_ZINC::Promise<boost::tuple<boost::shared_ptr<Control>,
            ::DBus::UnixFD, ::DBus::UnixFD> > promise(dispatcher);

    promise.complete(t) ;
    return promise.getFuture();
}

} // anon namespace

boost::shared_ptr<Factory> createLinearSourceFactory(
    NS_ZINC::Dispatcher& dispatcher,
    uint64_t bufferSizeCap,
        const std::string& userAgent,
            const size_t vqeBufferSize )
{
    return boost::make_shared<FactoryImpl>(boost::ref(dispatcher), bufferSizeCap, userAgent, vqeBufferSize);
}

} // LinearSource
} // Media
} // Zinc
