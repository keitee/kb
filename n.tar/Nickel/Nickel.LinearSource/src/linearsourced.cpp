/*
 * linearsourced.cpp
 *
 *  Created on: 3 Oct 2012
 *      Author: mariusz.buras@gmail.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#include "macros.h"
#include "bus-name.h"
#include "FactoryAsyncToDBus.h"
#include "LinearSourceFactoryImpl.h"
#include "LinearSourceControlImpl.h"

#include <dbus-c++/eventloop-integration.h>
//#include <nickel-common/NickelLogger.h>
#include <zinc-binding-runtime/dbus/DBusService.h>
#include <zinc-binding-runtime/dbus/MainLoop.h>
#include <zinc-binding-runtime/dbus/NonInheritingAdaptorFactory.h>
#include <zinc-binding-runtime/dbus/RefCountedAdaptor.h>
#include <zinc-binding-runtime/dbus/SignalReceiver.h>
#include <zinc-common/async/InlineDispatcher.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/noncopyable.hpp>
#include <boost/thread.hpp>
#include <boost/program_options.hpp>

#include <gst/gst.h>

#include <iostream>
#include <signal.h>
#include <stdexcept>

#include <cstdlib>
#include <cstdio>

const uint64_t MB = 1024 * 1024;
const uint64_t PAUSE_BUFFER_SIZE = 512 * MB;

using namespace NS_ZINC_DBUS_BINDING;
using namespace NS_NICKEL_SYSTEM;
using namespace Zinc::Media::LinearSource;
using namespace std;

namespace {
class LinearSourceDaemon : boost::noncopyable
{
public:
    LinearSourceDaemon(MainLoop& mainloop_, int argc, char* argv[]);
    ~LinearSourceDaemon();
    void start();
    void stop();
private:
    void parseCommandline(int argc, char* argv[] );

    std::string userAgent;
    size_t vqeBufferSize;

    MainLoop& mainloop;
    SignalReceiver sr;
    DBusService dbus;
    NS_ZINC::InlineDispatcher futureDispatcher;
    boost::scoped_ptr<NS_ZINC_DBUS_BINDING::BusNameMonitor> bnm;

    std::string getUserAgentString();
};


LinearSourceDaemon::LinearSourceDaemon(MainLoop& mainloop_, int argc, char* argv[]):
        mainloop(mainloop_),
        sr(mainloop_, createExitSignalHandler(boost::bind(&LinearSourceDaemon::stop, this))),
        dbus(mainloop_)
{
    parseCommandline(argc,argv);
}

void LinearSourceDaemon::parseCommandline(int argc, char* argv[]){

    namespace po = boost::program_options;

    po::options_description lsdOpts("linearsourced options");
    lsdOpts.add_options()
        ("user-agent", boost::program_options::value<std::string>(&userAgent)
            ->default_value("YouView"), "Set the user agent to be used by LSD http accesses.")
        ("vqe-buffer-size", boost::program_options::value<size_t>(&vqeBufferSize)
            ->default_value(32768), "Buffer size to be used by GstVqe.");

    po::variables_map vm;
    po::store(po::command_line_parser(argc, argv).
               options(lsdOpts).run(), vm);
    po::notify(vm);
}

LinearSourceDaemon::~LinearSourceDaemon()
{
}

void LinearSourceDaemon::start()
{
    sr.start();
    dbus.start();

    DBus::Connection conn = dbus.getConnection();

    boost::shared_ptr<Factory> factory = createLinearSourceFactory(
            futureDispatcher, PAUSE_BUFFER_SIZE, userAgent, vqeBufferSize);

    bnm.reset(new NS_ZINC_DBUS_BINDING::BusNameMonitor(conn));
    dbus.expose(OBJECT_PATH_FACTORY, factory,
        boost::make_shared<NS_ZINC_DBUS_BINDING::NonInheritingAdaptorFactory<Control> >(
            NS_ZINC_DBUS_BINDING::RefCountedAdaptorFactory<Control>(*bnm), conn, OBJECT_PATH_CONTROL));

    dbus.request_name(BUS_NAME);
}

void LinearSourceDaemon::stop()
{
    dbus.stop();
    sr.stop();
}

}// anon namespace


int main(int argc, char* argv[])
{
    int result = EXIT_SUCCESS;

    try
    {
        gst_init(NULL, NULL);

        GMainLoop *const loop = g_main_loop_new (NULL, FALSE);
        boost::thread gstThread(g_main_loop_run, loop);

        MainLoop mainloop(BUS_NAME);
        LinearSourceDaemon daemon(mainloop, argc, argv);
        mainloop.post(boost::bind(&LinearSourceDaemon::start, &daemon));
        result = mainloop.run();

        // join gst main loop thread
        g_main_loop_quit(loop);
        gstThread.join();
    }
    catch (const std::exception& e)
    {
        cout << e.what() << endl;
        result = EXIT_FAILURE;
    }

    return result;
}
