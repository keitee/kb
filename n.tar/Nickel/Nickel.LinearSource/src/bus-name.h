/*
 * bus-name.h
 *
 *  Created on: 3 Oct 2012
 *      Author: mariusz.buras@youview.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_LINEARSOURCE_BUS_NAME_H_
#define NICKEL_LINEARSOURCE_BUS_NAME_H_

#include "macros.h"

NS_NICKEL_LINEARSOURCE_OPEN

char const* const BUS_NAME             = "Zinc.LinearSource";

char const* const OBJECT_PATH_FACTORY = "/Zinc/LinearSource/Factory";
char const* const OBJECT_PATH_CONTROL = "/Zinc/LinearSource/Control";

NS_NICKEL_LINEARSOURCE_CLOSE

#endif /* NICKEL_LINEARSOURCE_BUS_NAME_H_ */
