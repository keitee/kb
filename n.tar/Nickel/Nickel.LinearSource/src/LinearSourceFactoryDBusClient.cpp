/*
 * LinearSourceDBusClientFactory.cpp
 *
 *  Created on: 1 November 2012
 *      Author: mariusz.buras@gmail.com
 *
 *  Copyright (C) 2012 YouView TV Ltd
 *
 */

#include "macros.h"
#include "bus-name.h"
#include "LinearSourceFactoryDBusClient.h"
#include "../include/Control.h"
#include "FactoryDBusToSyncAndAsync.h"

#include <dbus-c++/connection.h>
#include <dbus-c++/dispatcher.h>
#include <dbus-c++/eventloop-integration.h>

extern "C"
{

boost::shared_ptr< Zinc::Media::LinearSource::FactoryAsync > createLinearSourceFactoryDBusClient ( boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher, DBus::Connection& connection )
{
    using namespace NS_ZINC_DBUS_BINDING;
    ObjectProxyFactory< Zinc::Media::LinearSource::ControlDBusToSyncAndAsync > proxyFactory( dispatcher );
    boost::shared_ptr<ProxyFactory< Zinc::Media::LinearSource::ControlDBusToSyncAndAsync > > controlProxyFactory = boost::make_shared< ProxyFactory< Zinc::Media::LinearSource::ControlDBusToSyncAndAsync > >( proxyFactory );

    boost::shared_ptr<Zinc::Media::LinearSource::FactoryDBusToSyncAndAsync > factoryProxy = Zinc::Media::LinearSource::FactoryDBusToSyncAndAsync::create( connection,
                                                  NS_NICKEL_LINEARSOURCE::BUS_NAME,
                                                  NS_NICKEL_LINEARSOURCE::OBJECT_PATH_FACTORY,
                                                  dispatcher,
                                                  controlProxyFactory);

    return boost::static_pointer_cast<Zinc::Media::LinearSource::FactoryAsync >(factoryProxy);
}

}