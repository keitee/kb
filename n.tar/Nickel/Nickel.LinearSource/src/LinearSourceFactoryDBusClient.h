/*
 * LinearSourceFactoryDBusClient.h
 *
 *  Created on: 1 Nov 2012
 *      Author: mariusz.buras@gmail.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_SOURCEDBUSCLIENTFACTORY_FACTORY_H_
#define NICKEL_SOURCEDBUSCLIENTFACTORY_FACTORY_H_

#include "macros.h"
#include "Factory.h"
#include <boost/make_shared.hpp>

// The purpose of this factory functions is to aid in creating DBusClinet API to LinearSource clinets.
// We can't use the plugin system here, because we need to pass down a dispatcher and a DBus connection.
// As it stands its not possible (or at least very messy) with our current plugin system.
// We hope to be able to use a plugin system for that at some point hence the wishful "extern" 

// TODO: make it use proper plugin system so that we can have more flexibility.

extern "C"
{

    boost::shared_ptr< Zinc::Media::LinearSource::FactoryAsync > createLinearSourceFactoryDBusClient ( boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher, DBus::Connection& connection ) ZINC_EXPORT;

}
#endif // NICKEL_SOURCEDBUSCLIENTFACTORY_FACTORY_H_