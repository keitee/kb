/*
 * SourceContirolFactory.h
 *
 *  Created on: 30 May 2012
 *      Author: mariusz.buras@gmail.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_SOURCECONTROL_FACTORY_H_
#define NICKEL_SOURCECONTROL_FACTORY_H_

#include "macros.h"
#include "FactoryAsync.h"

namespace Zinc {
namespace Media {
namespace LinearSource {

typedef Zinc::Media::LinearSource::FactoryAsync Factory;

} // namespace LinearSource
} // namespace LinearSource
} // namespace Zinc

#endif /* NICKEL_SOURCECONTROL_FACTORY_H_ */
