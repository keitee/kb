/*
 * macros.h
 *
 *  Created on: 29 May 2012
 *      Author: mariusz.buras@gmail.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_SOURCE_PLAYBACK_MACROS_H_
#define NICKEL_SOURCE_PLAYBACK_MACROS_H_

//#include <titanium-common/macros.h>

#define NS_NICKEL_LINEARSOURCE_OPEN \
 	namespace Zinc { \
    namespace Media { \
 	namespace LinearSource {

#define NS_NICKEL_LINEARSOURCE_CLOSE } } }
#define NS_NICKEL_LINEARSOURCE Zinc::Media::LinearSource

#endif /* NICKEL_SOURCE_PLAYBACK_MACROS_H_ */
