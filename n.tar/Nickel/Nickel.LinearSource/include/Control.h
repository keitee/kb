/*
 *  Control.h
 *
 *  Created on: 30 Sept 2012
 *      Author: mariusz.buras@gmail.com
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_LINEARSOURCE_CONTROL_H_
#define NICKEL_LINEARSOURCE_CONTROL_H_

#include "macros.h"
#include "ControlAsync.h"

namespace Zinc {
namespace Media {
namespace LinearSource {

enum ControlFlags
{
    CONTROL_FLAG_WITH_TIMESHIFTER = (1 << 0),  
};

typedef Zinc::Media::LinearSource::ControlAsync Control;

} // LinearSource
} // namespace Media
} // namespace Zinc

#endif /* NICKEL_LINEARSOURCE_CONTROL_H_ */
