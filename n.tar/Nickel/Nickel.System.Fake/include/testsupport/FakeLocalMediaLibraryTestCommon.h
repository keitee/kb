/*
 * FakeLocalMediaLibraryTestCommon.h
 *
 *  Created on: Mar 17, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKELOCALMEDIALIBRARYTESTCOMMON_H_
#define NICKEL_SYSTEM_FAKE_FAKELOCALMEDIALIBRARYTESTCOMMON_H_

#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/zinc-common.h>
#include <zinc-common/testsupport/CppUnit.h>

#include <zinc-common/testsupport/PluginTestCommonBase.h>
#include <zinc-common/testsupport/PluginTestMacros.h>

#include <boost/shared_ptr.hpp>

#include <string>
#include <list>

NS_NICKEL_SYSTEM_OPEN

class LMLListener;

class FakeLocalMediaLibraryTestCommon
	:	public NS_ZINC::PluginTestCommonBase< NS_NICKEL_SYSTEM::SystemFactory >
{

public: // Members required by TestCommonBase
	void commonSetup();
	void commonTearDown();

public:
	// tests based upon data from the Fake implementation
	void testGetMediaRecords();
	void testGetMediaRecord();
	void testGetMediaRecordsByContentIdentifier();
	void testDeleteMediaRecord();
	void testGetStorageSpace();
	void testSetMediaRecordProtected();
	void testGetMediaRecordTimingSignature();
	void testSignals();
    void testSubtitles();
    void testGetMediaRecordsSortingByAcquisition();
    void testGetMediaRecordsSortingByLastWatched();
    void testGetMediaRecordsSortingByTitle();

	ZINC_REGISTER_COMMON_TEST_SUITE(FakeLocalMediaLibraryTestCommon);

	ZINC_REGISTER_TEST(testGetMediaRecords);
	ZINC_REGISTER_TEST(testGetMediaRecord);
	ZINC_REGISTER_TEST(testGetMediaRecordsByContentIdentifier);
	ZINC_REGISTER_TEST(testDeleteMediaRecord);
	ZINC_REGISTER_TEST(testGetStorageSpace);
	ZINC_REGISTER_TEST(testSetMediaRecordProtected);
	ZINC_REGISTER_TEST(testGetMediaRecordTimingSignature);
	ZINC_REGISTER_TEST(testSignals);
	ZINC_REGISTER_TEST(testSubtitles);
	ZINC_REGISTER_TEST(testGetMediaRecordsSortingByAcquisition);
	ZINC_REGISTER_TEST(testGetMediaRecordsSortingByLastWatched);
	ZINC_REGISTER_TEST(testGetMediaRecordsSortingByTitle);

	ZINC_REGISTER_COMMON_TEST_SUITE_CLOSE();

protected:
	boost::shared_ptr<LocalMediaLibrary> localMediaLibrary;
	boost::shared_ptr<LMLListener> lmlListener;

};	/* class FakeLocalMediaLibraryTestCommon */

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_FAKE_FAKELOCALMEDIALIBRARYTESTCOMMON_H_ */
