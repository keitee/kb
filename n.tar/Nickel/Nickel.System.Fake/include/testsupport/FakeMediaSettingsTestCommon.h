/*
 * FakeMediaSettingsTestCommon.h
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKEMEDIASETTINGSTESTCOMMON_H_
#define NICKEL_SYSTEM_FAKE_FAKEMEDIASETTINGSTESTCOMMON_H_

#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/zinc-common.h>
#include <zinc-common/testsupport/CppUnit.h>

#include <zinc-common/testsupport/PluginTestCommonBase.h>
#include <zinc-common/testsupport/PluginTestMacros.h>

#include <boost/shared_ptr.hpp>
#include <boost/thread/recursive_mutex.hpp>

#include <string>
#include <list>

NS_NICKEL_SYSTEM_OPEN

class FakeMediaSettingsTestCommon
	:	public NS_ZINC::PluginTestCommonBase< NS_NICKEL_SYSTEM::SystemFactory >
{
public:
	class TestListener : virtual public MediaSettingsEventListener {
	public:
		TestListener();
		virtual ~TestListener();

		virtual void MediaSettingsChange();

		bool eventOccured();
		int  eventCount();
		void resetEventOccured();

	private:
		boost::recursive_mutex m_mutex;
		int m_eventCount, m_lastCount;
	};

public: // Members required by TestCommonBase
	void commonSetup();
	void commonTearDown();

public:
	// tests based upon data from the Fake implementation
	void testAudioDescriptionsEnabled();
	void testSubtitlesEnabled();
	void testPreferredAudioLanguage();
	void testPreferredSubtitleLanguage();

	ZINC_REGISTER_COMMON_TEST_SUITE(FakeMediaSettingsTestCommon);

	ZINC_REGISTER_TEST(testAudioDescriptionsEnabled);
	ZINC_REGISTER_TEST(testSubtitlesEnabled);
	ZINC_REGISTER_TEST(testPreferredAudioLanguage);
	ZINC_REGISTER_TEST(testPreferredSubtitleLanguage);

	ZINC_REGISTER_COMMON_TEST_SUITE_CLOSE();

protected:
	boost::shared_ptr<MediaSettings> mediaSettings;
	boost::shared_ptr<TestListener>  listener;

	int timeout;

};	/* class FakeMediaSettingsTestCommon */

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_FAKE_FAKEMEDIASETTINGSTESTCOMMON_H_ */
