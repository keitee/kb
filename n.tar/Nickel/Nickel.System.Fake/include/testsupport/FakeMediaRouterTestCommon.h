/*
 * FakeMediaRouterTestCommon.h
 *
 *  Created on: Feb 26, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKEMEDIAROUTERTESTCOMMON_H_
#define NICKEL_SYSTEM_FAKE_FAKEMEDIAROUTERTESTCOMMON_H_

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/MediaRouterSync.h>

#include <zinc-common/zinc-common.h>
#include <zinc-common/testsupport/CppUnit.h>

#include <zinc-common/testsupport/PluginTestCommonBase.h>
#include <zinc-common/testsupport/PluginTestMacros.h>

#include <boost/shared_ptr.hpp>

NS_NICKEL_SYSTEM_OPEN

class MRFListener;

class FakeMediaRouterTestCommon
    :    public NS_ZINC::PluginTestCommonBase< NS_NICKEL_SYSTEM::SystemFactory >
{
public: // Members required by TestCommonBase
    void commonSetup();
    void commonTearDown();

public:

    // tests based upon data from the Fake implementation
    void testStartStopPlay();
    void testNotifyOnSignalLoss();
    void testBuffering();
    void testAudioDescriptionTrack();
    void testSubtitlesTrack();
    void testVideoWindow();
    void testSeekPosition();
    void testDVBWithBuffering();
    void testExceptions();

    ZINC_REGISTER_COMMON_TEST_SUITE(FakeMediaRouterTestCommon);

      ZINC_REGISTER_TEST(testBuffering);
      ZINC_REGISTER_TEST(testStartStopPlay);
      ZINC_REGISTER_TEST(testNotifyOnSignalLoss);
      ZINC_REGISTER_TEST(testAudioDescriptionTrack);
      ZINC_REGISTER_TEST(testSubtitlesTrack);
      ZINC_REGISTER_TEST(testVideoWindow);
      ZINC_REGISTER_TEST(testSeekPosition);
      ZINC_REGISTER_TEST(testDVBWithBuffering);
      ZINC_REGISTER_TEST(testExceptions);


    ZINC_REGISTER_COMMON_TEST_SUITE_CLOSE();

protected:
    boost::shared_ptr<MediaRouterSync> router;
    boost::shared_ptr<MediaRouterFactorySync> mrf;

};    /* class FakeMediaRouterTestCommon */

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_FAKE_FAKEMEDIAROUTERTESTCOMMON_H_ */
