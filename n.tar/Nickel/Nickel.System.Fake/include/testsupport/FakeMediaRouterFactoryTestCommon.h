/*
 * FakeMediaRouterFactoryTestCommon.h
 *
 *  Created on: 23 Jun, 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKEMEDIAROUTERFACTORYTESTCOMMON_H_
#define NICKEL_SYSTEM_FAKE_FAKEMEDIAROUTERFACTORYTESTCOMMON_H_

#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/zinc-common.h>
#include <zinc-common/testsupport/CppUnit.h>

#include <zinc-common/testsupport/PluginTestCommonBase.h>
#include <zinc-common/testsupport/PluginTestMacros.h>

#include <boost/shared_ptr.hpp>

NS_NICKEL_SYSTEM_OPEN

class FakeMediaRouterFactoryTestCommon
	:	public NS_ZINC::PluginTestCommonBase< NS_NICKEL_SYSTEM::SystemFactory >
{
public: // Members required by TestCommonBase
	void commonSetup();
	void commonTearDown();

public:
	// tests based upon data from the Fake implementation
	void testMethodsAndEvents();

	ZINC_REGISTER_COMMON_TEST_SUITE(FakeMediaRouterFactoryTestCommon);

	ZINC_REGISTER_TEST(testMethodsAndEvents);

	ZINC_REGISTER_COMMON_TEST_SUITE_CLOSE();

protected:
    SystemFactory * factory;
    boost::shared_ptr<MediaRouterFactorySync> mrf;
};	/* class FakeMediaRouterFactoryTestCommon */

NS_NICKEL_SYSTEM_CLOSE


#endif /* NICKEL_SYSTEM_FAKE_FAKEMEDIAROUTERFACTORYTESTCOMMON_H_ */
