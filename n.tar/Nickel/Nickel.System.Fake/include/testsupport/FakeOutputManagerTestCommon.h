/*
 * FakeOutputManagerTestCommon.h
 *
 *  Created on: Mar 2, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGERTESTCOMMON_H_
#define NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGERTESTCOMMON_H_

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/MockOutputManagerEventListener.h>

#include <zinc-common/zinc-common.h>
#include <zinc-common/testsupport/CppUnit.h>

#include <zinc-common/testsupport/PluginTestCommonBase.h>
#include <zinc-common/testsupport/PluginTestMacros.h>

#include <boost/shared_ptr.hpp>

#include <string>
#include <list>

NS_NICKEL_SYSTEM_OPEN

class FakeOutputManagerTestCommon
	:	public NS_ZINC::PluginTestCommonBase< NS_NICKEL_SYSTEM::SystemFactory >
{

public: // Members required by TestCommonBase
	void commonSetup();
	void commonTearDown();

public:
	// tests based upon data from the Fake implementation
	void testVolume();
	void testGetPrimaryDisplay();
    void testAudioOutputs();

	ZINC_REGISTER_COMMON_TEST_SUITE(FakeOutputManagerTestCommon);

	ZINC_REGISTER_TEST(testVolume);
	ZINC_REGISTER_TEST(testGetPrimaryDisplay);
	ZINC_REGISTER_TEST(testAudioOutputs);

	ZINC_REGISTER_COMMON_TEST_SUITE_CLOSE();

protected:
	boost::shared_ptr<OutputManagerSync> outputManager;
	boost::shared_ptr<MockOutputManagerEventListener> listener;

};	/* class FakeOutputManagerTestCommon */

NS_NICKEL_SYSTEM_CLOSE


#endif /* NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGERTESTCOMMON_H_ */
