/*
 * FakeServiceListBuilderTest.cpp
 *
 *  Created on: 15 Jun, 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_SERVICELISTBUILDER_TEST
#define NICKEL_SYSTEM_FAKE_SERVICELISTBUILDER_TEST

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include "../include/testsupport/FakeServiceListBuilderTestCommon.h"

#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>


NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL FakeServiceListBuilderTest : NS_ZINC::UnitTestSandbox, public NS_ZINC::PluginTestFixture<FakeServiceListBuilderTestCommon> {
public:
	CPPUNIT_TEST_SUITE(FakeServiceListBuilderTest);

	ZINC_REGISTER_COMMON_TESTS(FakeServiceListBuilderTestCommon);

	CPPUNIT_TEST_SUITE_END();

};

CPPUNIT_TEST_SUITE_REGISTRATION(FakeServiceListBuilderTest);

NS_NICKEL_SYSTEM_CLOSE

ZINC_CONFIGURE_TEST_FIXTURE_FACTORY_PLUGIN(NS_NICKEL_SYSTEM::FakeServiceListBuilderTestCommon,
		                                   "libNickelSystemFake.so",
		                                   "createFakeSystemFactory");

#endif /* NICKEL_SYSTEM_FAKE_SERVICELISTBUILDER_TEST */
