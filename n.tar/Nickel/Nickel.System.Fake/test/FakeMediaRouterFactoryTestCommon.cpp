/* Copyright (C) 2010 British Broadcasting Corporation */

#ifndef NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_TEST_COMMON
#define NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_TEST_COMMON

#include "../include/testsupport/FakeMediaRouterFactoryTestCommon.h"

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-common/zinc-common.h>

#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/AsynchronousEventProbe.h>

#include <nickel-system-api/MediaRouterFactoryConvertToSync.h>

using namespace NS_ZINC;
using namespace NS_NICKEL_SYSTEM;

NS_NICKEL_SYSTEM_OPEN

void FakeMediaRouterFactoryTestCommon::commonSetup() {
    mrf = convertToSync( factory->createMediaRouterFactory() );
}

void FakeMediaRouterFactoryTestCommon::commonTearDown() {
    mrf.reset();
}

void FakeMediaRouterFactoryTestCommon::testMethodsAndEvents() {

    // create
    boost::shared_ptr<MediaRouter> mr = mrf->createMediaRouter();
    CPPUNIT_ASSERT_MESSAGE("No router",mr);

    // default
    mr = factory->createDefaultMediaRouter();
    CPPUNIT_ASSERT_MESSAGE("No default router",mr);

}

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_TEST_COMMON */
