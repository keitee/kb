/*
 * FakeMediaSettingsTestCommon.cpp
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */
#include <nickel-common/NickelLogger.h>

#include <nickel-common/nickel-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/testsupport/AsynchronousEventProbe.h>

#include "../include/testsupport/FakeMediaSettingsTestCommon.h"

using namespace NS_ZINC;

NS_NICKEL_SYSTEM_OPEN

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FakeMediaSettingsTestCommon::TestListener

FakeMediaSettingsTestCommon::TestListener::TestListener()
	:	m_eventCount(0)
	,	m_lastCount(0)
{
	NICKEL_FUNC_TRACE;
}
FakeMediaSettingsTestCommon::TestListener::~TestListener() {
	NICKEL_FUNC_TRACE;
}

void FakeMediaSettingsTestCommon::TestListener::MediaSettingsChange() {
	NICKEL_FUNC_TRACE;

	boost::recursive_mutex::scoped_lock lock(m_mutex);
	++m_eventCount;

	NICKEL_DEBUG("m_eventCount == " << m_eventCount);
}

bool FakeMediaSettingsTestCommon::TestListener::eventOccured() {
	NICKEL_FUNC_TRACE;

	boost::recursive_mutex::scoped_lock lock(m_mutex);
	return m_eventCount != m_lastCount;
}

int FakeMediaSettingsTestCommon::TestListener::eventCount() {
	return m_eventCount;
}

void FakeMediaSettingsTestCommon::TestListener::resetEventOccured() {
	NICKEL_FUNC_TRACE;

	m_lastCount = m_eventCount;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FakeMediaSettingsTestCommon

void FakeMediaSettingsTestCommon::commonSetup() {
	NICKEL_FUNC_TRACE;

	mediaSettings = factory->createMediaSettings();
	listener.reset(new TestListener());
	mediaSettings->addListener(listener);

	timeout = 5000;
}

void FakeMediaSettingsTestCommon::commonTearDown() {
	NICKEL_FUNC_TRACE;

	mediaSettings->removeListener(listener);
	mediaSettings.reset();
	listener.reset();
}

void FakeMediaSettingsTestCommon::testAudioDescriptionsEnabled() {
	NICKEL_FUNC_TRACE;

	listener->resetEventOccured();

	CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

	int changes = 0;

	CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Audio Description Enabled not as expected", mediaSettings->getADEnabled().get(), false);
	mediaSettings->setADEnabled(true).get();
	++changes;

	AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
	CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe1.retrieveArtifact(), changes);
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getADEnabled().get(), true);
	listener->resetEventOccured();

	mediaSettings->setADEnabled(false).get();
	++changes;

	AsynchronousEventProbe<int, TestListener> probe2(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
	CPPUNIT_ASSERT_MESSAGE("No event received", probe2.waitForEvent());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe2.retrieveArtifact(), changes);
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getADEnabled().get(), false);
	listener->resetEventOccured();
}

void FakeMediaSettingsTestCommon::testSubtitlesEnabled() {
	NICKEL_FUNC_TRACE;

	listener->resetEventOccured();

	CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

	int changes = 0;

	CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Subtitles Enabled not as expected", mediaSettings->getSubtitlesEnabled().get(), false);
	mediaSettings->setSubtitlesEnabled(true).get();
	++changes;

	AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
	CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe1.retrieveArtifact(), changes);
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getSubtitlesEnabled().get(), true);
	listener->resetEventOccured();

	mediaSettings->setSubtitlesEnabled(false).get();
	++changes;

	AsynchronousEventProbe<int, TestListener> probe2(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
	CPPUNIT_ASSERT_MESSAGE("No event received", probe2.waitForEvent());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe2.retrieveArtifact(), changes);
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getSubtitlesEnabled().get(), false);
	listener->resetEventOccured();
}

void FakeMediaSettingsTestCommon::testPreferredAudioLanguage() {
	NICKEL_FUNC_TRACE;

	listener->resetEventOccured();

	CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

	int changes = 0;
    std::string value = "xxx";

	CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Audio Language not as expected", std::string(), mediaSettings->getPreferredAudioLanguage().get());
	mediaSettings->setPreferredAudioLanguage(value).get();
	++changes;

	AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
	CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", changes, probe1.retrieveArtifact());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Audio Language not as expected", value, mediaSettings->getPreferredAudioLanguage().get());
	listener->resetEventOccured();

}

void FakeMediaSettingsTestCommon::testPreferredSubtitleLanguage() {
	NICKEL_FUNC_TRACE;

	listener->resetEventOccured();

	CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

	int changes = 0;
    std::string value = "xxx";

	CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Subtitle Language not as expected", std::string(), mediaSettings->getPreferredSubtitleLanguage().get());
	mediaSettings->setPreferredSubtitleLanguage(value).get();
	++changes;

	AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
	CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", changes, probe1.retrieveArtifact());
	CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitle Language not as expected", value, mediaSettings->getPreferredSubtitleLanguage().get());
	listener->resetEventOccured();

}

NS_NICKEL_SYSTEM_CLOSE
