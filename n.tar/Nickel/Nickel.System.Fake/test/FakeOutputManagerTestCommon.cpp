/*
 * FakeOutputManagerTestCommon.cpp
 *
 *  Created on: Mar 2, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#include "../include/testsupport/FakeOutputManagerTestCommon.h"

#include <nickel-common/NickelLogger.h>
#include <nickel-common/nickel-common.h>
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/OutputManagerConvertToSync.h>
#include <zinc-common/testsupport/AsynchronousEventProbe.h>
#include <zinc-common/testsupport/assert_within_timeout.h>

#include <boost/bind.hpp>

using namespace NS_ZINC;
using ::testing::InSequence;
using ::testing::Invoke;

NS_NICKEL_SYSTEM_OPEN

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FakeOutputManagerTestCommon

void FakeOutputManagerTestCommon::commonSetup() {
	NICKEL_FUNC_TRACE;

	outputManager = convertToSync(factory->createOutputManager());
	listener.reset(new MockOutputManagerEventListener());
	outputManager->addListener(listener);
}

void FakeOutputManagerTestCommon::commonTearDown() {
	NICKEL_FUNC_TRACE;

	outputManager->removeListener(listener);
	CPPUNIT_ASSERT(testing::Mock::VerifyAndClearExpectations(listener.get()));
	outputManager.reset();
	listener.reset();
}

static void increment(size_t& counter) {
	++counter;
}

void FakeOutputManagerTestCommon::testVolume()
{
	NICKEL_FUNC_TRACE;

	uint32_t startVolume = 42;

	InSequence seq;

	size_t count(0);

	EXPECT_CALL(*listener, VolumeChange(startVolume, false))
		.WillOnce(Invoke(boost::bind(&increment, boost::ref(count))));

	EXPECT_CALL(*listener, VolumeChange(++startVolume, false))
		.WillOnce(Invoke(boost::bind(&increment, boost::ref(count))));

	EXPECT_CALL(*listener, VolumeChange(--startVolume, false))
		.WillOnce(Invoke(boost::bind(&increment, boost::ref(count))));

	EXPECT_CALL(*listener, VolumeChange(startVolume, true))
		.WillOnce(Invoke(boost::bind(&increment, boost::ref(count))));

	EXPECT_CALL(*listener, VolumeChange(startVolume, false))
		.WillOnce(Invoke(boost::bind(&increment, boost::ref(count))));

	outputManager->setVolume(startVolume);
	outputManager->incVolume();
	outputManager->decVolume();
	outputManager->muteVolume();
	outputManager->unmuteVolume();

	ZINC_ASSERT_WITHIN_TIMEOUT((count == 5), 10000);
}

void FakeOutputManagerTestCommon::testAudioOutputs()
{
	NICKEL_FUNC_TRACE;
    std::map<uint32_t, AudioOutputType::Enum> outputs(outputManager->getAudioOutputs());

    CPPUNIT_ASSERT_EQUAL(size_t(3), outputs.size());

    // first audio output
    {
        CPPUNIT_ASSERT_EQUAL(outputs[0], AudioOutputType::analogue_scart);
        std::vector<AudioFormat::Enum> formats(outputManager->getAudioFormatOptions(0));
        CPPUNIT_ASSERT_EQUAL(formats.size(), size_t(1));
        CPPUNIT_ASSERT_EQUAL(formats[0], AudioFormat::analogue);
    };

    // second audio output
    {
        CPPUNIT_ASSERT_EQUAL(outputs[1], AudioOutputType::hdmi);
    };

    // third audio output
    {
        CPPUNIT_ASSERT_EQUAL(outputs[4], AudioOutputType::spdif);
    };

    // invalid audio output
    CPPUNIT_ASSERT_THROW(outputManager->getAudioFormatOptions(2), InvalidOutput);
    // output not supporting delay
    CPPUNIT_ASSERT_THROW(outputManager->setAudioDelay(0, 10), NotSupported);
    // invalid delay value
    CPPUNIT_ASSERT_THROW(outputManager->setAudioDelay(1, 251), OutOfBounds);

    InSequence seq;

    size_t count(0);

    EXPECT_CALL(*listener, AudioPreferenceChange(1))
    	.Times(2)
    	.WillRepeatedly(Invoke(boost::bind(&increment, boost::ref(count))));

    outputManager->setAudioDelay(1, 40);
    outputManager->setAudioFormatPreference(1, AudioFormat::pcm_2ch);

    ZINC_ASSERT_WITHIN_TIMEOUT((count == 2), 10000);

    // those calls should not generate AudioPreferenceChange
    outputManager->setAudioFormatPreference(1, AudioFormat::analogue);
    outputManager->setAudioFormatPreference(1, AudioFormat::ac3);

}

void FakeOutputManagerTestCommon::testGetPrimaryDisplay() {

	NICKEL_FUNC_TRACE;

	CPPUNIT_ASSERT_EQUAL(DisplayType::hdmi, outputManager->getPrimaryDisplayPreference());
}

NS_NICKEL_SYSTEM_CLOSE
