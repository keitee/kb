/*
 * FakeMediaRouterTestCommon.cpp
 *
 *  Created on: Feb 26, 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#include "../src/FakeMediaRouterFactory.h"
#include "../src/FakeMediaRouter.h"
#include "../include/testsupport/FakeMediaRouterTestCommon.h"
#include <dbus-c++-1/include/dbus-c++/error.h>

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-common/nickel-common.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/MediaRouterConvertToSync.h>
#include <nickel-system-api/MediaRouterFactoryConvertToSync.h>

#include <zinc-common/zinc-common.h>
#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/AsynchronousEventProbe.h>
#include <cppunit/extensions/HelperMacros.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <utility>
#include <algorithm>
#include <iterator>

using namespace std;
using namespace boost;
using namespace NS_ZINC;
using namespace NS_NICKEL_SYSTEM;

namespace {

int32_t const timeout = 10000;

}

NS_NICKEL_SYSTEM_OPEN

enum EventType {
    ET_BufferStatusEvent,
    ET_DrmEvent,
    ET_PositionChangeEvent,
    ET_SourceEvent,
    ET_SpeedChangeEvent,
    ET_StatusEvent
};

struct Result {
    EventType type;
    int32_t value;
    Position position;
};

class MREventListener : public MediaRouterEventListener {
public:
    MREventListener() : nReqEvnts(1) {}

    virtual void BufferStatusEvent(const BufferStatusEventValue::Enum event) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_BufferStatusEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void DrmEvent(const DrmEventValue::Enum event,const std::string& drmMediaIdentifier,const std::string& rightsIssuerUrl) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_DrmEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void PositionChangeEvent(const Position& position) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_PositionChangeEvent;
        result->position = position;
        results.push_back(result);
    }
    virtual void SourceEvent(const SourceEventValue::Enum event, const SetSourceReason::Enum reason) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_SourceEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void SpeedChangeEvent() {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_SpeedChangeEvent;
        result->value = 0;
        results.push_back(result);
    }
    virtual void StatusEvent(const StatusEventValue::Enum event) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_StatusEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void ErrorEvent(const ErrorEventValue::Enum error,const ErrorEventContext::Enum context,const std::string& info) {
        NICKEL_FUNC_DEBUG;
    }


    void lock() { theMutex.lock(); }
    void unlock() { theMutex.unlock(); }
    bool wasResultReceived() { return (results.size() >= nReqEvnts); }
    void setNumberEventsRequired(int32_t i) { nReqEvnts = i; }
    void resetResult() { results.clear(); nReqEvnts = 1; }
    std::vector<boost::shared_ptr<Result> >& getResult() { return results; }
private:
    boost::mutex theMutex;
    std::vector<boost::shared_ptr<Result> > results;
    int32_t nReqEvnts;
};

void FakeMediaRouterTestCommon::commonSetup() {
    NICKEL_FUNC_TRACE;

    mrf = convertToSync( factory->createMediaRouterFactory() );
}

void FakeMediaRouterTestCommon::commonTearDown() {
    NICKEL_FUNC_TRACE;

    router.reset();
    mrf.reset();
}

void FakeMediaRouterTestCommon::testStartStopPlay() {
    NICKEL_FUNC_DEBUG;

    router = convertToSync( mrf->createMediaRouter() );

    boost::shared_ptr<MREventListener> lListener(new MREventListener());
    router->addListener(lListener);

    std::string expectedSink = "klaff";
    router->setSink(expectedSink);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected sink",expectedSink, router->getSink());

    string expectedSource = "http://www.bbc.co.uk/radio79";
    router->setSource(expectedSource, SetSourceReason::unspecified);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected source",expectedSource, router->getSource());

    // receive started event
    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> setSourceProbe(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    lListener->setNumberEventsRequired(2);
    // Wait for EventResult
    CPPUNIT_ASSERT(setSourceProbe.waitForEvent());

    // Verify result
    std::vector<boost::shared_ptr<Result> >& results = setSourceProbe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(SourceEventValue::change_initiated),results.at(0)->value);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(1)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(SourceEventValue::change_complete),results.at(1)->value);
    lListener->resetResult();

    double expectedPlaySpeed = 2.250;
    router->setPlaySpeed(expectedPlaySpeed);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",expectedPlaySpeed, router->getPlaySpeed());

    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> playSpeedProbe(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(playSpeedProbe.waitForEvent());

    // Verify result
    results = playSpeedProbe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
    lListener->resetResult();

    // Set it back to 1 for the test
    expectedPlaySpeed = 1.0;
    router->setPlaySpeed(expectedPlaySpeed);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",expectedPlaySpeed, router->getPlaySpeed());

    // Wait for EventResult
    CPPUNIT_ASSERT(playSpeedProbe.waitForEvent());

    // Verify result
    results = playSpeedProbe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
    lListener->resetResult();

    // Test playing - note buffering and playing are independent
    router->start();

    // receive started event
    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe1(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe1.waitForEvent());

    // Verify result
    results = probe1.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_StatusEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(StatusEventValue::started),results.at(0)->value);
    lListener->resetResult();

    // receive position change events
    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe2(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe2.waitForEvent());

    // Verify result
    results = probe2.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,results.at(0)->position.current);
    lListener->resetResult();

    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe3(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe3.waitForEvent());

    // Verify result
    results = probe3.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",2000,results.at(0)->position.current);
    lListener->resetResult();

    // receive complete event
    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe4(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    lListener->setNumberEventsRequired(2);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe4.waitForEvent());

    // Verify result
    results = probe4.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_StatusEvent,results.at(1)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(StatusEventValue::complete),results.at(1)->value);
    lListener->resetResult();

    router->removeListener(lListener);
}

void FakeMediaRouterTestCommon::testNotifyOnSignalLoss() {
    NICKEL_FUNC_TRACE;

    map<string,string> info;
    map<string,string>::const_iterator infoIt;

    router = convertToSync(mrf->createMediaRouter());

    boost::shared_ptr<MREventListener> lListener(new MREventListener());
    router->addListener(lListener);

    // write trigger file
    std::string sigLossFile = NS_ZINC::getMutableDataPath() + "send_signal_strength_signal";
    NICKEL_DEBUG("sigLossFile "<<sigLossFile);
	NICKEL_DEBUG("Writing signal strength file " << sigLossFile);
    std::ofstream outFile(sigLossFile.c_str(),std::ios::ate);
    outFile<<"0 1 1\n";
    outFile.close();

    // check get 2 signals one good, one bad
    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe1(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe1.waitForEvent());

    // Verify result
    std::vector<boost::shared_ptr<Result> >& results = probe1.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong result received in event", 
            int32_t(SourceEventValue::source_information_change),results.at(0)->value);
    lListener->resetResult();

    info = router->getSourceInformation();
    infoIt = info.find("QUALITY");
    CPPUNIT_ASSERT_MESSAGE("No \"QUALITY\" property received", (infoIt != info.end()));
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong \"Quality\"", string("0"), infoIt->second);

    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe2(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe2.waitForEvent());

    // Verify result
    results = probe2.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong result received in event", int32_t(SourceEventValue::source_information_change),results.at(0)->value);
    lListener->resetResult();

    info = router->getSourceInformation();
    infoIt = info.find("QUALITY");
    CPPUNIT_ASSERT_MESSAGE("No \"QUALITY\" property received", (infoIt != info.end()));
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong \"QUALITY\"", string("100"), infoIt->second);

    infoIt = info.find("STRENGTH");
    CPPUNIT_ASSERT_MESSAGE("No STRENGTH property received", (infoIt != info.end()));
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong STRENGTH", string("100"), infoIt->second);

    router->removeListener(lListener);
}

void FakeMediaRouterTestCommon::testBuffering() {
    NICKEL_FUNC_TRACE;

    router = convertToSync(mrf->createMediaRouter());

    boost::shared_ptr<MREventListener> lListener(new MREventListener());
    router->addListener(lListener);

    // startBuffering
    router->startBuffering();

    // buffering started event
    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> bufferProbe1(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(bufferProbe1.waitForEvent());

    // Verify result
    std::vector<boost::shared_ptr<Result> >& results = bufferProbe1.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_BufferStatusEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(BufferStatusEventValue::buffering_started),results.at(0)->value);
    lListener->resetResult();

    // getBufferStatus()
    // when got enough start - but buffering and starting are independent
    timespec tv = {1,100000000};
    nanosleep(&tv,NULL);
    BufferStatus buffer = router->getBufferStatus();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong bufferedBytes",int64_t(100000),buffer.bufferedBytes);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong totalBytesRemaining",int64_t(100000),buffer.totalBytesRemaining);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong totalStreamBytes",int64_t(200000),buffer.totalStreamBytes);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong arrivalBytesPerSecond",int32_t(100000),buffer.arrivalBytesPerSecond);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong streamBytesPerSecond",int32_t(10000),buffer.streamBytesPerSecond);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong bufferedMilliseconds",int32_t(1000),buffer.bufferedMilliseconds);

    // receive buffering complete event
    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> bufferProbe2(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    // Wait for EventResult
    CPPUNIT_ASSERT(bufferProbe2.waitForEvent());

    // Verify result
    results = bufferProbe2.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_BufferStatusEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(BufferStatusEventValue::buffering_complete),results.at(0)->value);
    lListener->resetResult();

    router->removeListener(lListener);
}

void FakeMediaRouterTestCommon::testVideoWindow() {
    NICKEL_FUNC_TRACE;

    router = convertToSync(mrf->createMediaRouter());

    VideoWindowDescriptor vw = VideoWindowDescriptor();
    vw.sourceX = 2;
    vw.sourceY = 3;
    vw.sourceWidth = 4;
    vw.sourceHeight = 5;
    vw.destinationX = 6;
    vw.destinationY = 7;
    vw.destinationWidth = 8;
    vw.destinationHeight = 9;

    router->setVideoWindow(vw);

    VideoWindowDescriptor vwRet = router->getVideoWindow();

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong sourceX",vw.sourceX,vwRet.sourceX);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong sourceY",vw.sourceY,vwRet.sourceY);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong sourceWidth",vw.sourceWidth,vwRet.sourceWidth);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong sourceHeight",vw.sourceHeight,vwRet.sourceHeight);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong destinationX",vw.destinationX,vwRet.destinationX);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong destinationY",vw.destinationY,vwRet.destinationY);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong destinationWidth",vw.destinationWidth,vwRet.destinationWidth);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong destinationHeight",vw.destinationHeight,vwRet.destinationHeight);
}

void FakeMediaRouterTestCommon::testAudioDescriptionTrack() {
    NICKEL_FUNC_TRACE;

    router = convertToSync(mrf->createMediaRouter());

    int32_t const tag = 1;
    router->setAudioTrack(tag);
    Track track = router->getAudioTrack();

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong tag", tag, track.tag);
}

void FakeMediaRouterTestCommon::testSubtitlesTrack() {
    NICKEL_FUNC_TRACE;

    router = convertToSync(mrf->createMediaRouter());

    int32_t const tag = 2;
    router->setAudioTrack(tag);
    Track track = router->getAudioTrack();

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong tag", tag, track.tag);
}

void FakeMediaRouterTestCommon::testSeekPosition() {
    NICKEL_FUNC_TRACE;

    router = convertToSync(mrf->createMediaRouter());

    Position position = router->getPosition();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),    position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(0),    position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position.end);

    router->seekPosition(SeekReference::start, 1000, SeekMode::prioritise_accuracy);

    position = router->getPosition();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),    position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(1000), position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position.end);

    router->seekPosition(SeekReference::current, 1000, SeekMode::prioritise_accuracy);

    position = router->getPosition();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),    position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(2000), position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position.end);

    router->seekPosition(SeekReference::end, -2000, SeekMode::prioritise_accuracy);

    position = router->getPosition();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),    position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(1000), position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position.end);
}

void FakeMediaRouterTestCommon::testDVBWithBuffering() {
    NICKEL_FUNC_DEBUG;

    router = convertToSync(mrf->createMediaRouter());

    boost::shared_ptr<MREventListener> lListener(new MREventListener());
    router->addListener(lListener);

    // setSink
    std::string expectedSink = "klaff";
    router->setSink(expectedSink);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected sink",expectedSink, router->getSink());

    // setSource
    string expectedSource = "dvb://fish";
    router->setSource(expectedSource, SetSourceReason::unspecified);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected source",expectedSource, router->getSource());

    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe(
            lListener, &MREventListener::wasResultReceived,
            &MREventListener::getResult,
            timeout);
    lListener->setNumberEventsRequired(2);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    std::vector<boost::shared_ptr<Result> >& results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(SourceEventValue::change_initiated),results.at(0)->value);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(1)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(SourceEventValue::change_complete),results.at(1)->value);
    lListener->resetResult();

    Position position = router->getPosition();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position start",0,position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position current",0,position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position end",0,position.end);

    // start
    router->start();

    // receive started event
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_StatusEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(StatusEventValue::started),results.at(0)->value);
    lListener->resetResult();

    // check position
    // Wait for EventResult
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",0,results.at(0)->position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,results.at(0)->position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,results.at(0)->position.end);

    position = router->getPosition();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",0,position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,position.end);

    lListener->resetResult();

    // rewind to start
    router->setPlaySpeed(-2);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",double(-2), router->getPlaySpeed());

    // Wait for EventResult
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
    lListener->resetResult();


    // pause
    router->setPlaySpeed(0);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",double(0), router->getPlaySpeed());

    // Wait for EventResult
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
    lListener->resetResult();

    // check position
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",0,results.at(0)->position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,results.at(0)->position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",2000,results.at(0)->position.end);
    lListener->resetResult();

    // XXX wait for buffer to fill and see start moving

    // ff to end of buffer
    router->setPlaySpeed(2);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",double(2), router->getPlaySpeed());

    // Wait for EventResult
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
    lListener->resetResult();

    lListener->setNumberEventsRequired(2);
    // check position
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    results = probe.retrieveArtifactNoWait();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(1)->type);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",0,results.at(1)->position.start);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",3000,results.at(1)->position.current);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",3000,results.at(1)->position.end);
    lListener->resetResult();



    router->removeListener(lListener);
}

void FakeMediaRouterTestCommon::testExceptions()
{
    NICKEL_FUNC_DEBUG;

    router = convertToSync(mrf->createMediaRouter());

    CPPUNIT_ASSERT_THROW_MESSAGE(
            "Should have thrown exception", router->setSource("TestThrowIllegalReconfiguration",SetSourceReason::unspecified),
            IllegalReconfiguration);

    VideoTerminationMode::Enum m = VideoTerminationMode::Enum(100);
    CPPUNIT_ASSERT_THROW(router->setVideoTerminationMode(m), std::invalid_argument);
}

NS_NICKEL_SYSTEM_CLOSE
