/* Copyright (C) 2010 British Broadcasting Corporation */

#ifndef NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_TEST_COMMON
#define NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_TEST_COMMON

#include "../src/FakeServiceListBuilder.h"
#include "../include/testsupport/FakeServiceListBuilderTestCommon.h"

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-common/zinc-common.h>

#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/AsynchronousEventProbe.h>

#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/foreach.hpp>

#include <vector>
#include <sstream>
#include <fstream>

#include <nickel-system-api/ServiceListBuilderConvertToSync.h>

using namespace NS_ZINC;
using namespace NS_NICKEL_SYSTEM;

namespace {
const std::string controlFile("/tmp/servicelistbuilder_control.txt");
int32_t const timeout = 20000;
struct Result {
    int32_t progress;
    uint32_t channelsScanned;
    ScanningProgressStatus::Enum status;
};
}
NS_NICKEL_SYSTEM_OPEN

class SLBEventListener : public ServiceListBuilderEventListener {
public:

    SLBEventListener() : nReqEvnts(1) {}

	virtual void ScanningProgress(const int32_t progress, const ScanningProgressStatus::Enum status, const uint32_t channelsScanned, const uint32_t /*totalChannels*/,
            const std::map< uint32_t, uint32_t >& /*servicesFound*/)
    {
        NICKEL_FUNC_DEBUG;
        NICKEL_DEBUG("progress "<<progress<<" channelsScanned "<<channelsScanned<<" status "<<status);
        boost::shared_ptr<Result> result(new Result());
        result->channelsScanned = channelsScanned;
        result->progress = progress;
        result->status = status;
        results.push_back(result);
        NICKEL_DEBUG("nReqEvnts "<<nReqEvnts<<" results.size() "<<results.size());
    }

    bool wasResultReceived() { return (results.size() >= nReqEvnts); }
    void setNumberEventsRequired(int32_t i) { nReqEvnts = i; }
    void resetResult() { results.clear(); nReqEvnts = 1; }
    std::vector<boost::shared_ptr<Result> >& getResult() { return results; }
private:
    std::vector<boost::shared_ptr<Result> > results;
    int32_t nReqEvnts;
};

void FakeServiceListBuilderTestCommon::commonSetup() {
    NICKEL_FUNC_DEBUG;
    ::unlink(controlFile.c_str());
    servicelistbuilder = convertToSync(factory->createServiceListBuilder());
}

void FakeServiceListBuilderTestCommon::commonTearDown() {
    NICKEL_FUNC_DEBUG;
    servicelistbuilder.reset();
    ::unlink(controlFile.c_str());
}

void FakeServiceListBuilderTestCommon::testScanServiceSignals() {
    NICKEL_FUNC_DEBUG;

    boost::shared_ptr<SLBEventListener> listener = boost::shared_ptr<SLBEventListener>(new SLBEventListener);
    servicelistbuilder->addListener(listener);

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Should not be any signals yet",size_t(0),listener->getResult().size());

    servicelistbuilder->serviceScan();

    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, SLBEventListener> probe(
            listener, &SLBEventListener::wasResultReceived,
            &SLBEventListener::getResult,
            timeout);
    listener->setNumberEventsRequired(49);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    std::vector<boost::shared_ptr<Result> >& results = probe.retrieveArtifactNoWait();

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(49),results.size());
    // check 0,99 and 100 index
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong progress type",0,results.at(0)->progress);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong channelsScanned type",uint32_t(0),results.at(0)->channelsScanned);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong status type",ScanningProgressStatus::in_progress,results.at(0)->status);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong progress type",100,results.at(48)->progress);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong channelsScanned type",uint32_t(48),results.at(48)->channelsScanned);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong status type",ScanningProgressStatus::success,results.at(48)->status);

    listener->resetResult();

    servicelistbuilder->removeListener(listener);

    NICKEL_DEBUG("Normal test passed");
}

void FakeServiceListBuilderTestCommon::testAbortScan() {
    NICKEL_FUNC_DEBUG;
    boost::shared_ptr<SLBEventListener> listener = boost::shared_ptr<SLBEventListener>(new SLBEventListener);
    servicelistbuilder->addListener(listener);

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Should not be any signals yet",size_t(0),listener->getResult().size());

    servicelistbuilder->serviceScan();

    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, SLBEventListener> probe(
            listener, &SLBEventListener::wasResultReceived,
            &SLBEventListener::getResult,
            timeout);
    int32_t numReqEvents = 5;
    listener->setNumberEventsRequired(numReqEvents);
    CPPUNIT_ASSERT(probe.waitForEvent());

    servicelistbuilder->stopServiceScan();

    numReqEvents += 2;
    listener->setNumberEventsRequired(numReqEvents);
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    std::vector<boost::shared_ptr<Result> >& results = probe.retrieveArtifactNoWait();

    while(results.at((results.size()-1))->status != ScanningProgressStatus::aborted)
    {
        // Wait a bit longer for the final event
        numReqEvents = results.size() + 1;
        listener->setNumberEventsRequired(numReqEvents);
        CPPUNIT_ASSERT(probe.waitForEvent());
        results = probe.retrieveArtifactNoWait();
    }

    uint32_t const buildingIdx = results.size() - 2;
    uint32_t const abortedIdx = results.size() - 1;

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong channelsScanned type",buildingIdx,results.at(buildingIdx)->channelsScanned);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong status type",ScanningProgressStatus::in_progress,results.at(buildingIdx)->status);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong channelsScanned type",abortedIdx,results.at(abortedIdx)->channelsScanned);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong status type",ScanningProgressStatus::aborted,results.at(abortedIdx)->status);

    listener->resetResult();

    servicelistbuilder->removeListener(listener);

    NICKEL_DEBUG("Abort test passed");
}

void FakeServiceListBuilderTestCommon::testFailedScan() {
    NICKEL_FUNC_DEBUG;
    std::ofstream contFile(controlFile.c_str());
    contFile<<std::endl;
    contFile.close();

    boost::shared_ptr<SLBEventListener> listener = boost::shared_ptr<SLBEventListener>(new SLBEventListener);
    servicelistbuilder->addListener(listener);

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Should not be any signals yet",size_t(0),listener->getResult().size());

    servicelistbuilder->serviceScan();

    NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, SLBEventListener> probe(
            listener, &SLBEventListener::wasResultReceived,
            &SLBEventListener::getResult,
            timeout);
    listener->setNumberEventsRequired(3);
    // Wait for EventResult
    CPPUNIT_ASSERT(probe.waitForEvent());

    // Verify result
    std::vector<boost::shared_ptr<Result> >& results = probe.retrieveArtifactNoWait();

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(3),results.size());
    // check 0,99 and 100 index
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong channelsScanned type",uint32_t(1),results.at(1)->channelsScanned);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong status type",ScanningProgressStatus::in_progress,results.at(1)->status);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong channelsScanned type",uint32_t(2),results.at(2)->channelsScanned);
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong status type",ScanningProgressStatus::failure,results.at(2)->status);

    listener->resetResult();

    servicelistbuilder->removeListener(listener);

    NICKEL_DEBUG("Fail test passed");

}


NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_TEST_COMMON */
