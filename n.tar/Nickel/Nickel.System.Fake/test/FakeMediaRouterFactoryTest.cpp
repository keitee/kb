/*
 * FakeMediaRouterFactoryTest.cpp
 *
 *  Created on: 23 Jun, 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_MEDIAROUTERFACTORY_TEST
#define NICKEL_SYSTEM_FAKE_MEDIAROUTERFACTORY_TEST


#include "../include/testsupport/FakeMediaRouterFactoryTestCommon.h"

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>


NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL FakeMediaRouterFactoryTest : NS_ZINC::UnitTestSandbox, public NS_ZINC::PluginTestFixture<FakeMediaRouterFactoryTestCommon> {
public:
	CPPUNIT_TEST_SUITE(FakeMediaRouterFactoryTest);

	ZINC_REGISTER_COMMON_TESTS(FakeMediaRouterFactoryTestCommon);

	CPPUNIT_TEST_SUITE_END();

};

CPPUNIT_TEST_SUITE_REGISTRATION(FakeMediaRouterFactoryTest);

NS_NICKEL_SYSTEM_CLOSE

ZINC_CONFIGURE_TEST_FIXTURE_FACTORY_PLUGIN(NS_NICKEL_SYSTEM::FakeMediaRouterFactoryTestCommon,
		                                   "libNickelSystemFake.so",
		                                   "createFakeSystemFactory");

#endif /* NICKEL_SYSTEM_FAKE_MEDIAROUTERFACTORY_TEST */
