/* Copyright (C) 2009 British Broadcasting Corporation */


#ifndef NICKEL_SYSTEM_FAKE_MEDIA_ROUTER_TEST
#define NICKEL_SYSTEM_FAKE_MEDIA_ROUTER_TEST
#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include "../include/testsupport/FakeMediaRouterTestCommon.h"

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>


NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL FakeMediaRouterTest : NS_ZINC::UnitTestSandbox, public NS_ZINC::PluginTestFixture<FakeMediaRouterTestCommon> {
public:
	void tearDown() {
		NS_ZINC::PluginTestFixture<FakeMediaRouterTestCommon>::tearDown();
		resetFilesystemSandbox();
	}

	CPPUNIT_TEST_SUITE(FakeMediaRouterTest);

	ZINC_REGISTER_COMMON_TESTS(FakeMediaRouterTestCommon);

	CPPUNIT_TEST_SUITE_END();

};

CPPUNIT_TEST_SUITE_REGISTRATION(FakeMediaRouterTest);

NS_NICKEL_SYSTEM_CLOSE

ZINC_CONFIGURE_TEST_FIXTURE_FACTORY_PLUGIN(NS_NICKEL_SYSTEM::FakeMediaRouterTestCommon,
		                                   "libNickelSystemFake.so",
		                                   "createFakeSystemFactory");

#endif /* NICKEL_SYSTEM_FAKE_MEDIA_ROUTER_TEST */
