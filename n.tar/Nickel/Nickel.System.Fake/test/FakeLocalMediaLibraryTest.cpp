/*
 * FakeLocalMediaLibraryTest.cpp
 *
 *  Created on: Mar 18, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_LOCAL_MEDIA_LIBRARY_TEST
#define NICKEL_SYSTEM_FAKE_LOCAL_MEDIA_LIBRARY_TEST
#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include "../include/testsupport/FakeLocalMediaLibraryTestCommon.h"

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>


NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL FakeLocalMediaLibraryTest : NS_ZINC::UnitTestSandbox, public NS_ZINC::PluginTestFixture<FakeLocalMediaLibraryTestCommon> {
public:
	CPPUNIT_TEST_SUITE(FakeLocalMediaLibraryTest);

	ZINC_REGISTER_COMMON_TESTS(FakeLocalMediaLibraryTestCommon);

	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(FakeLocalMediaLibraryTest);

NS_NICKEL_SYSTEM_CLOSE

ZINC_CONFIGURE_TEST_FIXTURE_FACTORY_PLUGIN(NS_NICKEL_SYSTEM::FakeLocalMediaLibraryTestCommon,
		                                   "libNickelSystemFake.so",
		                                   "createFakeSystemFactoryTemp");

#endif /* NICKEL_SYSTEM_FAKE_LOCAL_MEDIA_LIBRARY_TEST */
