/*
 * FakeLocalMediaLibrarySyncTest.cpp
 *
 *  Created on: 8 September 2011
 *      Author: morgan.henry@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */


/**
 * Test consuming of LocalMediaLibrary as a synchronous interface
 *
 * The "default" LocalMediaLibrary is typedef as LocalMediaLibraryAsync
 * We use the converter to consume it as a LocalMediaLibrarySync
 *
 */

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/LocalMediaLibrary.h>
#include <nickel-system-api/LocalMediaLibraryConvertToSync.h>

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/FactoryPluginLoader.h>

#include <boost/make_shared.hpp>


NS_NICKEL_SYSTEM_OPEN


class ZINC_LOCAL FakeLocalMediaLibrarySyncTest : public CppUnit::TestFixture, public NS_ZINC::UnitTestSandbox
{
public:
	void setUp()
	{
		SystemFactory & factory = NS_ZINC::FactoryPluginLoader<SystemFactory>::getFactoryFromFixedPlugin("libNickelSystemFake.so", "createFakeSystemFactory");
		localmedialibrary_async = factory.createLocalMediaLibrary();
		localmedialibrary_sync = convertToSync(localmedialibrary_async);
	}

	void tearDown()
	{
	}

	void testSyncBasicImplementation()
	{
		MediaStorageSpace s = localmedialibrary_sync->getStorageSpace();
		CPPUNIT_ASSERT_MESSAGE("Check we have a reasonable implementation", s.free > 0);
		CPPUNIT_ASSERT_EQUAL_MESSAGE("Check values are equivalent across Sync and Async", localmedialibrary_async->getStorageSpace().get().free, localmedialibrary_sync->getStorageSpace().free);
	}

private:
	boost::shared_ptr<LocalMediaLibraryAsync> localmedialibrary_async;
	boost::shared_ptr<LocalMediaLibrarySync> localmedialibrary_sync;
public:
	CPPUNIT_TEST_SUITE(FakeLocalMediaLibrarySyncTest);

	CPPUNIT_TEST(testSyncBasicImplementation);

	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(FakeLocalMediaLibrarySyncTest);

NS_NICKEL_SYSTEM_CLOSE
