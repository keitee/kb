/*
 * FakeLocalMediaRouterTestCommon.cpp
 *
 *  Created on: Mar 17, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */


//local
#include "../include/testsupport/FakeLocalMediaLibraryTestCommon.h"
#include "../src/FakeLocalMediaLibrary.h"

//api
#include <nickel-common/nickel-common.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/MockLocalMediaLibraryEventListener.h>
#include <zinc-common/async/SequentialFutureDispatcher.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/MultipleListenerEventDispatcher.h>

//standard
#include <boost/assign.hpp>
#include <boost/foreach.hpp>
#include <boost/make_shared.hpp>
#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <vector>

using namespace NS_ZINC;
using namespace testing;

NS_NICKEL_SYSTEM_OPEN

using std::vector;
using std::map;
using std::string;
using boost::assign::map_list_of;

struct Result
{
    MediaStorageSpace storageSpace;
    map< string, LibraryContentChangeType::Enum > changes;
};

class LMLListener : public LocalMediaLibraryEventListener
{
    public:
    LMLListener() : resultReceived(false) {}
	virtual ~LMLListener() {}
    virtual void LowStorageSpace(const MediaStorageSpace& storageSpace)
    {
        NICKEL_FUNC_DEBUG;
        result.storageSpace = storageSpace;
        resultReceived = true;
    }
    virtual void LibraryContentChange(const map< string, LibraryContentChangeType::Enum >& changes)
    {
        NICKEL_FUNC_DEBUG;
        result.changes = changes;
        resultReceived = true;
    }
    bool wasResultReceived() { return resultReceived; }
    void resetResult() { resultReceived = false; }
    const Result& getResult() { return result; }
private:
    Result result;
    bool resultReceived;

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FakeLocalMediaLibraryTestCommon

void FakeLocalMediaLibraryTestCommon::commonSetup() {
	NICKEL_FUNC_DEBUG;

	localMediaLibrary = factory->createLocalMediaLibrary();
    lmlListener.reset(new LMLListener());
    localMediaLibrary->addListener(lmlListener);
}

void FakeLocalMediaLibraryTestCommon::commonTearDown() {
	NICKEL_FUNC_DEBUG;

    localMediaLibrary->removeListener(lmlListener);
    lmlListener.reset();
	localMediaLibrary.reset();
}

void FakeLocalMediaLibraryTestCommon::testGetMediaRecords()
{
	NICKEL_FUNC_DEBUG;
	NS_ZINC::Future< vector< MediaRecord > > f = 
        localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::least_recently_acquired, 
                true, 0, 1234567890);
    vector< MediaRecord > mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(45),mrs.size());

    //dont include adult content
	f = localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::least_recently_acquired, 
                false, 0, 1234567890);
    mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(43),mrs.size());

    //filter by played
	f = localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played, 
                SortBy::least_recently_acquired, 
                true, 0, 1234567890);
    mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(6),mrs.size());

    //filter by unplayed
	f = localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::unplayed, 
                SortBy::least_recently_acquired, 
                true, 0, 1234567890);
    mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(39),mrs.size());

    //filter by played but dont include adult content
	f = localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played, 
                SortBy::least_recently_acquired, 
                false, 0, 1234567890);
    mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(4),mrs.size());
}

void FakeLocalMediaLibraryTestCommon::testGetMediaRecordsSortingByAcquisition()
{
	NICKEL_FUNC_DEBUG;

    //sort by least_recently_acquired : oldest acquisition first
	NS_ZINC::Future< vector< MediaRecord > > f = 
        localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::least_recently_acquired, 
                true, 0, 1234567890);
    vector< MediaRecord > mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(45),mrs.size());

    BOOST_FOREACH(MediaRecord mr, mrs)
    {
        NICKEL_DEBUG("****");
        NICKEL_DEBUG("mrecid : " << mr.mediaRecordIdentifier);
        NICKEL_DEBUG("acquired : " << mr.acquisitionDateTime);
        NICKEL_DEBUG("la : " << mr.lastAccessed);
    }

    vector<MediaRecord>::const_iterator prevIt, it; 
    prevIt = it = mrs.begin();
    if(it != mrs.end())
    {
        ++it;
        for(;it != mrs.end(); ++it)
        {
            CPPUNIT_ASSERT_MESSAGE("Not sorted!!",
                    prevIt->acquisitionDateTime <= it->acquisitionDateTime); 
            prevIt = it;
        }
    }

    //sort by most_recently_acquired : most recent acquisition first
	f = localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::most_recently_acquired, 
                true, 0, 1234567890);
    mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(45),mrs.size());

    BOOST_FOREACH(MediaRecord mr, mrs)
    {
        NICKEL_DEBUG("****");
        NICKEL_DEBUG("mrecid : " << mr.mediaRecordIdentifier);
        NICKEL_DEBUG("acquired : " << mr.acquisitionDateTime);
        NICKEL_DEBUG("la : " << mr.lastAccessed);
    }

    prevIt = it = mrs.begin();
    if(it != mrs.end())
    {
        ++it;
        for(;it != mrs.end(); ++it)
        {
            CPPUNIT_ASSERT_MESSAGE("Not sorted!!",
                    prevIt->acquisitionDateTime >= it->acquisitionDateTime); 
            prevIt = it;
        }
    }

}//testGetMediaRecordsSortingByAcquisition

void FakeLocalMediaLibraryTestCommon::testGetMediaRecordsSortingByLastWatched()
{

    //sort by least_recently_watched : least value of lastAccessed first 
	NS_ZINC::Future< vector< MediaRecord > > f = 
        localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::least_recently_watched, 
                true, 0, 1234567890);
    vector<MediaRecord> mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(45),mrs.size());

    BOOST_FOREACH(MediaRecord mr, mrs)
    {
        NICKEL_DEBUG("****");
        NICKEL_DEBUG("mrecid : " << mr.mediaRecordIdentifier);
        NICKEL_DEBUG("acquired : " << mr.acquisitionDateTime);
        NICKEL_DEBUG("la : " << mr.lastAccessed);
    }

    vector<MediaRecord>::const_iterator prevIt, it;
    prevIt = it = mrs.begin();
    if(it != mrs.end())
    {
        ++it;
        for(;it != mrs.end(); ++it)
        {
            CPPUNIT_ASSERT_MESSAGE("Not sorted!!",
                    prevIt->lastAccessed <= it->lastAccessed); 
            prevIt = it;
        }
    }

    //sort by most_recently_watched : highest value of lastAccessed first 
	f = localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::most_recently_watched, 
                true, 0, 1234567890);
    mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(45),mrs.size());

    BOOST_FOREACH(MediaRecord mr, mrs)
    {
        NICKEL_DEBUG("****");
        NICKEL_DEBUG("mrecid : " << mr.mediaRecordIdentifier);
        NICKEL_DEBUG("acquired : " << mr.acquisitionDateTime);
        NICKEL_DEBUG("la : " << mr.lastAccessed);
    }

    prevIt = it = mrs.begin();
    if(it != mrs.end())
    {
        ++it;
        for(;it != mrs.end(); ++it)
        {
            CPPUNIT_ASSERT_MESSAGE("Not sorted!!",
                    prevIt->lastAccessed >= it->lastAccessed); 
            prevIt = it;
        }
    }

}//testGetMediaRecordsSortingByLastWatched

void FakeLocalMediaLibraryTestCommon::testGetMediaRecordsSortingByTitle()
{

    //sort by title_a_to_z  
	NS_ZINC::Future< vector< MediaRecord > > f = 
        localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::title_a_to_z, 
                true, 0, 1234567890);
    vector<MediaRecord> mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(45),mrs.size());

    BOOST_FOREACH(MediaRecord mr, mrs)
    {
        NICKEL_DEBUG("****");
        NICKEL_DEBUG("title : " << mr.title);
        NICKEL_DEBUG("mrecid : " << mr.mediaRecordIdentifier);
    }

    vector<MediaRecord>::const_iterator prevIt,it; 
    prevIt = it = mrs.begin();
    if(it != mrs.end())
    {
        ++it;
        for(;it != mrs.end(); ++it)
        {
            CPPUNIT_ASSERT_MESSAGE("Not sorted!!",
                    prevIt->title <= it->title); 
            prevIt = it;
        }
    }

    //sort by title_z_to_a  
	f = localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::title_z_to_a, 
                true, 0, 1234567890);
    mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(45),mrs.size());

    BOOST_FOREACH(MediaRecord mr, mrs)
    {
        NICKEL_DEBUG("****");
        NICKEL_DEBUG("title : " << mr.title);
        NICKEL_DEBUG("mrecid : " << mr.mediaRecordIdentifier);
    }

    prevIt = it = mrs.begin();
    if(it != mrs.end())
    {
        ++it;
        for(;it != mrs.end(); ++it)
        {
            CPPUNIT_ASSERT_MESSAGE("Not sorted!!",
                    prevIt->title >= it->title); 
            prevIt = it;
        }
    }

} //testGetMediaRecordsSortingByTitle

void FakeLocalMediaLibraryTestCommon::testGetMediaRecord()
{
	NICKEL_FUNC_DEBUG;
	NS_ZINC::Future< MediaRecord > f = 
        localMediaLibrary->getMediaRecord("file://dummy44");
    MediaRecord mr = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong record id",
            string("file://dummy44"),
            mr.mediaRecordIdentifier);

	f = localMediaLibrary->getMediaRecord("TestID");
    CPPUNIT_ASSERT_THROW_MESSAGE(
            "Should have thrown exception", f.get(),
            MediaRecordNotFound);
}

void FakeLocalMediaLibraryTestCommon::testGetMediaRecordsByContentIdentifier()
{
	NICKEL_FUNC_DEBUG;
	NS_ZINC::Future< vector< MediaRecord > > f = 
        localMediaLibrary->getMediaRecordsByContentIdentifier(
                "dvb://233a..4780;f28b");
    vector< MediaRecord > mrs = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong number of records",
            size_t(4),
            mrs.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong record id",
            string("file://dummy44"),
            mrs[1].mediaRecordIdentifier);
    
	NS_ZINC::Future< vector< MediaRecord > > f1 = 
        localMediaLibrary->getMediaRecordsByContentIdentifier(
                "dvb://233a..1044;b741");
    mrs = f1.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong number of records",
            size_t(1),
            mrs.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong title",
            string("TV Very Short Duration"),
            mrs[0].title);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong synopsis",
            string("A very short programme "),
            mrs[0].synopsis);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong synopsis",
            string("A very short programme "),
            mrs[0].synopsis);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong acquisitionDateTime",
            static_cast<uint32_t>(1309025755),
            mrs[0].acquisitionDateTime);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong acquisitionStatus",
            1,
            static_cast<int>(mrs[0].acquisitionStatus));
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong adult field",
            false,
            mrs[0].adult);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong audioDescription",
            false,
            mrs[0].audioDescription);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong contentIdentifier",
            string("dvb://233a..1044;b741"),
            mrs[0].contentIdentifier);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong duration",
            static_cast<uint32_t>(900),
            mrs[0].duration);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong guidanceCode",
            string(),
            mrs[0].guidanceCode);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong guidanceText",
            string(),
            mrs[0].guidanceText);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong identifiers",
            string("crid://fp.bbc.co.uk/AJR2HV"),
            mrs[0].identifiers["http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.programmeCRID"]);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong isProtected",
            false,
            mrs[0].isProtected);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong lastAccessed",
            static_cast<uint32_t>(0),
            mrs[0].lastAccessed);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong mediaLocator",
            string("file://dummy28"),
            mrs[0].mediaLocator);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong mediaRecordIdentifier",
            string("file://dummy28"),
            mrs[0].mediaRecordIdentifier);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong publishedDuration",
            static_cast<uint32_t>(900),
            mrs[0].publishedDuration);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong resumeAt",
            static_cast<uint32_t>(0),
            mrs[0].resumeAt);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong serviceName",
            string("Channel 4"),
            mrs[0].serviceName);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong signing",
            false,
            mrs[0].signing);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong size",
            static_cast<int64_t>(1),
            mrs[0].size);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong subtitles map size",
            static_cast<size_t>(0),
            mrs[0].subtitles.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong watershed",
            false,
            mrs[0].watershed);
}

void FakeLocalMediaLibraryTestCommon::testDeleteMediaRecord()
{
	NICKEL_FUNC_DEBUG;
	NS_ZINC::Future< bool > f = 
        localMediaLibrary->deleteMediaRecord("file://dummy44");
    bool success = f.get();
    CPPUNIT_ASSERT_MESSAGE("Wrong result",success);

	NS_ZINC::Future< vector< MediaRecord > > f1 = 
        localMediaLibrary->getMediaRecords( FilterByType::recordings, 
                FilterByPlayed::played_and_unplayed, 
                SortBy::least_recently_acquired, 
                false, 0, 1234567890);
    vector< MediaRecord > mrs = f1.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of records",
            size_t(42),mrs.size());
}

void FakeLocalMediaLibraryTestCommon::testGetStorageSpace()
{
    NICKEL_FUNC_DEBUG;
    NS_ZINC::Future< MediaStorageSpace > f = localMediaLibrary->getStorageSpace();
    MediaStorageSpace mss = f.get();

    const int64_t KB = int64_t(1024);
    const int64_t MB = KB*1024;
    const int64_t GB = MB*1024;
    int64_t expectedResult = 1*KB;

    try
    {
        std::ifstream configFile( NS_ZINC::PackageDataFinder().find("fake_getStorageSpace.txt").c_str(), std::ifstream::in );
        std::string mode;
        configFile >> mode;
        if(mode == "0")
            expectedResult = 0;
        else if(mode == "10")
            expectedResult = 28*GB;
        else if(mode == "90")
            expectedResult = 252*GB;
        else if(mode == "100")
            expectedResult = 280*GB;
        else if(mode == "ERR1")
            expectedResult = 0;
        else if(mode == "ERR2")
            expectedResult = 0;
    }
    catch(const NS_ZINC::ResourceNotFoundException& e)
    {
        NICKEL_DEBUG("Fake configuration file not found.");
    }

    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong result",expectedResult,mss.usedForRecordings);
}

void FakeLocalMediaLibraryTestCommon::testSetMediaRecordProtected()
{
	NICKEL_FUNC_DEBUG;
	NS_ZINC::Future< bool > f 
        = localMediaLibrary->setMediaRecordProtected("file://dummy44",true);
    bool success = f.get();
    CPPUNIT_ASSERT_MESSAGE("Wrong result",success);
}

void FakeLocalMediaLibraryTestCommon::testGetMediaRecordTimingSignature()
{
	NICKEL_FUNC_DEBUG;
	NS_ZINC::Future< string > f = localMediaLibrary->getMediaRecordTimingSignature("xxx");
    string result = f.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong result",string("TheTimingSignature"),result);
}

void FakeLocalMediaLibraryTestCommon::testSignals()
{
	NICKEL_FUNC_DEBUG;
    boost::shared_ptr<MockLocalMediaLibraryEventListener> listener = boost::make_shared<NS_NICKEL_SYSTEM::MockLocalMediaLibraryEventListener>();
    localMediaLibrary->setDispatcher(boost::make_shared<NS_ZINC::MultipleListenerEventDispatcher>());
    localMediaLibrary->addListener(listener);

    MediaStorageSpace mss;
    mss.usedForRecordings = 10240;
    EXPECT_CALL(*listener, LowStorageSpace(mss));
	localMediaLibrary->getMediaRecordTimingSignature("TriggerLowStorageSpace").get();

    map< string, LibraryContentChangeType::Enum > changes =
        map_list_of("hello", LibraryContentChangeType::deleted);
    EXPECT_CALL(*listener, LibraryContentChange(changes));
	localMediaLibrary->getMediaRecordTimingSignature("TriggerLibraryContentChange").get();

    CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(listener.get()));
}

void FakeLocalMediaLibraryTestCommon::testSubtitles()
{
	NICKEL_FUNC_DEBUG;
    
	NS_ZINC::Future< vector< MediaRecord > > f1 = 
        localMediaLibrary->getMediaRecordsByContentIdentifier(
                "dvb://233a..1044;b735");
    vector< MediaRecord > mrs = f1.get();
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong number of records",
            size_t(1),
            mrs.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong title",
            string("TV Multiple Language Subtitles"),
            mrs[0].title);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong synopsis",
            string("A recording with subtitles in multiple langauges"),
            mrs[0].synopsis);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong acquisitionDateTime",
            static_cast<uint32_t>(1309750555),
            mrs[0].acquisitionDateTime);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong acquisitionStatus",
            1,
            static_cast<int>(mrs[0].acquisitionStatus));
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong adult field",
            false,
            mrs[0].adult);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong audioDescription",
            false,
            mrs[0].audioDescription);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong contentIdentifier",
            string("dvb://233a..1044;b735"),
            mrs[0].contentIdentifier);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong duration",
            static_cast<uint32_t>(7200),
            mrs[0].duration);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong guidanceCode",
            string(),
            mrs[0].guidanceCode);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong guidanceText",
            string(),
            mrs[0].guidanceText);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong identifiers",
            string("crid://fp.bbc.co.uk/AAO6Z5"),
            mrs[0].identifiers["http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.programmeCRID"]);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong isProtected",
            false,
            mrs[0].isProtected);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong lastAccessed",
            static_cast<uint32_t>(0),
            mrs[0].lastAccessed);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong mediaLocator",
            string("file://dummy38"),
            mrs[0].mediaLocator);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong mediaRecordIdentifier",
            string("file://dummy38"),
            mrs[0].mediaRecordIdentifier);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong publishedDuration",
            static_cast<uint32_t>(7200),
            mrs[0].publishedDuration);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong resumeAt",
            static_cast<uint32_t>(0),
            mrs[0].resumeAt);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong serviceName",
            string("BBC Wales"),
            mrs[0].serviceName);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong signing",
            true,
            mrs[0].signing);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong size",
            static_cast<int64_t>(1),
            mrs[0].size);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong subtitles map size",
            static_cast<size_t>(2),
            mrs[0].subtitles.size());
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong subtitles map size",
            static_cast<uint32_t>(4),
            mrs[0].subtitles["ENG"]);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong subtitles map size",
            static_cast<uint32_t>(4),
            mrs[0].subtitles["CYM"]);
    CPPUNIT_ASSERT_EQUAL_MESSAGE(
            "Wrong watershed",
            false,
            mrs[0].watershed);
}

NS_NICKEL_SYSTEM_CLOSE
