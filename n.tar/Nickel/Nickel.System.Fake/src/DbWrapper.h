/*
 * DbWrapper.h
 *
 *  Created on: 20 June, 2011
 *      Author: milton.mukhopadhyay@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */
#ifndef DB_WRAPPER_H
#define DB_WRAPPER_H

#include <sqlite3.h>
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include <map>
#include <stdexcept>
#include <stdint.h>
#include <boost/utility.hpp>

#include <nickel-system-api/nickel-system-api.h>
#include "SqlStatement.h"

NS_NICKEL_SYSTEM_OPEN


class DbWrapper : boost::noncopyable
{
    public:
        typedef boost::shared_ptr<sqlite3> DbPtr; 
        typedef boost::shared_ptr<SqlStatement> StatementPtr;
        typedef std::map<std::string, std::string> StrStrMap;

        ~DbWrapper(){}
        explicit DbWrapper(const std::string& dbPath);

        std::vector<StrStrMap> selectAll() const;

        DbPtr getHandle() const
        {
            return dbHandle; 
        }
    private:
        StrStrMap getOneRecord(StatementPtr stmt) const;
        DbPtr dbHandle;
        StatementPtr selectStmt;
};

class S3Error : public std::runtime_error
{
    public:
        explicit S3Error(char const* msg);
        explicit S3Error(const DbWrapper& db);
};


NS_NICKEL_SYSTEM_CLOSE

#endif //DB_WRAPPER_H  
