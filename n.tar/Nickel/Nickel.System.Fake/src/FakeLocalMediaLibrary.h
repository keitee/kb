/*
 * LocalMediaLibrary.h
 *
 *  Created on: Mar 15, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_LOCALMEDIALIBRARY_H_
#define NICKEL_SYSTEM_FAKE_LOCALMEDIALIBRARY_H_

#include <nickel-system-api/LocalMediaLibrary.h>
#include <nickel-system-api/LocalMediaLibraryEventListener.h>
#include <zinc-common/async/FutureDispatcher.h>
#include <zinc-common/async/Promise.h>
#include <zinc-common/ActionProcessor.h>

NS_NICKEL_SYSTEM_OPEN

class FakeLocalMediaLibrary : public LocalMediaLibrary
{
    private:
        typedef std::map<std::string, std::string> StrStrMap;
    public:
        typedef std::vector<MediaRecord> MediaRecordVec;
        FakeLocalMediaLibrary(boost::shared_ptr<NS_ZINC::FutureDispatcher>);
        virtual ~FakeLocalMediaLibrary();

        virtual NS_ZINC::Future<MediaRecordVec>
            getMediaRecords(
                    const FilterByType::Enum filterByType_in,
                    const FilterByPlayed::Enum filterByPlayed_in,
                    const SortBy::Enum sortBy_in,
                    const bool includeAdult_in,
                    const uint32_t start_in,
                    const uint32_t size_in);

        virtual NS_ZINC::Future< MediaRecord >
            getMediaRecord(const std::string& mediaRecordIdentifier_in);

        virtual NS_ZINC::Future<MediaRecordVec>
            getMediaRecordsByContentIdentifier(
                    const std::string& conentIdentifier_in
                    );

        virtual NS_ZINC::Future< bool >
            deleteMediaRecord(const std::string& mediaRecordIdentifier_in);

        virtual NS_ZINC::Future< MediaStorageSpace > getStorageSpace();

        virtual NS_ZINC::Future< bool >
            setMediaRecordProtected(
                    const std::string& mediaRecordIdentifier_in,
                    const bool isProtected_in);

        virtual NS_ZINC::Future< std::string >
            getMediaRecordTimingSignature(
                    const std::string& mediaRecordIdentifier_in);

    private:
        void reformat(std::string& val);
        void extractData();
        void doLowStorageSpaceSignal();
        void sendLowStorageSpaceSignal(MediaStorageSpace mss);
        void sendLibraryContentChangeSignal(const std::map< std::string, LibraryContentChangeType::Enum >& changes);

        typedef struct
        {
            uint32_t isActive;
            uint32_t timePeriod;
        } SignalGeneratorState;

        boost::shared_ptr<NS_ZINC::FutureDispatcher> dispatcher;

        MediaRecordVec records;
        NS_ZINC::ActionProcessor ap;

        SignalGeneratorState sgState;
};

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_FAKE_LOCALMEDIALIBRARY_H_ */
