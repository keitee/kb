/*
 * FakeOutputManagerState.cpp
 *
 *  Created on: Jun 21, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2011 YouView TV
 */

#include "FakeOutputManagerState.h"

#include <nickel-system-api/AudioFormat.h>
#include <nickel-system-api/DisplayResolution.h>

#include <yaml-cpp/yaml.h>
#include <boost/preprocessor/seq/for_each.hpp>
#include <iterator>
#include <exception>
#include <iostream>

namespace
{

template <typename DestT>
void convertEnum(DestT& result, const YAML::Node& node)
{
    if(!NS_NICKEL_SYSTEM::enum_from_string(result, node.as<std::string>().c_str()))
    {
        throw std::runtime_error("convertEnum failed");
    };
};

/**
 * Read optional value for given key
 */
template <typename DestT>
void readOptional(const YAML::Node& node, const char* key, DestT& dest)
{
    if(const YAML::Node value = node[key])
    {
        dest = value.as<DestT>();
    }
};

/**
 * Read enum for given key
 */
template <typename DestT>
void readEnum(const YAML::Node& node, const char* key, DestT& dest)
{
    convertEnum(dest, node[key]); 
};

/**
 * Read optional enum for given key
 */
template <typename DestT>
void readOptionalEnum(const YAML::Node& node, const char* key, DestT& dest)
{
    if(const YAML::Node value = node[key])
    {
        convertEnum(dest, value);
    };
};

/**
 * Read sequence
 */

template <typename SequenceT>
void readSeq(const YAML::Node& node, const char* key, SequenceT& output)
{
    output = node[key].as<SequenceT>();
};

template <typename SequenceT>
void readOptionalSeq(const YAML::Node& node, const char* key, SequenceT& output)
{
    if(const YAML::Node value = node[key])
    {
        output = node[key].as<SequenceT>();
    };
};

};

/**
 * Node readers for state collections value types 
 */
namespace YAML
{
template<>
struct convert<Zinc::Media::DisplayResolution::Enum>
{
    static bool decode(const Node& node,
            Zinc::Media::DisplayResolution::Enum& result)
{
    convertEnum(result, node);
        return true;
    }
};

template<>
struct convert<Zinc::Media::AudioFormat::Enum>
{
    static bool decode(const Node& node,
            Zinc::Media::AudioFormat::Enum& result)
{
    convertEnum(result, node);
        return true;
    }
};

template<>
struct convert<NS_NICKEL_SYSTEM::AudioOutputState>
{
    static bool decode(const Node& node,
            NS_NICKEL_SYSTEM::AudioOutputState& state)
{
        state.id = node["id"].as<uint32_t>();
    readEnum(node, "type", state.outType);
    readSeq(node, "formats", state.formats);
    readEnum(node, "formatPreference", state.formatPreference);
        if(const YAML::Node delay = node["delay"])
    {
            state.delay = delay.as<uint32_t>();
        state.delaySupported = true;
    }
    else
    {
        state.delay = 0;
        state.delaySupported = false;
    };
        return true;
    }
};


bool convert<NS_NICKEL_SYSTEM::FakeOutputManagerState>::decode(
        const YAML::Node& node,
        NS_NICKEL_SYSTEM::FakeOutputManagerState& state)
{
    readOptionalEnum(node,
            "primaryDisplayPreference",
            state.primaryDisplayPreference);

    if(const YAML::Node hdmi = node["hdmiDisplay"])
    {
        readOptionalSeq(hdmi, "resolutions", state.hdmiResolutions);
        readOptionalEnum(hdmi, "resolutionPreference",
                state.hdmiResolutionPreference);
        readOptionalEnum(hdmi, "hdcpPreference", state.hdcpPreference);
        readOptionalEnum(hdmi, "status", state.hdmiStatus);
        readOptional(hdmi, "standby", state.hdmiStandby);
    }

    if(const YAML::Node an = node["analogueDisplay"])
    {
        readOptionalEnum(an, "aspectRatio", state.analogueAspectRatio);
        readOptionalEnum(an, "videoStandard", state.analogueVideoStandard);
        readOptionalEnum(an, "colourMode", state.analogueColourMode);
    }

    readOptionalSeq(node, "audioOutputs", state.audioOutputs);

    readOptional(node, "volume", state.volume);
    readOptional(node, "muted", state.volumeMuted);
    readOptional(node, "relativeADVolume", state.relativeADVolume);
    readOptionalEnum(node, "adRouting", state.adRouting);
    readOptional(node, "outputsEnabled", state.outputsEnabled);

    if(const YAML::Node vc = node["videoConversions"])
    {
        readOptionalEnum(vc, "standardToWide",
                state.videoConversionsPreference.standardToWide);
        readOptionalEnum(vc, "wideToStandard",
                state.videoConversionsPreference.wideToStandard);
    }
    return true;
}

}

NS_NICKEL_SYSTEM_OPEN

FakeOutputManagerState::FakeOutputManagerState():
    primaryDisplayPreference(DisplayType::hdmi),
    hdmiResolutionPreference(DisplayResolution::hd1920x1080p50),
    hdcpPreference(HDCPPreference::when_required),
    hdmiStatus(HDMIStatus::active_hdcp_on),
    hdmiStandby(false),
    analogueAspectRatio(AspectRatio::_4_3),
    analogueVideoStandard(VideoStandard::pal),
    analogueColourMode(ColourMode::composite),
    volume(100),
    volumeMuted(false),
    relativeADVolume(0),
    adRouting(ADRouting::ad_all_outputs),
    outputsEnabled(true)
{
    videoConversionsPreference.standardToWide = Conversion_4_3_To_16_9::automatic;
    videoConversionsPreference.wideToStandard = Conversion_16_9_To_4_3::letterbox_14_9;
};

NS_NICKEL_SYSTEM_CLOSE
