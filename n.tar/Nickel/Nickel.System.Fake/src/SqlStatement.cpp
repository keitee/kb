/*
 * SqlStatement.cpp
 *
 *  Created on: 20 June, 2011
 *      Author: milton.mukhopadhyay@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */

#include "SqlStatement.h"
#include <string>
#include <stdexcept>

#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/nickel-system-api.h>
#include "DbWrapper.h"

NS_NICKEL_SYSTEM_OPEN

using std::string;

SqlStatement::SqlStatement(const DbWrapper* db, const string& query)
    :state(INVALID)
{
    DbWrapper::DbPtr dbHandle = db->getHandle();
    sqlite3_stmt* sqlite_handle;
    //"If the caller knows that the supplied string is nul-terminated, 
    //then there is a small performance advantage to be gained by passing 
    //an nByte parameter that is equal to the number of bytes in the input 
    //string including the nul-terminator bytes."
    if(sqlite3_prepare_v2(dbHandle.get(), query.c_str(), 
                query.size()+1, &sqlite_handle, 0) != SQLITE_OK)
    {
        throw S3Error(*db);
    }
    stmt = StmtPtr(sqlite_handle, sqlite3_finalize);
    state = VALID;
}

SqlStatement::~SqlStatement()
{
}

void SqlStatement::begin()
{
    //Can begin fail ? Failure from reset is really about a previous 
    //failure.
    sqlite3_reset(stmt.get());
    //sqlite3_clear_binding(stmt.get());
}

bool SqlStatement::next()
{
    if(sqlite3_step(stmt.get()) != SQLITE_ROW)
    {
        state = INVALID;
        return false;
    }
    state = VALID;
    return true;
}

NS_NICKEL_SYSTEM_CLOSE
