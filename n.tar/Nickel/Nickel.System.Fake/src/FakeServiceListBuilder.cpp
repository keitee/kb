/*
 * FakeServiceListBuilder.cpp
 */

#include "FakeServiceListBuilder.h"
#include <nickel-common/NickelLogger.h>
#include <fstream>

using namespace boost;
using NS_ZINC::BoundEvent;

namespace {
const std::string controlFile("/tmp/servicelistbuilder_control.txt");
}

NS_NICKEL_SYSTEM_OPEN

FakeServiceListBuilder::FakeServiceListBuilder()
	:	scanningThreadStruct()
	,	scanningThread(NULL)
    ,   running(false) {
    NICKEL_FUNC_DEBUG;
}

FakeServiceListBuilder::~FakeServiceListBuilder() {
	if(running) {
		stopServiceScan();
	}

    if(scanningThread) {
        scanningThread->join();
        delete scanningThread;
        scanningThread = NULL;
    }
}

void FakeServiceListBuilder::serviceScan() {
    NICKEL_FUNC_DEBUG;
	// begin scan: spawn thread to send the progress update signals
	if(running) {
        NICKEL_DEBUG("Error already running");
		//  thread currently running
		// TODO - functionality undefined, throw exception? will just ignore for now
	} else {
        NICKEL_DEBUG("Starting scanning thread");
		running = true;
		scanningThreadStruct.scanStart = 21;
		scanningThreadStruct.counter = scanningThreadStruct.scanStart;
		scanningThreadStruct.totToScan = 48;
		scanningThreadStruct.scanEnd = scanningThreadStruct.scanStart + scanningThreadStruct.totToScan;
		scanningThreadStruct.parent  = this;
		scanningThread = new thread(scanningThreadStruct);
	}
}

void FakeServiceListBuilder::stopServiceScan() {
    NICKEL_FUNC_DEBUG;
    running = false;
}

void FakeServiceListBuilder::ScanningThreadStruct::operator()() {
    NICKEL_FUNC_DEBUG;
    bool doScanFail = false;
    int32_t progress = 0;
    std::ifstream inFile(controlFile.c_str());
    if(inFile.is_open()) {
        NICKEL_DEBUG("File present triggering fail");
        doScanFail = true;
    }

    while(parent->running && (counter <= scanEnd)) {
        NICKEL_DEBUG("Sending signal "<<counter);
        // send update, increment counter
        ScanningProgressStatus::Enum status;
        if(counter >=(scanStart+2) && doScanFail) {
            NICKEL_DEBUG("Simulating failure");
            break;
        }
        else if(counter < scanEnd) {
            status = ScanningProgressStatus::in_progress;
        }
        else {
            status = ScanningProgressStatus::success;
        }

        progress = ((counter-scanStart)*100)/totToScan;

        parent->produceEvent(
                                bind(
                                        &ServiceListBuilderEventListener::ScanningProgress,
                                        _1,
                                        progress,
                                        status,
                                        counter-scanStart,
                                        totToScan,
                                        services
                                     )
                            );

        ++counter;
        timespec tv={0,10000000};
        nanosleep(&tv,NULL);
    }

    if(doScanFail) {
        NICKEL_DEBUG("Failed");
        progress = ((counter-scanStart)*100)/totToScan;

        parent->produceEvent(
                      bind(
                            &ServiceListBuilderEventListener::ScanningProgress,
                            _1,
                            progress,
                            ScanningProgressStatus::failure,
                            counter-scanStart,
                            totToScan,
                            services
                           )
                        );
    }
    else if(!parent->running && counter < 100) {
        NICKEL_DEBUG("Aborting");
        progress = ((counter-scanStart)*100)/totToScan;

        parent->produceEvent(
                      bind(
                            &ServiceListBuilderEventListener::ScanningProgress,
                            _1,
                            progress,
                            ScanningProgressStatus::aborted,
                            counter-scanStart,
                            totToScan,
                            services
                          )
                      );
    }

    parent->running = false;

}


NS_NICKEL_SYSTEM_CLOSE
