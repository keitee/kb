/*
 * FakeMediaRouterFactory.cpp
 *
 *  Created on: 13-Aug-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 */

#include "FakeMediaRouterFactory.h"
#include "FakeMediaRouter.h"
#include <nickel-common/NickelLogger.h>
#include <boost/make_shared.hpp>
#include <nickel-system-api/MediaRouterConvertToAsync.h>

using namespace NS_ZINC;
using namespace std;

NS_NICKEL_SYSTEM_OPEN

FakeMediaRouterFactory::FakeMediaRouterFactory(boost::shared_ptr<FutureDispatcher> futureDispatcher_, boost::shared_ptr<ActionProcessor> actionProcessor_)
: futureDispatcher(futureDispatcher_), actionProcessor(actionProcessor_)
{
    NICKEL_FUNC_TRACE;
}

FakeMediaRouterFactory::~FakeMediaRouterFactory() {
    NICKEL_FUNC_TRACE;
}

boost::shared_ptr<MediaRouter> FakeMediaRouterFactory::createMediaRouter() {
    NICKEL_FUNC_TRACE;

    boost::shared_ptr<MediaRouterSync> newMediaRouter = createFakeMediaRouter();
    newMediaRouter->setDispatcher(boost::make_shared<MultipleListenerEventDispatcher>());
    return convertToAsync(newMediaRouter, *actionProcessor);
}

NS_NICKEL_SYSTEM_CLOSE

