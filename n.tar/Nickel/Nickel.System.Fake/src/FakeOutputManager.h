/*
 * FakeOutputManager.h
 *
 *  Created on: Mar 2, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGER_H_
#define NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGER_H_

#include <nickel-system-api/nickel-system-api.h>

NS_NICKEL_SYSTEM_OPEN

class FakeOutputManagerState;

class FakeOutputManager
	:	public virtual OutputManagerSync {

public:
	FakeOutputManager();
	FakeOutputManager(std::auto_ptr<FakeOutputManagerState> state);
	virtual ~FakeOutputManager();

public: // from OutputManager
	typedef std::map< uint32_t, AudioOutputType::Enum > AudioOutputs;

	virtual DisplayType::Enum getPrimaryDisplayPreference() const;
	virtual void setPrimaryDisplayPreference(const DisplayType::Enum preference);

	virtual DisplayResolution::Enum getHDMIResolutionPreference() const;
	virtual void setHDMIResolutionPreference(const DisplayResolution::Enum resolution);
	virtual std::vector<DisplayResolution::Enum>  getHDMIResolutionOptions() const;
	virtual HDCPPreference::Enum getHDMIHDCPPreference() const;
	virtual void setHDMIHDCPPreference(const HDCPPreference::Enum preference);
	virtual HDMIStatus::Enum getHDMIStatus() const;
	virtual void requestHDMIStandby();

	virtual AspectRatio::Enum getAnalogueDisplayAspectRatio() const;
	virtual void setAnalogueDisplayAspectRatio(const AspectRatio::Enum aspectRatio);
	virtual VideoStandard::Enum getAnalogueVideoStandard() const;
	virtual void setAnalogueVideoStandard(const VideoStandard::Enum standard);
	virtual ColourMode::Enum getSCARTColourPreference() const;
	virtual void setSCARTColourPreference(const ColourMode::Enum colourMode);

	virtual VideoConversions getVideoConversionPreference() const;
	virtual void setVideoConversionPreference(const VideoConversions& preference);
	virtual DisplayResolution::Enum getPrimaryDisplayResolution() const;
	virtual AspectRatio::Enum getPrimaryDisplayAspectRatio() const;
	virtual GraphicsResolution getGraphicsLayerResolution() const;

	virtual AudioOutputs getAudioOutputs() const;
	virtual std::vector<AudioFormat::Enum> getAudioFormatOptions(const uint32_t outputId) const;
	virtual AudioFormat::Enum getAudioFormatPreference(const uint32_t outputId) const;
	virtual void setAudioFormatPreference(const uint32_t outputId, const AudioFormat::Enum format);
	virtual int32_t getAudioDelay(const uint32_t outputId) const;
	virtual void setAudioDelay(const uint32_t outputId, const int32_t delay);

	virtual void incVolume();
	virtual void decVolume();
	virtual uint32_t getVolume() const;
	virtual void setVolume(const uint32_t volume);
	virtual void muteVolume();
	virtual void unmuteVolume();
	virtual bool isMuted() const;

	virtual void disableOutputs();
	virtual void enableOutputs();
    virtual int32_t getRelativeADVolume() const;
    virtual void setRelativeADVolume(const int32_t volume);
    virtual ADRouting::Enum getADRouting() const;
    virtual void setADRouting(const ADRouting::Enum routing);

public: // from OutputManagerEventListener
	virtual void DisplayPreferenceChange();
	virtual void HDMIEvent(const HDMIStatus::Enum status);
	virtual void HDMICECEvent(const HDMICECEventType::Enum eventType);
	virtual void PrimaryDisplayChange();
	virtual void AudioPreferenceChange(const uint32_t outputId);
	virtual void VolumeChange(const uint32_t volume, const bool muted);
	virtual void OutputStatusEvent(const bool enabled);

private:
    boost::scoped_ptr<FakeOutputManagerState> _state;
	void sendVolumeChangeEvent();
};

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGER_H_ */
