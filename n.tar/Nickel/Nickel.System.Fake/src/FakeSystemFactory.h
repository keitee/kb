/* Copyright (C) 2009 British Broadcasting Corporation */
/*
 * FakeSystemFactory.h
 *
 *  Created on: 24-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 */

#ifndef NICKELFAKESYSTEMFACTORY_H_
#define NICKELFAKESYSTEMFACTORY_H_

#include <nickel-system-api/nickel-system-api.h>
#include <boost/shared_ptr.hpp>
#include <zinc-common/ActionProcessor.h>

NS_NICKEL_SYSTEM_OPEN

class FakeLocalMediaLibrary;

class FakeSystemFactory : virtual public SystemFactory {

public:
    FakeSystemFactory( const bool temp );

	boost::shared_ptr<LocalMediaLibrary>  createLocalMediaLibrary()  ;
	boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory() ;
	boost::shared_ptr<MediaRouter>        createDefaultMediaRouter() ;
	boost::shared_ptr<MediaSettings>      createMediaSettings()      ;
	boost::shared_ptr<OutputManager>      createOutputManager()      ;
	boost::shared_ptr<ServiceListBuilder> createServiceListBuilder() ;

protected:

	/**
	 * This is deliberately protected. I just want to fix the choice of dispatcher
	 * implementation in one place. Services will be created complete with dispatcher.
	 * It is always possible to override later.
	 */
	boost::shared_ptr<NS_ZINC::EventDispatcher> createDispatcher();

private:
    boost::shared_ptr<NS_ZINC::FutureDispatcher> futureDispatcher;
    boost::shared_ptr<NS_ZINC::ActionProcessor> actionProcessor;
    boost::shared_ptr<FakeLocalMediaLibrary> lml;
    boost::shared_ptr<ServiceListBuilder> slb;
    boost::weak_ptr<MediaRouter> defaultMediaRouter;
    bool temp;
};

NS_NICKEL_SYSTEM_CLOSE

extern "C" {
	NS_ZINC::Plugin* createFakeSystemFactory();
	NS_ZINC::Plugin* createFakeSystemFactoryTemp();
}

#endif /* NICKELFAKESYSTEMFACTORY_H_ */
