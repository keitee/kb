/*
 * FakeMediaRouter.cpp
 *
 *    Created on: 13-Aug-2009
 *        Author: mark.nicoll1@bbc.co.uk
 */

#include "FakeMediaRouter.h"

#include <nickel-system-api/Position.h>
#include <nickel-system-api/Track.h>
#include <nickel-system-api/nickel-system-exceptions.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-common/Action.h>
#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/macros.h>
#include <zinc-common/Enum.h>
#include <nickel-system-api/BufferConstraint.h>
#include <nickel-system-api/AdaptiveMode.h>
#include <nickel-system-api/AudioFormat.h>
#include <nickel-system-api/BufferMode.h>


#include <boost/make_shared.hpp>

#include <iostream>
#include <fstream>
#include <sstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

NS_NICKEL_SYSTEM_OPEN

FakeMediaRouter::FakeMediaRouter()
    : playSpeed(1000),
      sourceType(MRSRC_NOTSET),
      position(),
      audioTrack(),
      subtitleTrack(),
      videoWindow(),
      buffer(),
      mrState(MR_CREATED),
      mrBufferState(MRB_CREATED),
      ssPrevTime(0),
      ssStarted(false),
      signalQuality("100"),
      dvbBufferSize(3600000),
      restrictedMode(0),
      bufferConstraint(BufferConstraint::threshold),
      adaptiveMode(AdaptiveMode::repeat),
      createTestRTPStats(false)
{
    NICKEL_FUNC_TRACE;

    position.start = 0;
    position.current = 0;
    position.end = 3600000;
    buffer.bufferedBytes = 0;
    buffer.totalBytesRemaining = 500000;
    buffer.totalStreamBytes = 500000;
    buffer.arrivalBytesPerSecond = 100000;
    buffer.streamBytesPerSecond = 10000;
    buffer.bufferedMilliseconds = 0;

    audioTrack.format = TrackFormat::video_h264;
    audioTrack.type = TrackType::video;
    audioTrack.usage = TrackUsage::audio_normal;
    subtitleTrack.format = TrackFormat::subtitle_dvb;
    subtitleTrack.type = TrackType::subtitle;
    subtitleTrack.usage = TrackUsage::audio_normal;

    try {
        std::string mediaRouterConfigFile = NS_ZINC::PackageDataFinder().find("media_router_config.txt");

        std::ifstream config(mediaRouterConfigFile.c_str());
        if(config.is_open()) {
            NICKEL_DEBUG("Parsing config file: " << mediaRouterConfigFile);
            std::string line;
            while(!config.eof()) {
                getline(config, line);
//                NICKEL_DEBUG("line \""<<line<<"\"");
                std::string::size_type idx = line.find('=');
                if(idx != std::string::npos) {
                    std::string key = line.substr(0,idx);
                    std::string value = line.substr(idx+1);
//                    NICKEL_DEBUG("key "<<key<<" value "<<value);
                    if(key == "create_test_rtp_stats") {
                        createTestRTPStats = true;
                    }
                    if(key == "position_start") {
                        std::istringstream iss;
                        iss.str(value);
                        iss>>position.start;
                    }
                    else if(key == "position_current") {
                        std::istringstream iss;
                        iss.str(value);
                        iss>>position.current;
                    }
                    else if(key == "position_end") {
                        std::istringstream iss;
                        iss.str(value);
                        iss>>position.end;
                    }
                    else if(key == "dvb_bufferSize") {
                        std::istringstream iss;
                        iss.str(value);
                        iss>>dvbBufferSize;
                    }
                    else if(key == "buffer_arrivalBytesPerSecond") {
                        std::istringstream iss;
                        iss.str(value);
                        iss>>buffer.arrivalBytesPerSecond;
                    }
                    else if(key == "buffer_totalStreamBytes") {
                        std::istringstream iss;
                        iss.str(value);
                        iss>>buffer.totalStreamBytes;
                        buffer.totalBytesRemaining = buffer.totalStreamBytes;
                    }
                    else if(key == "buffer_streamBytesPerSecond") {
                        std::istringstream iss;
                        iss.str(value);
                        iss>>buffer.streamBytesPerSecond;
                    }
                    else {
                        NICKEL_DEBUG("Unknown key "<<key);
                    }
                }
            }
        }
        config.close();
    }
    catch (NS_ZINC::ResourceNotFoundException& e) {
        // Config file does not exist is not an error
        NICKEL_DEBUG("Not loading config file: " << e.what());
    }
}

FakeMediaRouter::~FakeMediaRouter() {
    NICKEL_FUNC_TRACE;
    ap.stop();
}

boost::shared_ptr<MediaRouterSync> createFakeMediaRouter() {
    boost::shared_ptr<FakeMediaRouter> mr = boost::make_shared<FakeMediaRouter>();

    mr->ap.start();

    boost::shared_ptr<NS_ZINC::Action> action(
            new NS_ZINC::Action(boost::bind(&FakeMediaRouter::simulateBehaviour, mr)));
    action->schedule(boost::posix_time::seconds(1),boost::posix_time::seconds(1));
    mr->ap.addAction(action);
    return mr;
}

void FakeMediaRouter::swapFakeMediaRouter(FakeMediaRouter& other) {
    using std::swap;
    swap(mediaLocator, other.mediaLocator);
    swap(playSpeed, other.playSpeed);
    swap(sink, other.sink);
    swap(sourceType, other.sourceType);
    swap(position, other.position);
    swap(audioTrack, other.audioTrack);
    swap(subtitleTrack, other.subtitleTrack);
    swap(videoWindow, other.videoWindow);
    swap(buffer, other.buffer);
    swap(ap, other.ap);
    swap(mrState, other.mrState);
    swap(mrBufferState, other.mrBufferState);
    swap(ssPrevTime, other.ssPrevTime);
    swap(ssStarted, other.ssStarted);
    swap(ssIncrement, other.ssIncrement);
    swap(ssState, other.ssState);
    swap(ssInterval, other.ssInterval);
    swap(ssTicksToNextEvent, other.ssTicksToNextEvent);
    swap(signalQuality, other.signalQuality);
    swap(dvbBufferSize, other.dvbBufferSize);
}

void FakeMediaRouter::simulateBehaviour() {
    // NICKEL_FUNC_TRACE;

    boost::mutex::scoped_lock lock(mrMutex);
    switch(mrState) {
        case MR_CREATED:
            // Nothing to do
            break;
        case MR_STARTED: {
            // Send started event
            NICKEL_DEBUG("MR_STARTED");
            produceEvent( boost::bind(&MediaRouterEventListener::StatusEvent, _1, StatusEventValue::started) );
            mrState = MR_PLAYING;
            break;
        }
        case MR_PLAYING: {
            // Send started event
            // NICKEL_DEBUG("MR_PLAYING");

            int32_t const ticksPast = 1;
            if(sourceType == MRSRC_DVB) {
                //NICKEL_DEBUG("MRSRC_DVB");
                bool newPlaySpeed = false;
                int32_t theNewPlaySpeed = 0;

                position.end += ticksPast*1000;

                int32_t tmpCurrent = position.current + ticksPast*playSpeed;
                if(playSpeed > 1000 && tmpCurrent >= position.end) {
                    NICKEL_DEBUG("Reached end of DVB buffer dropping play speed");
                    position.current = position.end;
                    newPlaySpeed = true;
                    theNewPlaySpeed = 1000;
                }
                else if(playSpeed < 0 && tmpCurrent < position.start) {
                    NICKEL_DEBUG("Reached beginning of DVB buffer dropping play speed");
                    position.current = position.start;
                    newPlaySpeed = true;
                    theNewPlaySpeed = 0;
                }
                else {
                    position.current = tmpCurrent;
                }

                if(position.end - position.start > dvbBufferSize) {
                    // Run out of DVB buffer move the start along
                    position.start = position.end - dvbBufferSize;
                    if(position.current < position.start) {
                        position.current = position.start;
                        newPlaySpeed = true;
                        theNewPlaySpeed = 1000;
                    }
                }

                if(newPlaySpeed) {
                    setPlaySpeedInt(theNewPlaySpeed,false);
                }
            }
            else {
                position.current += ticksPast*playSpeed;
            }

            if(sourceType == MRSRC_DVB || (position.current < position.end && playSpeed != 0)) {
                produceEvent( boost::bind(&MediaRouterEventListener::PositionChangeEvent, _1, position) );
            }
            else if(position.current >= position.end){
                // XXX Scope for 2x play speed change signals
                setPlaySpeedInt(0,false);
                produceEvent( boost::bind(&MediaRouterEventListener::StatusEvent, _1, StatusEventValue::complete) );
                mrState = MR_COMPLETED;
            }
            break;
        }
        case MR_COMPLETED: {
            NICKEL_DEBUG("MR_COMPLETED");
            // nothing to do?
            break;
        }
        default:
            NICKEL_ERROR("Should not get here");
    }

    // XXX is this right - means buffer will be irrelevent?
    if(sourceType != MRSRC_DVB) {
        // XXX do we still buffer if playing has finished?
        // XXX other interalated cases?
        switch(mrBufferState) {
            case MRB_CREATED:
                // Nothing to do
                break;
            case MRB_STARTED: {
                // Send started event
                NICKEL_DEBUG("MRB_STARTED");
                produceEvent( boost::bind(&MediaRouterEventListener::BufferStatusEvent, _1, BufferStatusEventValue::buffering_started) );
                mrBufferState = MRB_BUFFERING;
                break;
            }
            case MRB_BUFFERING: {
                // Send started event
                NICKEL_DEBUG("MRB_BUFFERING");
                NICKEL_DEBUG("bufferedBytes "<<buffer.bufferedBytes<<" arrivalBytesPerSecond "<<buffer.arrivalBytesPerSecond);
                buffer.bufferedBytes += buffer.arrivalBytesPerSecond;
                buffer.totalBytesRemaining = buffer.totalStreamBytes - buffer.bufferedBytes;
                buffer.bufferedMilliseconds += 1000;
                if(buffer.totalBytesRemaining <= 0) {
                    produceEvent( boost::bind(&MediaRouterEventListener::BufferStatusEvent, _1, BufferStatusEventValue::buffering_complete) );
                    mrBufferState = MRB_COMPLETED;
                }
                break;
            }
            case MRB_COMPLETED: {
                NICKEL_DEBUG("MRB_COMPLETED");
                // nothing to do?
                break;
            }
            default:
                NICKEL_ERROR("Should not get here");
        }
    }

    doRestrictedMode();
    doSignalStrength();
}

void FakeMediaRouter::doSignalStrength() {
//    NICKEL_FUNC_DEBUG;
    std::string fileName = NS_ZINC::getMutableDataPath() + "send_signal_strength_signal";

	// NICKEL_DEBUG("Checking for signal strength file " << fileName);

    // stat file
    bool update = false;
    struct stat fileStat;
    if(::stat(fileName.c_str(), &fileStat) == 0)
    {
		NICKEL_DEBUG("Found signal strength file " << fileName);
        NICKEL_DEBUG("fileStat.st_mtime "<<fileStat.st_mtime<<" ssPrevTime "<<ssPrevTime);
        if(fileStat.st_mtime != ssPrevTime)
        {
            ssPrevTime = fileStat.st_mtime;
            ssStarted = true;
            update = true;
        }
    }
    else
    {
//		NICKEL_DEBUG("No signal strength file found " << fileName);
//        NICKEL_DEBUG("No file stopping any events");
        ssStarted = false;
        ssState = MRS_GOOD;
    }

    if(update)
    {
        NICKEL_DEBUG("Updating test configuration");
        std::ifstream inFile(fileName.c_str());
        if(inFile.is_open())
        {
            // Format
            // <state_to_signal> <repeat_interval> <increment_state>
            // Examples
            // Start at 0, send signal every second, increment state - same as empty file
            // 0 1 1
            // Start at 1, send every 2 seconds, do not increment
            // 1 2 0
            // Start at 2, send every 2, do not increment
            // 2 2
            // Start at 0, send single signal
            // 0
            // Behaviour
            // If empty file increment and send signal every second
            // If only state specified a single signal of that state will be sent
            // If state and interval then signal of that state will be sent every interval
            // If all three parameters, if increment_state == 1 then the state will increment
            int const bufSize = 128;
            char buf[bufSize];
            memset(buf,0,bufSize);
            inFile.getline(buf,bufSize);

            int32_t readState = -1;
            int32_t readInterval = -1;
            int32_t tmpIncrement = 0;

            NICKEL_DEBUG("buf \""<<buf<<"\"");
            std::string line(buf);
            if(!line.empty())
            {
                std::istringstream iss;
                iss.str(line);
                iss>>readState>>readInterval>>tmpIncrement;
                NICKEL_DEBUG("readState "<<readState<<" readInterval "<<readInterval<<" tmpIncrement "<<tmpIncrement);
            }

            if(readState == -1)
            {
                readState = MRS_GOOD;
                readInterval = 1;
                tmpIncrement = 1;
            }
            else if(readInterval == -1)
            {
                tmpIncrement = 0;
            }

            ssState = static_cast<MRSignalStrength>(readState);
            ssInterval = readInterval;
            if(ssInterval == -1)
            {
                ssTicksToNextEvent = 0;
            }
            else
            {
                ssTicksToNextEvent = ssInterval-1;
            }

            if(tmpIncrement == 1)
            {
                ssIncrement = true;
            }
            else
            {
                ssIncrement = false;
            }

            inFile.close();
            NICKEL_DEBUG("ssState "<<ssState<<" ssInterval "<<ssInterval<<" ssIncrement "<<ssIncrement);
        }
    }
    else
    {
        // Carry on as instructed
        if(ssStarted)
        {
            NICKEL_DEBUG("ssTicksToNextEvent "<<ssTicksToNextEvent);
            if(ssTicksToNextEvent == 0)
            {
                ssTicksToNextEvent = ssInterval;
                if(ssIncrement)
                {
                    switch(ssState) {
                        case MRS_NONE:
                            signalQuality = "100";
                            ssState = MRS_GOOD;
                            break;
                        case MRS_GOOD:
                        default:
                            signalQuality = "0";
                            ssState = MRS_NONE;
                            break;
                    }
                }

                NICKEL_DEBUG("Sending signal "<<ssState);
                produceEvent( boost::bind(&MediaRouterEventListener::SourceEvent, _1, SourceEventValue::source_information_change, SetSourceReason::unspecified) );
            }

        }
        if(ssTicksToNextEvent > -1) ssTicksToNextEvent--;
    }
}

inline Position FakeMediaRouter::getPosition() const
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    return position;
}

inline void FakeMediaRouter::setSource(std::string const &mediaLocator_, const SetSourceReason::Enum reason_) {
    NICKEL_FUNC_TRACE;

    if(mediaLocator_ == "TestThrowIllegalReconfiguration")
    {
        NICKEL_DEBUG("Testing exception, throwing IllegalReconfiguration");
        throw IllegalReconfiguration();
    }

    std::string::size_type idx = mediaLocator_.find("dvb://");
    NICKEL_DEBUG("idx "<<idx);
    boost::mutex::scoped_lock lock(mrMutex);
    {
        if(idx == 0) {
            sourceType = MRSRC_DVB;
        }
        else {
            sourceType = MRSRC_OTHER;
        }

        mediaLocator = mediaLocator_;
        NICKEL_DEBUG("mediaLocator "<<mediaLocator);
        if(sourceType == MRSRC_DVB) {
            // These values need to be set specifically for this case
            position.start = 0;
            position.current = 0;
            position.end = 0;
            buffer.bufferedBytes = 0;
            buffer.totalBytesRemaining = 0;
            buffer.totalStreamBytes = 0;
            buffer.bufferedMilliseconds = 0;
        }

        // Set play speed to 1
        playSpeed = 1000;
    }

    produceEvent(  boost::bind(&MediaRouterEventListener::SourceEvent, _1, SourceEventValue::change_initiated,reason_) );
    produceEvent( boost::bind(&MediaRouterEventListener::SourceEvent, _1, SourceEventValue::change_complete,reason_) );
}

void FakeMediaRouter::setAudioTrack(const int32_t tag) {
    NICKEL_FUNC_TRACE;

    boost::mutex::scoped_lock lock(mrMutex);
    audioTrack.tag = tag;
}

Track FakeMediaRouter::getAudioTrack() const
{
    NICKEL_FUNC_TRACE;

    boost::mutex::scoped_lock lock(mrMutex);
    return audioTrack;
}

void FakeMediaRouter::setSubtitleTrack(const int32_t tag, const std::string& language)
{
    NICKEL_FUNC_TRACE;

    boost::mutex::scoped_lock lock(mrMutex);
    subtitleTrack.tag = tag;
    subtitleTrack.language = language;
}

Track FakeMediaRouter::getSubtitleTrack() const
{
    NICKEL_FUNC_TRACE;

    boost::mutex::scoped_lock lock(mrMutex);
    return subtitleTrack;
}

inline void FakeMediaRouter::setSink(std::string const &sink_)
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    sink = sink_;
    // XXX Send SinkEvent?
}

inline void FakeMediaRouter::setPlaySpeedInt(const int32_t playSpeed_,bool lock_) {
    NICKEL_FUNC_TRACE;
    if(lock_) mrMutex.lock();
    playSpeed = playSpeed_;
    NICKEL_DEBUG("playSpeed "<<playSpeed);

    if((!(playSpeed > 1000 && position.end == position.current)) ||
       (!(playSpeed < 0 && position.start == position.current))) {
        produceEvent( boost::bind(&MediaRouterEventListener::SpeedChangeEvent, _1) );
    }
    else {
        NICKEL_DEBUG("Doing DVB, current pos at end of buffer cannot increase play speed");
    }
    if(lock_) mrMutex.unlock();
}

inline void FakeMediaRouter::setPlaySpeed(double speed_)
{
    NICKEL_FUNC_TRACE;
    double tmpSpeed = speed_ * 1000;
    if(tmpSpeed >= 0) {
        tmpSpeed += 0.5;
    }
    else {
        tmpSpeed -= 0.5;
    }
    NICKEL_DEBUG("speed_ "<<speed_<<" tmpSpeed "<<tmpSpeed);

    setPlaySpeedInt(static_cast<int32_t>(tmpSpeed),true);
}

inline double FakeMediaRouter::getPlaySpeed() const
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    NICKEL_DEBUG("playSpeed "<<playSpeed);
    return (double(playSpeed)/1000);
}

void FakeMediaRouter::seekPosition(const SeekReference::Enum whence, const int32_t offset, const SeekMode::Enum /*mode*/)
{
    NICKEL_FUNC_TRACE;

    NICKEL_DEBUG("whence "<<whence<<" offset "<<offset);

    boost::mutex::scoped_lock lock(mrMutex);
    if(whence == SeekReference::start) {
        position.current = position.start + offset;
    } else if(whence == SeekReference::current) {
        position.current = position.current + offset;
    } else if(whence == SeekReference::end) {
        position.current = position.end + offset;
    }

    if(position.current > position.end) {
        NICKEL_DEBUG("Seeked passed end of the content");
        position.current = position.end;
    }
    NICKEL_DEBUG("position.current "<<position.current);
}

inline std::string FakeMediaRouter::getSource() const
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    return mediaLocator;
}

inline std::string FakeMediaRouter::getSink() const
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    return sink;
}

void FakeMediaRouter::setEndTime(const int32_t end)
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    position.end = end;
}

inline int32_t FakeMediaRouter::getEndTime() const
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    return position.end;
}

inline void FakeMediaRouter::start() {
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    if(mrState == MR_CREATED) {
        mrState = MR_STARTED;
    }
    else {
        NICKEL_DEBUG("Router already started current state ("<<mrState<<")");
    }
}

inline void FakeMediaRouter::startDeferred() {
    NICKEL_FUNC_TRACE;
    start();
}

inline void FakeMediaRouter::stop() {
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);

    if(sourceType == MRSRC_DVB) {
        // Throw away the buffer
        position.start = 0;
        position.current = 0;
        position.end = 0;
    }
    else {
        position.current = position.start;
    }

    // This allows the router to be restarted
    mrState = MR_CREATED;
}

void FakeMediaRouter::doRestrictedMode()
{
//    NICKEL_FUNC_TRACE;
    // Read value of 'restricted_mode' from the config file.
    int32_t newRestrictedMode=0;
    try
    {
        std::string mediaRouterConfigFile = NS_ZINC::PackageDataFinder().find("media_router_config.txt");
        std::ifstream config(mediaRouterConfigFile.c_str());
        if(config.is_open()) {
//            NICKEL_DEBUG("Parsing config file: " << mediaRouterConfigFile << " for >>restricted_mode<< value.");
            std::string line;
            while(!config.eof()) {
                getline(config,line);
//                NICKEL_DEBUG("line \""<<line<<"\"");
                std::string::size_type idx = line.find('=');
                if(idx != std::string::npos) {
                    std::string key = line.substr(0,idx);
                    std::string value = line.substr(idx+1);
//                    NICKEL_DEBUG("key "<<key<<" value "<<value);
                    if(key == "restricted_mode") {
                    	std::istringstream iss;
                    	iss.str(value);
                    	iss >> newRestrictedMode;
                    }else if(key == "restricted_mode_services"){
                        std::istringstream iss;
                        iss.str(value);
//                        NICKEL_DEBUG("restricted_mode_services = " << value );
                        size_t startpos = value.find_first_not_of(" \t");
                        size_t endpos = value.find_last_not_of(" \t");
                        if((std::string::npos == startpos) || (std::string::npos == endpos)){
                            restrictedModeServiceList = "";
                        }else{
                            restrictedModeServiceList = value.substr(startpos, endpos-startpos+1);
                        }
                    }
                }
            }
        }
        config.close();
    }
    catch (NS_ZINC::ResourceNotFoundException& e)
    {
        // Config file does not exist is not an error
        NICKEL_DEBUG("Not loading config file: " << e.what());
        return;
    }
    // Incorrect value in the config file.
    if(newRestrictedMode!=0 && newRestrictedMode!=1)
    {
    	NICKEL_DEBUG("Incorrect value for >>restricted_mode<<. Usage: 0 - OFF, 1 - ON.");
    	return;
    }
    // No change for restricted mode.
    if(newRestrictedMode==restrictedMode)
    {
    	return;
    }
    // Turn on/off the restricted mode and send the signal.
    restrictedMode=newRestrictedMode;
    NICKEL_DEBUG("Sending signal "<<ssState);

	produceEvent( boost::bind(&MediaRouterEventListener::SourceEvent, _1, SourceEventValue::source_information_change, SetSourceReason::unspecified) );
}

std::map<std::string,std::string> FakeMediaRouter::getSourceInformation() const
{
	NICKEL_FUNC_TRACE;

	std::map<std::string,std::string> info;
    boost::mutex::scoped_lock lock(mrMutex);
    info["QUALITY"] = signalQuality;
    info["STRENGTH"] = "100";

    if(restrictedMode!=0)
    {
        if(!restrictedModeServiceList.empty())
            info["RESTRICTED_SERVICE_SET"] = restrictedModeServiceList;
        else
            info["RESTRICTED_SERVICE_SET"] = "dvb://233a..1044 dvb://233a..1084";
    }

    if(createTestRTPStats)
    {
    	info["POST_REPAIR_OUTPUTS"] = std::string("1000");
    	info["POST_REPAIR_LOSSES"] = std::string("10");
    }
    return info;
}

BufferStatus FakeMediaRouter::getBufferStatus() const
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    return buffer;
}

void FakeMediaRouter::startBuffering()
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
    mrBufferState = MRB_STARTED;
}

void FakeMediaRouter::stopBuffering()
{
    NICKEL_FUNC_TRACE;
    boost::mutex::scoped_lock lock(mrMutex);
// XXX     mrBufferState = MRB_???;
}

void FakeMediaRouter::setVolume(const int32_t /*volume*/)
{
    NICKEL_FUNC_DEBUG;
}

int32_t FakeMediaRouter::getVolume() const
{
    NICKEL_FUNC_DEBUG;
    return 0;
}

void FakeMediaRouter::setAudioTrackExternal(const std::string& /*mediaLocator*/, const int32_t /* tag */) {
    NICKEL_FUNC_DEBUG;
}

void FakeMediaRouter::setVideoTrack(const int32_t tag) {
    NICKEL_FUNC_TRACE;

    boost::mutex::scoped_lock lock(mrMutex);
    videoTrack.tag = tag;
    switch (tag)
    {
        case 265:
            videoTrack.format = TrackFormat::video_h265;
            break;
        case 264:
            videoTrack.format = TrackFormat::video_h264;
            break;
        default:
            videoTrack.format = TrackFormat::other;
            break;
    }
}

void FakeMediaRouter::setVideoTrackExternal(const std::string& /*mediaLocator*/, const int32_t /*tag*/) {
    NICKEL_FUNC_DEBUG;
}

Track FakeMediaRouter::getVideoTrack() const
{
    NICKEL_FUNC_DEBUG;
    return videoTrack;
}

int32_t FakeMediaRouter::addSubtitleTrack(const std::string& /*subtitleLocator*/) {
    NICKEL_FUNC_DEBUG;
    return 0;
}

std::vector<Track> FakeMediaRouter::getTracks() const
{
    NICKEL_FUNC_DEBUG;
    return std::vector<Track>();
}

void FakeMediaRouter::setVideoWindow(const VideoWindowDescriptor& videoWindow_) {
    NICKEL_FUNC_DEBUG;
    videoWindow = videoWindow_;
}

VideoWindowDescriptor FakeMediaRouter::getVideoWindow() const
{
    NICKEL_FUNC_DEBUG;
    return videoWindow;
}

ControlCapabilities FakeMediaRouter::getControlCapabilities() const
{
    NICKEL_FUNC_DEBUG;
    return ControlCapabilities();
}

void FakeMediaRouter::setBufferingMode(const std::map<std::string,std::string>& bufferingMode)
{
	NICKEL_FUNC_DEBUG;

	std::map<std::string,std::string>::const_iterator it = bufferingMode.find(BufferMode::BUFFER_CONSTRAINT);
	if ( it != bufferingMode.end() )
	{
		std::string s = it->second;
		if ( ! enum_from_string( bufferConstraint, s.c_str() ) )
		{
			bufferConstraint = BufferConstraint::threshold;    // revert to default if supplied value is not valid
		}
	}

	/**
	 * There is a wrinkle in here.
	 *
	 * We define "repeat" instead of "default" as the default ABR mode (because "default" clashes with the the C++ keyword)
	 *
	 * However, the resulting behaviour of our enum marshaling implementation is aligned with the spec because of the clause regarding unrecognised values.
	 */
	std::map<std::string,std::string>::const_iterator it2 = bufferingMode.find(BufferMode::ADAPTIVE_MODE);
	if ( it2 != bufferingMode.end() )
	{
		std::string s = it2->second;
		if ( ! enum_from_string( adaptiveMode, s.c_str() ) )
		{
			adaptiveMode = AdaptiveMode::repeat;    // revert to default if supplied value is not valid
		}
	}

}

std::string getAdaptiveMode(AdaptiveMode::Enum am)
{
	if ( am == AdaptiveMode::repeat )
		return "default";
	return enum_to_string(am);
}

std::map<std::string,std::string> FakeMediaRouter::getBufferingMode() const
{
    NICKEL_FUNC_DEBUG;
    std::map<std::string,std::string> bm;
    bm[BufferMode::BUFFER_CONSTRAINT] = enum_to_string(bufferConstraint);
    bm[BufferMode::ADAPTIVE_MODE] = getAdaptiveMode( adaptiveMode );
    return bm;
}

void FakeMediaRouter::setVideoTerminationMode(const VideoTerminationMode::Enum mode)
{
    NICKEL_FUNC_DEBUG;
    if (mode == VideoTerminationMode::freeze )
    	return;
    if (mode == VideoTerminationMode::disappear )
    	return;
    throw std::invalid_argument("Invalid enumerator.");
}

VideoTerminationMode::Enum FakeMediaRouter::getVideoTerminationMode() const
{
    NICKEL_FUNC_DEBUG;
    return VideoTerminationMode::freeze;
}

void FakeMediaRouter::setMediaDuration(const int32_t /*end*/)
{
    NICKEL_FUNC_DEBUG;
}

int32_t FakeMediaRouter::getMediaDuration() const
{
    NICKEL_FUNC_DEBUG;
    return 3600;
}

ABRStreamSet FakeMediaRouter::getABRStreamSet() const
{
    NICKEL_FUNC_DEBUG;
    return ABRStreamSet();
}

ABRStatus FakeMediaRouter::getABRStatus() const
{
    NICKEL_FUNC_DEBUG;
    return ABRStatus();
}

void FakeMediaRouter::setABRStream(const int32_t /*index*/,const bool /*deferred*/)
{
    NICKEL_FUNC_DEBUG;
}

void FakeMediaRouter::setCaptureMode(const TimeShiftCaptureMode::Enum /*mode*/)
{
    NICKEL_FUNC_DEBUG;
}

TimeShiftCaptureMode::Enum FakeMediaRouter::getCaptureMode() const
{
    NICKEL_FUNC_DEBUG;
    return TimeShiftCaptureMode::disabled;
}

void FakeMediaRouter::recycle()
{
    NICKEL_FUNC_DEBUG;
    boost::mutex::scoped_lock lock(mrMutex);
    FakeMediaRouter().swapFakeMediaRouter(*this);
}

NS_NICKEL_SYSTEM_CLOSE

