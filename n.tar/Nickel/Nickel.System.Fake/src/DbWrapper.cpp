/*
 * DbWrapper.cpp
 *
 *  Created on: 20 June, 2011
 *      Author: milton.mukhopadhyay@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */

#include "DbWrapper.h"
#include <boost/make_shared.hpp>
#include <boost/algorithm/string/replace.hpp>
#include <string>
#include <vector>
#include <stdexcept>

#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/nickel-system-api.h>

NS_NICKEL_SYSTEM_OPEN

using std::string;
using boost::make_shared;
using std::vector;



DbWrapper::DbWrapper(string const& dbPath)
{
  sqlite3* db = NULL;
  int result = sqlite3_open(dbPath.c_str(), &db);
  if (result != SQLITE_OK)
  {
      throw S3Error("sqlite3_open failed.");
  }
  dbHandle = DbPtr(db, sqlite3_close);
  selectStmt = boost::make_shared<SqlStatement>(this, 
          string("select * from mediarecords"));  
}

vector<DbWrapper::StrStrMap> DbWrapper::selectAll() const
{
    vector<StrStrMap> recs;

    for(selectStmt->begin(); selectStmt->isValid(); selectStmt->next())
    {
        recs.push_back(getOneRecord(selectStmt));
    }
    const char* msg = sqlite3_errmsg(dbHandle.get());
    if(msg)
    {
        NICKEL_DEBUG("Message from Sqlite:" << string(msg));
    }
    NICKEL_DEBUG("number of records:" << recs.size());
    return recs;
}


DbWrapper::StrStrMap DbWrapper::getOneRecord(StatementPtr stmt) const
{
    sqlite3_stmt* sqliteStmt = stmt->getSqliteHandle().get();
    int colNum = sqlite3_column_count(sqliteStmt);
    StrStrMap rec;
    while(colNum--)
    {
        string name = sqlite3_column_name(sqliteStmt, colNum);
        unsigned const char* sqlval = sqlite3_column_text(sqliteStmt, colNum);
        string val;
        if(sqlval)
        {
            val = string(reinterpret_cast<const char*>(sqlval));
            int sqliteType = sqlite3_column_type(sqliteStmt, colNum);
        }
        rec[name] = val;
    }
    return rec;
}

S3Error::S3Error(char const* msg) : 
    std::runtime_error(msg)
{
}

S3Error::S3Error(const DbWrapper& db) : 
    std::runtime_error(sqlite3_errmsg(db.getHandle().get()))
{
}


NS_NICKEL_SYSTEM_CLOSE
