/*
 * DbWrapper.h
 *
 *  Created on: 20 June, 2011
 *      Author: milton.mukhopadhyay@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */
#ifndef SQL_STATEMENT_H
#define SQL_STATEMENT_H

#include <sqlite3.h>
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include <map>
#include <stdint.h>
#include <boost/utility.hpp>

#include <nickel-system-api/nickel-system-api.h>

NS_NICKEL_SYSTEM_OPEN

class DbWrapper;
/** todo : use iterator_facade to turn it into a proper iterator **/
class SqlStatement : boost::noncopyable
{
    public:
        typedef boost::shared_ptr<sqlite3_stmt> StmtPtr;

        SqlStatement(const DbWrapper* db, const std::string& query);
        ~SqlStatement();
        void begin();
        bool next();
        bool isValid() const
        {
            return state == VALID;
        }
        StmtPtr getSqliteHandle() const
        {
            return stmt;
        }
    private:
        enum State_t{ VALID = 0, INVALID };
        State_t state;
        StmtPtr stmt;
};

NS_NICKEL_SYSTEM_CLOSE

#endif //SQL_STATEMENT_H
