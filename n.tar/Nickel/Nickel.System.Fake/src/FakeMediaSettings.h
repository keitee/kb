/*
 * FakeMediaSetttings.h
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKEMEDIASETTTINGS_H_
#define NICKEL_SYSTEM_FAKE_FAKEMEDIASETTTINGS_H_

#include <nickel-system-api/nickel-system-api.h>

NS_NICKEL_SYSTEM_OPEN

class FakeMediaSettings
	:	public virtual NS_NICKEL_SYSTEM::MediaSettings {

public:
	FakeMediaSettings();
	virtual ~FakeMediaSettings();
public:
	virtual NS_ZINC::Future<bool> getADEnabled() const;
	virtual NS_ZINC::Future<void> setADEnabled(const bool value);
	virtual NS_ZINC::Future<bool> getSubtitlesEnabled() const;
	virtual NS_ZINC::Future<void> setSubtitlesEnabled(const bool value);
	virtual NS_ZINC::Future<std::string> getPreferredAudioLanguage() const;
	virtual NS_ZINC::Future<void> setPreferredAudioLanguage(const std::string& value);
	virtual NS_ZINC::Future<std::string> getPreferredSubtitleLanguage() const;
	virtual NS_ZINC::Future<void> setPreferredSubtitleLanguage(const std::string& value);

private:
	void signalChange();

private:
	bool adEnabled;
	bool subtitlesEnabled;
    std::string preferedAudioLanguage;
    std::string preferedSubtitleLanguage;

};	// class FakeMediaSettings

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_FAKE_FAKEMEDIASETTTINGS_H_ */
