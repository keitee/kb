/* Copyright (C) 2009 British Broadcasting Corporation */
/*
 * FakeSystemFactory.cpp
 *
 *  Created on: 24-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 */

#include "FakeLocalMediaLibrary.h"
#include "FakeSystemFactory.h"
#include "FakeMediaRouterFactory.h"
#include "FakeMediaRouter.h"
#include "FakeMediaSettings.h"
#include "FakeOutputManager.h"
#include "FakeOutputManagerState.h"
#include "FakeServiceListBuilder.h"

#include <nickel-common/NickelLogger.h>

#include <zinc-common/async/SequentialFutureDispatcher.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <nickel-system-api/MediaRouterConvertToAsync.h>
#include <nickel-system-api/MediaRouterFactoryConvertToAsync.h>
#include <nickel-system-api/OutputManagerConvertToAsync.h>
#include <nickel-system-api/ServiceListBuilderConvertToAsync.h>

#include <yaml-cpp/yaml.h>

#include <fstream>
//#include <stdio.h>


using boost::shared_ptr;
using namespace NS_NICKEL_SYSTEM;
using namespace NS_ZINC;

namespace
{
#if 0 // currenlty not used (commented out)
    void createFakeOutputManagerOutputs(AudioOutputsState& outputs)
    {
        AudioOutputState first;
        first.id = 0;
        first.outType = AudioOutputType::analogue_scart;
        first.formats.push_back(AudioFormat::analogue);
        first.formatPreference = AudioFormat::analogue;
        first.delay = 0;
        first.delaySupported = false;
        outputs.push_back(first);

        AudioOutputState second;
        second.id = 1;
        second.outType = AudioOutputType::hdmi;
        second.formats.push_back(AudioFormat::pcm_2ch);
        second.formats.push_back(AudioFormat::pcm_5_1);
        second.formats.push_back(AudioFormat::dts);
        second.formatPreference = AudioFormat::pcm_2ch;
        second.delay = 0;
        second.delaySupported = true;
        outputs.push_back(second);

        AudioOutputState third;
        third.id = 4;
        third.outType = AudioOutputType::spdif;
        third.formats.push_back(AudioFormat::pcm_2ch);
        third.formats.push_back(AudioFormat::pcm_5_1);
        third.formatPreference = AudioFormat::pcm_5_1;
        third.delay = 0;
        third.delaySupported = true;
        outputs.push_back(third);
    };
#endif
}; // anonymous namespace

FakeSystemFactory::FakeSystemFactory( const bool temp ) : temp( temp ) {
    futureDispatcher.reset(new NS_ZINC::SequentialFutureDispatcher());
    actionProcessor = boost::make_shared<ActionProcessor>();
    actionProcessor->start();
}

shared_ptr<LocalMediaLibrary> FakeSystemFactory::createLocalMediaLibrary()  {
	shared_ptr<LocalMediaLibrary> localMediaLibraryService;
// XXX 	if( temp )
// XXX 	{
// XXX 	    // If we make an in memory local media library, we need to create and populate
// XXX 	    // the tables every time
// XXX 	    std::string filename(tmpnam(NULL));
// XXX 	    shared_ptr<FakeLocalMediaLibrary> library(new FakeLocalMediaLibrary(filename));
// XXX 	    library->createTables();
// XXX 	    library->populateTables();
// XXX 
// XXX 	    localMediaLibraryService = boost::dynamic_pointer_cast<LocalMediaLibrary>(library);
// XXX 	}
// XXX 	else
// XXX 	{
        if(!lml)
        {
            lml.reset(new FakeLocalMediaLibrary(futureDispatcher));
            lml->setDispatcher(createDispatcher());
        }
        localMediaLibraryService = lml;
// XXX 	}

	return localMediaLibraryService;
}

shared_ptr<MediaRouterFactory> FakeSystemFactory::createMediaRouterFactory()  {
	boost::shared_ptr<MediaRouterFactorySync> mrf_sync( new FakeMediaRouterFactory(futureDispatcher, actionProcessor) );

	shared_ptr<MediaRouterFactory> mediaRouterService( convertToAsync(mrf_sync, *actionProcessor) );
	return mediaRouterService;
}

shared_ptr<MediaSettings> FakeSystemFactory::createMediaSettings()  {
	shared_ptr<MediaSettings> mediaSettingsService(shared_ptr<MediaSettings>(new FakeMediaSettings()));
	mediaSettingsService->setDispatcher(createDispatcher());
	return mediaSettingsService;
}

shared_ptr<OutputManager> FakeSystemFactory::createOutputManager()  
{
    NICKEL_FUNC_TRACE;

    // create fake data
    std::auto_ptr<FakeOutputManagerState> state(new FakeOutputManagerState);

    try
    {
        // look for configuration file
        PackageDataFinder finder;
        std::string path = finder.find("fakeoutputmanager.yaml");

        // load it from yaml file
        std::ifstream input(path.c_str());

        // get document and parse it
        YAML::Node document = YAML::Load(input);
        *state = document.as<FakeOutputManagerState>();
    }
    catch(const ResourceNotFoundException& exc)
    {
        NICKEL_ERROR(exc.what());
    }
    catch(const YAML::Exception& exc)
    {
        NICKEL_ERROR(exc.what());
    };

//    createFakeOutputManagerOutputs(state->audioOutputs);

    boost::shared_ptr<OutputManagerSync> om_sync(new FakeOutputManager(state));
    boost::shared_ptr<OutputManager> om = convertToAsync(om_sync, *actionProcessor);
    om->setDispatcher(createDispatcher());
	return om;
}

shared_ptr<ServiceListBuilder> FakeSystemFactory::createServiceListBuilder()  {
    if(!slb)
    {
    	boost::shared_ptr<ServiceListBuilderSync> slb_sync( new FakeServiceListBuilder() );
    	slb_sync->setDispatcher(createDispatcher());
        slb = convertToAsync(slb_sync, *actionProcessor);
    }
	return slb;
}

shared_ptr<MediaRouter> FakeSystemFactory::createDefaultMediaRouter()  {
    boost::shared_ptr<MediaRouter> dmr = defaultMediaRouter.lock();
    if(!dmr)
    {
        boost::shared_ptr<MediaRouterSync> dmr_sync = createFakeMediaRouter();
        dmr_sync->setDispatcher(createDispatcher());
        dmr_sync->setSink("decoder://0");
        dmr_sync->setSource("dvb://233a..1044", SetSourceReason::unspecified);
        dmr_sync->start();
        dmr = convertToAsync(dmr_sync, *actionProcessor);
        defaultMediaRouter = dmr;
    }
    return dmr;
}

shared_ptr<EventDispatcher> FakeSystemFactory::createDispatcher() {
	shared_ptr<EventDispatcher> dispatcher(new MultipleListenerEventDispatcher());
	return dispatcher;
}

Plugin *createFakeSystemFactory() {
	return new FakeSystemFactory(false) ;
}

Plugin *createFakeSystemFactoryTemp() {
    return new FakeSystemFactory(true) ;
}
