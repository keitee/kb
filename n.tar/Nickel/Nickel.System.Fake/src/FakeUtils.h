/*
 * FakeUtils.h
 *
 *  Created on: 20 June, 2011
 *      Author: milton.mukhopadhyay@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */
#ifndef FAKE_UTILS_H
#define FAKE_UTILS_H

#include <string>
#include <map>
#include <boost/tuple/tuple.hpp>

#include <nickel-system-api/nickel-system-api.h>


NS_NICKEL_SYSTEM_OPEN

/**
 * Bunch of static string utility functions.
 */
class FakeUtils
{
    public:
        typedef std::map<std::string, std::string> StrStrMap;
        static boost::tuple<std::string, int>
            extractWrappedContent(std::string wrapped, char beg, char end);
        static boost::tuple<std::string, std::string> 
            splitToKeyVal(std::string str);
        static StrStrMap parseToMap(std::string str);
};


NS_NICKEL_SYSTEM_CLOSE

#endif //FAKE_UTILS_H
