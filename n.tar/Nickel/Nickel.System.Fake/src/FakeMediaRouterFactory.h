/*
 * FakeMediaRouterFactory.h
 *
 *  Created on: 13-Aug-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 */

#ifndef NICKEL_SYSTEM__FAKE_MEDIA_ROUTER_FACTORY_H_
#define NICKEL_SYSTEM__FAKE_MEDIA_ROUTER_FACTORY_H_

#include "FakeSystemFactory.h"
#include <nickel-system-api/nickel-system-api.h>
#include <boost/shared_ptr.hpp>
#include <boost/noncopyable.hpp>
#include <set>
#include <zinc-common/ActionProcessor.h>

NS_NICKEL_SYSTEM_OPEN

class FakeMediaRouterFactory : virtual public MediaRouterFactorySync, boost::noncopyable {
public:
    FakeMediaRouterFactory(boost::shared_ptr<NS_ZINC::FutureDispatcher> futureDispatcher_, boost::shared_ptr<NS_ZINC::ActionProcessor> actionProcessor_);
    virtual ~FakeMediaRouterFactory();

    virtual boost::shared_ptr<MediaRouter> createMediaRouter();
private:
    boost::shared_ptr<NS_ZINC::FutureDispatcher> futureDispatcher;
    boost::shared_ptr<NS_ZINC::ActionProcessor> actionProcessor;
};

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM__FAKE_MEDIA_ROUTER_FACTORY_H_ */
