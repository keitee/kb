/*
 * FakeOutputManagerState.h
 *
 *  Created on: Jun 21, 2011
 *      Author: Zbigniew Mandziejewicz
 *
 *   Copyright (C) 2011 YouView TV
 */

#ifndef NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGERSTATE_H_
#define NICKEL_SYSTEM_FAKE_FAKEOUTPUTMANAGERSTATE_H_

#include <nickel-system-api/nickel-system-api.h>

#include <yaml-cpp/yaml.h>
#include <boost/preprocessor/seq/for_each.hpp>
#include <vector>

NS_NICKEL_SYSTEM_OPEN

struct AudioOutputState
{
    uint32_t id;
    AudioOutputType::Enum outType;
    std::vector<AudioFormat::Enum> formats;
    AudioFormat::Enum formatPreference;
    int32_t delay;
    bool delaySupported;
};

typedef std::vector<AudioOutputState> AudioOutputsState;

struct FakeOutputManagerState
{
    FakeOutputManagerState();

	DisplayType::Enum primaryDisplayPreference;

	DisplayResolution::Enum hdmiResolutionPreference;
	std::vector<DisplayResolution::Enum> hdmiResolutions;
	HDCPPreference::Enum hdcpPreference;
	HDMIStatus::Enum hdmiStatus;
	bool hdmiStandby;

	AspectRatio::Enum analogueAspectRatio;
	VideoStandard::Enum analogueVideoStandard;
	ColourMode::Enum analogueColourMode;

	VideoConversions videoConversionsPreference;
	AudioOutputsState audioOutputs;

	uint32_t volume;
	bool volumeMuted;
    int32_t relativeADVolume;
    ADRouting::Enum adRouting;

	bool outputsEnabled;
};

NS_NICKEL_SYSTEM_CLOSE

namespace YAML
{

class Node;
template<>
struct convert<NS_NICKEL_SYSTEM::FakeOutputManagerState>
{
    static bool decode(const Node& node, NS_NICKEL_SYSTEM::FakeOutputManagerState& rhs);
};

};

#endif
