/*
 * FakeMediaSettins.cpp
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#include "FakeMediaSettings.h"
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-common/async/async-helpers.h>

#include <stdexcept>
#include <string>

using namespace NS_ZINC;
using namespace NS_NICKEL_SYSTEM;

FakeMediaSettings::FakeMediaSettings()
	:	adEnabled(false)
	,	subtitlesEnabled(false) {
	NICKEL_FUNC_TRACE;
}

FakeMediaSettings::~FakeMediaSettings() {
	NICKEL_FUNC_TRACE;
}

NS_ZINC::Future<bool> FakeMediaSettings::getADEnabled() const
{
	NICKEL_FUNC_TRACE;
	return completedFuture(adEnabled);
}

NS_ZINC::Future<void> FakeMediaSettings::setADEnabled(const bool value) {
	NICKEL_FUNC_TRACE;

	NICKEL_DEBUG("Setting adEnabled to " << value);

	adEnabled = value;
	signalChange();
	return completedFuture();
}

NS_ZINC::Future<bool> FakeMediaSettings::getSubtitlesEnabled() const
{
	NICKEL_FUNC_TRACE;
	return completedFuture(subtitlesEnabled);
}

NS_ZINC::Future<void> FakeMediaSettings::setSubtitlesEnabled(const bool value) {
	NICKEL_FUNC_TRACE;

	NICKEL_DEBUG("Setting subtitlesEnabled to " << value);

	subtitlesEnabled = value;
	signalChange();
	return completedFuture();
}

NS_ZINC::Future<std::string> FakeMediaSettings::getPreferredAudioLanguage() const
{
	NICKEL_FUNC_TRACE;
	return completedFuture(preferedAudioLanguage);
}

NS_ZINC::Future<void> FakeMediaSettings::setPreferredAudioLanguage(const std::string& value)
{
	NICKEL_FUNC_TRACE;
	NICKEL_DEBUG("Setting preferedAudioLanguage to " << value);
    preferedAudioLanguage = value;
	signalChange();
	return completedFuture();
}

NS_ZINC::Future<std::string> FakeMediaSettings::getPreferredSubtitleLanguage() const
{
	NICKEL_FUNC_TRACE;
	return completedFuture(preferedSubtitleLanguage);
}

NS_ZINC::Future<void> FakeMediaSettings::setPreferredSubtitleLanguage(const std::string& value)
{
	NICKEL_FUNC_TRACE;
	NICKEL_DEBUG("Setting preferedSubtitleLanguage to " << value);
    preferedSubtitleLanguage = value;
	signalChange();
	return completedFuture();
}


void FakeMediaSettings::signalChange() {
	NICKEL_FUNC_TRACE;

	NICKEL_DEBUG("Sending MediaSettingsChange Event");

	produceEvent( bind( &MediaSettingsEventListener::MediaSettingsChange, _1) );
}
