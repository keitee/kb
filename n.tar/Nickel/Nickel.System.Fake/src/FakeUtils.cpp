/*
 * FakeUtils.cpp
 *
 *  Created on: 20 June, 2011
 *      Author: milton.mukhopadhyay@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */

#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/foreach.hpp>
#include <string>
#include <vector>
#include <map>
#include <boost/algorithm/string/replace.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/tuple/tuple.hpp>

#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/nickel-system-api.h>

#include "FakeUtils.h"

using boost::tuple;
using boost::tie;
using boost::make_tuple;
using std::vector;
using std::map;
using std::string;
using std::cout;
using std::endl;

NS_NICKEL_SYSTEM_OPEN
tuple<string, int>
FakeUtils::extractWrappedContent(string wrapped, char beg, char end)
{
    string retstr;
    size_t pos = wrapped.find_first_of(beg);
    if(pos == string::npos)
    {
        //cout << "beg not found." << endl;
        return wrapped;
    }
    size_t cbeg = pos+1;
    pos = wrapped.find_first_of(end, cbeg);
    if(pos == string::npos)
    {
        //cout << "end not found." << endl;
        return wrapped;
    }
    size_t content_len = pos - cbeg;
    if(content_len <= 0)
    {
        //cout << "empty string." << endl;
        return retstr;
    }
    retstr = wrapped.substr(cbeg, content_len);
    //cout << "retstr:" << retstr << endl;
    //the position to be given should skip the end marker
    return boost::make_tuple(retstr, pos +1);
}

/**
 * works with a strict format which is either "key":"value" in which case
 * you could have ':' characters inside key or value
 * or key:val in the second case there shouldnt be a single ':'.
 */
tuple<string, string>
FakeUtils::splitToKeyVal(string str)
{
    string key, val;
    size_t pos;
    size_t maxpos = str.size() - 1;
    //First check if its "key:::key::key":"val::val::val" or key:val
    vector<string> frags;
    boost::split(frags, str, boost::is_any_of(":"));
    if(frags.size() > 2)
    {
        tie(key, pos) = extractWrappedContent(str, '\"','\"');
        if(pos +1 >= maxpos)
        {
            //cout << "key : " << key << endl;
            //cout << "given string : " << str << endl;
            throw std::runtime_error("malformed dict, only key is there.");
        }
        str = str.substr(pos, string::npos);
        tie(val, pos) = extractWrappedContent(str, '\"','\"');
    }
    else if(frags.size() == 2)
    {
        tie(key, boost::tuples::ignore) = extractWrappedContent(frags[0], '\"','\"');
        tie(val, boost::tuples::ignore) = extractWrappedContent(frags[1], '\"','\"');
    }
    else
    {
        throw std::runtime_error("malformed dict, ':' does not split properly.");
    }
    //cout << "key: " << key << endl;
    //cout << "val: " << val << endl;
    return boost::make_tuple(key, val);
}


FakeUtils::StrStrMap FakeUtils::parseToMap(string str)
{
    StrStrMap retmap;
    //extract content
    tie(str, boost::tuples::ignore) = extractWrappedContent(str, '{', '}');
    if(str.empty())
    {
        //cout << "empty map." << endl;
        return retmap;
    }
    //split
    vector<string> frags;
    boost::split(frags, str, boost::is_any_of(","));
    BOOST_FOREACH(string s, frags)
    {
        string key, val;
        boost::trim(s);
        tie(key, val) = splitToKeyVal(s);
        retmap[key] = val;
    }
    return retmap;
}

NS_NICKEL_SYSTEM_CLOSE
