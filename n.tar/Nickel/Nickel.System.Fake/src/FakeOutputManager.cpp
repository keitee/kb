/*
 * FakeOutputManager.cpp
 *
 *  Created on: Mar 2, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#include "FakeOutputManager.h"
#include "FakeOutputManagerState.h"

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/nickel-system-exceptions.h>

#include <nickel-common/NickelLogger.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace NS_ZINC;
using namespace std;

NS_NICKEL_SYSTEM_OPEN

FakeOutputManager::FakeOutputManager():
    _state(new FakeOutputManagerState)
{
    NICKEL_FUNC_TRACE;
}

FakeOutputManager::FakeOutputManager(std::auto_ptr<FakeOutputManagerState> state):
    _state(state)
{
    NICKEL_FUNC_TRACE;
}

FakeOutputManager::~FakeOutputManager() {
	NICKEL_FUNC_TRACE;
}

DisplayType::Enum FakeOutputManager::getPrimaryDisplayPreference() const
{
	NICKEL_FUNC_TRACE;
	return _state->primaryDisplayPreference;
}

void FakeOutputManager::setPrimaryDisplayPreference(const DisplayType::Enum preference)
{
	NICKEL_FUNC_TRACE;
	_state->primaryDisplayPreference = preference;
	DisplayPreferenceChange();
}

DisplayResolution::Enum FakeOutputManager::getHDMIResolutionPreference() const
{
	NICKEL_FUNC_TRACE;
	return _state->hdmiResolutionPreference;
}

void FakeOutputManager::setHDMIResolutionPreference(const DisplayResolution::Enum resolution)
{
	NICKEL_FUNC_TRACE;
	_state->hdmiResolutionPreference = resolution;

	DisplayPreferenceChange();

	if(_state->primaryDisplayPreference == DisplayType::hdmi)
	{
		PrimaryDisplayChange();
	}
}

std::vector<DisplayResolution::Enum> FakeOutputManager::getHDMIResolutionOptions() const
{
	NICKEL_FUNC_TRACE;
	return _state->hdmiResolutions;
}

HDCPPreference::Enum FakeOutputManager::getHDMIHDCPPreference() const
{
	NICKEL_FUNC_TRACE;
	return _state->hdcpPreference;
}

void FakeOutputManager::setHDMIHDCPPreference(const HDCPPreference::Enum preference)
{
	NICKEL_FUNC_TRACE;
	_state->hdcpPreference = preference;
}

HDMIStatus::Enum FakeOutputManager::getHDMIStatus() const
{
	NICKEL_FUNC_TRACE;
	return _state->hdmiStatus;
}

void FakeOutputManager::requestHDMIStandby()
{
	NICKEL_FUNC_TRACE;
};

AspectRatio::Enum FakeOutputManager::getAnalogueDisplayAspectRatio() const
{
	NICKEL_FUNC_TRACE;
	return _state->analogueAspectRatio;
}

void FakeOutputManager::setAnalogueDisplayAspectRatio(const AspectRatio::Enum aspectRatio)
{
	NICKEL_FUNC_TRACE;
	_state->analogueAspectRatio = aspectRatio;

	DisplayPreferenceChange();

	if(_state->primaryDisplayPreference == DisplayType::analogue)
	{
		PrimaryDisplayChange();
	}
}

VideoStandard::Enum FakeOutputManager::getAnalogueVideoStandard() const
{
	NICKEL_FUNC_TRACE;
	return _state->analogueVideoStandard;
}

void FakeOutputManager::setAnalogueVideoStandard(const VideoStandard::Enum standard)
{
	NICKEL_FUNC_TRACE;
	_state->analogueVideoStandard = standard;
}

ColourMode::Enum FakeOutputManager::getSCARTColourPreference() const
{
	NICKEL_FUNC_TRACE;
	return _state->analogueColourMode;
}

void FakeOutputManager::setSCARTColourPreference(const ColourMode::Enum colourMode)
{
	NICKEL_FUNC_TRACE;
	_state->analogueColourMode = colourMode;
}

VideoConversions FakeOutputManager::getVideoConversionPreference() const
{
	NICKEL_FUNC_TRACE;
	return _state->videoConversionsPreference;
}

void FakeOutputManager::setVideoConversionPreference(const VideoConversions& preference)
{
	NICKEL_FUNC_TRACE;
	_state->videoConversionsPreference = preference;
	DisplayPreferenceChange();
}

void FakeOutputManager::incVolume()
{
	NICKEL_FUNC_TRACE;
	setVolume(std::min(_state->volume + 1, uint32_t(100)));
}

void FakeOutputManager::decVolume()
{
	NICKEL_FUNC_TRACE;
	if(_state->volume != 0)
	{
		setVolume(_state->volume - 1);
	};
}

uint32_t FakeOutputManager::getVolume() const
{
	NICKEL_FUNC_TRACE;
	return _state->volume;
}

void FakeOutputManager::setVolume(const uint32_t volume)
{
	NICKEL_FUNC_TRACE;

	if(volume > 100)
	{
		throw OutOfBounds();
	}

	if(volume != _state->volume)
	{
		_state->volume = volume;
		sendVolumeChangeEvent();
	}
}

void FakeOutputManager::muteVolume()
{
	NICKEL_FUNC_TRACE;

	_state->volumeMuted = true;
	sendVolumeChangeEvent();
}

void FakeOutputManager::unmuteVolume()
{
	NICKEL_FUNC_TRACE;

	_state->volumeMuted = false;
	sendVolumeChangeEvent();
}

bool FakeOutputManager::isMuted() const
{
	NICKEL_FUNC_TRACE;

	return _state->volumeMuted;
}

void FakeOutputManager::disableOutputs()
{
	NICKEL_FUNC_TRACE;

    if(_state->outputsEnabled)
    {
        _state->outputsEnabled = false;
        OutputStatusEvent(_state->outputsEnabled);
    };
}

void FakeOutputManager::enableOutputs()
{
	NICKEL_FUNC_TRACE;

    if(!_state->outputsEnabled)
    {
        _state->outputsEnabled = true;
        OutputStatusEvent(_state->outputsEnabled);
    };
}

DisplayResolution::Enum FakeOutputManager::getPrimaryDisplayResolution() const
{
	NICKEL_FUNC_TRACE;

	if(_state->primaryDisplayPreference == DisplayType::hdmi)
	{
		return _state->hdmiResolutionPreference;
	}

	return DisplayResolution::sd;
}

AspectRatio::Enum FakeOutputManager::getPrimaryDisplayAspectRatio() const
{
	NICKEL_FUNC_TRACE;

	if(_state->primaryDisplayPreference == DisplayType::hdmi)
	{
		return AspectRatio::_16_9;
	};

	return  _state->analogueAspectRatio;
}

GraphicsResolution FakeOutputManager::getGraphicsLayerResolution() const
{
    NICKEL_FUNC_TRACE;

	GraphicsResolution result;
	return result;
}

namespace
{

    /**
     * Returns pair of outputId -> outputType values for given AudioOutput
     */
	struct TransformAudioOutputState
	{
		FakeOutputManager::AudioOutputs::value_type operator()(const AudioOutputState& value)
		{
			return FakeOutputManager::AudioOutputs::value_type(value.id, value.outType);
		}
	};

    /**
     * Functor matching AudioOutput id with id provided in constructor
     */
	class FindOutputById
	{
	public:
		FindOutputById(uint32_t id): _id(id) { };
		bool operator()(const AudioOutputState& value)
		{
			return value.id == _id;
		}
	private:
		uint32_t _id;
	};


    /**
     * Returns iterator to output with given outputId, if output is not found throws InvalidOutput exception
     *
     * @param outputs list of audio outputs
     * @param outputId queried output identifier
     * @return iterator to output state
     */
	AudioOutputsState::iterator findOutput(AudioOutputsState& outputs, const uint32_t outputId)
	{
		AudioOutputsState::iterator iter = std::find_if(outputs.begin(), outputs.end(), FindOutputById(outputId));
		if(iter == outputs.end())
		{
			throw InvalidOutput();
		};
		return iter;
	}
}

FakeOutputManager::AudioOutputs FakeOutputManager::getAudioOutputs() const
{
	NICKEL_FUNC_TRACE;

    // construct map of outputId -> outputType basing on outputs state
	FakeOutputManager::AudioOutputs result;
	std::transform(_state->audioOutputs.begin(), _state->audioOutputs.end(), std::inserter(result, result.begin()), TransformAudioOutputState());

	return result;
}

std::vector<AudioFormat::Enum> FakeOutputManager::getAudioFormatOptions(const uint32_t outputId) const
{
	NICKEL_FUNC_TRACE;
	return findOutput(_state->audioOutputs, outputId)->formats;
}

AudioFormat::Enum FakeOutputManager::getAudioFormatPreference(const uint32_t outputId) const
{
	NICKEL_FUNC_TRACE;
	return findOutput(_state->audioOutputs, outputId)->formatPreference;
}

void FakeOutputManager::setAudioFormatPreference(const uint32_t outputId, const AudioFormat::Enum format)
{
	NICKEL_FUNC_TRACE;
    AudioOutputsState::iterator iter = findOutput(_state->audioOutputs, outputId);
    const std::vector<AudioFormat::Enum>& formats(iter->formats);

    // if format is supported then change preference and send event
    if(std::find(formats.begin(), formats.end(), format) != formats.end())
    {
        iter->formatPreference = format;
    	AudioPreferenceChange(outputId);
    };
}

int32_t FakeOutputManager::getAudioDelay(const uint32_t outputId) const
{
	NICKEL_FUNC_TRACE;
	return findOutput(_state->audioOutputs, outputId)->delay;
}

void FakeOutputManager::setAudioDelay(const uint32_t outputId, const int32_t delay)
{
	NICKEL_FUNC_TRACE;

    AudioOutputsState::iterator iter = findOutput(_state->audioOutputs, outputId);

    if(!iter->delaySupported)
    {
        throw NotSupported();
    };

    if((delay < -1) || (delay > 250))
    {
        throw OutOfBounds();
    };

	iter->delay = delay;
	AudioPreferenceChange(outputId);
}

int32_t FakeOutputManager::getRelativeADVolume() const
{
	NICKEL_FUNC_TRACE;
    return _state->relativeADVolume;
}

void FakeOutputManager::setRelativeADVolume(const int32_t vol)
{
	NICKEL_FUNC_TRACE;
    _state->relativeADVolume = vol;
}

ADRouting::Enum FakeOutputManager::getADRouting() const
{
	NICKEL_FUNC_TRACE;
	return _state->adRouting;
}

void FakeOutputManager::setADRouting(const ADRouting::Enum routing)
{
	NICKEL_FUNC_TRACE;
	_state->adRouting = routing;
}

void FakeOutputManager::DisplayPreferenceChange()
{
	NICKEL_FUNC_TRACE;
	produceEvent( boost::bind( &OutputManagerEventListener::DisplayPreferenceChange, _1) );
}

void FakeOutputManager::HDMIEvent(const HDMIStatus::Enum status)
{
	NICKEL_FUNC_TRACE;
	produceEvent( boost::bind( &OutputManagerEventListener::HDMIEvent, _1, status) );
}

void FakeOutputManager::HDMICECEvent(const HDMICECEventType::Enum eventType)
{
	NICKEL_FUNC_TRACE;
	produceEvent( boost::bind( &OutputManagerEventListener::HDMICECEvent, _1, eventType) );
}


void FakeOutputManager::PrimaryDisplayChange()
{
	NICKEL_FUNC_TRACE;
	produceEvent( boost::bind( &OutputManagerEventListener::PrimaryDisplayChange, _1) );
}

void FakeOutputManager::AudioPreferenceChange(const uint32_t outputId)
{
	NICKEL_FUNC_TRACE;
	produceEvent( boost::bind( &OutputManagerEventListener::AudioPreferenceChange, _1, outputId) );
}

void FakeOutputManager::VolumeChange(const uint32_t volume, const bool muted) {
	NICKEL_FUNC_TRACE;
	produceEvent( boost::bind( &OutputManagerEventListener::VolumeChange, _1, volume, muted) );
}

void FakeOutputManager::OutputStatusEvent(const bool enabled)
{
	NICKEL_FUNC_TRACE;
	produceEvent( boost::bind( &OutputManagerEventListener::OutputStatusEvent, _1, enabled) );
}

void FakeOutputManager::sendVolumeChangeEvent() {
	NICKEL_FUNC_TRACE;

	VolumeChange(getVolume(), isMuted());
}

NS_NICKEL_SYSTEM_CLOSE
