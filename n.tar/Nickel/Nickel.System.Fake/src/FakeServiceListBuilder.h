/*
 * FakeServiceListBuilder.h
 */

#ifndef NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_H_
#define NICKEL_SYSTEM__FAKE_SERVICELISTBUILDER_H_

#include <nickel-system-api/nickel-system-api.h>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <string>
#include <map>

NS_NICKEL_SYSTEM_OPEN

class FakeServiceListBuilder
	:	virtual public ServiceListBuilderSync {
public:
	virtual ~FakeServiceListBuilder();

public: // ServiceListBuilder
	virtual void serviceScan();
	virtual void stopServiceScan();

private:
	FakeServiceListBuilder();

	struct ScanningThreadStruct {
		void operator()();
		uint32_t counter;
        uint32_t scanStart;
        uint32_t scanEnd;
        uint32_t totToScan;
        std::map<uint32_t,uint32_t> services;
		FakeServiceListBuilder* parent;
	};

	ScanningThreadStruct scanningThreadStruct;
	boost::thread* 		 scanningThread;

    bool            running;

	friend class ScanningThreadStruct;
	friend class FakeSystemFactory;
};

NS_NICKEL_SYSTEM_CLOSE

#endif
