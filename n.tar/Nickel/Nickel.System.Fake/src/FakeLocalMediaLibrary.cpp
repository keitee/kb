/*
 * FakeLocalMediaLibrary.cpp
 *
 *  Created on: Mar 15, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */


//local
#include "DbWrapper.h"
#include "FakeLocalMediaLibrary.h"
#include "FakeUtils.h"

//api
#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/nickel-system-api.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/Utilities.h>
#include <zinc-common/DateTimeUtilities.h>

//standard
#include <algorithm>
#include <boost/foreach.hpp>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string/replace.hpp>
#include <vector>
#include <iostream>
#include <fstream>

#include <zinc-common/Action.h>

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;

using std::string;
using std::vector;
using std::map;
using boost::lexical_cast;
using boost::bind;

FakeLocalMediaLibrary::~FakeLocalMediaLibrary()
{
    NICKEL_FUNC_DEBUG;
    ap.stop();
}

FakeLocalMediaLibrary::FakeLocalMediaLibrary(
        boost::shared_ptr<NS_ZINC::FutureDispatcher> d)
 : dispatcher(d)
{
    try
    {
        NICKEL_FUNC_DEBUG;
        extractData();
        sgState.isActive = 0U;
        sgState.timePeriod = 0U;

        ap.start();
        boost::shared_ptr<NS_ZINC::Action> action(
                new NS_ZINC::Action(boost::bind(&FakeLocalMediaLibrary::doLowStorageSpaceSignal,this)));
        action->schedule(boost::posix_time::seconds(1), boost::posix_time::seconds(1));
        ap.addAction(action);
    }
    catch(const std::exception& e)
    {
        NICKEL_ERROR("Error : Fake LocalMediaLibrary Error."
                << NS_ZINC::demangleRttiName(typeid(e).name())
                << "  " << e.what());
        throw std::runtime_error("FakeLocalMediaLibrary couldnt be constructed.");
    }
};

void FakeLocalMediaLibrary::doLowStorageSpaceSignal()
{
    // Read config file.
    SignalGeneratorState newState;
    try
    {
        std::ifstream configFile( NS_ZINC::PackageDataFinder().find("fake_signalLowStorageSpace.txt").c_str(), std::ifstream::in );
        configFile >> newState.isActive >> newState.timePeriod;
    }
    catch(const NS_ZINC::ResourceNotFoundException& e)
    {
        NICKEL_DEBUG("Configuration file fake_getStorageSpace.txt not found.");
    }

    // Set signal generator.
    static boost::shared_ptr<NS_ZINC::Action> action(
            new NS_ZINC::Action(boost::bind(&FakeLocalMediaLibrary::sendLowStorageSpaceSignal,this,MediaStorageSpace())));
    if( sgState.isActive != newState.isActive || sgState.timePeriod != newState.timePeriod )
    {
        sgState = newState;
        action->cancel();
        if( sgState.isActive != 0U )
        {
            if( sgState.timePeriod == 0U )
            {
                const uint32_t delay = 1U;
                action->schedule(boost::posix_time::seconds(delay));
            }
            else
            {
                action->schedule(boost::posix_time::seconds(sgState.timePeriod), boost::posix_time::seconds(sgState.timePeriod));
            }
            this->ap.addAction(action);
        }
    }
}


namespace {

    template <typename T>
    T castWithDef(string src, const T def = T())
    {
        T retval = def;
        if(src.empty() == false)
        {
            try
            {
                retval = lexical_cast<T>(src);
            }
            catch(const boost::bad_lexical_cast& )
            {
                //do nothing
            }
        }
        return retval;
    }

    uint32_t castTimeWithSpecialValuesAndDef(string src, const uint32_t def = 0)
    {
        uint32_t retval = def;

        if(src.empty())
        {
            //do nothing
        }
        else if(src == "\"[YESTERDAY]\"")
        {
            retval = to_time_t(boost::posix_time::second_clock::universal_time() - boost::posix_time::hours(24));
        }
        else if(src == "\"[NOW]\"")
        {
            retval = to_time_t(boost::posix_time::second_clock::universal_time());
        }
        else if(src == "\"[TODAY]\"")
        {
            retval = to_time_t(boost::posix_time::second_clock::universal_time() + boost::posix_time::hours(1));
        }
        else
        {
            retval = castWithDef<uint32_t>(src,def);
        }
        return retval;
    }

}

void FakeLocalMediaLibrary::reformat(string& val)
{
    boost::replace_all(val, "__", "\"");
}

void FakeLocalMediaLibrary::extractData()
{
    NICKEL_FUNC_DEBUG;
    using namespace std;
    string dbfile = NS_ZINC::PackageDataFinder().find("lmlmock.db");;
    NICKEL_DEBUG("dbfile : " << dbfile);
    DbWrapper db(dbfile);
    vector<DbWrapper::StrStrMap> recs = db.selectAll();

    BOOST_FOREACH(DbWrapper::StrStrMap row, recs)
    {
        MediaRecord mr;
        //maps
        string identifiers = row["identifiers"];
        //this reformat stuff is adhoc and not nice and we have to fix
        //something in the python script
        //reformat(identifiers);
        mr.identifiers = FakeUtils::parseToMap(identifiers);
        StrStrMap stringsubs = FakeUtils::parseToMap(row["subtitles"]);
        BOOST_FOREACH(StrStrMap::value_type& nv, stringsubs)
        {
            mr.subtitles[nv.first] = castWithDef<uint32_t>(nv.second);
        }

        //single vals
        mr.mediaRecordIdentifier = row["mediaRecordIdentifier"];
        mr.contentIdentifier = row["contentIdentifier"];
        mr.mediaLocator = row["mediaLocator"];
        mr.serviceName = row["serviceName"];
        mr.title = row["title"];
        mr.synopsis = row["synopsis"];
        mr.publishedDuration = castWithDef<uint32_t>(row["publishedDuration"]);
        mr.duration = castWithDef<uint32_t>(row["duration"]);
        mr.adult = castWithDef<bool>(row["adult"]);
        mr.watershed = castWithDef<bool>(row["watershed"]);
        mr.guidanceCode = row["guidanceCode"];
        mr.guidanceText = row["guidanceText"];
        mr.audioDescription = castWithDef<bool>(row["audioDescription"]);
        mr.signing = castWithDef<bool>(row["signing"]);
        mr.acquisitionDateTime = castTimeWithSpecialValuesAndDef(row["acquisitionDateTime"]);
        mr.acquisitionStatus = static_cast<AcquisitionStatus::Enum>(
                castWithDef<int>(row["acquisitionStatus"]));
        mr.resumeAt = castWithDef<uint32_t>(row["resumeAt"]);
        mr.lastAccessed = castTimeWithSpecialValuesAndDef(row["lastAccessed"]);
        mr.isProtected = castWithDef<bool>(row["isProtected"]);
        mr.size = castWithDef<int64_t>(row["size"]);
        if (!mr.mediaRecordIdentifier.empty())
        {
            records.push_back(mr);
        }
    }
}


NS_ZINC::Future<FakeLocalMediaLibrary::MediaRecordVec>
FakeLocalMediaLibrary::getMediaRecords(
        const FilterByType::Enum filterByType,
        const FilterByPlayed::Enum filterByPlayed,
        const SortBy::Enum sortBy,
        const bool includeAdult,
        const uint32_t start,
        const uint32_t size)
{
    NICKEL_FUNC_DEBUG;
    NS_ZINC::Promise<MediaRecordVec> p(*dispatcher);

    MediaRecordVec crecs = records;
    if(!includeAdult)
    {
        //there is no copy_if
        crecs.erase(std::remove_if(crecs.begin(), crecs.end(),
                    bind(&MediaRecord::adult, _1) == true),
                crecs.end());
    }

    if(filterByPlayed == FilterByPlayed::played)
    {
        //remove all the ones with resumeAt 0
        crecs.erase(std::remove_if(crecs.begin(), crecs.end(),
                    bind(&MediaRecord::resumeAt, _1) == 0),
                crecs.end());
    }
    else if(filterByPlayed == FilterByPlayed::unplayed)
    {
        //remove all the ones with resumeAt 0
        crecs.erase(std::remove_if(crecs.begin(), crecs.end(),
                    bind(&MediaRecord::resumeAt, _1) != 0),
                crecs.end());
    }

    //Now sort the result
    if(sortBy == SortBy::least_recently_acquired)
    {
        std::sort(crecs.begin(), crecs.end(),
                bind(&MediaRecord::acquisitionDateTime, _1) < bind(&MediaRecord::acquisitionDateTime, _2));
    }
    else if(sortBy == SortBy::most_recently_acquired)
    {
        std::sort(crecs.begin(), crecs.end(),
                bind(&MediaRecord::acquisitionDateTime, _1) > bind(&MediaRecord::acquisitionDateTime, _2));
    }
    else if(sortBy == SortBy::least_recently_watched)
    {
        std::sort(crecs.begin(), crecs.end(),
                bind(&MediaRecord::lastAccessed, _1) < bind(&MediaRecord::lastAccessed, _2));
    }
    else if(sortBy == SortBy::most_recently_watched)
    {
        std::sort(crecs.begin(), crecs.end(),
                bind(&MediaRecord::lastAccessed, _1) > bind(&MediaRecord::lastAccessed, _2));
    }
    else if(sortBy == SortBy::title_a_to_z )
    {
        std::sort(crecs.begin(), crecs.end(),
                bind(&MediaRecord::title, _1) < bind(&MediaRecord::title, _2));
    }
    else if(sortBy == SortBy::title_z_to_a)
    {
        std::sort(crecs.begin(), crecs.end(),
                bind(&MediaRecord::title, _1) > bind(&MediaRecord::title, _2));
    }

    p.complete(crecs);
    return p.getFuture();
}

NS_ZINC::Future< MediaRecord >
FakeLocalMediaLibrary::getMediaRecord(const string& recId)
{
    NICKEL_FUNC_DEBUG;
    NS_ZINC::Promise< MediaRecord > p(*dispatcher);

    MediaRecordVec::const_iterator it =
        find_if(records.begin(), records.end(),
                bind(&MediaRecord::mediaRecordIdentifier, _1) == recId);
    if(it != records.end())
    {
        NICKEL_DEBUG("Found record");
        p.complete(*it);
    }
    else
    {
        NICKEL_DEBUG("Record not found sending exception");
        p.exception(MediaRecordNotFound());
    }
    return p.getFuture();
}

NS_ZINC::Future<FakeLocalMediaLibrary::MediaRecordVec>
FakeLocalMediaLibrary::getMediaRecordsByContentIdentifier(const string& cid)
{
    NICKEL_FUNC_DEBUG;
    NS_ZINC::Promise<MediaRecordVec> p(*dispatcher);
    MediaRecordVec crecs = records;
    MediaRecordVec::iterator it =
        std::partition(crecs.begin(), crecs.end(),
                bind(&MediaRecord::contentIdentifier, _1) == cid);
    crecs.erase(it, crecs.end());
    p.complete(crecs);
    return p.getFuture();
}

NS_ZINC::Future<bool>
FakeLocalMediaLibrary::deleteMediaRecord(const string& mri)
{
    NICKEL_FUNC_DEBUG;

    // Find MediaRecord to be removed.
    std::vector<MediaRecord>::iterator newpos = std::remove_if(records.begin(), records.end(), bind(&MediaRecord::mediaRecordIdentifier, _1) == mri);
    std::vector<MediaRecord>::iterator endpos = records.end();

    // If MediaRecord was found, remove it then.
    NS_ZINC::Promise< bool > p(*dispatcher);
    if(endpos != newpos)
    {
        assert(std::distance(newpos,endpos)==1);
        records.erase(newpos, endpos);

        // Send a LibraryContentChange signal about the removed MediaRecord.
        std::map< std::string, LibraryContentChangeType::Enum > changes;
        changes.insert(std::pair<std::string, LibraryContentChangeType::Enum>(mri, LibraryContentChangeType::deleted));
        sendLibraryContentChangeSignal(changes);

        p.complete(true);
    }
    else
    {
        p.complete(false);
    }
    return p.getFuture();
}

NS_ZINC::Future<MediaStorageSpace>
FakeLocalMediaLibrary::getStorageSpace()
{
    NICKEL_FUNC_DEBUG;
    NS_ZINC::Promise< MediaStorageSpace > p(*dispatcher);

    const int64_t KB = int64_t(1024);
    const int64_t MB = KB*1024;
    const int64_t GB = MB*1024;

    MediaStorageSpace mss;
    mss.usedForRecordings = 1*KB;
    mss.usedForDownloads = 2*KB;
    mss.free = 3*KB;
    mss.anticipatedForRecordings = 4*KB;
    mss.anticipatedForDownloads = 5*KB;

    try
    {
        std::ifstream configFile( NS_ZINC::PackageDataFinder().find("fake_getStorageSpace.txt").c_str(), std::ifstream::in );
        std::string mode;
        configFile >> mode;

        if(mode == "0"){
            mss.usedForRecordings = 0;
            mss.usedForDownloads = 0;
            mss.free = 280*GB;
            mss.anticipatedForRecordings = 0;
            mss.anticipatedForDownloads = 0;
        }else if(mode == "10"){
            mss.usedForRecordings = 28*GB;
            mss.usedForDownloads = 0;
            mss.free = 252*GB;
            mss.anticipatedForRecordings = 0;
            mss.anticipatedForDownloads = 0;
        }else if(mode == "90"){
            mss.usedForRecordings = 252*GB;
            mss.usedForDownloads = 0;
            mss.free = 28*GB;
            mss.anticipatedForRecordings = 0;
            mss.anticipatedForDownloads = 0;
        }else if(mode == "100"){
            mss.usedForRecordings = 280*GB;
            mss.usedForDownloads = 0;
            mss.free = 0;
            mss.anticipatedForRecordings = 0;
            mss.anticipatedForDownloads = 0;
        }else if(mode == "ERR1"){
            mss.usedForRecordings = 0;
            mss.usedForDownloads = 0;
            mss.free = 0;
            mss.anticipatedForRecordings = 0;
            mss.anticipatedForDownloads = 0;
        }else if(mode == "ERR2"){
            mss.usedForRecordings = 0;
            mss.usedForDownloads = 0;
            mss.free = 280*GB;
            mss.anticipatedForRecordings = 320*GB;
            mss.anticipatedForDownloads = 0;
        }
    }
    catch(const NS_ZINC::ResourceNotFoundException& e)
    {
        NICKEL_DEBUG("Configuration file fake_getStorageSpace.txt not found.");
    }

    p.complete(mss);
    return p.getFuture();
}

void FakeLocalMediaLibrary::sendLowStorageSpaceSignal(MediaStorageSpace mss)
{
    NICKEL_FUNC_DEBUG;
    NICKEL_DEBUG("Sending LowStorageSpace signal.");
    produceEvent( bind(&LocalMediaLibraryEventListener::LowStorageSpace, _1, mss) );
}

void FakeLocalMediaLibrary::sendLibraryContentChangeSignal(const std::map< std::string, LibraryContentChangeType::Enum >& changes)
{
    NICKEL_FUNC_DEBUG;
    NICKEL_DEBUG("Sending LibraryContentChange signal.");
    produceEvent( bind(&LocalMediaLibraryEventListener::LibraryContentChange, _1, changes) );
}

NS_ZINC::Future<bool>
FakeLocalMediaLibrary::setMediaRecordProtected(
        const string& recId,
        const bool isProtected)
{
    NICKEL_FUNC_DEBUG;
    NS_ZINC::Promise< bool > p(*dispatcher);
    MediaRecordVec::iterator it =
        find_if(records.begin(), records.end(),
                bind(&MediaRecord::mediaRecordIdentifier, _1) == recId);
    if(it != records.end())
    {
        NICKEL_DEBUG("Found record");
        it->isProtected = isProtected;
        p.complete(true);
    }
    else
    {
        //should we throw or should we return ? throw.
        NICKEL_DEBUG("Record not found sending exception");
        p.exception(MediaRecordNotFound());
    }
    return p.getFuture();
}

NS_ZINC::Future< string >
FakeLocalMediaLibrary::getMediaRecordTimingSignature(
        const string& mediaRecordIdentifier_in)
{
    NICKEL_FUNC_DEBUG;
    NS_ZINC::Promise< string > p(*dispatcher);
    string timingSignature = "TheTimingSignature";
    p.complete(timingSignature);

    if(mediaRecordIdentifier_in == "TriggerLowStorageSpace")
    {
        NICKEL_DEBUG("Triggering LowStorageSpace signal");
        MediaStorageSpace mss;
        mss.usedForRecordings = 10*1024;
        produceEvent( boost::bind(&LocalMediaLibraryEventListener::LowStorageSpace, _1, mss) );
    }
    else if(mediaRecordIdentifier_in == "TriggerLibraryContentChange")
    {
        NICKEL_DEBUG("Triggering LibraryContentChange signal");
        map< string, LibraryContentChangeType::Enum > changes;
        changes["hello"] = LibraryContentChangeType::deleted;
        produceEvent( boost::bind( &LocalMediaLibraryEventListener::LibraryContentChange, _1, changes) );
    }

    return p.getFuture();
}

NS_NICKEL_SYSTEM_CLOSE
