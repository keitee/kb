/*
 * FakeMediaRouter.h
 *
 *    Created on: 13-Aug-2009
 *        Author: mark.nicoll1@bbc.co.uk
 */

#ifndef NICKEL_SYSTEM__FAKE_MEDIA_ROUTER_H_
#define NICKEL_SYSTEM__FAKE_MEDIA_ROUTER_H_

#include <nickel-system-api/MediaRouter.h>
#include <nickel-system-api/MediaRouterSync.h>
#include <nickel-system-api/MediaRouterEventListener.h>
#include <zinc-common/ActionProcessor.h>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <string>
#include <zinc-common/macros.h>
#include <nickel-system-api/BufferConstraint.h>
#include <nickel-system-api/AdaptiveMode.h>

NS_NICKEL_SYSTEM_OPEN

boost::shared_ptr<MediaRouterSync> createFakeMediaRouter();

class FakeMediaRouter : virtual public MediaRouterSync {
public:
    enum MRState {
        MR_CREATED,
        MR_STARTED,
        MR_PLAYING,
        MR_COMPLETED
    };
    enum MRBufferState {
        MRB_CREATED,
        MRB_STARTED,
        MRB_BUFFERING,
        MRB_COMPLETED
    };
    enum MRSignalStrength {
        MRS_GOOD,
        MRS_NONE
    };
    enum MRSourceType {
        MRSRC_NOTSET,
        MRSRC_DVB,
        MRSRC_OTHER
    };

    FakeMediaRouter();
    virtual ~FakeMediaRouter();

    // System API Methods
    virtual void setSource(const std::string& mediaLocator,const SetSourceReason::Enum reason);
    virtual std::string getSource() const;
    virtual void setVolume(const int32_t volume);
    virtual int32_t getVolume() const;
    virtual void setAudioTrack(const int32_t tag);
    virtual void setAudioTrackExternal(const std::string& mediaLocator,const int32_t tag);
    virtual Track getAudioTrack() const;
    virtual void setVideoTrack(const int32_t tag);
    virtual void setVideoTrackExternal(const std::string& mediaLocator,const int32_t tag);
    virtual Track getVideoTrack() const;
    virtual void setSubtitleTrack(const int32_t tag, const std::string& language);
    virtual Track getSubtitleTrack() const;
    virtual int32_t addSubtitleTrack(const std::string& subtitleLocator);
    virtual std::vector<Track> getTracks() const;
    virtual void setVideoWindow(const VideoWindowDescriptor& videoWindow);
    virtual VideoWindowDescriptor getVideoWindow() const;
    virtual void setPlaySpeed(const double speed);
    virtual double getPlaySpeed() const;
    virtual void seekPosition(const SeekReference::Enum whence,const int32_t offset,const SeekMode::Enum mode);
    virtual Position getPosition() const;
    virtual void setSink(const std::string& mediaLocator);
    virtual std::string getSink() const;
    virtual void setEndTime(const int32_t end);
    virtual int32_t getEndTime() const;
    virtual void start();
    virtual void startDeferred();
    virtual ControlCapabilities getControlCapabilities() const;
    virtual void stop();
    virtual std::map<std::string,std::string> getBufferingMode() const;
    virtual void setBufferingMode(const std::map<std::string,std::string>& bufferingMode);
    virtual void startBuffering();
    virtual void stopBuffering();
    virtual BufferStatus getBufferStatus() const;
    virtual void setVideoTerminationMode(const VideoTerminationMode::Enum mode_in);
    virtual VideoTerminationMode::Enum getVideoTerminationMode() const;
    virtual std::map<std::string,std::string> getSourceInformation() const;
    virtual void setMediaDuration(const int32_t end);
    virtual int32_t getMediaDuration() const;
    virtual ABRStreamSet getABRStreamSet() const;
    virtual ABRStatus getABRStatus() const;
    virtual void setABRStream(const int32_t index,const bool deferred);
    virtual void setCaptureMode(const TimeShiftCaptureMode::Enum mode);
    virtual TimeShiftCaptureMode::Enum getCaptureMode() const;
    virtual void recycle();
    // End System API Methods

    void simulateBehaviour();
    void doSignalStrength();
    void doRestrictedMode();

protected:
    // No locking is done in this method and the member mutexes themselves are
    // *not* swapped.
    void swapFakeMediaRouter(FakeMediaRouter& other);
private:
    void setPlaySpeedInt(const int32_t playSpeed_,bool lock_=true);

    std::string mediaLocator;
    int32_t playSpeed;
    std::string sink;
    MRSourceType sourceType;
    Position position;
    Track audioTrack;
    Track videoTrack;
    Track subtitleTrack;
    VideoWindowDescriptor videoWindow;
    BufferStatus buffer;
    NS_ZINC::ActionProcessor ap;
    volatile MRState mrState;
    volatile MRBufferState mrBufferState;
    mutable boost::mutex mrMutex;
    // Signal strength state
    time_t ssPrevTime;
    bool ssStarted;
    bool ssIncrement;
    MRSignalStrength ssState;
    int32_t ssInterval;
    int32_t ssTicksToNextEvent;
    std::string signalQuality;
    int32_t dvbBufferSize;
    // Restricted mode
    int32_t restrictedMode;
    std::string restrictedModeServiceList;
    bool createTestRTPStats;

    BufferConstraint::Enum bufferConstraint;
    AdaptiveMode::Enum adaptiveMode;

    friend boost::shared_ptr<MediaRouterSync> createFakeMediaRouter();
};

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM__FAKE_MEDIA_ROUTER_H_ */
