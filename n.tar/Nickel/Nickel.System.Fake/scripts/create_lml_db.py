# Copyright (C) 2010 British Broadcasting Corporation */
# 
#  Created on: 29-11-2010
#      Author: dave.evans1@bbc.co.uk
# 
import os.path
import sys
nickel_system_fake = __import__('nickel-system-fake.Sqlite3LocalMediaLibrary', globals(), locals(), [], -1)

if len(sys.argv) == 2:
    filename = sys.argv[1]
else:
    filename = "lmldata.db"
    
print "Writing to " + filename
try:
    os.remove( filename )
except:
    pass
    
with nickel_system_fake.Sqlite3LocalMediaLibrary.Sqlite3LocalMediaLibrary(filename) as db:
    db.CreateTables()
    db.PopulateTables()        