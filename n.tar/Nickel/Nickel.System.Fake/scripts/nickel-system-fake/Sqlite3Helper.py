import sqlite3

debug_mode = 0
def debugPrint(pri,msg):
    if pri <= debug_mode: print msg

def _quoteIfString(value):
    if(isinstance(value,str)):
        return '"' + value + '"'
    else:
        return str(value)

# Use this as a standard means of managing a connection to the database
class sqlite3Context(object):
    def __init__(self, dbpath):
        self.dbpath = dbpath

    def __enter__(self):
        #debugPrint( 2, "Opening db " + self.dbpath )

        self.connection = sqlite3.connect(self.dbpath)
        self.cursor     = self.connection.cursor()

        return self

    def __exit__(self, _type, _value, _traceback):
        #debugPrint( 2,  "Closing db " + self.dbpath )
        self.cursor.close()
        self.connection.close()

        if _type is None:
            #placeholder for some cleanup action
            pass
        elif issubclass(_type, sqlite3.Error):
            #Exception raised
            debugPrint(2,"sqlite3.Error " + str(_value))
            #formatExceptionInfo()
            #Dont raise this
            return True
        else:
            # Log it but let it be raised
            debugPrint(1,"Caught exception")
            #formatExceptionInfo()
            return False

class sqlite3Row(object):
    def __init__(self, table):
        self.table = table

        self.fieldValues = {}
        for f in self.table.fieldNames:
            self.fieldValues[f] = ""

    def __repr__(self):
        output = ""
        for f in self.table.fieldNames:
            output += f + ": "
            output += str(self.fieldValues[f]) + " "
        return output

    def PrimaryKeyValue(self):
        return self.fieldValues[self.table.PrimaryKeyName()]

class sqlite3Table(object):

    def __init__(self, dbpath, tableName, fieldNames, primaryKeyIndex, createTable, populateTable):
        self.dbpath = dbpath
        self.tableName = tableName
        self.fieldNames = fieldNames
        self.primaryKeyIndex = primaryKeyIndex
        self.createTable = createTable
        self.populateTable = populateTable

    def __repr__(self):
        return self.tableName

    def CreateTable(self):
        if self.createTable is not None:
            self.createTable()

    def PopulateTable(self):
        if self.populateTable is not None:
            self.populateTable()

    def PrimaryKeyName(self):
        return self.fieldNames[self.primaryKeyIndex]

    def EmptyRow(self):
        return sqlite3Row( self )

    def GetAllPrimaryKeys(self):
        output = []
        with sqlite3Context(self.dbpath) as db:
            query = "select " + self.fieldNames[0] + " from " + self.tableName
            debugPrint(2,query)
            rows = db.cursor.execute(query)

            for row in rows:
                if len(row) == 1:
                    output.append(str(row[0]))
                else:
                    debugPrint(2,"Error unexpected row size")

        return output

    def GetRowFromPrimaryKey(self, primaryKeyValue):
        with sqlite3Context(self.dbpath) as db:
            query = "select * from " + self.tableName + " where " + self.PrimaryKeyName() + " = ?";
            debugPrint(2,query)
            debugPrint(2,primaryKeyValue)
            rows = db.cursor.execute(query, [primaryKeyValue])

            for row in rows:
                output = sqlite3Row(self);
                for i, item in enumerate(row):
                    output.fieldValues[ self.fieldNames[ i ] ] = item
                return output

    def Add(self, row):
        with sqlite3Context(self.dbpath) as db:
            query = "insert into " + self.tableName + \
                      " ( " + ", ".join( map( lambda f: '"' + f + '"', self.fieldNames ) ) + " ) " + \
                "values ( " + ", ".join( map( lambda f: "?", row.fieldValues ) ) + " )"

            queryValues = tuple(map( lambda f : row.fieldValues[f], self.fieldNames))
            debugPrint(2, query)
            debugPrint(2, queryValues)
            db.cursor.execute(query, queryValues)
            db.connection.commit()

    def Update(self, row):
        with sqlite3Context(self.dbpath) as db:
            query = "update " + self.tableName + \
                  " set " + ", ".join( map( lambda f: '"' + f + '" = ?', self.fieldNames ) ) + \
                 " where ( " + self.PrimaryKeyName() + " = ?" " )"

            queryValues = tuple(map( lambda f : row.fieldValues[f], self.fieldNames) + [ row.PrimaryKeyValue() ] )
            debugPrint(2, query)
            debugPrint(2, queryValues)
            db.cursor.execute(query, queryValues)
            db.connection.commit()

    def Delete(self, row):
        with sqlite3Context(self.dbpath) as db:
            query = "delete from " + self.tableName + \
                 " where ( " + self.PrimaryKeyName() + " = ?" " )"

            queryValues = ( row.PrimaryKeyValue(), )
            debugPrint(2, query)
            debugPrint(2, queryValues)
            db.cursor.execute(query, queryValues)
            db.connection.commit()

def createTableHelper(dbpath, tableName, fieldNames, fieldTypes):
    assert len(fieldNames) == len(fieldTypes)
    assert len(fieldNames) > 0
    assert len(fieldTypes) > 0
    assert dbpath is not None
    assert tableName is not None

    with sqlite3Context(dbpath) as db:
        query = "create table " + tableName + " ("
        query += ", ".join(map(lambda (name, type): name + " " + type, zip(fieldNames,fieldTypes)))
        query += ")"

        db.cursor.execute(query)
        db.connection.commit();

def populateTableHelper(dbpath, tableName, fieldNames, fieldValues):

    assert len(fieldNames) > 0
    assert len(fieldValues) > 0
    assert dbpath is not None
    assert tableName is not None

    with sqlite3Context(dbpath) as db:
        for row in fieldValues:
            values = list(row)
            assert len(fieldNames) == len(values)
            query = "insert into " + tableName + " (" + ", ".join(fieldNames) + " ) values ( " + ", ".join(map(lambda x: _quoteIfString(x), values)) + ")"

            db.cursor.execute(query)
        db.connection.commit()
