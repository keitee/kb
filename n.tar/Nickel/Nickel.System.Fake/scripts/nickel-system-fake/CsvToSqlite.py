'''
YouView TV LTD.
Author : Milton Mukhopadhyay
'''
import csv
import sys
import sqlite3
import itertools

debug_mode = 10
def debugPrint(pri , msg):
    if pri <= debug_mode:
        print "python : %s"%(msg)

class S3Con(object):
    def __init__(self, dbpath):
        self.dbpath = dbpath

    def __enter__(self):
        self.conn = sqlite3.connect(self.dbpath)
        self.conn.row_factory = sqlite3.Row
        #This will make sqlite3 return bytestrings. The bytestrings will
        #be encoded in UTF-8.
        self.conn.text_factory = str
        self.cur = self.conn.cursor()
        return self

    def __exit__(self, _type, _value, _tb):
        self.conn.commit()
        self.cur.close()
        self.conn.close()
        return False

class Converter(object):
    def __init__(self, dbname, table_name, csv_file):
        self.dbname = dbname
        self.table_name = table_name
        self.csv_file = csv_file
        self.rec_table = 'recordtypes'

    def write_to_csv(self, filename, fieldnames = None):
        '''
        This one expects you to have a prepopulated sqlite table and produces
        a csv file.
        When fieldnames are there they will be used for the order.
        '''
        q_types = "select * from %s"%(self.rec_table)
        q_all = "select * from %s"%(self.table_name)
        rectypes = None
        with S3Con(self.dbname) as db:
            # Get the record types
            db.cur.execute(q_types)
            rectypes = db.cur.fetchall()[0]
            db.cur.execute(q_all)
            sql_rows = db.cur.fetchall()
        if not fieldnames:
            fieldnames = rectypes.keys()
            print "fieldnames:%s"%(fieldnames)
        with open(filename, 'wb') as f:
            writer = csv.DictWriter(f, fieldnames, dialect='excel')
            print "rectypes:%s"%(dict(rectypes))
            name_row = dict()
            for k in fieldnames:
                name_row[k] = k
            writer.writerow(name_row)
            writer.writerow(dict(rectypes))
            for sql_row in sql_rows:
                # copy to get a read-write dictionary
                sql_row_cp = dict(sql_row)
                for k in sql_row_cp:
                    val = sql_row_cp[k]
                    if rectypes[k.lower()] == 'boolean':
                        val = str(bool(int(val))).lower()
                    if rectypes[k.lower()] in ["string", "object"]:
                        val = val.replace('__', '"')
                    sql_row_cp[k] = val
                writer.writerow(sql_row_cp)
                

    def create_tables(self, record_types,  if_not_exists = True):
        '''
        Create the table by extracting column names from record_types.
        todo : if 'if_not_exists = False', we should really drop the table.
        '''
        to_sqlite_type = {
                'boolean':'INTEGER',
                'string':'TEXT',
                'uint':'INTEGER',
                'int':'INTEGER',
                'object':'TEXT',
                }
        kvs = ('%s %s'%(k, to_sqlite_type[record_types[k].lower()]) 
                for k in record_types)
        q = ','.join(kvs)
        if_not_exists_str = ('if not exists' if if_not_exists else '')
        q = 'create table %s %s (%s)'%(if_not_exists_str, self.table_name, q)
        print q
        # Efficiency is not my primary concern here, so I'd keep opening
        # and closing db connection and keep 'it' clean.
        with S3Con(self.dbname) as db:
            db.cur.execute(q)
        # Also keep the record types, we will need the types when we 
        # retrieve them back without any type info.
        kvs = ('%s %s'%(k, 'TEXT') for k in record_types)
        create_q = 'create table %s %s (%s)'%(if_not_exists_str, 
                self.rec_table, ','.join(kvs))
        print create_q
        colstr = ','.join(record_types.keys())
        valstr = ','.join(['"%s"'%(str(i).lower()) 
            for i in record_types.values()])
        insert_q = 'insert into %s (%s) values(%s)'%(self.rec_table, colstr, 
                valstr)
        print insert_q
        with S3Con(self.dbname) as db:
            db.cur.execute(create_q)
            db.conn.commit()
            db.cur.execute(insert_q)

    def insert_vals(self, rtypes, dr):
        '''
        '''
        colstr = ','.join(rtypes.keys())
        print colstr
        def reformat(itemtuple):
            t = rtypes[itemtuple[0]].lower()
            val = itemtuple[1]
            if not val:
                val = ''
            if t == 'string':
                return val.decode('unicode_escape')
            elif val.lower() == 'false':
                return '0'
            elif val.lower()=='true':
                return '1'
            elif t in ['uint', 'int', 'boolean'] and not val:
                return '0'
            else:
                return val
        for row in dr:
            valtuple = list(itertools.imap(reformat, row.iteritems()))
            valqs = ','.join(len(valtuple)*('?',))
            print valtuple
            q = 'insert into %s (%s) values (%s)'%(self.table_name, colstr, valqs)
            with S3Con(self.dbname) as db:
                db.cur.execute(q, valtuple)

    def convert_to_db(self):
        '''
        Have to pass an open file.
        '''
        dr = csv.DictReader(self.csv_file, dialect='excel')
        record_types = dr.next()
        self.create_tables(record_types)
        self.insert_vals(record_types, dr)

def main():
    if len(sys.argv) != 2:
        print "Usage: %s <csv-file-name>"%(sys.argv[0])
        return 
    dbname = 'lmlmock.db'
    table_name = 'mediarecords'
    with open(sys.argv[1], 'rU') as csv_file:
        con = Converter(dbname, table_name, csv_file)
        con.convert_to_db()

if __name__=="__main__":
    main()
'''
#To rewrite it the database back to a csv :
con.write_to_csv('bbb.csv',["title","synopsis","acquisitionDateTime","acquisitionStatus","adult","audioDescription","contentIdentifier","duration","guidanceCode","guidanceText","identifiers","isProtected","lastAccessed","mediaLocator","mediaRecordIdentifier","publishedDuration","resumeAt","serviceName","signing","size","subtitles","watershed"])
'''
 



