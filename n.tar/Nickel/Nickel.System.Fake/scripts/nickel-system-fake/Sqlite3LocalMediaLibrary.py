from Sqlite3Helper import *

class Sqlite3LocalMediaLibrary(object):
    def __init__(self, dbpath):
        self.dbpath = dbpath

    def CreateTables(self):
        self.PublicationStatus().CreateTable()
        self.Publication().CreateTable()
        self.PublicationIdentifiers().CreateTable()
        self.Programme().CreateTable()

    def PopulateTables(self):
        self.PublicationStatus().PopulateTable()
        self.Publication().PopulateTable()
        self.PublicationIdentifiers().PopulateTable()
        self.Programme().PopulateTable()

    def PublicationStatus(self):
        table  = "publicationstatus"
        fields = [ "publicationRecordIdentifier", "acquisitionStatus", "played", "protected" ]
        types  = ["text PRIMARY KEY", "integer", "integer", "integer"]

        def CreateTable():
            createTableHelper(self.dbpath, table, fields, types)
            
        def PopulateTable():
            populateTableHelper(self.dbpath, table, fields,
                                [("1", 0, 0, 0),
                                 ("2", 1, 0, 1),
                                 ("3", 2, 0, 0),
                                 ("4", 3, 0, 1)])

        return sqlite3Table( self.dbpath, table, fields, 0, CreateTable, PopulateTable )

    def Publication(self):
        table  = "publication"
        fields = [ "recordIdentifier", "subtitlesClosed", "signingClosed", "highDefinition", "audioDescription", "programmeRecordIdentifier", "serviceRecordIdentifier" ]
        types  = ["text PRIMARY KEY", "integer", "integer", "integer", "integer", "text", "text"]

        def CreateTable():
            createTableHelper(self.dbpath, table, fields, types)
            
        def PopulateTable():
            populateTableHelper(self.dbpath, table, fields,
                                [("1", 1, 1, 1, 0, "http://c-backend.rad0.net/aggregator/editorial_version/240#editorial_version",  "http://c-backend.rad0.net/aggregator/service/1#service"),
                                 ("2", 0, 1, 0, 1, "http://c-backend.rad0.net/aggregator/editorial_version/3381#editorial_version", "http://c-backend.rad0.net/aggregator/service/1#service"),
                                 ("3", 1, 0, 0, 0, "http://c-backend.rad0.net/aggregator/editorial_version/3382#editorial_version", "http://c-backend.rad0.net/aggregator/service/1#service"),
                                 ("4", 0, 0, 1, 1, "http://c-backend.rad0.net/aggregator/editorial_version/3383#editorial_version", "http://c-backend.rad0.net/aggregator/service/6#service")])

        return sqlite3Table( self.dbpath, table, fields, 0, CreateTable, PopulateTable )

    def PublicationIdentifiers(self):
        table  = "publicationidentifiers"
        fields = [ "recordIdentifier", "name", "value" ]
        types  = ["text PRIMARY KEY", "text", "text"]

        def CreateTable():
            createTableHelper(self.dbpath, table, fields, types)
            
        def PopulateTable():
            populateTableHelper(self.dbpath, table, fields,
                                [("1", "mediaLocator", "file:///opt/video/dummy1.ts"),
                                 ("2", "mediaLocator", "file:///opt/video/dummy2.ts"),
                                 ("3", "mediaLocator", "file:///opt/video/dummy3.ts"),
                                 ("4", "mediaLocator", "file:///opt/video/dummy4.ts")])

        return sqlite3Table( self.dbpath, table, fields, 0, CreateTable, PopulateTable )

    def Programme(self):
        table  = "programme"
        fields = [ "recordIdentifier", "primaryTitle", "mediumSynopsis", "duration" ]
        types  = ["text PRIMARY KEY", "text", "text", "integer"]

        def CreateTable():
            createTableHelper(self.dbpath, table, fields, types)
            
        def PopulateTable():
            populateTableHelper(self.dbpath, table, fields,
                                [("http://c-backend.rad0.net/aggregator/editorial_version/240#editorial_version",  "Wine",                                                                "A look at the wine industry's importance to South Africa's identity and future.",        3600000),
                                 ("http://c-backend.rad0.net/aggregator/editorial_version/3381#editorial_version", "In The Nightgarden (Series 1)",                                       "The Tombliboos' trousers get mixed up all over - in the Ninky Nonk, in the Pinky Ponk.", 1500000),
                                 ("http://c-backend.rad0.net/aggregator/editorial_version/3382#editorial_version", "When Diets Go Wrong",                                                 "Actress Mikyla Dodd takes a tour through a whole range of dieting disasters.",           3600000),
                                 ("http://c-backend.rad0.net/aggregator/editorial_version/3383#editorial_version", "British Touring Car Championship (British Touring Car Championship)", "Steve Rider presents highlights of the sixth meeting of the British Touring Car Championship from Snetterton in Norfolk. With half the season gone, Colin Turkington in his Team RAC BMW leads the drivers. Commentary by Tim Harvey and Ben Edwards.", 0)])

        return sqlite3Table( self.dbpath, table, fields, 0, CreateTable, PopulateTable )


"""
import tempfile

# Get a table
useInMemory = True
if useInMemory:
    path = tempfile.mktemp()
    print path
    db = Sqlite3LocalMediaLibrary( path )
    db.CreateTables()
    db.PopulateTables()
else:
    db = Sqlite3LocalMediaLibrary( "/home/zinc/Zinc/install/debug/i686-pc-linux-gnu/share/nickel-system-fake/lmldata.db" )

ps = db.PublicationStatus()
print ps

# Get all of the primary keys
print ps.GetAllPrimaryKeys()

# Get a particular primary key
psrow = ps.GetRowFromPrimaryKey( "2" )
print psrow.PrimaryKeyValue()

# Make a new row
psrow = ps.EmptyRow()
psrow.fieldValues[ ps.fieldNames[ 0 ] ] = "555"
psrow.fieldValues[ ps.fieldNames[ 1 ] ] = 0
psrow.fieldValues[ ps.fieldNames[ 2 ] ] = 0
print psrow
ps.Add(psrow)

# Update a row
psrow.fieldValues[ ps.fieldNames[ 1 ] ] = 1
ps.Update(psrow)

# Delete a row
ps.Delete(psrow)
"""