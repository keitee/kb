import libNickelSystemFake
import libZincPython
import sqlite3
import sys
import traceback
import Sqlite3LocalMediaLibrary

debug_mode = 0

# Table name
pubstat_table = "publicationstatus"
# Field definitions
pubstat_f1="publicationRecordIdentifier"
pubstat_t1="text PRIMARY KEY"
pubstat_f2="acquisitionStatus"
pubstat_t2="integer"
pubstat_f3="played"
pubstat_t3="integer"
pubstat_f4="protected"
pubstat_t4="integer"

# Table name
pub_table="publication"
# Field definitions
pub_f1="recordIdentifier"
pub_t1="text PRIMARY KEY"
pub_f2="subtitlesClosed"
pub_t2="integer"
pub_f3="signingClosed"
pub_t3="integer"
pub_f4="highDefinition"
pub_t4="integer"
pub_f5="audioDescription"
pub_t5="integer"
pub_f6="programmeRecordIdentifier"
pub_t6="text"
pub_f7="serviceRecordIdentifier"
pub_t7="text"

# Table name
pubidentifiers_table="publicationidentifiers"
pubident_f1="recordIdentifier"
pubident_t1="text PRIMARY KEY"
pubident_f2="name"
pubident_t2="text"
pubident_f3="value"
pubident_t3="text"

# Table name
prog_table="programme"
# Field definitions
prog_f1="recordIdentifier"
prog_t1="text PRIMARY KEY"
prog_f2="primaryTitle"
prog_t2="text"
prog_f3="mediumSynopsis"
prog_t3="text"
prog_f4="duration"
prog_t4="integer"

def formatExceptionInfo(maxTBlevel=5):
    cla, exc, trbk = sys.exc_info()
    excName = cla.__name__
    try:
        excArgs = exc.__dict__["args"]
    except KeyError:
        excArgs = "<no args>"
    excTb = traceback.format_tb(trbk, maxTBlevel)
    debugPrint(1, (excName, excArgs, excTb))

def debugPrint(pri,msg):
    if pri <= debug_mode: print msg


class FakeLocalMediaLibrarySimulatorImpl(libNickelSystemFake.FakeLocalMediaLibrarySimulator):
    def __init__(self,dbpath):
        libNickelSystemFake.FakeLocalMediaLibrarySimulator.__init__(self)
        self.db = Sqlite3LocalMediaLibrary.Sqlite3LocalMediaLibrary(dbpath)
        self.dbpath = dbpath
        debugPrint(2,"FakeLocalMediaLibrarySimulator constructor DB path "+self.dbpath)

    def createTables(self):
        self.db.CreateTables()

    def populateTables(self):
        self.db.PopulateTables()

    def getPublications(self, filterByType, filterByPlayed, sortBy, start, size):
        debugPrint(2,"getPublications \""+str(filterByType)+"\" \""+str(filterByPlayed)+"\", \""+str(sortBy)+"\", \""+str(start)+"\", \""+str(size)+"\" ")

        # Adapt to a Zinc string vector
        publications = libZincPython.StringVector()
        for i in self.db.Publication().GetAllPrimaryKeys():
            publications.append(i)

        return publications

    def getPublication(self, recordIdentifier):
        debugPrint(2,"getPublication \""+recordIdentifier+"\" "+str(recordIdentifier))
        publication = libNickelSystemFake.Publication()
        # Get the publication
        db_publication = self.db.Publication().GetRowFromPrimaryKey(recordIdentifier)
        if db_publication is not None:
            publication.recordIdentifier          = str( db_publication.fieldValues[ pub_f1 ])
            publication.subtitlesClosed           = bool(db_publication.fieldValues[ pub_f2 ])
            publication.signingClosed             = bool(db_publication.fieldValues[ pub_f3 ])
            publication.highDefinition            = bool(db_publication.fieldValues[ pub_f4 ])
            publication.audioDescription          = bool(db_publication.fieldValues[ pub_f5 ])
            publication.programmeRecordIdentifier = str( db_publication.fieldValues[ pub_f6 ])
            publication.serviceRecordIdentifier   = str( db_publication.fieldValues[ pub_f7 ])
        publication.aspectRatio = libNickelSystemFake.AspectRatio.ratio_4_3
        publication.mediaType = libNickelSystemFake.MediaType.default_media
        # Get the identifiers
        # TODO: Is this 1:n? The DB schema doesn't allow it, but I suspect it should be - DE
        db_publicationid = self.db.PublicationIdentifiers().GetRowFromPrimaryKey(recordIdentifier)
        if db_publicationid is not None:
            publication.identifiers[ str(db_publicationid.fieldValues[ pubident_f2 ]) ] = str(db_publicationid.fieldValues[ pubident_f3 ])
        return publication

    def getProgrammeByPublicationRecordIdentifier(self, publicationRecordIdentifier):
        debugPrint(2,"getProgrammeByPublicationRecordIdentifier \""+publicationRecordIdentifier+"\"" )

        programme = libNickelSystemFake.Programme()

        # Get the programme
        db_programme = self.db.Programme().GetRowFromPrimaryKey(publicationRecordIdentifier)
        if db_programme is not None:
            programme.recordIdentifier = str(db_programme.fieldValues[ prog_f1 ])
            programme.primaryTitle     = str(db_programme.fieldValues[ prog_f2 ])
            programme.mediumSynopsis   = str(db_programme.fieldValues[ prog_f3 ])
            programme.duration         = int(db_programme.fieldValues[ prog_f4 ])

        return programme

    def getPublicationStatus(self, recordIdentifier):
        debugPrint(2,"getPublicationStatus "+str(recordIdentifier))

        publicationStatus = libNickelSystemFake.PublicationStatus()

        # Get the publication status
        db_publicationStatus = self.db.PublicationStatus().GetRowFromPrimaryKey(recordIdentifier)
        if db_publicationStatus is not None:
            publicationStatus.publicationRecordIdentifier = str( db_publicationStatus.fieldValues[ pubstat_f1 ])
            publicationStatus.acquisitionStatus           = libNickelSystemFake.AcquisitionStatus( db_publicationStatus.fieldValues[ pubstat_f2 ])
            publicationStatus.played                      = bool(db_publicationStatus.fieldValues[ pubstat_f3 ])
            publicationStatus.isProtected                 = libNickelSystemFake.ProtectedStatus( db_publicationStatus.fieldValues[ pubstat_f4 ])

        return publicationStatus

    def deletePublication(self, recordIdentifier):
        publicationTable = self.db.Publication()
        publication = publicationTable.GetRowFromPrimaryKey(recordIdentifier)
        if publication is not None:
            publicationTable.Delete( publication )

        return publication is not None

    def setPublicationProtected(self,recordIdentifier,isProtected):
        debugPrint(2,"setPublicationProtected "+str(recordIdentifier)+" "+str(isProtected))

        publicationStatusTable = self.db.PublicationStatus()
        publicationStatus = publicationStatusTable.GetRowFromPrimaryKey(recordIdentifier)
        if publicationStatus is not None:
            publicationStatus.fieldValues[pubstat_f4] = isProtected
            publicationStatusTable.Update( publicationStatus )

        return publicationStatus is not None
