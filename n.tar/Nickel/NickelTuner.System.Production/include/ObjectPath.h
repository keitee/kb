/*
 * ObjectPath.h
 *
 *  Created on: 16 Aug 2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_DBUS_OBJECTPATH_H_
#define NICKELTUNER_SYSTEM_DBUS_OBJECTPATH_H_

#include <cobalt-system-api/macros.h>
#include <dbus-c++/types.h>

NS_NICKELTUNER_SYSTEM_OPEN

namespace ObjectPath
{
    const char* const TUNER_CONTROL = "/Zinc/Tuner/TunerControl";
    const char* const LINEAR_PLAYBACK_CONTROL = "/Zinc/Tuner/LinearPlaybackControl";
}

NS_NICKELTUNER_SYSTEM_CLOSE

#endif /* NICKELTUNER_SYSTEM_DBUS_OBJECTPATH_H_ */
