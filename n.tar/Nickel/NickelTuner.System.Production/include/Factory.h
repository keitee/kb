/* 
 * File:   Factory.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 01 July 2013
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_PRODUCTION_FACTORY_H_
#define NICKELTUNER_SYSTEM_PRODUCTION_FACTORY_H_

#include <cadmium-system-api/macros.h>

#include <cobalt-system-api/macros.h>

#include <copper-system-api/macros.h>

#include <neon-client-api/macros.h>

#include <mercury-system-api/macros.h>

#include <nickel-system-api/macros.h>

#include <nickeltuner-system-api/macros.h>

#include <boost/optional.hpp>
#include <boost/shared_ptr.hpp>

#include <string>

// TODO: DEVARCH-6925 - Create fwd decl in every project
NS_COPPER_SYSTEM_OPEN
struct Registry;
NS_COPPER_SYSTEM_CLOSE

NS_NEON_CLIENT_OPEN
class ClientFactory;
class IPNetwork;
NS_NEON_CLIENT_CLOSE

NS_NICKEL_SYSTEM_OPEN
class ParentallyControlledMediaRouter;
NS_NICKEL_SYSTEM_CLOSE

NS_ZINC_OPEN
class ActionProcessor;
class Dispatcher;
template < typename T > class Property;
NS_ZINC_CLOSE

namespace Zinc {
namespace Application {
class UIManagerAsync;
} // namespace Application
namespace Broker {
class ProvisioningServiceAsync;
class UnifiedServiceRepositoryAsync;
class HiddenServicesStoreAsync;
class UnifiedEventRepositoryAsync;
} //namespace Broker
namespace ContentAcquisition {
class LinearAcquisitionAsync;
} //namespace ContentAcquisition
namespace Media {
class MediaRouterAsync;
} // namespace Media
namespace System {
class LocalStorageRepositoryAsync;
class LocalStorageRepositorySync;
}
} // namespace Zinc



NS_NICKELTUNER_SYSTEM_OPEN

class LinearPlaybackControlAsync;
class TunerControlAsync;

class ZINC_EXPORT Factory
{
public:
    Factory(boost::shared_ptr< NS_ZINC::Dispatcher > d);

    boost::shared_ptr< TunerControlAsync > createTunerControl();
    boost::shared_ptr< LinearPlaybackControlAsync > createLinearPlaybackControl();

public:

    boost::shared_ptr< NS_CADMIUM_SYSTEM::LinearAcquisitionAsync > createLinearAcquisition();

    boost::shared_ptr< NS_COBALT_SYSTEM::ProvisioningServiceAsync > createProvisioningService();
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedServiceRepositoryAsync > createUnifiedServiceRepository();
    boost::shared_ptr< NS_COBALT_SYSTEM::HiddenServicesStoreAsync > createHiddenServicesStore();
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > createUnifiedEventRepository();

    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > createLocalStorageRepository();
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > createSyncLocalStorageRepository();
    boost::shared_ptr< NS_COPPER_SYSTEM::Registry > createRegistry();

    boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync > createUIManager();

    boost::shared_ptr< NS_NEON_CLIENT::IPNetwork > createIPNetwork();

    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > createDTTMediaRouter();
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > createIPMediaRouter();
    boost::shared_ptr< NS_NICKEL_SYSTEM::ParentallyControlledMediaRouter > createParentallyControlledIPMediaRouter();

    boost::shared_ptr< NS_ZINC::ActionProcessor > createActionProcessor();
    boost::shared_ptr< NS_ZINC::Property< std::string > > createLastSelectedServiceProperty();
    boost::shared_ptr< NS_ZINC::Property< int32_t > > createPlatformIPMaxStreamsProperty();
    boost::shared_ptr< NS_ZINC::Property< int32_t > > createISPIPMaxStreamsProperty();
    boost::shared_ptr< NS_ZINC::Property< int32_t > > createOEMIPMaxStreamsProperty();

    void setLinearAcquisition(boost::shared_ptr< NS_CADMIUM_SYSTEM::LinearAcquisitionAsync > la);

    void setProvisioningService(boost::shared_ptr< NS_COBALT_SYSTEM::ProvisioningServiceAsync > ps);
    void setUnifiedServiceRepository(boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedServiceRepositoryAsync > usr);
    void setHiddenServicesStore(boost::shared_ptr< NS_COBALT_SYSTEM::HiddenServicesStoreAsync > hss);
    void setUnifiedEventRepository(boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > uer);

    void setLocalStorageRepository(boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > lsr);

    void setUIManager(boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync > uiManager);

    void setIPNetwork(boost::shared_ptr< NS_NEON_CLIENT::IPNetwork > in);

    void setDTTMediaRouter(boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > dttMR);
    void setIPMediaRouter(boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > ipMR);

    void setActionProcessor(const boost::shared_ptr< NS_ZINC::ActionProcessor >& ap);
    void setLastSelectedServiceProperty(boost::shared_ptr< NS_ZINC::Property< std::string > > p);
    void setPlatformIPMaxStreamsProperty(boost::shared_ptr< NS_ZINC::Property< int32_t > > max);
    void setISPIPMaxStreamsProperty(boost::shared_ptr< NS_ZINC::Property< int32_t > > max);
    void setOEMIPMaxStreamsProperty(boost::shared_ptr< NS_ZINC::Property< int32_t > > max);

    void setTunerControl(const boost::shared_ptr< TunerControlAsync >& tc);

private:

    boost::shared_ptr< NS_ZINC::Dispatcher >                                dispatcher;
    boost::shared_ptr< TunerControlAsync >                                  tunerControl;
    boost::shared_ptr< LinearPlaybackControlAsync >                         linearPlaybackControl;
    boost::shared_ptr< NS_CADMIUM_SYSTEM::LinearAcquisitionAsync >          linearAcquisition;
    boost::shared_ptr< NS_COBALT_SYSTEM::ProvisioningServiceAsync >         provisioningService;
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedServiceRepositoryAsync >    unifiedServiceRepository;
    boost::shared_ptr< NS_COBALT_SYSTEM::HiddenServicesStoreAsync >         hiddenServicesStore;
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync >      unifiedEventRepository;
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync >      localStorageRepository;
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync >       syncLocalStorageRepository;
    boost::shared_ptr< NS_COPPER_SYSTEM::Registry >                         registry;
    boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync >                  uiManager;
    boost::shared_ptr< NS_NEON_CLIENT::IPNetwork >                          ipNetwork;
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync >                 dttMediaRouter;
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync >                 ipMediaRouter;
    boost::shared_ptr< NS_NICKEL_SYSTEM::ParentallyControlledMediaRouter >  parentallyControlledIPMediaRouter;
    boost::shared_ptr< NS_ZINC::ActionProcessor >                           actionProcessor;
    boost::shared_ptr< NS_ZINC::Property< std::string > >                   lastSelectedServiceProperty;
    boost::shared_ptr< NS_ZINC::Property< int32_t > >                       platformIPMaxStreamsProperty;
    boost::shared_ptr< NS_ZINC::Property< int32_t > >                       ispIPMaxStreamsProperty;
    boost::shared_ptr< NS_ZINC::Property< int32_t > >                       oemIPMaxStreamsProperty;
};

NS_NICKELTUNER_SYSTEM_CLOSE

#endif	/* NICKELTUNER_SYSTEM_PRODUCTION_FACTORY_H_ */

