/*
 * BusName.h
 *
 *  Created on: 16 Aug 2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_DBUS_BUSNAME_H_
#define NICKELTUNER_SYSTEM_DBUS_BUSNAME_H_

#include <nickeltuner-system-api/macros.h>
#include <zinc-common/macros.h>

NS_NICKELTUNER_SYSTEM_OPEN

class ZINC_EXPORT BusName
{
public:
    static char const * const TUNER;
private:
    BusName();
};

NS_NICKELTUNER_SYSTEM_CLOSE

#endif /* NICKELTUNER_SYSTEM_DBUS_BUSNAME_H_ */
