/*
 * TunerControlImpl.cpp
 *
 *  Created on: 28-Jun-2013
 *      Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 *
 */
#include "TunerControlImpl.h"

#include "TuningHelpers.h"

#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/MediaRouterAsync.h>
#include <nickel-system-api/MediaRouterEventListener.h>
#include <nickel-system-api/PlayConflictException.h>
#include <nickeltuner-system-api/FutureProvider.h>
#include <nickeltuner-system-api/TunerControlAsync.h>
#include <nickeltuner-system-api/TunerControlEventListener.h>
#include <nickeltuner-system-api/TunerControlStatus.h>

#include <cobalt-system-api/UnifiedServiceHelpers.h>
#include <cobalt-system-api/ProvisioningInformationRetrievalFailedException.h>

#include <copper-system-api/LocalStorageRepositoryAsync.h>

#include <neon-client-api/IPNetwork.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/Continuation.h>
#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/async/FutureBarrier.h>
#include <zinc-common/async/FutureValue.h>
#include <zinc-common/Property.h>

#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/optional.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/utility/in_place_factory.hpp>

#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>

using namespace NS_COBALT_SYSTEM;
using namespace NS_COPPER_SYSTEM;
using namespace NS_NEON_CLIENT;
using namespace NS_NICKEL_SYSTEM;
using namespace NS_ZINC;

using boost::bind;
using boost::function;
using boost::make_shared;
using boost::optional;
using boost::shared_ptr;

using std::vector;
using std::string;

NS_NICKELTUNER_SYSTEM_OPEN

///////////////////////////////////////////////////////////
// TunerControl declaration
///////////////////////////////////////////////////////////

namespace {

/**
 * TunerControl makes it possible to tune to linear services (DVB or IP).
 *
 * TunerControl is responsible for:
 *   - Making it possible to tune to linear services, provisioned or not,
 *     using the DefaultMediaRouter for DVB services and an IP MediaRouter
 *     for IP services,
 *   - Making it possible to detune to allow other playback to be started,
 *   - Dealing / Relaying DTT / IP Tuner Exhaustion,
 *   - Storing / Restoring the last service that was tuned across reboots,
 *   - Preventing clients from tuning to a service that does not exist or
 *     that is restricted, throwing immediately,
 *   - Sending signals to notify clients of any State transition happening.
 *
 * Playback control, informations about the events played and parental
 * controls can then be accessed using LinearPlaybackControl.
 *
 * @see LinearPlaybackControl
 */
class TunerControlImpl : public TunerControlAsync,
                         public IPNetworkEventListener,
                         public MediaRouterEventListener
{
public:
    TunerControlImpl(
                    shared_ptr< Dispatcher > dispatcher_,
                    const TunerControlConfig& config_,
                    const TunerControlServices& services_)
        : dispatcher(dispatcher_),
          config(config_),
          services(services_),
          status(TunerControlStatus(TunerControlState::uninitialised, UnifiedService(),
                                    TuningReason::unspecified,
                                    TuningErrorType::no_error, "")),
          connected(services_.ipNetwork->getNetworkStatus() == IPNetwork::CONNECTED)
    {
    }

    /**
     * Returns the service locator of the service that is tuning/tuned/deactivating/deactivated.
     *
     * @return the service locator of the service that TunerControl is tuning to,
     *         tuned to, deactivating from or deactivated from.
     * @throws std::runtime_error if this method is called when TunerControlState
     *         is uninitialised.
     */
    virtual Future< string > getTargetService() const
    {
        if (getState() == TunerControlState::uninitialised)
        {
            NICKEL_ERROR("TunerControlImpl::getTargetService - uninitialised - Cannot get target service.");
            return exceptionalFuture< string >(
                std::runtime_error("Uninitialised - Cannot get target service."));
        }
        else
        {
            return completedFuture(targetService->serviceLocator);
        }
    }

    /**
     * Tunes to the service specified by serviceLocator.
     *
     * Requests are processed in the order they are queued
     * and cannot be interrupted.
     *
     * When the request is processed, two signals
     * TunerControlEventListener::StatusChange will always be emitted,
     * respectively with the TunerControlState::tuning and tuned.
     * Note that the two signals TunerControlEventListener::StatusChange
     * will be emitted even when an error happens during tuning. The signal
     * TunerControlEventListener::StatusChange with the TunerControlState::tuned
     * will describe the error with a TuningErrorType and a context.
     *
     * The serviceLocator is stored in the LSR so that a call to
     * activate() after a reboot can restore the service that was tuned.
     *
     * @return a Future completed quickly with success to indicate that the request
     *         is queued. It is completed with an exception when the request is not queued.
     * @throws NS_COBALT_SYSTEM::ServiceNotFoundException if no valid
     *         last selected service is found.
     * @throws ServiceRestrictedException if the DVB
     *         service is not in the restricted set of the MediaRouter.
     * @throws ServiceHiddenException if the service can not be tuned
     *         due to it is hidden.
     *
     * @see TunerControl#activate()
     * @see TunerControlEventListener
     */
    virtual Future< void > setTargetService(const string& serviceLocator,
        const TuningReason::Enum tuningReason);

    /**
     * Tunes to the last selected service.
     *
     * The last selected service is either the one that was tuned before
     * calling deactivate() or the one stored in the LSR.
     *
     * Requests are processed in the order they are queued
     * and cannot be interrupted.
     *
     * When the request is processed, two signals
     * TunerControlEventListener::StatusChange will always be emitted,
     * respectively with the TunerControlState::tuning and tuned.
     * Note that the two signals TunerControlEventListener::StatusChange
     * will be emitted even when an error happens during tuning. The signal
     * TunerControlEventListener::StatusChange with the TunerControlState::tuned
     * will describe the error with a TuningErrorType and a context.
     *
     * @return a Future completed quickly with success to indicate that the request
     *         is queued. It is completed with an exception when the request is not queued.
     * @throws NS_COBALT_SYSTEM::ServiceNotFoundException if no valid
     *         last selected service is found.
     * @throws ServiceRestrictedException if the DVB
     *         service is not in the restricted set of the MediaRouter.
     * @throws ServiceHiddenException if the service can not be tuned
     *         due to it is hidden.
     *
     * @see TunerControl#deactivate()
     * @see TunerControl#tune()
     * @see TunerControlEventListener
     */
    virtual Future< void > activate(const TuningReason::Enum tuningReason)
    {
        switch (getState())
        {
            case TunerControlState::uninitialised:
                NICKEL_INFO("TunerControlImpl::activate - Restoring last service tuned to from LSR...");
                return setTargetService(config.lastSelectedService->getValue(), tuningReason);
            break;
            case TunerControlState::tuning:
            case TunerControlState::tuned:
                NICKEL_ERROR("TunerControlImpl::activate - tuning/tuned - Cannot call activate.");
                return exceptionalFuture< void >(std::runtime_error("Already tuning/tuned - Cannot call activate."));
            break;
            case TunerControlState::deactivating:
                NICKEL_INFO("TunerControlImpl::activate() - Waiting for deactivating request completion...");
                deactivatingRequest->getNewFuture().setCallback(
                    *dispatcher,
                    bind(&TunerControlImpl::activate, this, tuningReason));
                // completes as soon as activating request is queued
            break;
            case TunerControlState::deactivated:
                NICKEL_INFO("TunerControlImpl::activate() - Tuning to service '"
                            << targetService->serviceLocator << "'...");
                BOOST_ASSERT(targetService);
                return setTargetService(targetService->serviceLocator, tuningReason);
            break;
        }
        return completedFuture();
    }

    /**
     * Stops playback and keeps track of the service that was tuned.
     *
     * This effectively checks that the state is tuned or tuning, completes
     * the Future, if necessary waits for the end of the tuning, sends a signal
     * StatusChange with the TunerControlState::deactivating, stops the MediaRouter
     * and sends a signal StatusChange with the TunerControlState::deactivated.
     *
     * Any error occuring when stopping the MediaRouter is not reported.
     *
     * @return a Future completed quickly with success to indicate that the request
     *         is queued. It is completed with an exception when the request is not queued.
     * @throws std::runtime_error when this method is called when TunerControl
     *         is uninitialised, deactivating or deactivated.
     */
    virtual Future< void > deactivate(const TuningReason::Enum tuningReason)
    {
        switch (getState())
        {
            case TunerControlState::uninitialised:
                NICKEL_ERROR("TunerControlImpl::deactivate - uninitialised - Cannot call deactivate.");
                return exceptionalFuture< void >(std::runtime_error("Uninitialised - Cannot call deactivate."));
            break;
            case TunerControlState::tuning:
                NICKEL_INFO("TunerControlImpl::deactivate() - Waiting for tuning request completion...");
                tuningRequest->getNewFuture().setCallback(
                    *dispatcher,
                    bind(&TunerControlImpl::deactivate, this, tuningReason));
                // completes as soon as deactivating request is queued
            break;
            case TunerControlState::tuned:
                NICKEL_INFO("TunerControlImpl::deactivate() - Deactivating...");
                BOOST_ASSERT(activeMR && targetService);
                setStatus(TunerControlState::deactivating, *targetService,
                          tuningReason, TuningErrorType::no_error, "");
                deactivatingRequest =
                    FutureProvider< void >::create(
                        boost::ref(*dispatcher),
                        activeMR->stop()
                    );
                activeMR.reset();
                tunedService.reset();
                deactivatingRequest->getNewFuture().setCallback(
                    *dispatcher,
                    bind(&TunerControlImpl::onDeactivated, this, _1, tuningReason));
                // completes as soon as deactivating request is queued
            break;
            case TunerControlState::deactivating:
            case TunerControlState::deactivated:
                NICKEL_ERROR("TunerControlImpl::deactivate - deactivating/deactivated - Cannot call deactivate.");
                return exceptionalFuture< void >(
                    std::runtime_error("Already deactivating/deactivated - Cannot call deactivate."));
            break;
        }
        return completedFuture();
    }

    /**
     * Returns the status of TunerControl and never throws.
     *
     * @return a completed Future that describes the state of TunerControl.
     */
    virtual Future< TunerControlStatus > getStatus()
    {
        return completedFuture(status);
    }

public: // IPNetworkEventListener

    virtual void NetworkStatusChange(const int32_t status)
    {
        NICKEL_INFO("TunerControlImpl::NetworkStatusChange(" << status << ")");
        connected = (status == NS_NEON_CLIENT::IPNetwork::CONNECTED);
    }

public: // DTT MediaRouterEventListener

    virtual void BufferStatusEvent(const BufferStatusEventValue::Enum)
    {
    }
    virtual void DrmEvent(const DrmEventValue::Enum, const std::string& , const std::string& )
    {
    }
    virtual void PositionChangeEvent(const Position& )
    {
    }
    virtual void SourceEvent(const SourceEventValue::Enum event, const SetSourceReason::Enum reason);
    virtual void SpeedChangeEvent()
    {
    }
    virtual void StatusEvent(const StatusEventValue::Enum)
    {
    }
    virtual void ErrorEvent(const ErrorEventValue::Enum, const ErrorEventContext::Enum, const std::string& )
    {
    }

private:

    shared_ptr< MediaRouterAsync > getMediaRouterForService(const UnifiedService& service) const
    {
        return isIpService(service) ? services.ipMR : services.dttMR;
    }

    void attemptTuning(FutureValue< UnifiedService > fv, TuningReason::Enum tuningReason);

    void onDeactivated(FutureValue< void > fv, TuningReason::Enum tuningReason)
    {
        NICKEL_INFO("TunerControlImpl::onDeactivated() - Deactivated.");
        if (fv.getError())
        {
            // For some reasons, MR::stop() threw.
            NICKEL_ERROR("TunerControlImpl::onDeactivated() - Failed to stop MR - "
                         << fv.getError() << " - " << fv.getError().message());
        }
        setStatus(TunerControlState::deactivated, *targetService,
                  tuningReason, TuningErrorType::no_error, "");
        fv.get(); // Rethrow exception if any
    }

    // Give access to this class' private interface to the Continuations
    // to avoid having to pass around too many objects.
    class TuneContinuation;
    class UpdateTargetServiceAsNeededContinuation;

    shared_ptr< Dispatcher >                        dispatcher;
    TunerControlConfig                              config;
    TunerControlServices                            services;

private:

    // It is assumed that the state of TunerControl will
    // always be modified / accessed from the same thread.
    // These helpers ensure this is the case - do not bother
    // adding helpers for all the members of the state.
    const TunerControlState::Enum& getState() const
    {
        BOOST_VERIFY(!stateModifierThreadId || pthread_self() == *stateModifierThreadId);
        stateModifierThreadId = pthread_self();
        return status.state;
    }

    void setStatus(TunerControlState::Enum state, const UnifiedService& targetService_,
                   TuningReason::Enum tuningReason, const TuningErrorType::Enum errorType,
                   const std::string& errorContext)
    {
        BOOST_VERIFY(!stateModifierThreadId || pthread_self() == *stateModifierThreadId);
        stateModifierThreadId = pthread_self();
        targetService   = targetService_;

        status = TunerControlStatus(state, targetService_, tuningReason, errorType, errorContext);
        NICKEL_INFO("TunerControl::StatusChange("
                    << "'" << enum_to_string(state) << "', "
                    << "'" << targetService_.serviceLocator << "',"
                    << "'" << enum_to_string(tuningReason) << "', "
                    << "'" << enum_to_string(errorType) << "', "
                    << errorContext << ")");
        produceEvent( bind( &TunerControlEventListener::StatusChange, _1, status) );
    }

    TunerControlStatus                  status;
    mutable optional< pthread_t >       stateModifierThreadId; ///< Helper to check state is accessed from only 1 thread

    bool                                connected;

    // Deactivated / Deactivating / Tuning / Tuned states
    optional< UnifiedService >          targetService;

    // Tuning state
    shared_ptr< FutureProvider< void > >  tuningRequest;

    // Tuned state
    optional< UnifiedService >          tunedService;
    shared_ptr< MediaRouterAsync >      activeMR;

    // Deactivating state
    shared_ptr< FutureProvider< void > >  deactivatingRequest;
};

} // anon namespace


///////////////////////////////////////////////////////////
// TunerControl Implementation
///////////////////////////////////////////////////////////

namespace {

struct TunerControlImpl::TuneContinuation :
        Continuation< void, TunerControlImpl::TuneContinuation >
{
    TunerControlImpl*               tunerControl;
    TuningReason::Enum              tuningReason;

    string                          mediaSourceURI;
    shared_ptr< MediaRouterAsync >  targetMR;

    void start(TunerControlImpl* tunerControl_,
               const UnifiedService& targetService,
               TuningReason::Enum tuningReason_)
    {
        NICKEL_DEBUG("TuneContinuation::start(" << targetService.serviceLocator << ")");
        tunerControl    = tunerControl_;
        tuningReason    = tuningReason_;

        // Voluntarily do not prevent from retuning to an already tuned service -
        // we could be tuned with error and client might want to try to tune again.

        BOOST_ASSERT(tunerControl->getState() != TunerControlState::tuning);
        tunerControl->setStatus(TunerControlState::tuning, targetService,
                                tuningReason, TuningErrorType::no_error, "");
        BOOST_ASSERT(tunerControl->targetService->serviceLocator == targetService.serviceLocator);

        bool stopNotRequired =
            !tunerControl->activeMR
            || (!isIpService(*tunerControl->tunedService) && !isIpService(*tunerControl->targetService)); // DTT->DTT

        FutureBarrier inParallel( getDispatcher() );
        if (!stopNotRequired)
        {
            NICKEL_DEBUG("TuneContinuation::start - active MR needs to be stopped");
            inParallel.add(tunerControl->activeMR->stop());
            tunerControl->activeMR.reset();
            tunerControl->tunedService.reset();
        }
        inParallel.add(
            tunerControl->services.lsr->setItem(
                0, "", LAST_SELECTED_SERVICE_LOCATOR_KEY, targetService.serviceLocator));
        inParallel.addWithCallback(
            GetMediaSourceURIContinuation::create(getDispatcher(),
                                                  tunerControl->services.provisioning.get(),
                                                 *tunerControl->targetService,
                                                  tunerControl->connected),
            bind(&This::onGotMediaSourceURI, this, _1));

        continueOnSuccess( inParallel, &This::onGotMediaSourceURIWithMRStopped );
    }

    void onGotMediaSourceURI(FutureValue< string > fv)
    {
        try
        {
            mediaSourceURI = fv.get();
            NICKEL_DEBUG("TuneContinuation::onGotMediaSourceURI(" << mediaSourceURI << ")");
        }
        catch (const NS_COBALT_SYSTEM::NetworkProblemException& e)
        {
            NICKEL_ERROR("TuneContinuation - IP connection required to tune to IP service: '"
                         << tunerControl->targetService->serviceLocator << "'");
            completeWithError(TuningErrorType::network_error, "");
        }
        catch (const ProvisioningInformationRetrievalFailedException& e)
        {
            NICKEL_ERROR("TuneContinuation - Failed to retrieve SAS URL for service '"
                         << tunerControl->targetService->serviceLocator << "': "
                         << e.getReason());
            ProvisioningInformationRetrievalFailureReason::Enum reason = e.getReason();
            if (reason == ProvisioningInformationRetrievalFailureReason::not_provisioned)
            {
                completeWithError(TuningErrorType::not_provisioned_error, "");
            }
            else
            {
                completeWithError(TuningErrorType::provisioning_information_retrieval_error,
                                  mapProvisioningInformationRetrievalFailureToHelperErrorReason(e));
            }
        }
        catch (const std::exception& e)
        {
            NICKEL_ERROR("TuneContinuation - Unexpected error when retrieving SAS URL for service : '"
                         << tunerControl->targetService->serviceLocator << "' - " << e.what());
            completeWithError(TuningErrorType::unknown_error, "");
        }
    }

    void onGotMediaSourceURIWithMRStopped()
    {
        NICKEL_DEBUG("TuneContinuation::onGotMediaSourceURIWithMRStopped(" << mediaSourceURI << ")");
        // This is executed if GetMediaSourceURIContinuation failed (a callback
        // is set for getMediaSourceURI) but not if MR::stop or setItem failed.
        if (!mediaSourceURI.empty())
        {
            targetMR = tunerControl->getMediaRouterForService(*tunerControl->targetService);
            continueOnSuccess(
                recycleMediaRouterAsNeededToGoToService(*targetMR,
                                                        *tunerControl->targetService),
                &This::onCurrentMediaRouterRecycled);
        }
    }

    void onCurrentMediaRouterRecycled()
    {
        NICKEL_DEBUG("TuneContinuation::onCurrentMediaRouterRecycled()");
        continueOnSuccess(
            targetMR->setCaptureMode(NS_NICKEL_SYSTEM::TimeShiftCaptureMode::enabled),
            &This::onTimeshiftCaptureModeSet);
    }

    void onTimeshiftCaptureModeSet()
    {
        NICKEL_DEBUG("TuneContinuation::onTimeshiftCaptureModeSet()");
        continueOnSuccess(
            SetSinkAsNeededContinuation::create(getDispatcher(), targetMR.get()),
            &This::onSinkSet);
    }

    void onSinkSet()
    {
        NICKEL_DEBUG("TuneContinuation::onSinkSet()");
        continueOnSuccess(
            targetMR->setSource(mediaSourceURI, SetSourceReason::unspecified),
            &This::onSourceSet);
    }

    void onSourceSet()
    {
        NICKEL_DEBUG("TuneContinuation::onSourceSet()");
        if (!tunerControl->activeMR)
        {
            NICKEL_DEBUG("TuneContinuation::onSourceSet - MR needs to be started");
            continueOn(targetMR->start(), &This::onTuned);
        }
        else
        {
            onTunedWithSuccess();
        }
    }

    void onTuned(const NS_ZINC::FutureValue<void>& fv)
    {
        if (fv.getError())
        {
            NICKEL_ERROR("TuneContinuation::onTuned(" << fv.getError() << "-" << fv.getError().message() << ")");
            // Special case that happens due to a bad design elsewhere in the stack:
            // - When closing on demand app back to live TV with On Demand MediaRouter not properly stopped,
            // - When closing DVR playback back to live TV with DVR playback MediaRouter not properly stopped,
            if (fv.getError() == NS_NICKEL_SYSTEM::error::PlayConflictExceptionCode)
            {
                completeWithError(TuningErrorType::play_conflict_error, fv.getError().message());
            }
            else
            {
                onError(fv.getError());
            }
        }
        else
        {
            onTunedWithSuccess();
        }
    }

    void onTunedWithSuccess()
    {
        NICKEL_INFO("TuneContinuation::onTunedWithSuccess()");
        // Voluntarily do not wait for event from MediaRouter indicating that playback started:
        // this would be a PlaybackError.
        tunerControl->activeMR      = targetMR;
        tunerControl->tunedService  = tunerControl->targetService;
        tunerControl->setStatus(TunerControlState::tuned,
                                *tunerControl->targetService,
                                tuningReason,
                                TuningErrorType::no_error,
                                "");
        BOOST_ASSERT(tunerControl->getState() == TunerControlState::tuned);
        promise.complete();
    }

    void onError(const ErrorCode& e)
    {
        NICKEL_ERROR("TuneContinuation::onError(" << e << "-" << e.message() << ")");
        completeWithError(TuningErrorType::unknown_error, e.message());
    }

    void completeWithError(TuningErrorType::Enum errorType, const std::string& errorContext)
    {
        NICKEL_ERROR("TuneContinuation::completeWithError('"
                     << NS_NICKELTUNER_SYSTEM::enum_to_string(errorType) << "', '"
                     << errorContext << "')");
        tunerControl->setStatus(TunerControlState::tuned,
                                *tunerControl->targetService,
                                tuningReason,
                                errorType,
                                errorContext);
        BOOST_ASSERT(tunerControl->getState() == TunerControlState::tuned);
        // Voluntarily complete the promise without error:
        // as there are multiple clients, they will all be notified of the
        // error when the signal StatusChange(tuned) is emitted.
        promise.complete();
    }
};

void TunerControlImpl::attemptTuning(FutureValue< UnifiedService > fv,
        TuningReason::Enum tuningReason)
{
    if (fv.getError())
    {
        // Should only ever happen if GetServiceAvailabilityContinuation failed.
        // TuningRequests never fail.
        NICKEL_INFO("TunerControlImpl::attemptTuning - Discarding request - "
                    << fv.getError() << " - " << fv.getError().message());
    }
    // Voluntarily leave it fail as setTargetService has to return exceptional future
    // if service is not found / not available.
    const UnifiedService& service = fv.get();
    switch (getState())
    {
        case TunerControlState::tuning:
            NICKEL_INFO("TunerControlImpl::attemptTuning(" << service.serviceLocator
                        << ") - Waiting for tuning request completion...");
            tuningRequest->getNewFuture().setCallback(
                *dispatcher,
                bind(&TunerControlImpl::attemptTuning, this, fv, tuningReason));
        break;
        case TunerControlState::uninitialised:
        case TunerControlState::tuned:
        case TunerControlState::deactivated:
            NICKEL_INFO("TunerControlImpl::attemptTuning(" << service.serviceLocator << ") - Tuning...");
            tuningRequest =
                FutureProvider< void >::create(
                    boost::ref(*dispatcher),
                    TuneContinuation::create(*dispatcher, this, service, tuningReason)
                );
            BOOST_ASSERT(getState() == TunerControlState::tuning
                         || getState() == TunerControlState::tuned); // Internet not connected
        break;
        case TunerControlState::deactivating:
            NICKEL_INFO("TunerControlImpl::attemptTuning(" << service.serviceLocator
                        << ") - Waiting for deactivating request completion...");
            deactivatingRequest->getNewFuture().setCallback(
                *dispatcher,
                bind(&TunerControlImpl::attemptTuning, this, fv, tuningReason));
        break;
    }
}

Future< void > TunerControlImpl::setTargetService(const string& serviceLocator,
        const TuningReason::Enum tuningReason)
{
    // Return as soon as the tuning request is checked to be valid
    // (i.e. serviceLocator references existing and non restricted service.).
    return GetServiceAvailabilityContinuation::create(
        *dispatcher, services, config, serviceLocator, tuningReason).then(
                *dispatcher,
                bind(&TunerControlImpl::attemptTuning, this, _1, tuningReason));
}

struct TunerControlImpl::UpdateTargetServiceAsNeededContinuation :
        Continuation< void, TunerControlImpl::UpdateTargetServiceAsNeededContinuation >
{
    TunerControlImpl*       tunerControl;
    bool                    mhegInitiated;

    void start(TunerControlImpl* tunerControl_,
               bool mhegInitiated_)
    {
        NICKEL_DEBUG("UpdateTargetServiceAsNeededContinuation::start()");
        tunerControl        = tunerControl_;
        mhegInitiated       = mhegInitiated_;

        continueOnSuccess(
            tunerControl->services.dttMR->getSource(),
            &This::onGotSource);
    }

    void onGotSource(const std::string& serviceLocator) // source == serviceLocator in DTT
    {
        NICKEL_DEBUG("UpdateTargetServiceAsNeededContinuation::onGotSource(" << serviceLocator << ")");
        continueOnSuccess(
            tunerControl->services.usr->getService(serviceLocator),
            &This::onGotService);
    }

    void onGotService(const UnifiedService& dttServiceCurrentlyTuned)
    {
        NICKEL_DEBUG("UpdateTargetServiceAsNeededContinuation::onGotService(" << dttServiceCurrentlyTuned.serviceLocator << ")");
        if (   tunerControl->getState() == TunerControlState::tuned
            && !isIpService(*tunerControl->targetService)
            && tunerControl->targetService->serviceLocator != dttServiceCurrentlyTuned.serviceLocator)
        {
            TuningReason::Enum reason = mhegInitiated
                    ? TuningReason::mheg_initiated
                    : TuningReason::forced_on_dtt_exhaustion;
            NICKEL_INFO("UpdateTargetServiceAsNeededContinuation::setStatus("
                        << dttServiceCurrentlyTuned.serviceLocator
                        << ") - Forced tune detected - TuningReason = " << reason);
            // UI expects a TunerControlStatusChange signal with tuning status.
            // see DEVARCH-7225.
            // TODO: DEVARCH-7649: TuningReason::unspecified is set as
            // TuningReason for a tuning signal in order to keep the consistency
            // with the signals expected by the UI.
            tunerControl->setStatus(TunerControlState::tuning, dttServiceCurrentlyTuned,
                                    TuningReason::unspecified, TuningErrorType::no_error, "");
            // TunerControlState is directly set as tuned, so tuningRequest will
            // not be set in tuning state.
            tunerControl->setStatus(TunerControlState::tuned, dttServiceCurrentlyTuned,
                                    reason, TuningErrorType::no_error, "");
        }
        promise.complete();
    }

    void onError(const ErrorCode& e)
    {
        NICKEL_ERROR("UpdateTargetServiceAsNeededContinuation::onError(" << e << "-" << e.message() << ")");
        promise.error(e);
    }
};

void TunerControlImpl::SourceEvent(const SourceEventValue::Enum event, const SetSourceReason::Enum reason)
{
    if (event == SourceEventValue::change_complete)
    {
        // Check if this is the result of a DTT tuner exhaustion / MHEG forced tune
        // and possibly signal clients that the targetService changed.
        UpdateTargetServiceAsNeededContinuation::create(
                *dispatcher,
                this, reason != SetSourceReason::unspecified);
    }
}

} // anon namespace

int32_t TunerControlConfig::getIPTunersCount()
{
    return ((platformIPMaxStreams && platformIPMaxStreams->getValue() >= 0) ?
        platformIPMaxStreams->getValue() : ((ispIPMaxStreams && ispIPMaxStreams->getValue() >= 0) ?
           ispIPMaxStreams->getValue() : ((oemIPMaxStreams && oemIPMaxStreams->getValue() >= 0) ?
                oemIPMaxStreams->getValue() : DEFAULT_IP_TUNERS_COUNT)));
}
///////////////////////////////////////////////////////////
// Factory method
///////////////////////////////////////////////////////////

shared_ptr< TunerControlAsync >  createTunerControlImpl (
        shared_ptr< Dispatcher > dispatcher,
        const TunerControlConfig& config,
        const TunerControlServices& services)
{
    shared_ptr< TunerControlImpl > ctrl =
        make_shared< TunerControlImpl >(dispatcher, config, services);

    services.ipNetwork->addListener(dispatcher, ctrl);
    services.dttMR->addListener(dispatcher, ctrl); // Need to listen to DTT MR for forced tune / does not happen in IP.
    return ctrl;
}

NS_NICKELTUNER_SYSTEM_CLOSE
