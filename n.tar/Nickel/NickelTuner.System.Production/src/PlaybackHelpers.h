/*
 * File:   PlaybackHelpers.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 24 September 2013
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_PRODUCTION_PLAYBACKHELPERS_H_
#define NICKELTUNER_SYSTEM_PRODUCTION_PLAYBACKHELPERS_H_

#include "LinearPlaybackControlImpl.h"

#include <nickeltuner-system-api/macros.h>

#include <cobalt-system-api/EntitlementType.h>
#include <cobalt-system-api/NetworkProblemException.h>
#include <cobalt-system-api/ProvisioningInformationRetrievalFailedException.h>
#include <cobalt-system-api/ProvisioningServiceAsync.h>
#include <cobalt-system-api/UnifiedService.h>
#include <cobalt-system-api/UnifiedServiceHelpers.h>
#include <cobalt-system-api/UnifiedServiceRepositoryAsync.h>

#include <nickel-common/NickelLogger.h>

#include <nickel-system-api/MediaRouterAsync.h>
#include <nickel-parental-controls/ParentallyControlledMediaRouter.h>

#include <zinc-common/async/Continuation.h>
#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/async/FutureValue.h>
#include <zinc-common/ActionProcessor.h>
#include <zinc-common/Action.h>
#include <zinc-common/CancellableFunctor.h>

#include <boost/date_time/time_duration.hpp>
#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/assign/list_of.hpp>

#include <stdexcept>
#include <string>
#include <vector>

#include <ctime>
#include <stdint.h>

NS_NICKELTUNER_SYSTEM_OPEN

// The period used to purge PresentFollowingArchive has to be bigger than
// the time-shift buffer size so that the correct ratings are used when
// skipping back to the beginning of the time-shift buffer.
// According to SOLDES-192, when oem.device.capabilities.dvr.available is
// set, the timeshift buffer is assumed to be 2 hours.
const boost::posix_time::time_duration PURGE_PERIOD = boost::posix_time::hours(3); // 3 hours to be on the safe side

const uint32_t TRICKPLAY_MAX_BUFFER_TIME = 2 * 3600; // 2 hours

const uint32_t UPDATE_INTERVAL_MS = 500;
const uint32_t REFRESH_INTERVAL_MS = 1000; // Required to replace missing PositionChangeEvent for  DTT MR

const uint32_t STAGE_WIDTH = 1280;
const uint32_t STAGE_HEIGHT = 720;
const uint32_t BG_LEFT_CHUNK_WIDTH = 987;
const uint32_t BG_TOP_CHUNK_HEIGHT = 31;
const uint32_t CUTOUT_WIDTH = 218;
const uint32_t SHRUNKTV_OVERSCAN_PX = 5;
const uint32_t SHRUNKTV_ROUNDING_ERR = 2;
const double SHRUNKTV_X_PERCENT = static_cast< double >(BG_LEFT_CHUNK_WIDTH + SHRUNKTV_ROUNDING_ERR - SHRUNKTV_OVERSCAN_PX) / STAGE_WIDTH;
const double SHRUNKTV_Y_PERCENT = static_cast< double >(BG_TOP_CHUNK_HEIGHT + SHRUNKTV_ROUNDING_ERR - SHRUNKTV_OVERSCAN_PX) / STAGE_HEIGHT;
const double SHRUNKTV_SCALE_PERCENT = static_cast< double >(CUTOUT_WIDTH + SHRUNKTV_OVERSCAN_PX * 2) / STAGE_WIDTH;
const NS_NICKEL_SYSTEM::VideoWindowDescriptor SHRUNK_WINDOW =
    NS_NICKEL_SYSTEM::VideoWindowDescriptor(0.0, 0.0, 1.0, 1.0,
                          static_cast< double > (SHRUNKTV_X_PERCENT),
                          static_cast< double >(SHRUNKTV_Y_PERCENT),
                          static_cast< double >(SHRUNKTV_SCALE_PERCENT),
                          static_cast< double >(SHRUNKTV_SCALE_PERCENT));
const NS_NICKEL_SYSTEM::VideoWindowDescriptor UNSHRUNK_WINDOW =
    NS_NICKEL_SYSTEM::VideoWindowDescriptor(0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0);

const std::vector< double > PLAYBACK_INCREMENTS = boost::assign::list_of(2.0)(6.0)(12.0)(30.0);

// See DEVARCH-7427: Parental controls are applied temporarily in the case where
// UER.getPF() takes a long time to reply. The timeout should be long enough not
// to affect normal tuning unnecessarily, but short enough not to cause the video
// to appear briefly when it should be restricted.
const boost::posix_time::time_duration PARENTAL_CONTROLS_SAFETY_TIMEOUT_MS =
    boost::posix_time::milliseconds(1000);

inline int64_t getEpochTimeInNanoSecondsImpl()
{
    struct timespec now;
    int res = clock_gettime(CLOCK_REALTIME, &now);
    if (res != 0) {
        throw std::runtime_error("Failed to call clock_gettime.");
    }
    return now.tv_sec * 1e9 + now.tv_nsec;
}

// Copied from TimeslipPFEventsStore.as and translated to C++
inline boost::posix_time::time_duration getTimeshiftBufferDurationAtBitrate(uint32_t bitrate, uint32_t timeshiftBufferSizeInBytes)
{
    BOOST_VERIFY(bitrate > 0);
    uint32_t theoricalDuration = timeshiftBufferSizeInBytes * 8 / bitrate;
    uint32_t timeshiftBufferDuration = std::min(theoricalDuration, TRICKPLAY_MAX_BUFFER_TIME);
    NICKEL_DEBUG("getTimeshiftBufferDurationAtBitrate("
                 << bitrate << ", " <<  - timeshiftBufferSizeInBytes << ") = " << timeshiftBufferDuration);
    return boost::posix_time::seconds(timeshiftBufferDuration);
}

// Copied from TimeslipPFEventsStore.as and translated to C++
inline boost::posix_time::time_duration getMaximumTimeshiftBufferDuration(const LinearPlaybackControlConfig& config)
{
    boost::posix_time::time_duration maxTimeshiftBufferDuration =
        getTimeshiftBufferDurationAtBitrate(config.broadcastSdBitrate, config.timeshiftBufferSizeInBytes);
    NICKEL_DEBUG("getMaximumTimeshiftBufferDuration = " << maxTimeshiftBufferDuration.total_seconds());
    return maxTimeshiftBufferDuration;
}

// Copied from MediaRouterPlayBackModel.as and translated to C++
inline double getNextAbsoluteSpeed(double absoluteCurrentSpeed)
{
    std::vector< double >::const_iterator it =
        std::find(PLAYBACK_INCREMENTS.begin(), PLAYBACK_INCREMENTS.end(), absoluteCurrentSpeed);

    return (it == PLAYBACK_INCREMENTS.end()) ?
                PLAYBACK_INCREMENTS[0] :
                ( (it + 1) == PLAYBACK_INCREMENTS.end() ? *it : *(it+1) );
}
inline double doFastForward(double currentSpeed)
{
    return (currentSpeed <= 1.0) ? PLAYBACK_INCREMENTS[0] : getNextAbsoluteSpeed(currentSpeed);
}
inline double doRewind(double currentSpeed)
{
    return (currentSpeed >= 0.0) ? -PLAYBACK_INCREMENTS[0] : -getNextAbsoluteSpeed(-currentSpeed);
}
inline double doSetSpeed(double requestedSpeed)
{
    return requestedSpeed;
}


/**
 * @brief Make it possible to create a timeout and to cancel it.
 * @return a cancellable functor that will be executed on the dispatcher provided (not on the AP).
 *
 * Cancelling from "dispatcher" the functor returned by this method
 * guarantees that "timeoutFn" is not going to be executed if it has
 * not been executed yet.
 */
inline boost::shared_ptr< NS_ZINC::CancellableFunctor >
    postWithDelayOnDispatcher(
        boost::function< void (void) > timeoutFn,
        NS_ZINC::ActionProcessor& actionProcessor, ///< Need an AP as this is the only way to post with delay
        NS_ZINC::Dispatcher& dispatcher, ///< dispatcher to post to from Action Processor thread: it needs to
                                         ///< stay alive as long as ActionProcessor.
        const boost::posix_time::time_duration& delay)
{
    // Create a cancellable timeout functor that will be executed on the dispatcher provided (not on AP)
    boost::shared_ptr< NS_ZINC::CancellableFunctor > cancellableTimeout =
        boost::make_shared< NS_ZINC::CancellableFunctor >(timeoutFn);
    boost::function< void (void) > cancellableTimeoutFn =
        boost::bind(&NS_ZINC::CancellableFunctor::operator(), cancellableTimeout);

    // Make sure we have only one thread accessing the implementation by posting from ActionProcessor to Dispatcher
    boost::function< void (void) > callTimeoutFunctorOnProvidedDispatcher =
        bind(&NS_ZINC::Dispatcher::post, &dispatcher, cancellableTimeoutFn);
    boost::shared_ptr< NS_ZINC::Action > timeoutAction =
        boost::make_shared< NS_ZINC::Action >(callTimeoutFunctorOnProvidedDispatcher);
    timeoutAction->schedule(delay);
    actionProcessor.addAction(timeoutAction);

    return cancellableTimeout;
}

NS_NICKELTUNER_SYSTEM_CLOSE

#endif	/* NICKELTUNER_SYSTEM_PRODUCTION_PLAYBACKHELPERS_H_ */

