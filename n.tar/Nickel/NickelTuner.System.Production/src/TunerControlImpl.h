/*
 * TunerControlImpl.h
 *
 *  Created on: 28-Jun-2013
 *      Author: hubert.lacote@youview.com
 * 
 *  Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_PRODUCTION_TUNERCONTROL_IMPL_H_
#define NICKELTUNER_SYSTEM_PRODUCTION_TUNERCONTROL_IMPL_H_

#include <cadmium-system-api/macros.h>

#include <cobalt-system-api/macros.h>

#include <copper-system-api/macros.h>

#include <neon-client-api/macros.h>

#include <nickel-system-api/macros.h>

#include <nickeltuner-system-api/macros.h>

#include <zinc-common/macros.h>

#include <boost/shared_ptr.hpp>

#include <vector>
#include <string>
#include <stdint.h>

// TODO: DEVARCH-6925 - Create fwd decl in every project
NS_NEON_CLIENT_OPEN
class IPNetwork;
NS_NEON_CLIENT_CLOSE

NS_ZINC_OPEN
class Dispatcher;
template <typename T> class Property;
NS_ZINC_CLOSE

namespace Zinc {
namespace Broker {
class ProvisioningServiceAsync;
class UnifiedServiceRepositoryAsync;
class HiddenServicesStoreAsync;
class UnifiedEventRepositoryAsync;
} // namespace Broker
namespace ContentAcquisition {
class LinearAcquisitionAsync;
} //namespace ContentAcquisition
namespace Media {
class MediaRouterAsync;
} // namespace Media
namespace System {
class LocalStorageRepositoryAsync;
} // namespace System
} // namespace Zinc

NS_NICKELTUNER_SYSTEM_OPEN

class TunerControlAsync;

// TODO: DEVARCH-7141 - Find a proper LSR key name
const std::string LAST_SELECTED_SERVICE_LOCATOR_KEY = "platform.tuner.last-selected-service-locator";
const std::string OEM_IP_TUNERS_KEY                 = "oem.device.ip-tuner-count";
const std::string PLATFORM_IP_MAX_STREAMS_KEY       = "platform.ui.ipchannels.max-concurrent-streams";
const std::string ISP_IP_MAX_STREAMS_KEY            = "isp.ipnetwork.max-concurrent-streams";
const int32_t DEFAULT_IP_TUNERS_COUNT               = 2;

struct TunerControlConfig
{
    boost::shared_ptr< NS_ZINC::Property< std::string > > lastSelectedService;
    boost::shared_ptr< NS_ZINC::Property< int32_t > > platformIPMaxStreams;
    boost::shared_ptr< NS_ZINC::Property< int32_t > > ispIPMaxStreams;
    boost::shared_ptr< NS_ZINC::Property< int32_t > > oemIPMaxStreams;

    int32_t getIPTunersCount();
};

struct TunerControlServices
{
    boost::shared_ptr< NS_COBALT_SYSTEM::ProvisioningServiceAsync > provisioning;
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedServiceRepositoryAsync > usr;
    boost::shared_ptr< NS_COBALT_SYSTEM::HiddenServicesStoreAsync > hss;
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > uer;
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > dttMR;
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > ipMR;
    boost::shared_ptr< NS_NEON_CLIENT::IPNetwork > ipNetwork;
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > lsr;
    boost::shared_ptr< NS_CADMIUM_SYSTEM::LinearAcquisitionAsync > acquisition;
};

boost::shared_ptr< TunerControlAsync > createTunerControlImpl(
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
    const TunerControlConfig& config,
    const TunerControlServices& services
    ) ZINC_LOCAL;

NS_NICKELTUNER_SYSTEM_CLOSE

#endif /* NICKELTUNER_SYSTEM_PRODUCTION_TUNERCONTROL_IMPL_H_ */
