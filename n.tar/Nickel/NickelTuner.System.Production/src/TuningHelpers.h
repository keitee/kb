/*
 * File:   TuningHelpers.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 27 August 2013
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_PRODUCTION_TUNINGHELPERS_H_
#define NICKELTUNER_SYSTEM_PRODUCTION_TUNINGHELPERS_H_

#include <nickeltuner-system-api/macros.h>
#include <nickeltuner-system-api/ServiceHiddenException.h>
#include <nickeltuner-system-api/ServiceRestrictedException.h>
#include <nickeltuner-system-api/TuningReason.h>

#include <cadmium-system-api/LinearAcquisition.h>
#include <cadmium-system-api/ScheduledRecording.h>

#include <cobalt-system-api/EntitlementType.h>
#include <cobalt-system-api/NetworkProblemException.h>
#include <cobalt-system-api/ProvisioningInformationRetrievalFailedException.h>
#include <cobalt-system-api/ProvisioningServiceAsync.h>
#include <cobalt-system-api/ResultHelpers.h>
#include <cobalt-system-api/UnifiedEventRepository.h>
#include <cobalt-system-api/UnifiedService.h>
#include <cobalt-system-api/UnifiedServiceHelpers.h>
#include <cobalt-system-api/UnifiedServiceRepositoryAsync.h>
#include <cobalt-system-api/HiddenServicesStoreAsync.h>

#include <nickel-common/NickelLogger.h>

#include <nickel-system-api/MediaRouterAsync.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/Continuation.h>
#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/async/FutureBarrier.h>
#include <zinc-common/async/FutureValue.h>

#include <boost/algorithm/string.hpp>
#include <boost/optional.hpp>
#include <boost/shared_ptr.hpp>

#include <string>
#include <map>
#include <set>
#include <vector>

namespace
{
const std::string MEDIA_ROUTER_RESTRICTED_SERVICE_SET   = "RESTRICTED_SERVICE_SET";
const std::string DEFAULT_MEDIA_ROUTER_SINK             = "decoder://0";

std::string createCompoundURL(const std::string& mediaContentURL,
                              const boost::optional< std::string >& sasURL = boost::optional< std::string >())
{
    return "linear:" + (sasURL ? *sasURL + "#" : "") + mediaContentURL;
}

std::vector< std::string >
getNonRestrictedChannelsFromSourceInformation(
    const std::map< std::string, std::string >& sourceInformation)
{
    const std::string* availableChannels =
        NS_COBALT_SYSTEM::getValuePtrFromMap(sourceInformation, MEDIA_ROUTER_RESTRICTED_SERVICE_SET);

    std::vector< std::string > availableChannelsVector;
    if (availableChannels)
    {
        std::string availableChannelsTrimmed = boost::trim_copy(*availableChannels);
        if (!availableChannelsTrimmed.empty())
        {
            boost::split(availableChannelsVector, availableChannelsTrimmed, boost::is_any_of(" "),
                boost::token_compress_on);
        }
    }
    return availableChannelsVector;
}

bool isDTTEvent(const std::string& eventLocator)
{
    return boost::starts_with(eventLocator, "dvb://");
}

} // anon namespace

NS_NICKELTUNER_SYSTEM_OPEN

void convertUnifiedServiceFutureToVoidFuture(NS_ZINC::FutureValue< NS_COBALT_SYSTEM::UnifiedService > fv)
{
    fv.get();
}

NS_ZINC::Future< void > recycleMediaRouterAsNeededToGoToService(
        NS_NICKEL_SYSTEM::MediaRouterAsync& targetMR,
        const NS_COBALT_SYSTEM::UnifiedService& targetService)
{
    bool recycleRequired = NS_COBALT_SYSTEM::isIpService(targetService);
    NICKEL_DEBUG("recycleMediaRouterAsNeededToGoToService() - recycleRequired = " << recycleRequired);
    return recycleRequired ? targetMR.recycle() : NS_ZINC::completedFuture();
}

// This is to avoid IllegalReconfiguration: sink has already been set.
// Could be done once for first tuning without having to call getSink.
struct SetSinkAsNeededContinuation : NS_ZINC::Continuation< void, SetSinkAsNeededContinuation >
{
    NS_NICKEL_SYSTEM::MediaRouterAsync* mr;

    void start(NS_NICKEL_SYSTEM::MediaRouterAsync* mr_)
    {
        mr = mr_;
        continueOnSuccess(mr->getSink(), &This::onGotCurrentSink);
    }

    void onGotCurrentSink(const std::string& currentSink)
    {
        if (currentSink != DEFAULT_MEDIA_ROUTER_SINK)
        {
            continueOnSuccess(mr->setSink(DEFAULT_MEDIA_ROUTER_SINK), &This::onSinkSet);
        }
        else
        {
            promise.complete();
        }
    }

    void onSinkSet()
    {
        promise.complete();
    }
};


/**
 * This function maps a ProvisioningInformationRetrievalFailed exception thrown
 * by ProvisioningService::getSASURLForServiceLivePlayback to a CP Helper Application
 * "Linear Problem" Launch Context string.
 *
 * The resulting string should be passed to the Helper Application when it is launched,
 * as the value of the 'reason.error.youview.com' parameter.
 *
 * NOTE: This method will return an empty string if the exception indicates  that the
 * 'reason.error.youview.com' launch parameter should NOT be supplied to the helper app.
 * This can happen if the reason is not_provisioned.
 *
 * See 0018-S IP Channels, Annex A
 */
std::string mapProvisioningInformationRetrievalFailureToHelperErrorReason(
    const NS_COBALT_SYSTEM::ProvisioningInformationRetrievalFailedException& e)
{
    using NS_COBALT_SYSTEM::ProvisioningInformationRetrievalFailureReason;
    switch (e.getReason())
    {
        case ProvisioningInformationRetrievalFailureReason::not_provisioned:
            return "";

        case ProvisioningInformationRetrievalFailureReason::bad_request:
            return "provisioning_information.malformed_locator";

        case ProvisioningInformationRetrievalFailureReason::invalid_server_domain:
            return "provisioning_information.invalid_server_domain";

        case ProvisioningInformationRetrievalFailureReason::server_unreachable:
            return "provisioning_information.server_unreachable";

        case ProvisioningInformationRetrievalFailureReason::untrusted_server:
            return "provisioning_information.untrusted_server";

        case ProvisioningInformationRetrievalFailureReason::connection_denied:
            return "provisioning_information.connection_denied";

        case ProvisioningInformationRetrievalFailureReason::server_error:
            return "provisioning_information.server_error";

        case ProvisioningInformationRetrievalFailureReason::unsuccsessful_request:
            return "provisioning_information.unsuccessful_request";

        case ProvisioningInformationRetrievalFailureReason::server_denied:
            return "provisioning_information.server_denied";

        case ProvisioningInformationRetrievalFailureReason::bad_server_response:
            return "provisioning_information.malformed_response";

        case ProvisioningInformationRetrievalFailureReason::information_missing:
            return "provisioning_information.information_missing";

        default:
            return "provisioning_information";
    }
}

/**
 * Return the URI to give to the MediaRouter for playback of an IP channel
 * as specified in 00-18-S IP Channels - 0.4E, section 4.5.4.
 *
 * This shall not be cached and shall be called just before giving the URL
 * to the MediaRouter.
 *
 * For DTT services, this returns the service locator.
 * For IP services, this returns "linear:" followed by:
 *  - the ContentURL obtained from the relevant Content Referencing Information
 *    for FTA IP Services,
 *  - a MS3 compound URI built from the relevant ContentURL and SAS-URL for
 *    FTV or subscription IP services.
 *
 * For convenience, this also fails if trying to tune to an IP service without
 * Internet connection.
 */
struct GetMediaSourceURIContinuation :
        NS_ZINC::Continuation< std::string, GetMediaSourceURIContinuation >
{
    NS_COBALT_SYSTEM::ProvisioningServiceAsync* provisioningService;
    NS_COBALT_SYSTEM::UnifiedService service;

    void start(NS_COBALT_SYSTEM::ProvisioningServiceAsync* provisioningService_,
               const NS_COBALT_SYSTEM::UnifiedService& service_,
               bool connected)
    {
        NICKEL_DEBUG("GetMediaSourceURIContinuation::start(" << service_.serviceLocator << ")");
        provisioningService = provisioningService_;
        service             = service_;

        if (NS_COBALT_SYSTEM::isIpService(service) && !connected)
        {
            promise.exception(NS_COBALT_SYSTEM::NetworkProblemException());
        }
        else
        {
            // This returns the URI to give to the MediaRouter, it is a compound URL
            // for IP channels and the service locator for DTT services.
            if (NS_COBALT_SYSTEM::isIpService(service))
            {
                if (NS_COBALT_SYSTEM::getEntitlementType(service) == NS_COBALT_SYSTEM::EntitlementType::free_to_air)
                {
                    promise.complete(createCompoundURL(service.mediaContent.url));
                }
                else
                {
                    continueOnSuccess(
                        provisioningService->getSASURLForServiceLivePlayback(service.serviceLocator),
                        &This::onGotSASURL);
                }
            }
            else
            {
                promise.complete(service.serviceLocator);
            }
        }
    }

    void onGotSASURL(const std::string& sasURL)
    {
        NICKEL_DEBUG("GetMediaSourceURIContinuation::onGotSASURL(" << sasURL << ")");
        promise.complete(createCompoundURL(service.mediaContent.url, sasURL));
    }
};

struct GetServiceAvailabilityContinuation :
        NS_ZINC::Continuation< NS_COBALT_SYSTEM::UnifiedService, GetServiceAvailabilityContinuation >
{
    TunerControlServices                  services;

    TunerControlConfig                    config;

    TuningReason::Enum                    tuningReason;

    bool                                  isTargetServiceRecording;

    NS_COBALT_SYSTEM::UnifiedService      service;

    std::vector<std::string>              hiddenServices;

    void start(const TunerControlServices& services_,
               const TunerControlConfig& config_,
               const std::string& serviceLocator,
               const TuningReason::Enum tuningReason_)
    {
        NICKEL_DEBUG("GetServiceAvailabilityContinuation::start(" << serviceLocator << ")");
        services = services_;
        config = config_;
        tuningReason = tuningReason_;
        isTargetServiceRecording = false;

        NS_ZINC::FutureBarrier inParallel(getDispatcher());

        inParallel.addWithSuccessCallback(
            services.usr->getService(serviceLocator),
            NS_ZINC::assignTo(&service));

        inParallel.addWithSuccessCallback(
            services.hss->get(),
            NS_ZINC::assignTo(&hiddenServices));

        continueOnSuccess(
            inParallel,
            &This::onGotService);
    }

    void onGotService()
    {
        NICKEL_DEBUG("GetServiceAvailabilityContinuation::onGotService("
                     << service.serviceLocator << ")");

        if (std::binary_search(hiddenServices.begin(), hiddenServices.end(),
                service.serviceLocator))
        {
            NICKEL_INFO("GetServiceAvailabilityContinuation::onGotService - "
                        << "Service '" << service.serviceLocator << "' hidden");
            promise.exception(ServiceHiddenException());
        }
        else if (NS_COBALT_SYSTEM::isIpService(service))
        {
            // Temporarily prevent IP tuner exhaustion only for tuning requests
            // coming from CRB.
            // TODO: DEVARCH-8634: Apply this logic for all tuning requests and
            // do not even pass tuningReason
            if (tuningReason == TuningReason::video_broadcast_initiated)
            {
                continueOnSuccess(
                    services.acquisition->getScheduledRecordings(),
                    &This::onGotScheduledRecordings);
            }
            else
            {
                promise.complete(service);
            }
        }
        else
        {
            continueOnSuccess(
                services.dttMR->getSourceInformation(),
                &This::onGotSourceInformation);
        }
    }

    void onGotScheduledRecordings(const std::vector<NS_CADMIUM_SYSTEM::ScheduledRecording>& scheduledRecordings)
    {
        NICKEL_DEBUG("GetServiceAvailabilityContinuation::onGotScheduledRecordings("
                     << scheduledRecordings.size() << " scheduled recordings)");

        NS_ZINC::FutureBarrier inParallel(getDispatcher());

        std::set<std::string> recordingIpStreams;
        BOOST_FOREACH(const NS_CADMIUM_SYSTEM::ScheduledRecording& s, scheduledRecordings)
        {
            // Compute only recordings in progress for IP services
            if (!isDTTEvent(s.eventLocator) &&
                (s.status == NS_CADMIUM_SYSTEM::ScheduledRecordingStatus::in_progress ||
                 s.status == NS_CADMIUM_SYSTEM::ScheduledRecordingStatus::in_progress_in_series))
            {
                // Make getEvent() dbus requests only for unique event locators
                if (recordingIpStreams.insert(s.eventLocator).second)
                {
                    inParallel.addWithSuccessCallback(
                        services.uer->getEvent(s.eventLocator),
                        boost::bind(&This::onGotUnifiedEvent, this, _1));
                }
            }
        }

        continueOnSuccess(
            inParallel,
            boost::bind(&This::onGotAllUnifiedEventsForScheduledRecordings, this,
                (int32_t)recordingIpStreams.size()));
    }

    void onGotUnifiedEvent(const NS_COBALT_SYSTEM::UnifiedEvent& ue)
    {
        NICKEL_DEBUG("GetServiceAvailabilityContinuation::onGotUnifiedEvent("
                     << ue.data.eventLocator << ")");
        if (ue.data.serviceLocator == service.serviceLocator)
        {
            NICKEL_DEBUG("GetServiceAvailabilityContinuation::onGotUnifiedEvent "
                         << "- Service '" << ue.data.serviceLocator << "' is recording");
            isTargetServiceRecording = true;
        }
    }

    void onGotAllUnifiedEventsForScheduledRecordings(const int32_t& nIPRecordingsInProgress)
    {
        const int32_t ipTunersCount = config.getIPTunersCount();
        NICKEL_DEBUG("GetServiceAvailabilityContinuation::onGotAllUnifiedEventsForScheduledRecordings "
                     << "- IP Recordings in progress: " << nIPRecordingsInProgress
                     << "- IP tuners availables: " << ipTunersCount
                     << "- Is target service recording?: " << isTargetServiceRecording);

        if (isTargetServiceRecording ||
            (!isTargetServiceRecording &&
                nIPRecordingsInProgress < ipTunersCount))
        {
            promise.complete(service);
        }
        else
        {
            NICKEL_INFO("GetServiceAvailabilityContinuation::onGotAllUnifiedEventsForScheduledRecordings "
                         << "- Tuning '" << service.serviceLocator
                         << "' will cause IP tuner exhaustion");
            promise.exception(ServiceRestrictedException());
        }
    }

    void onGotSourceInformation(const std::map< std::string, std::string >& sourceInformation)
    {
        NICKEL_DEBUG("GetServiceAvailabilityContinuation::onGotSourceInformation(" << service.serviceLocator << ")");
        std::vector< std::string > availableChannels =
            getNonRestrictedChannelsFromSourceInformation(sourceInformation);
        if (!availableChannels.empty() // Tuner exhaustion
            && std::find(availableChannels.begin(), availableChannels.end(), service.serviceLocator) ==
               availableChannels.end())
        {
            NICKEL_INFO("GetServiceAvailabilityContinuation::onGotSourceInformation - Service '"
                        << service.serviceLocator << "' is restricted - Alternative service: '"
                        << availableChannels[0] << "'.");
            promise.exception(ServiceRestrictedException());
        }
        else
        {
            promise.complete(service);
        }
    }

    void onError(const NS_ZINC::ErrorCode& e)
    {
        NICKEL_ERROR("GetServiceAvailabilityContinuation::onError("
                     << e << "-" << e.message() << ")");
        promise.error(e);
    }
};

NS_NICKELTUNER_SYSTEM_CLOSE

#endif	/* NICKELTUNER_SYSTEM_PRODUCTION_TUNINGHELPERS_H_ */

