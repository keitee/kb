/*
 * LinearPlaybackControlImpl.h
 *
 *  Created on: 28 Aug 2013
 *      Author: hubert.lacote@youview.com
 * 
 *  Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_PRODUCTION_LINEARPLAYBACKCONTROL_IMPL_H_
#define NICKELTUNER_SYSTEM_PRODUCTION_LINEARPLAYBACKCONTROL_IMPL_H_

#include <cobalt-system-api/macros.h>

#include <mercury-system-api/macros.h>

#include <nickel-system-api/macros.h>

#include <nickeltuner-system-api/macros.h>

#include <zinc-common/macros.h>

#include <boost/assign/list_of.hpp>
#include <boost/shared_ptr.hpp>

#include <string>
#include <vector>

#include <stdint.h>

// TODO: DEVARCH-6925 - Create fwd decl in every project
NS_NICKEL_SYSTEM_OPEN
class MultiServiceParentalController;
class ParentallyControlledMediaRouter;
class ParentalControlsSettings;
NS_NICKEL_SYSTEM_CLOSE

NS_ZINC_OPEN
class ActionProcessor;
class Dispatcher;
NS_ZINC_CLOSE

namespace Zinc {
namespace Application {
class UIManagerAsync;
} // namespace Application
namespace Media {
class MediaRouterAsync;
} // namespace Media
namespace Broker {
class UnifiedEventRepositoryAsync;
} //namespace Broker
} // namespace Zinc

NS_NICKELTUNER_SYSTEM_OPEN

class LinearPlaybackControlAsync;
class TunerControlAsync;

// TODO: DEVARCH-7142: Find proper LSR key names
const std::string BROADCAST_SD_BITRATE_KEY              = "platform.localmedialibrary.broadcastsdbitrate";
const std::string RESTRICTED_RATINGS_KEY                = "platform.tuner.restricted-ratings";
const std::string TIMESHIFT_BUFFER_SIZE_IN_BYTES_KEY    = "oem.device.timeshiftcapturebuffersize";
const std::string WATERSHED_END_TIME_KEY                = "platform.tuner.watershed-end-time";
const std::string WATERSHED_START_TIME_KEY              = "platform.tuner.watershed-start-time";

struct LinearPlaybackControlConfig
{
    LinearPlaybackControlConfig():
        broadcastSdBitrate(3300000),
        timeshiftBufferSizeInBytes(broadcastSdBitrate / 8 * 2 * 3600), ///< Made up so that timeshift buffer is just
                                                                       ///< big enough to store 2 hours of content.
        watershedEndTimeInSeconds(5*3600 + 0.5*3600),
        watershedStartTimeInSeconds(20 * 3600)
    {
        // TODO: DEVARCH-7142: Possibly load that from LSR
        restrictedRatings = boost::assign::list_of
            ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen")
            ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#sixteen")
            ("http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#eighteen")
            ("http://bbfc.org.uk/BBFCRatingCS/2002#15")
            ("http://bbfc.org.uk/BBFCRatingCS/2002#18")
            ("http://bbfc.org.uk/BBFCRatingCS/2002#R18");
    }

    uint32_t                    broadcastSdBitrate;
    std::vector< std::string >  restrictedRatings;
    uint32_t                    timeshiftBufferSizeInBytes;
    uint32_t                    watershedEndTimeInSeconds;
    uint32_t                    watershedStartTimeInSeconds;
};

boost::shared_ptr< LinearPlaybackControlAsync > createLinearPlaybackControlImpl(
    boost::shared_ptr< NS_ZINC::Dispatcher > dispatcher,
    boost::shared_ptr< NS_ZINC::ActionProcessor > ap,
    boost::shared_ptr< TunerControlAsync > tunerControl,
    boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync > uiManager,
    boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > uer,
    boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > dttMR,
    boost::shared_ptr< NS_NICKEL_SYSTEM::ParentallyControlledMediaRouter > parentallyControlledIpMR,
    const LinearPlaybackControlConfig& config) ZINC_LOCAL;

NS_NICKELTUNER_SYSTEM_CLOSE

#endif /* NICKELTUNER_SYSTEM_PRODUCTION_LINEARPLAYBACKCONTROL_IMPL_H_ */
