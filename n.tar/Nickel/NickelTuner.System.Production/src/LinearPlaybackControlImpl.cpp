/*
 * LinearPlaybackControlImpl.cpp
 *
 *  Created on: 28 Aug 2013
 *      Author: hubert.lacote@youview.com
 *
 *  Copyright (C) 2013 YouView TV Ltd
 */

#include "LinearPlaybackControlImpl.h"

#include "PlaybackHelpers.h"

#include <cobalt-system-api/UnifiedEvent.h>
#include <cobalt-system-api/UnifiedEventHelpers.h>
#include <cobalt-system-api/UnifiedService.h>
#include <cobalt-system-api/UnifiedServiceHelpers.h>

#include <nickel-common/NickelLogger.h>

#include <nickel-parental-controls/LinearEventTracker.h>
#include <nickel-parental-controls/ParentalControls.h>
#include <nickel-parental-controls/ParentalControlsHelpers.h>
#include <nickel-parental-controls/ParentallyControlledMediaRouter.h>
#include <nickel-parental-controls/PresentFollowingArchive.h>

#include <nickel-system-api/MediaRouterAsync.h>
#include <nickel-system-api/MediaRouterEventListener.h>

#include <nickeltuner-system-api/FutureProvider.h>
#include <nickeltuner-system-api/LinearPlaybackControlAsync.h>
#include <nickeltuner-system-api/LinearPlaybackControlEventListener.h>
#include <nickeltuner-system-api/TunerControlAsync.h>
#include <nickeltuner-system-api/TunerControlEventListener.h>
#include <nickeltuner-system-api/TunerControlStatus.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/Continuation.h>
#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Future.h>
#include <zinc-common/async/Promise.h>
#include <zinc-common/ActionProcessor.h>
#include <zinc-common/Action.h>
#include <zinc-common/MonotonicClock.h>

#include <boost/bind.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/function.hpp>
#include <boost/make_shared.hpp>
#include <boost/optional.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/utility/in_place_factory.hpp>

#include <stdexcept>

#include <time.h>

using namespace NS_COBALT_SYSTEM;
using namespace NS_MERCURY_SYSTEM;
using namespace NS_NICKEL_SYSTEM;
using namespace NS_NICKELTUNER_SYSTEM;
using namespace NS_ZINC;

using boost::bind;
using boost::function;
using boost::make_shared;
using boost::optional;
using boost::make_optional;
using boost::scoped_ptr;
using boost::shared_ptr;

NS_NICKELTUNER_SYSTEM_OPEN

namespace
{

struct LinearPlaybackControlState : NS_ZINC::Enum
{
    enum Enum {
        uninitialised = 0,
        initialising = 1,
        initialised = 2,
    };
};

class LinearPlaybackControlImpl : public LinearEventTrackerEventListener,
                                  public LinearPlaybackControlAsync,
                                  public MediaRouterEventListener,
                                  public ParentalControlsEventListener,
                                  public TunerControlEventListener,
                                  // The design of LinearEventTracker forces to use enable_shared_from_this
                                  // to add a listener.
                                  public boost::enable_shared_from_this< LinearPlaybackControlImpl >
{
public:
    LinearPlaybackControlImpl(
                    shared_ptr< Dispatcher > d,
                    shared_ptr< ActionProcessor > ap,
                    shared_ptr< UIManagerAsync > uiManager_,
                    shared_ptr< UnifiedEventRepositoryAsync > uer,
                    shared_ptr< MediaRouterAsync > dttMR,
                    shared_ptr< ParentallyControlledMediaRouter > pcIpMR,
                    const LinearPlaybackControlConfig& config)
        : dispatcher(d),
          actionProcessor(ap),
          uiManager(uiManager_),
          unifiedEventRepository(uer),
          dttMediaRouter(dttMR),
          parentallyControlledIpMediaRouter(pcIpMR),
          configuration(config),
          state(LinearPlaybackControlState::uninitialised),
          deactivationSignalReceivedDuringInitialisation(false)
    {
        function< void (void) > updateFn = bind(&LinearPlaybackControlImpl::doUpdateParentalControls, this);
        // Make sure we have only one thread accessing the implementation by posting from ActionProcessor on Dispatcher
        function< void (void) > callUpdateOnMainDispatcher = bind(&Dispatcher::post, dispatcher, updateFn);
        shared_ptr< NS_ZINC::Action > updateAction =
            make_shared< NS_ZINC::Action >(callUpdateOnMainDispatcher);
        updateAction->schedule(boost::posix_time::milliseconds(UPDATE_INTERVAL_MS),
                               boost::posix_time::milliseconds(UPDATE_INTERVAL_MS));

        function< void (void) > refreshFn = bind(&LinearPlaybackControlImpl::doRefreshLinearEventTracker, this);
        // Make sure we have only one thread accessing the implementation by posting from ActionProcessor on Dispatcher
        function< void (void) > callRefreshOnMainDispatcher = bind(&Dispatcher::post, dispatcher, refreshFn);
        shared_ptr< NS_ZINC::Action > refreshAction =
            make_shared< NS_ZINC::Action >(callRefreshOnMainDispatcher);
        refreshAction->schedule(boost::posix_time::milliseconds(REFRESH_INTERVAL_MS),
                                boost::posix_time::milliseconds(REFRESH_INTERVAL_MS));

        ap->addAction(updateAction);
        ap->addAction(refreshAction);
    }

    virtual Future< void > pause()
    {
        NICKEL_DEBUG(__FUNCTION__);
        return setPlaybackSpeed(0.0).then(
            bind(&LinearPlaybackControlImpl::doSetPlaybackModeOnSuccess,
                this, _1, PlaybackMode::timeshifting));
    }

    virtual Future< void > play()
    {
        NICKEL_DEBUG(__FUNCTION__);
        return setPlaybackSpeed(1.0);
    }

    virtual Future< void > fastForward()
    {
        NICKEL_DEBUG("fastForward()");
        return changePlaySpeed(&doFastForward);
    }

    virtual Future< void > rewind()
    {
        NICKEL_DEBUG("rewind()");
        return changePlaySpeed(&doRewind);
    }

    virtual Future< void > seekPosition(const SeekReference::Enum whence,
        const int32_t offset, const SeekMode::Enum mode)
    {
        NICKEL_DEBUG("seekPosition("
                     << enum_to_string(whence) << ", "
                     << offset << ", " << enum_to_string(mode) << ")");
        Future< void > seekPositionResult =
            executeMediaRouterMethod<void>(bind(&MediaRouterAsync::seekPosition, _1, whence, offset, mode));
        if (whence == SeekReference::end && offset == 0)
        {
            return seekPositionResult.then(
                bind(&LinearPlaybackControlImpl::doSetPlaybackModeOnSuccess,
                    this, _1, PlaybackMode::live));
        }
        else if (whence == SeekReference::current && offset < 0)
        {
            return seekPositionResult.then(
                bind(&LinearPlaybackControlImpl::doSetPlaybackModeOnSuccess,
                    this, _1, PlaybackMode::timeshifting));
        }
        else if (whence == SeekReference::current && offset > 0)
        {
            return seekPositionResult; // do not set playback mode live
                                       // expect call to seekPosition(end, 0)
        }
        else if (whence == SeekReference::start && offset == 0)
        {
            return seekPositionResult.then(
                bind(&LinearPlaybackControlImpl::doSetPlaybackModeOnSuccess,
                    this, _1, PlaybackMode::timeshifting));
        }
        else
        {
            NICKEL_WARN("Unexpected seekPosition("
                        << enum_to_string(whence) << ", "
                        << offset << ", " << enum_to_string(mode) << ")");
            return seekPositionResult;
        }
    }

    virtual Future< void > minimise()
    {
        NICKEL_DEBUG("minimise()");
        return executeMediaRouterMethod<void>(bind(
            &LinearPlaybackControlImpl::doSetDestinationVideoWindow,
            this, SHRUNK_WINDOW, _1));
    }

    virtual Future< void > maximise()
    {
        NICKEL_DEBUG("maximise()");
        return executeMediaRouterMethod<void>(bind(
            &LinearPlaybackControlImpl::doSetDestinationVideoWindow,
            this, UNSHRUNK_WINDOW, _1));
    }

    virtual Future< bool > isMaximised()
    {
        NICKEL_DEBUG("isMaximised()");
        return getInitialisationFuture().then(
            *dispatcher,
            bind(&LinearPlaybackControlImpl::doGetIsMaximised, this));
    }

    virtual Future< void > setDestinationVideoWindow(
        double destinationX, double destinationY,
        double destinationWidth, double destinationHeight)
    {
        NICKEL_DEBUG("setDestinationVideoWindow(destinationX = "
                     << destinationX << ", destinationY = " << destinationY
                     << ", destinationWidth = " << destinationWidth
                     << ", destinationHeight = " << destinationHeight << ")");

        VideoWindowDescriptor window;
        window.sourceX = 0.0;
        window.sourceY = 0.0;
        window.sourceWidth = 1.0;
        window.sourceHeight = 1.0;
        window.destinationX = destinationX;
        window.destinationY = destinationY;
        window.destinationWidth = destinationWidth;
        window.destinationHeight = destinationHeight;

        return executeMediaRouterMethod<void>(bind(
            &LinearPlaybackControlImpl::doSetDestinationVideoWindow,
            this, window, _1));
    }

    virtual Future< PlaybackMode::Enum > getPlaybackMode()
    {
        NICKEL_DEBUG("getPlaybackMode()");
        return getInitialisationFuture().then(
            *dispatcher,
            bind(&LinearPlaybackControlImpl::doGetPlaybackMode, this, _1));
    }

    virtual NS_ZINC::Future< double > getPlaybackSpeed()
    {
        NICKEL_DEBUG(__FUNCTION__);
        return executeMediaRouterMethod< double >(&MediaRouterAsync::getPlaySpeed);
    }

    virtual NS_ZINC::Future< void > setPlaybackSpeed(double requestedSpeed)
    {
        NICKEL_DEBUG("setPlaybackSpeed(" << requestedSpeed << ")");
        return changePlaySpeed(&doSetSpeed, make_optional(true, requestedSpeed));
    }

    virtual Future< uint32_t > getEventTimeshiftFromLiveInMilliSeconds(
        const std::string& eventLocator)
    {
        NICKEL_DEBUG("getEventTimeshiftFromLiveInMilliSeconds(" << eventLocator << ")");
        return getInitialisationFuture().then(
            *dispatcher,
            bind(&LinearPlaybackControlImpl::doGetEventTimeshiftFromLiveInMilliSeconds, this, eventLocator));
    }

    virtual Future< uint32_t > getTimeshiftFromLiveInMilliSeconds();

    virtual Future< std::map<std::string, std::string> > getSourceInformation()
    {
        NICKEL_DEBUG("getSourceInformation()");
        return executeMediaRouterMethod< std::map<std::string, std::string> >(&MediaRouterAsync::getSourceInformation);
    }

    virtual Future< Position > getPosition()
    {
        NICKEL_DEBUG("getPosition()");
        return executeMediaRouterMethod<Position>(&MediaRouterAsync::getPosition);
    };

    virtual Future< std::vector<Track> > getTracks()
    {
        NICKEL_DEBUG("getTracks()");
        return executeMediaRouterMethod< std::vector<Track> >(&MediaRouterAsync::getTracks);
    }

    virtual Future< Track > getVideoTrack()
    {
        NICKEL_DEBUG("getVideoTrack()");
        return executeMediaRouterMethod<Track>(&MediaRouterAsync::getVideoTrack);
    }

    virtual Future< Track > getSubtitleTrack()
    {
        NICKEL_DEBUG("getSubtitleTrack()");
        return executeMediaRouterMethod<Track>(&MediaRouterAsync::getSubtitleTrack);
    }

//------------------------
// Accessing what's on now
//------------------------
public:
    virtual Future< UnifiedEvent > getCurrentEvent()
    {
        NICKEL_DEBUG("getCurrentEvent()");
        return getInitialisationFuture().then(
            *dispatcher,
            bind(&LinearPlaybackControlImpl::doGetCurrentEvent, this));
    }

public: // LinearEventTrackerEventListener
    virtual void LinearEventChanged(const UnifiedEvent& event)
    {
        NICKEL_DEBUG("LinearEventChanged(" << event.data.eventLocator << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::CurrentEventChanged, _1, event ) );
    }

//---------------------------
// Accessing ParentalControls
//---------------------------
public:
    virtual Future< bool > isLocked()
    {
        NICKEL_DEBUG("isLocked()");
        return getInitialisationFuture().then(
            *dispatcher,
            bind(&LinearPlaybackControlImpl::doGetIsLocked, this));
    }

    virtual Future< void > allowRestrictedContent(const uint32_t autoAcceptSeconds)
    {
        NICKEL_DEBUG("allowRestrictedContent(" << autoAcceptSeconds << ")");
        return getInitialisationFuture().then(
            *dispatcher,
            bind(&LinearPlaybackControlImpl::doAllowRestrictedContent, this, autoAcceptSeconds));
    }

public: // ParentalControlsEventListener
    virtual void ParentalControlsStateChange(bool locked)
    {
        NICKEL_DEBUG("ParentalControlsStateChange(" << locked << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::ParentalControlsStateChange, _1, locked ) );
    }

public: // TunerControlEventListener

    virtual void StatusChange(const TunerControlStatus& status);

public: // MediaRouterEventListener

    virtual void BufferStatusEvent(const BufferStatusEventValue::Enum bufferStatus)
    {
        NICKEL_DEBUG("BufferStatusEvent(" << bufferStatus << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::BufferStatusEvent, _1, bufferStatus) );
    }
    virtual void DrmEvent(const DrmEventValue::Enum event, const std::string& drmMediaIdentifier,
                          const std::string& rightsIssuerUrl)
    {
        NICKEL_DEBUG("DrmEvent("
                     << event << ", " << drmMediaIdentifier << ", " << rightsIssuerUrl << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::DrmEvent,
                            _1, event, drmMediaIdentifier, rightsIssuerUrl) );
    }
    virtual void PositionChangeEvent(const Position& position)
    {
        NICKEL_TRACE("PositionChangeEvent(" << position.end - position.current << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::PositionChangeEvent, _1, position) );
    }
    virtual void SourceEvent(const SourceEventValue::Enum event, const SetSourceReason::Enum reason)
    {
        NICKEL_DEBUG("SourceEvent(" << event << ", " << reason << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::SourceEvent,
                            _1, event, reason) );
    }
    virtual void SpeedChangeEvent()
    {
        NICKEL_DEBUG("SpeedChangeEvent()");
        if (state == LinearPlaybackControlState::initialising || state == LinearPlaybackControlState::initialised)
        {
            getMediaRouterForService(*tunedService)->getPlaySpeed().then(
                *dispatcher,
                boost::bind(&LinearPlaybackControlImpl::emitSpeedChangeEvent, this, _1));
        }
    }
    virtual void StatusEvent(const StatusEventValue::Enum event)
    {
        NICKEL_DEBUG("StatusEvent(" << event << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::StatusEvent, _1, event) );
    }
    virtual void ErrorEvent(const ErrorEventValue::Enum error, const ErrorEventContext::Enum context, const std::string& info)
    {
        NICKEL_DEBUG("ErrorEvent(" << error << ", " << context << ", " << info << ")");
        produceEvent( bind( &LinearPlaybackControlEventListener::ErrorEvent, _1,
                            error, context, info) );
    }

private:

    bool doGetIsMaximised()
    {
        matchStateOrThrow(LinearPlaybackControlState::initialised);
        NICKEL_DEBUG("doGetIsMaximised() - isMaximised = " << !(*isMinimised));
        return !(*isMinimised);
    }

    void onVideoResized(const FutureValue<void>& setVideoWindowResult,
        const VideoWindowRelativeRect& window)
    {
        if (setVideoWindowResult.getError())
        {
            NICKEL_ERROR("onVideoResized (" << setVideoWindowResult.getError().name()
                << "-" << setVideoWindowResult.getError().message() << ")");

            setVideoWindowResult.get(); // propagate exception
        }
        else
        {
            isMinimised = window.x != 0.0 || window.y != 0.0
                || window.width != 1.0 || window.height != 1.0;

            produceEvent(bind(&LinearPlaybackControlEventListener::VideoResizeEvent,
                _1, window));
        }
    }

    PlaybackMode::Enum doGetPlaybackMode(const FutureValue< void >& initialisationFv)
    {
        if (initialisationFv.getError())
        {
            NICKEL_ERROR("doGetPlaybackMode(" << initialisationFv.getError() << "-"
                         << initialisationFv.getError().message() << ")");
            initialisationFv.get(); // will throw if uninitialised
        }

        NICKEL_DEBUG(__FUNCTION__);
        matchStateOrThrow(LinearPlaybackControlState::initialised);
        return *playbackMode;
    }

    uint32_t doGetEventTimeshiftFromLiveInMilliSeconds(const std::string& eventLocator)
    {
        matchStateOrThrow(LinearPlaybackControlState::initialised);
        boost::optional< EventTransition > eventTransition = presentFollowingArchive->getEventByEventLocator(eventLocator);
        if (eventTransition)
        {
            NS_ZINC::monotonic_clock::time_point now = NS_ZINC::monotonic_clock::now();
            NS_ZINC::monotonic_clock::time_point eventTransitionTime = eventTransition->transitionTime;
            boost::posix_time::time_duration negativePosition = eventTransitionTime - now;
            if (negativePosition.total_milliseconds() > 0)
            {
                // Should never happen unless something went really wrong with MonotonicClock:
                // eventTransitionTime was acquired by calling getEpochTimeInNanoSecondsImpl().
                const std::string errorMsg = "doGetEventTimeshiftFromLiveInMilliSeconds(" + eventLocator
                                             + ") - Monotonic time is not monotonic! event("
                                             + monotonicToDayTimePrintable(eventTransitionTime) + ") > now("
                                             + monotonicToDayTimePrintable(now) + ")";
                NICKEL_ERROR(errorMsg);
                throw std::runtime_error(errorMsg);
            }
            else if (-negativePosition > getMaximumTimeshiftBufferDuration(configuration))
            {
                const std::string errorMsg = "doGetEventTimeshiftFromLiveInMilliSeconds(" + eventLocator
                                             + ") - Event is not anymore in the buffer: event("
                                             + monotonicToDayTimePrintable(eventTransitionTime) + ") - now("
                                             + monotonicToDayTimePrintable(now) + ")";
                NICKEL_ERROR(errorMsg);
                throw std::runtime_error(errorMsg);
            }
            else
            {
                NICKEL_DEBUG("doGetEventTimeshiftFromLiveInMilliSeconds(" << eventLocator << ") - now("
                             << monotonicToDayTimePrintable(now) << ") - event("
                             << monotonicToDayTimePrintable(eventTransitionTime) << ") = "
                             << -negativePosition.total_seconds() << "s.");
                return static_cast< uint32_t >(-negativePosition.total_milliseconds());
            }
        }
        else
        {
            const std::string errorMsg = "doGetEventTimeshiftFromLiveInMilliSeconds(" + eventLocator +
                                             ") - Event is not in the buffer.";
            NICKEL_ERROR(errorMsg);
            throw std::runtime_error(errorMsg);
        }
    }

    UnifiedEvent doGetCurrentEvent()
    {
        matchStateOrThrow(LinearPlaybackControlState::initialised);
        NICKEL_DEBUG("doGetCurrentEvent()");
        if (!linearEventTracker)
        {
            NICKEL_ERROR("doGetCurrentEvent() - Not tuned to a service.");
        }
        return linearEventTracker ? linearEventTracker->getCurrentLinearEvent() : UnifiedEvent();
    }

    bool doGetIsLocked()
    {
        matchStateOrThrow(LinearPlaybackControlState::initialised);
        NICKEL_DEBUG("doGetIsLocked()");
        if (!parentalControls)
        {
            NICKEL_INFO("doGetIsLocked() - Not tuned to a parentally controlled service.");
        }
        return parentalControls ? parentalControls->isLocked() : false;
    }

    void doAllowRestrictedContent(uint32_t autoAcceptSeconds)
    {
        matchStateOrThrow(LinearPlaybackControlState::initialised);
        NICKEL_DEBUG("doAllowRestrictedContent(" << autoAcceptSeconds << ")");
        if (!parentalControls)
        {
            const std::string errorMsg("Cannot call allowRestrictedContent on a service not parentally controlled.");
            NICKEL_ERROR(errorMsg);
            throw std::runtime_error(errorMsg);
        }
        parentalControls->allowRestrictedContent(autoAcceptSeconds);
    }

    void emitSpeedChangeEvent(FutureValue<double> fv)
    {
        if (fv.getError())
        {
            NICKEL_ERROR("emitSpeedChangeEvent(" << fv.getError() << "-" << fv.getError().message() << ")");
        }
        else
        {
            NICKEL_DEBUG("emitSpeedChangeEvent(" << fv.get() << ")");
            produceEvent( bind( &LinearPlaybackControlEventListener::SpeedChangeEvent, _1, fv.get() ) );
        }
    }

private:

    Future< void > getInitialisationFuture()
    {
        switch (state)
        {
            case LinearPlaybackControlState::initialising:
            case LinearPlaybackControlState::initialised:
                return initialisationWork->getNewFuture();
            case LinearPlaybackControlState::uninitialised:
            default:
                NICKEL_ERROR("getInitialisationFuture() - Uninitialised.");
                return exceptionalFuture< void >(
                    std::runtime_error("getInitialisationFuture() - Uninitialised."));
        }
    }

    shared_ptr< MediaRouterAsync > getMediaRouterForService(const UnifiedService& service) const
    {
        return isIpService(service) ? parentallyControlledIpMediaRouter->mr : dttMediaRouter;
    }

    void matchStateOrThrow(LinearPlaybackControlState::Enum state_)
    {
        if (state != state_)
        {
            NICKEL_ERROR("matchStateOrThrow() - Request discarded.");
            throw std::runtime_error("matchStateOrThrow() - Request discarded.");
        }
    }

    template <typename T>
    bool matchState(LinearPlaybackControlState::Enum state_, Promise< T > promise)
    {
        if (state == state_)
        {
            return true;
        }
        else
        {
            NICKEL_ERROR("matchState() - Request discarded.");
            promise.exception(std::runtime_error("matchState() - Request discarded."));
            return false;
        }
    }

    template <typename T>
    bool matchState(LinearPlaybackControlState::Enum state_,
                      const std::string& serviceLocator_, Promise< T > promise)
    {
        if (state == state_ && tunedService->serviceLocator == serviceLocator_)
        {
            return true;
        }
        else
        {
            NICKEL_ERROR("matchState() - Request discarded.");
            promise.exception(std::runtime_error("matchState() - Request discarded."));
            return false;
        }
    }

    void doUpdateParentalControls()
    {
        if (parentalControls)
        {
            parentalControls->update(UPDATE_INTERVAL_MS);
        }
    }

    void doRefreshLinearEventTracker()
    {
        // Some DTT MediaRouter implementations do not conform to specs
        // (See 1125-S 1.2.E - section A.2.3) and do not send
        // PositionChangeEvent when not timeshifted, therefore not triggering LinearEventChanged.
        if (linearEventTracker)
        {
            // Trigger LinearEventChanged when necessary - Position will be assumed to be 0.
            linearEventTracker->getCurrentLinearEvent();
        }
    }

    Future< void > doSetDestinationVideoWindow(
        const VideoWindowDescriptor& window, MediaRouterAsync* mr)
    {
        NICKEL_DEBUG("doSetDestinationVideoWindow(src.x = " << window.sourceX
            << ", src.y = " << window.sourceY << ", src.width = "
            << window.sourceWidth << ", src.height = " << window.sourceHeight
            << ", dst.x = " << window.destinationX << ", dst.y = "
            << window.destinationY << ", dst.width = " << window.destinationWidth
            << ", dst.height = " << window.destinationHeight << ")");
        // The only potential error is OutOfBounds, i.e. video window is incorrect.
        // This cannot happen as SHRUNK_WINDOW and UNSHRUNK_WINDOW are constants.

        VideoWindowRelativeRect dstRect;
        dstRect.x = window.destinationX;
        dstRect.y = window.destinationY;
        dstRect.width = window.destinationWidth;
        dstRect.height = window.destinationHeight;

        return mr->setVideoWindow(window).then(boost::bind(
            &LinearPlaybackControlImpl::onVideoResized, this, _1, dstRect));
    }

    void doSetPlaybackModeOnSuccess(const FutureValue< void >& fv, const PlaybackMode::Enum playbackMode_)
    {
        if (fv.getError())
        {
            NICKEL_ERROR("doSetPlaybackModeOnSuccess("
                         << fv.getError() << "-" << fv.getError().message() << ")");
            fv.get(); // propagate exception
        }
        else
        {
            NICKEL_DEBUG("doSetPlaybackModeOnSuccess(playbackMode = "
                         << enum_to_string(playbackMode_) << ")");
            matchStateOrThrow(LinearPlaybackControlState::initialised);
            setPlaybackMode(playbackMode_);
        }
    }

    void setPlaybackMode(const PlaybackMode::Enum playbackMode_)
    {
        if (!playbackMode || *playbackMode != playbackMode_)
        {
            NICKEL_INFO("setPlaybackMode(playbackMode = " << enum_to_string(playbackMode_) << ")");
            playbackMode = playbackMode_;
            produceEvent( bind( &LinearPlaybackControlEventListener::PlaybackModeChange, _1,
                *playbackMode) );
        }
    }

    template<typename T>
    Future< T > executeMediaRouterMethod(function< Future< T > (MediaRouterAsync*) > mrMethod);

    Future< void > changePlaySpeed(function< double (double) > playSpeedFunction, const optional< double >&);
    Future< void > changePlaySpeed(function< double (double) > playSpeedFunction);

    // Give access to this class' private interface to the Continuations
    class ChangePlaySpeedContinuation;
    class InitialisationContinuation;
    template<typename T>
    struct ExecuteMediaRouterMethodContinuation :
            NS_ZINC::Continuation< T, ExecuteMediaRouterMethodContinuation<T> >
    {
        typedef NS_ZINC::Continuation<T, ExecuteMediaRouterMethodContinuation<T> > base_class;
        LinearPlaybackControlImpl                      *control;
        function< Future< T > (MediaRouterAsync*) > mrMethod;

        void start(LinearPlaybackControlImpl* control_,
                   function< Future< T > (MediaRouterAsync*) > mrMethod_)
        {
            NICKEL_DEBUG("ExecuteMediaRouterMethodContinuation::start()");
            control = control_;
            mrMethod = mrMethod_;
            this->continueOnSuccess(
                control->getInitialisationFuture(),
                &ExecuteMediaRouterMethodContinuation<T>::onInitialisationCompleted);
        }

        void onInitialisationCompleted()
        {
            if (control->matchState(LinearPlaybackControlState::initialised, base_class::promise))
            {
                NICKEL_DEBUG("ExecuteMediaRouterMethodContinuation::onInitialisationCompleted()");
                this->continueOn(
                    mrMethod(control->getMediaRouterForService(*control->tunedService).get()),
                    &ExecuteMediaRouterMethodContinuation<T>::onMediaRouterMethodExecuted);
            }
        }

        void onMediaRouterMethodExecuted(const NS_ZINC::FutureValue<T>& v);

        void onError(const NS_ZINC::ErrorCode &e)
        {
            NICKEL_ERROR("ExecuteMediaRouterMethodContinuation::onError(" << e << "-" << e.message() << ")");
            base_class::promise.error(e);
        }
    };

    void reset()
    {
        NICKEL_INFO("reset()");
        if (tunedService)
        {
            getMediaRouterForService(*tunedService)->removeListener(shared_from_this());
        }
        linearEventTracker.reset();
        parentalControls.reset();
        presentFollowingArchive.reset();
        deactivationSignalReceivedDuringInitialisation = false;
        tuningSignalsToProcess = std::queue< tuning_signal_entry_t >(); // no method clear() on a queue...
        initialisationWork.reset();
        tunedService.reset();
        isMinimised.reset();
        playbackMode.reset();
        state = LinearPlaybackControlState::uninitialised;
    }

    shared_ptr< Dispatcher >                        dispatcher;
    shared_ptr< ActionProcessor >                   actionProcessor;
    shared_ptr< UIManagerAsync >                    uiManager;
    shared_ptr< UnifiedEventRepositoryAsync >       unifiedEventRepository;
    shared_ptr< MediaRouterAsync >                  dttMediaRouter;
    shared_ptr< ParentallyControlledMediaRouter >   parentallyControlledIpMediaRouter;
    LinearPlaybackControlConfig                     configuration;

    shared_ptr< LinearEventTracker >                linearEventTracker;
    shared_ptr< ParentalControls >                  parentalControls;
    shared_ptr< PresentFollowingArchive >           presentFollowingArchive;

    LinearPlaybackControlState::Enum                state;

    typedef boost::tuple< UnifiedService, Promise< void > > tuning_signal_entry_t;
    enum { SERVICE = 0, TUNED_RECEIVED = 1 };
    bool                                            deactivationSignalReceivedDuringInitialisation;
    std::queue< tuning_signal_entry_t >             tuningSignalsToProcess;
    shared_ptr< FutureProvider< void > >            initialisationWork;
    optional< UnifiedService >                      tunedService;
    optional< bool >                                isMinimised;
    optional< PlaybackMode::Enum >                  playbackMode;
};

template<typename T>
void LinearPlaybackControlImpl::ExecuteMediaRouterMethodContinuation<T>::onMediaRouterMethodExecuted(const NS_ZINC::FutureValue<T>& v)
{
    base_class::promise.complete(v.get());
};

template<>
void LinearPlaybackControlImpl::ExecuteMediaRouterMethodContinuation<void>::onMediaRouterMethodExecuted(const NS_ZINC::FutureValue<void>& v)
{
    v.get();
    base_class::promise.complete();
};

template<typename T>
Future< T > LinearPlaybackControlImpl::executeMediaRouterMethod(function< Future< T > (MediaRouterAsync*) > mrMethod)
{
    return ExecuteMediaRouterMethodContinuation<T>::create(*dispatcher, this, mrMethod);
}

uint32_t getTimeshift(const Position& position)
{
    int32_t delay = position.end - position.current;
    NICKEL_DEBUG("getTimeshift(" << delay << ")");
    if (delay < 0)
    {
        return 0;
    }
    else
    {
        return delay;
    }
}

Future< uint32_t > LinearPlaybackControlImpl::getTimeshiftFromLiveInMilliSeconds()
{
    NICKEL_DEBUG("getTimeshiftFromLiveInMilliSeconds()");
    return executeMediaRouterMethod<Position>(&MediaRouterAsync::getPosition)
            .then(NS_ZINC::onSuccessCallback(&getTimeshift));
}

struct LinearPlaybackControlImpl::ChangePlaySpeedContinuation :
        NS_ZINC::Continuation< void, LinearPlaybackControlImpl::ChangePlaySpeedContinuation >
{
    LinearPlaybackControlImpl*  control;
    function< double (double) > playSpeedFunction;
    std::string                 serviceLocator;
    optional <double>           predefinedSpeed;

    void start(LinearPlaybackControlImpl*  control_,
               function< double (double) > playSpeedFunction_,
               const optional< double >& targetSpeed)
    {
        NICKEL_DEBUG("ChangePlaySpeedContinuation::start()");
        control = control_;
        playSpeedFunction = playSpeedFunction_;
        predefinedSpeed = targetSpeed;
        continueOnSuccess(
            control->getInitialisationFuture(),
            &This::onInitialisationCompleted);

    }

    void onInitialisationCompleted()
    {
        if (control->matchState(LinearPlaybackControlState::initialised, promise))
        {
            NICKEL_DEBUG("ChangePlaySpeedContinuation::onInitialisationCompleted()");
            serviceLocator = control->tunedService->serviceLocator;
            if(predefinedSpeed)
            {
                onGotPlaySpeed(*predefinedSpeed);
            }
            else
            {
                continueOnSuccess(
                    control->getMediaRouterForService(*control->tunedService)->getPlaySpeed(),
                    &This::onGotPlaySpeed);
            }
        }
    }

    void onGotPlaySpeed(double playSpeed)
    {
        if (control->matchState(LinearPlaybackControlState::initialised, serviceLocator, promise))
        {
            double newPlaySpeed = playSpeedFunction(playSpeed);
            NICKEL_DEBUG("ChangePlaySpeedContinuation::onGotPlaySpeed("
                         << playSpeed << ") - Setting to " << newPlaySpeed);
            continueOnSuccess(
                control->getMediaRouterForService(*control->tunedService)->setPlaySpeed(newPlaySpeed),
                &This::onPlaySpeedSet);
        }
    }

    void onPlaySpeedSet()
    {
        NICKEL_DEBUG("ChangePlaySpeedContinuation::onPlaySpeedSet()");
        promise.complete();
    }

    void onError(const NS_ZINC::ErrorCode& e)
    {
        NICKEL_ERROR("ChangePlaySpeedContinuation::onError(" << e << "-" << e.message() << ")");
        promise.error(e);
    }
};

Future< void > LinearPlaybackControlImpl::changePlaySpeed(function<double (double)> playSpeedFunction,
    const optional< double >& targetSpeed)
{
    return ChangePlaySpeedContinuation::create(*dispatcher, this, playSpeedFunction, targetSpeed);
}

Future< void > LinearPlaybackControlImpl::changePlaySpeed(function<double (double)> playSpeedFunction)
{
    return changePlaySpeed(playSpeedFunction, make_optional(false, 0.0));
}

struct LinearPlaybackControlImpl::InitialisationContinuation :
        Continuation< void, LinearPlaybackControlImpl::InitialisationContinuation >
{
    shared_ptr< LinearPlaybackControlImpl >                             control;
    shared_ptr< Dispatcher >                                            sharedDispatcher;
    shared_ptr< FutureProvider< shared_ptr< PresentFollowingArchive > > > pfArchiveProvider;
    shared_ptr< NS_ZINC::CancellableFunctor >                           cancellableSafetyTimeout;
    bool                                                                ipMrAVBlankedForSafety;

    void start(shared_ptr< LinearPlaybackControlImpl > control_,
               shared_ptr< Dispatcher > sharedDispatcher_,
               const UnifiedService& targetService,
               Future< void > tunedStatusReceived)
    {
        NICKEL_DEBUG("InitialisationContinuation::start(" << targetService.serviceLocator << ")");
        control = control_;
        sharedDispatcher = sharedDispatcher_;

        if (control->tunedService)
        {
            control->getMediaRouterForService(*control->tunedService)->removeListener(control);
        }
        control->tunedService = targetService;
        control->state = LinearPlaybackControlState::initialising;
        control->getMediaRouterForService(targetService)->addListener(sharedDispatcher, control);

        Future< shared_ptr< PresentFollowingArchive > > pfArchiveFuture =
            NS_NICKEL_SYSTEM::createPresentFollowingArchiveAsync(
                control->unifiedEventRepository, sharedDispatcher,
                targetService.serviceLocator,
                &NS_ZINC::monotonic_clock::now,
                PURGE_PERIOD);
        pfArchiveProvider =
            FutureProvider< shared_ptr< PresentFollowingArchive > >::create(
                boost::ref(*sharedDispatcher),
                pfArchiveFuture);

        // Clear the internal state of ParentallyControlledMediaRouter since the channel was changed
        control->parentallyControlledIpMediaRouter->resetMR();

        // Wait for MediaRouter to be started (StatusChange(tuned))
        // before making any calls to MediaRouter.
        continueOnSuccess(
            tunedStatusReceived,
            &This::onTunedStatusReceived);
    }

    void onTunedStatusReceived()
    {
        NICKEL_DEBUG("InitialisationContinuation::onTunedStatusReceived() - Tuned status received.");

        // Timeout added for safety in case the Future returned by
        // createLinearEventTrackerAsync() takes a long time to complete:
        // if this happens, we need to blank the video until the Future is completed.
        ipMrAVBlankedForSafety = false;
        if (isIpService(*control->tunedService))
        {
            cancellableSafetyTimeout =
                postWithDelayOnDispatcher(
                    bind(&LinearPlaybackControlImpl::InitialisationContinuation::onTimedOutForSafety, this),
                    *control->actionProcessor,
                    *sharedDispatcher,
                    PARENTAL_CONTROLS_SAFETY_TIMEOUT_MS);
        }

        continueOnSuccess( // Not a lot we can do if this fails.
                           // TODO: DEVARCH-7159: Add tests to show that 15 rated
                           //       content could be shown if UER.getPF() fails).
            NS_NICKEL_SYSTEM::createLinearEventTrackerAsync(
                pfArchiveProvider->getNewFuture(),
                control->getMediaRouterForService(*control->tunedService),
                control,
                sharedDispatcher,
                &NS_ZINC::monotonic_clock::now),
            &This::onLinearEventTrackerCreated);
    }

    /**
     * This is a safety mechanism added to make sure that parental controls
     * are applied temporarily (without notifying the UI) in the case where
     * it takes a long time for LinearEventTracker to be created (e.g. this can
     * happen when UER.getPresentFollowing() takes a long time to reply,
     * usually when booting the box).
     */
    void onTimedOutForSafety()
    {
        NICKEL_INFO("InitialisationContinuation::onTimedOutForSafety() - "
                    << "blanking A/V waiting for UER.getPF()...");
        control->parentallyControlledIpMediaRouter->lockMR();
        ipMrAVBlankedForSafety = true;
    }

    void onLinearEventTrackerCreated(shared_ptr< LinearEventTracker > let)
    {
        NICKEL_INFO("InitialisationContinuation::onLinearEventTrackerCreated()");

        // Note that it is guaranteed that the safety timeout cannot execute
        // when this method is executing (same dispatcher used).
        if (cancellableSafetyTimeout)
        {
            cancellableSafetyTimeout->cancel();
        }

        // Trigger the initial LinearEventChanged signal
        let->getCurrentLinearEvent();
        control->linearEventTracker = let;
        control->presentFollowingArchive = pfArchiveProvider->getNewFuture().get(); // Already completed

        if (isIpService(*control->tunedService))
        {
            NICKEL_DEBUG("InitialisationContinuation::onLinearEventTrackerCreated() - Creating parental controls...");
            NS_NICKEL_SYSTEM::ParentalControlsSettings pcSettings;
            pcSettings.restrictedRatings = control->configuration.restrictedRatings;
            pcSettings.watershedEndTime = control->configuration.watershedEndTimeInSeconds;
            pcSettings.watershedStartTime = control->configuration.watershedStartTimeInSeconds;
            control->parentalControls =
                NS_NICKEL_SYSTEM::createParentalControls(
                    control->uiManager,
                    control->dispatcher,
                    let,
                    control->parentallyControlledIpMediaRouter,
                    &getEpochTimeInNanoSecondsImpl,
                    pcSettings,
                    *control->tunedService);
            control->parentalControls->addListener(sharedDispatcher, control);
            control->parentalControls->update(0);
            if (ipMrAVBlankedForSafety && !control->parentalControls->isLocked())
            {
                NICKEL_INFO("InitialisationContinuation::onLinearEventTrackerCreated() - "
                            << "parental controls is not required - unblanking A/V...");
                control->parentallyControlledIpMediaRouter->unlockMR();
            }
        }
        else
        {
            control->parentalControls.reset();
        }
        continueOnSuccess(
            control->getMediaRouterForService(*control->tunedService)->getVideoWindow(),
            &This::onGotVideoWindow);
    }

    void onGotVideoWindow(const NS_NICKEL_SYSTEM::VideoWindowDescriptor& videoWindow)
    {
        // Comparing to UNSHRUNK_WINDOW that has exact double values (1.0 and 0.0)
        // There is therefore no need for an epsilon comparison.
        control->isMinimised = !(videoWindow == UNSHRUNK_WINDOW);
        NICKEL_DEBUG("InitialisationContinuation::onGotVideoWindow() - isMinimised = " << *(control->isMinimised));

        control->setPlaybackMode(PlaybackMode::live);

        control->state = LinearPlaybackControlState::initialised;
        if (!restartInitialisation())
        {
            if (control->deactivationSignalReceivedDuringInitialisation)
            {
                const std::string msg = "Initialisation failed - Deactivation signal received during initialisation.";
                NICKEL_INFO(msg);
                promise.exception(std::runtime_error(msg));
                control->reset();
            }
            else
            {
                NICKEL_DEBUG("Initialisation completed successfully.");
                promise.complete();
            }
        }
    }

    void onError(const ErrorCode& e)
    {
        NICKEL_ERROR("InitialisationContinuation::onError(" << e << "-" << e.message() << ")");
        // In case UER.getPF() fails, I think it is still preferable to let the user
        // watch TV even though the event could be restricted.
        if (ipMrAVBlankedForSafety)
        {
            NICKEL_INFO("InitialisationContinuation::onError() - Unlocking MR...");
            control->parentallyControlledIpMediaRouter->unlockMR();
        }
        if (!restartInitialisation())
        {
            NICKEL_DEBUG("InitialisationContinuation::onError() - Completing promise with error...");
            promise.error(e);
            control->reset();
        }
    }

    /**
     * @return true if Initialisation has to restart because there was
     *         a channel change during the current Initialisation.
     */
    bool restartInitialisation()
    {
        NICKEL_DEBUG("InitialisationContinuation::restartInitialisation()");
        BOOST_ASSERT(!control->tuningSignalsToProcess.empty());
        control->tuningSignalsToProcess.pop();

        if (!control->tuningSignalsToProcess.empty() && !control->deactivationSignalReceivedDuringInitialisation)
        {
            tuning_signal_entry_t& nextTuningSignalToProcess =
                control->tuningSignalsToProcess.front();
            const UnifiedService& service =
                nextTuningSignalToProcess.get< SERVICE >();
            NICKEL_INFO("InitialisationContinuation::restartInitialisation() - Restarting initialisation "
                        << "for service '" << service.serviceLocator << "'");
            start(control, sharedDispatcher,
                  service,
                  nextTuningSignalToProcess.get< TUNED_RECEIVED >().getFuture());
            return true;
        }
        return false;
    }

};

void LinearPlaybackControlImpl::StatusChange(const TunerControlStatus& status)
{
    NICKEL_DEBUG("StatusChange("
                 << enum_to_string(status.state) << " - " << status.service.serviceLocator << ")");
    switch (status.state)
    {
        case TunerControlState::tuning:
        {
            deactivationSignalReceivedDuringInitialisation = false;
            // Several `tuning` signals might be received before
            // InitialisationContinuation completes: queue them.
            tuningSignalsToProcess.push(
                boost::make_tuple(
                    status.service,
                    Promise< void >() // completed when tuned status received
                ) );
            // If an initialisation is in progress, wait for the end of the
            // continuation to start another one.
            if (state != LinearPlaybackControlState::initialising)
            {
                initialisationWork =
                    FutureProvider< void >::create(
                        boost::ref(*dispatcher),
                        InitialisationContinuation::create(
                            *dispatcher, shared_from_this(), dispatcher,
                            status.service,
                            tuningSignalsToProcess.back().get< TUNED_RECEIVED >().getFuture())
                    );
            }
        }
        break;
        case TunerControlState::tuned:
            if (!tuningSignalsToProcess.empty())
            {
                try
                {
                    NICKEL_DEBUG("StatusChange - completing last tunedReceived promise.");
                    tuningSignalsToProcess.back().get< TUNED_RECEIVED >().complete();
                }
                catch (const PromiseAlreadyCompleted&)
                {
                    NICKEL_ERROR("StatusChange - last tunedReceived promise already completed.");
                }
            }

        break;
        case TunerControlState::uninitialised:
        case TunerControlState::deactivating:
        case TunerControlState::deactivated:
            if (state != LinearPlaybackControlState::initialising)
            {
                NICKEL_DEBUG("StatusChange - Calling reset().");
                reset();
            }
            else
            {
                NICKEL_INFO("StatusChange - Deferring call to reset().");
                deactivationSignalReceivedDuringInitialisation = true;
            }
        break;
    }
}


} // anon namespace

///////////////////////////////////////////////////////////
// Factory method
///////////////////////////////////////////////////////////

shared_ptr< LinearPlaybackControlAsync > createLinearPlaybackControlImpl(
    shared_ptr< Dispatcher > dispatcher,
    shared_ptr< ActionProcessor > ap,
    shared_ptr< TunerControlAsync > tunerControl,
    shared_ptr< UIManagerAsync > uiManager,
    shared_ptr< UnifiedEventRepositoryAsync > uer,
    shared_ptr< MediaRouterAsync > dttMR,
    shared_ptr< ParentallyControlledMediaRouter > pcIpMR,
    const LinearPlaybackControlConfig& config)
{
    shared_ptr< LinearPlaybackControlImpl > ctrl =
        make_shared< LinearPlaybackControlImpl >(
            dispatcher, ap, uiManager, uer, dttMR, pcIpMR, config);
    tunerControl->addListener(dispatcher, ctrl);

    return ctrl;
}

NS_NICKELTUNER_SYSTEM_CLOSE
