/*
 * BusName.cpp
 *
 *  Created on: 16 Aug 2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/BusName.h"

NS_NICKELTUNER_SYSTEM_OPEN

char const * const BusName::TUNER = "Zinc.Tuner";

NS_NICKELTUNER_SYSTEM_CLOSE
