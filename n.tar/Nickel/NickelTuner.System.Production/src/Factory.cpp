/* 
 * File:   Factory.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 01 July 2013
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/Factory.h"

#include "TunerControlImpl.h"
#include "LinearPlaybackControlImpl.h"

#include <cadmium-system-api/SystemFactory.h>
#include <cadmium-system-api/LinearAcquisitionAsync.h>

#include <cobalt-system-api/SystemFactory.h>
#include <cobalt-system-api/ProvisioningServiceAsync.h>
#include <cobalt-system-api/UnifiedServiceRepositoryAsync.h>
#include <cobalt-system-api/HiddenServicesStoreAsync.h>
#include <cobalt-system-api/HiddenServicesStoreConvertToAsync.h>

#include <copper-system-api/LocalStorageRepositorySync.h>
#include <copper-system-api/LSRHelpers.h>
#include <copper-system-api/Registry.h>
#include <copper-system-api/SystemFactory.h>
#include <copper-system-api/LocalStorageRepositoryConvertToSync.h>

#include <mercury-system-api/SystemFactory.h>

#include <neon-client-api/ClientFactory.h>
#include <neon-client-api/IPNetwork.h>

#include <nickel-common/NickelLogger.h>

#include <nickel-parental-controls/ParentalControls.h>
#include <nickel-parental-controls/ParentallyControlledMediaRouter.h>

#include <nickel-system-api/SystemFactory.h>
#include <nickel-system-api/MediaRouterAsync.h>
#include <nickel-system-api/MediaRouterFactoryConvertToSync.h>

#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/ActionProcessor.h>
#include <zinc-common/FilePluginConfig.h>
#include <zinc-common/PluginFactory.h>

#include <boost/algorithm/string/classification.hpp> // for is_any_of
#include <boost/algorithm/string/join.hpp>
#include <boost/algorithm/string/split.hpp>

#include <string>
#include <vector>

using NS_ZINC::Dispatcher;
using NS_COPPER_SYSTEM::getLSRItem;
using boost::shared_ptr;

NS_NICKELTUNER_SYSTEM_OPEN

namespace
{

template<class FactoryT>
FactoryT& getFactory(const char* const config)
{
    const std::string configFilePath(NS_ZINC::PackageDataFinder()
        .find(config));
    NICKEL_DEBUG("Using configuration file: " << config);
    const NS_ZINC::FilePluginConfig pluginConfig(configFilePath);
    return NS_ZINC::PluginFactory::getInstance<FactoryT>(pluginConfig);
}

std::vector< std::string >
convertRestrictedRatings(const std::string& lsrRatings, const std::vector< std::string >& defaultRatings)
{
    if (lsrRatings.empty())
    {
        NICKEL_WARN("Overriding LSR provided value for '" << RESTRICTED_RATINGS_KEY << "': '"
                    << boost::algorithm::join(defaultRatings, ", ") << "'");
        return defaultRatings;
    }
    else
    {
        std::vector< std::string > restrictedRatings;
        boost::split(restrictedRatings,
                     lsrRatings,
                     boost::is_any_of("\t "),
                     boost::token_compress_on);
        NICKEL_DEBUG("Using LSR provided value for '" << RESTRICTED_RATINGS_KEY << "': '"
                     << boost::algorithm::join(restrictedRatings, ", ") << "'");
        return restrictedRatings;
    }
}

int32_t convertToIPMaxStreams(const std::string& value)
{
    int32_t result = -1;
    try
    {
        result = boost::lexical_cast< int32_t >( value );
    }
    catch( boost::bad_lexical_cast& )
    {
    }
    return result;
}

} // anon namespace

Factory::Factory(shared_ptr< Dispatcher > d)
    : dispatcher(d)
{
}

shared_ptr< TunerControlAsync > Factory::createTunerControl()
{
    NICKEL_FUNC_TRACE;
    if (!tunerControl)
    {
        const TunerControlConfig config =
        {
            createLastSelectedServiceProperty(),
            createPlatformIPMaxStreamsProperty(),
            createISPIPMaxStreamsProperty(),
            createOEMIPMaxStreamsProperty()
        };

        const TunerControlServices services =
        {
            createProvisioningService(),
            createUnifiedServiceRepository(),
            createHiddenServicesStore(),
            createUnifiedEventRepository(),
            createDTTMediaRouter(),
            createParentallyControlledIPMediaRouter()->mr,
            createIPNetwork(),
            createLocalStorageRepository(),
            createLinearAcquisition()
        };

        tunerControl = createTunerControlImpl(dispatcher,
                                              config,
                                              services);
    }
    return tunerControl;
}

shared_ptr< LinearPlaybackControlAsync > Factory::createLinearPlaybackControl()
{
    NICKEL_FUNC_TRACE;
    if (!linearPlaybackControl)
    {
        NS_COPPER_SYSTEM::LocalStorageRepositorySync& syncLSR = *createSyncLocalStorageRepository();

        LinearPlaybackControlConfig config;
        config.broadcastSdBitrate = getLSRItem< uint32_t >(syncLSR,
            BROADCAST_SD_BITRATE_KEY, config.broadcastSdBitrate);
        config.restrictedRatings = convertRestrictedRatings( getLSRItem< std::string >(syncLSR,
            RESTRICTED_RATINGS_KEY, std::string("")), config.restrictedRatings);
        config.timeshiftBufferSizeInBytes = getLSRItem< uint32_t >(syncLSR,
            TIMESHIFT_BUFFER_SIZE_IN_BYTES_KEY, config.timeshiftBufferSizeInBytes);
        config.watershedEndTimeInSeconds = getLSRItem< uint32_t >(syncLSR,
            WATERSHED_END_TIME_KEY, config.watershedEndTimeInSeconds);
        config.watershedStartTimeInSeconds = getLSRItem< uint32_t >(syncLSR,
            WATERSHED_START_TIME_KEY, config.watershedStartTimeInSeconds);
        if (config.broadcastSdBitrate == 0)
        {
            const std::string errorMsg("createLinearPlaybackControl - Invalid value for broadcastSdBitrate.");
            NICKEL_ERROR(errorMsg);
            throw std::invalid_argument(errorMsg);
        }
        linearPlaybackControl =
            createLinearPlaybackControlImpl(dispatcher,
                                            createActionProcessor(),
                                            createTunerControl(),
                                            createUIManager(),
                                            createUnifiedEventRepository(),
                                            createDTTMediaRouter(),
                                            createParentallyControlledIPMediaRouter(),
                                            config);
    }
    return linearPlaybackControl;
}

boost::shared_ptr< NS_CADMIUM_SYSTEM::LinearAcquisition > Factory::createLinearAcquisition()
{
    NICKEL_FUNC_TRACE;
    if (!linearAcquisition)
    {
        linearAcquisition = 
            getFactory<NS_CADMIUM_SYSTEM::SystemFactory>(
                "cadmium-system-factory.plugin-config").createLinearAcquisition();
    }
    return linearAcquisition;
}

boost::shared_ptr< NS_COBALT_SYSTEM::ProvisioningService > Factory::createProvisioningService()
{
    NICKEL_FUNC_TRACE;
    if (!provisioningService)
    {
        provisioningService = 
            getFactory<NS_COBALT_SYSTEM::SystemFactory>(
                "cobalt-system-factory.plugin-config").createProvisioningService();
    }
    return provisioningService;
}

boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedServiceRepository > Factory::createUnifiedServiceRepository()
{
    NICKEL_FUNC_TRACE;
    if (!unifiedServiceRepository)
    {
        unifiedServiceRepository = 
            getFactory<NS_COBALT_SYSTEM::SystemFactory>(
                "cobalt-system-factory.plugin-config").createUnifiedServiceRepository();
    }
    return unifiedServiceRepository;
}

boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepository > Factory::createUnifiedEventRepository()
{
    NICKEL_FUNC_TRACE;
    if (!unifiedEventRepository)
    {
        unifiedEventRepository = 
            getFactory<NS_COBALT_SYSTEM::SystemFactory>(
                "cobalt-system-factory.plugin-config").createUnifiedEventRepository();
    }
    return unifiedEventRepository;
}

boost::shared_ptr< NS_COBALT_SYSTEM::HiddenServicesStoreAsync > Factory::createHiddenServicesStore()
{
    NICKEL_FUNC_TRACE;
    if (!hiddenServicesStore)
    {
        hiddenServicesStore = NS_COBALT_SYSTEM::convertToAsync(
            getFactory<NS_COBALT_SYSTEM::SystemFactory>(
                "cobalt-system-factory.plugin-config").createHiddenServicesStore(),
             dispatcher);
    }
    return hiddenServicesStore;
}

boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > Factory::createLocalStorageRepository()
{
    NICKEL_FUNC_TRACE;
    if (!localStorageRepository)
    {
        localStorageRepository =
            getFactory<NS_COPPER_SYSTEM::SystemFactory>(
                "copper-system-factory.plugin-config").createLocalStorageRepository();
    }
    return localStorageRepository;
}

boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > Factory::createSyncLocalStorageRepository()
{
    NICKEL_FUNC_TRACE;
    if (!syncLocalStorageRepository)
    {
        // TODO: DEVARCH-7161 - Move synchronous initialisation of TunerControl out of the main-loop
        syncLocalStorageRepository = NS_COPPER_SYSTEM::convertToSync(createLocalStorageRepository());
    }
    return syncLocalStorageRepository;
}

boost::shared_ptr< NS_COPPER_SYSTEM::Registry > Factory::createRegistry()
{
    NICKEL_FUNC_TRACE;
    if (!registry)
    {
        registry = NS_COPPER_SYSTEM::createRegistry( dispatcher, createLocalStorageRepository() );
    }
    return registry;
}

boost::shared_ptr< NS_ZINC::Property< int32_t > > Factory::createPlatformIPMaxStreamsProperty()
{
    NICKEL_FUNC_TRACE;
    if (!platformIPMaxStreamsProperty)
    {
        platformIPMaxStreamsProperty = makeConversionProperty(
            convertToIPMaxStreams,
            createRegistry()->makeProperty(
                PLATFORM_IP_MAX_STREAMS_KEY,
                getLSRItem< std::string >(*createSyncLocalStorageRepository(), PLATFORM_IP_MAX_STREAMS_KEY)));
    }
    return platformIPMaxStreamsProperty;
}

boost::shared_ptr< NS_ZINC::Property< int32_t > > Factory::createISPIPMaxStreamsProperty()
{
    NICKEL_FUNC_TRACE;
    if (!ispIPMaxStreamsProperty)
    {
        ispIPMaxStreamsProperty =
            makeConversionProperty(
                convertToIPMaxStreams,
                createRegistry()->makeProperty(
                    ISP_IP_MAX_STREAMS_KEY,
                    getLSRItem< std::string >(*createSyncLocalStorageRepository(), ISP_IP_MAX_STREAMS_KEY)));
    }
    return ispIPMaxStreamsProperty;
}

boost::shared_ptr< NS_ZINC::Property< int32_t > > Factory::createOEMIPMaxStreamsProperty()
{
    NICKEL_FUNC_TRACE;
    if (!oemIPMaxStreamsProperty)
    {
        oemIPMaxStreamsProperty =
            makeConversionProperty(
                convertToIPMaxStreams,
                createRegistry()->makeProperty(
                    OEM_IP_TUNERS_KEY,
                    getLSRItem< std::string >(*createSyncLocalStorageRepository(), OEM_IP_TUNERS_KEY)));
    }
    return oemIPMaxStreamsProperty;
}

boost::shared_ptr< NS_ZINC::Property< std::string > > Factory::createLastSelectedServiceProperty()
{
    NICKEL_FUNC_TRACE;
    if (!lastSelectedServiceProperty)
    {
        lastSelectedServiceProperty =
            createRegistry()->makeProperty(
                LAST_SELECTED_SERVICE_LOCATOR_KEY,
                getLSRItem< std::string >(*createSyncLocalStorageRepository(), LAST_SELECTED_SERVICE_LOCATOR_KEY));
    }

    return lastSelectedServiceProperty;
}

boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync > Factory::createUIManager()
{
    NICKEL_FUNC_TRACE;
    if (!uiManager)
    {
        uiManager = getFactory<NS_MERCURY_SYSTEM::SystemFactory>(
            "mercury-system-factory.plugin-config").createUIManager();
    }
    return uiManager;
}

boost::shared_ptr< NS_NEON_CLIENT::IPNetwork > Factory::createIPNetwork()
{
    NICKEL_FUNC_TRACE;
    if (!ipNetwork)
    {
        NS_NEON_CLIENT::ClientFactory& clientFactory =
            getFactory<NS_NEON_CLIENT::ClientFactory>("neon-client-factory.plugin-config");
        // TODO: Modify Neon Client factory so that it does not require
        // default dispatcher to be set - dispatcher is specified when calling addListener.
        clientFactory.setDefaultDispatcher(dispatcher);
        clientFactory.setFutureDispatcher(dispatcher);
        ipNetwork = clientFactory.createIPNetwork();
    }
    return ipNetwork;
}

boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > Factory::createDTTMediaRouter()
{
    NICKEL_FUNC_TRACE;
    if (!dttMediaRouter)
    {
        dttMediaRouter =
            getFactory<NS_NICKEL_SYSTEM::SystemFactory>(
                "nickel-system-factory.plugin-config").createDefaultMediaRouter();
    }
    return dttMediaRouter;
}

boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > Factory::createIPMediaRouter()
{
    NICKEL_FUNC_TRACE;
    if (!ipMediaRouter)
    {
        // TODO: DEVARCH-7161 - Move synchronous initialisation of TunerControl out of the main-loop

        // For some reason, calling .get() deadlocks in this statement:
        // getNickelSystemFactory().createMediaRouterFactory()->createMediaRouter().get();
        // Calling getNickelSystemFactory().createMediaRouterFactory()->createMediaRouter().setCallback()
        // works but complicates the implementation. This is why convertToSync is used.
        // This is the cause of this message when tunerd is started:
        // "dbus-c++ WARNING: It is not a good idea to do blocking work in the main dispatcher thread!"
        using NS_NICKEL_SYSTEM::convertToSync;
        ipMediaRouter = convertToSync( getFactory<NS_NICKEL_SYSTEM::SystemFactory>(
            "nickel-system-factory.plugin-config").createMediaRouterFactory() )->createMediaRouter();
    }
    return ipMediaRouter;
}

boost::shared_ptr< NS_NICKEL_SYSTEM::ParentallyControlledMediaRouter > Factory::createParentallyControlledIPMediaRouter()
{
    NICKEL_FUNC_TRACE;
    if (!parentallyControlledIPMediaRouter)
    {
        parentallyControlledIPMediaRouter =
            NS_NICKEL_SYSTEM::createParentallyControlledMR(
                createIPMediaRouter(), dispatcher);
    }
    return parentallyControlledIPMediaRouter;
}

boost::shared_ptr< NS_ZINC::ActionProcessor > Factory::createActionProcessor()
{
    NICKEL_FUNC_TRACE;
    if (!actionProcessor)
    {
        actionProcessor = boost::make_shared< NS_ZINC::ActionProcessor >();
        actionProcessor->start();
    }
    return actionProcessor;
}

void Factory::setLinearAcquisition(boost::shared_ptr< NS_CADMIUM_SYSTEM::LinearAcquisitionAsync > la)
{
    NICKEL_FUNC_TRACE;
    linearAcquisition = la;
}

void Factory::setProvisioningService(boost::shared_ptr< NS_COBALT_SYSTEM::ProvisioningService > ps)
{
    NICKEL_FUNC_TRACE;
    provisioningService = ps;
}

void Factory::setUnifiedEventRepository(boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedEventRepositoryAsync > uer)
{
    NICKEL_FUNC_TRACE;
    unifiedEventRepository = uer;
}

void Factory::setUnifiedServiceRepository(boost::shared_ptr< NS_COBALT_SYSTEM::UnifiedServiceRepository > usr)
{
    NICKEL_FUNC_TRACE;
    unifiedServiceRepository = usr;
}

void Factory::setHiddenServicesStore(boost::shared_ptr< NS_COBALT_SYSTEM::HiddenServicesStoreAsync > hss)
{
    NICKEL_FUNC_TRACE;
    hiddenServicesStore = hss;
}

void Factory::setLocalStorageRepository(boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > lsr)
{
    NICKEL_FUNC_TRACE;
    localStorageRepository = lsr;
}

void Factory::setUIManager(boost::shared_ptr< NS_MERCURY_SYSTEM::UIManagerAsync > uiManager_)
{
    NICKEL_FUNC_TRACE;
    uiManager = uiManager_;
}

void Factory::setIPNetwork(boost::shared_ptr< NS_NEON_CLIENT::IPNetwork > in)
{
    NICKEL_FUNC_TRACE;
    ipNetwork = in;
}

void Factory::setDTTMediaRouter(boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > dttMR)
{
    NICKEL_FUNC_TRACE;
    dttMediaRouter = dttMR;
}

void Factory::setIPMediaRouter(boost::shared_ptr< NS_NICKEL_SYSTEM::MediaRouterAsync > ipMR)
{
    NICKEL_FUNC_TRACE;
    ipMediaRouter = ipMR;
}

void Factory::setActionProcessor(const boost::shared_ptr< NS_ZINC::ActionProcessor >& ap)
{
    NICKEL_FUNC_TRACE;
    actionProcessor = ap;
}

void Factory::setLastSelectedServiceProperty(boost::shared_ptr< NS_ZINC::Property< std::string > > p)
{
    NICKEL_FUNC_TRACE;
    lastSelectedServiceProperty = p;
}

void Factory::setPlatformIPMaxStreamsProperty(boost::shared_ptr< NS_ZINC::Property< int32_t > > max)
{
    NICKEL_FUNC_TRACE;
    platformIPMaxStreamsProperty = max;
}

void Factory::setISPIPMaxStreamsProperty(boost::shared_ptr< NS_ZINC::Property< int32_t > > max)
{
    NICKEL_FUNC_TRACE;
    ispIPMaxStreamsProperty = max;
}

void Factory::setOEMIPMaxStreamsProperty(boost::shared_ptr< NS_ZINC::Property< int32_t > > max)
{
    NICKEL_FUNC_TRACE;
    oemIPMaxStreamsProperty = max;
}

void Factory::setTunerControl(const boost::shared_ptr< TunerControlAsync >& tc)
{
    NICKEL_FUNC_TRACE;
    tunerControl = tc;
}

NS_NICKELTUNER_SYSTEM_CLOSE
