/*
 * tunerd.cpp
 *
 *  Created on: 16 Aug 2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/BusName.h"
#include "../include/ObjectPath.h"
#include "LinearPlaybackControlAsyncToDBus.h"
#include "TunerControlAsyncToDBus.h"

#include "../include/Factory.h" // Link with libNickelTunerSystemProduction

#include <nickel-common/NickelLogger.h>

#include <nickeltuner-system-api/macros.h>

#include <zinc-binding-runtime/dbus/DBusService.h>
#include <zinc-binding-runtime/dbus/MainLoop.h>
#include <zinc-binding-runtime/dbus/SignalReceiver.h>

#include <boost/bind.hpp>
#include <boost/make_shared.hpp>
#include <boost/noncopyable.hpp>

using namespace NS_ZINC_DBUS_BINDING;
using namespace NS_NICKELTUNER_SYSTEM;

namespace {
class TunerDaemon : boost::noncopyable
{
public:
    TunerDaemon(MainLoop& mainloop_);
    ~TunerDaemon();
    void start();
    void stop();
private:
    MainLoop& mainloop;
    SignalReceiver sr;
    DBusService dbus;
};

TunerDaemon::TunerDaemon(MainLoop& mainloop_):
        mainloop(mainloop_),
        sr(mainloop_, createExitSignalHandler(boost::bind(&TunerDaemon::stop, this))),
        dbus(mainloop_)
{
}

TunerDaemon::~TunerDaemon()
{
}

void TunerDaemon::start()
{
    sr.start();
    dbus.start();

    // TODO: DEVARCH-7161 - Move synchronous initialisation of TunerControl out of the main-loop
    //       This is to be able to use async goodies.
    Factory factory(mainloop.getZincDispatcher());

    dbus.expose(ObjectPath::LINEAR_PLAYBACK_CONTROL, factory.createLinearPlaybackControl());
    dbus.expose(ObjectPath::TUNER_CONTROL, factory.createTunerControl());

    dbus.request_name(BusName::TUNER);
}

void TunerDaemon::stop()
{
    dbus.stop();
    sr.stop();
}

}// anon namespace


int main()
{
    NICKEL_INFO("Launching Tunerd Daemon ...");
    int result = EXIT_SUCCESS;

    try
    {
        MainLoop mainloop(BusName::TUNER);
        TunerDaemon daemon(mainloop);
        mainloop.post(boost::bind(&TunerDaemon::start, &daemon));
        result = mainloop.run();
    }
    catch (const std::exception& e)
    {
        NICKEL_ERROR("Tuner Daemon stopping: " << e.what());
        result = EXIT_FAILURE;
    }

    NICKEL_INFO("Tunerd Daemon shutting down...");
    return result;
}

