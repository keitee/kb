/*
 * File:   LinearPlaybackControlProxy.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 12 June 2014
 *
 * Copyright (C) 2014 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_PRODUCTION_LINEARPLAYBACKCONTROLPROXY_H
#define NICKELTUNER_SYSTEM_PRODUCTION_LINEARPLAYBACKCONTROLPROXY_H

#include <nickeltuner-system-api/LinearPlaybackControlAsync.h>

#include <nickel-system-api/Position.h>
#include <nickel-system-api/Track.h>
#include <nickel-system-api/SeekReference.h>
#include <nickel-system-api/SeekMode.h>

#include <cobalt-system-api/UnifiedEvent.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/Future.h>

#include <boost/shared_ptr.hpp>
#include <string>

NS_NICKELTUNER_SYSTEM_OPEN

/**
 * Make it possible to access LinearPlaybackControl from the thread used
 * by the factory. LinearPlaybackControl relies on that for thread safety.
 */
class ZINC_LOCAL LinearPlaybackControlProxy : public LinearPlaybackControlAsync
{
public:
    LinearPlaybackControlProxy(
            boost::shared_ptr< LinearPlaybackControlAsync > linearPlaybackControl_,
            boost::shared_ptr< NS_ZINC::Dispatcher > zincDispatcher_):
        linearPlaybackControl(linearPlaybackControl_),
        zincDispatcher(zincDispatcher_)
    {
    }

    virtual NS_ZINC::Future< void > pause()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::pause, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > play()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::play, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > fastForward()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::fastForward, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > rewind()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::rewind, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > seekPosition(const NS_NICKEL_SYSTEM::SeekReference::Enum whence,
        const int32_t offset, const NS_NICKEL_SYSTEM::SeekMode::Enum mode)
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::seekPosition, linearPlaybackControl,
                            whence, offset, mode)).get();
    }

    virtual NS_ZINC::Future< void > minimise()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::minimise, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > maximise()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::maximise, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< bool > isMaximised()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::isMaximised, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > setDestinationVideoWindow(
        double destinationX, double destinationY,
        double destinationWidth, double destinationHeight)
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::setDestinationVideoWindow,
                linearPlaybackControl, destinationX, destinationY, destinationWidth,
                destinationHeight)).get();
    }

    virtual NS_ZINC::Future< PlaybackMode::Enum > getPlaybackMode()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getPlaybackMode, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< double > getPlaybackSpeed()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getPlaybackSpeed, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > setPlaybackSpeed(double requestedSpeed)
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::setPlaybackSpeed, linearPlaybackControl, requestedSpeed)).get();
    }

    virtual NS_ZINC::Future< uint32_t > getEventTimeshiftFromLiveInMilliSeconds(
        const std::string& eventLocator)
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getEventTimeshiftFromLiveInMilliSeconds,
                            linearPlaybackControl, eventLocator)).get();
    }

    virtual NS_ZINC::Future< uint32_t > getTimeshiftFromLiveInMilliSeconds()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getTimeshiftFromLiveInMilliSeconds, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< std::map<std::string, std::string> > getSourceInformation()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getSourceInformation, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< NS_NICKEL_SYSTEM::Position > getPosition()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getPosition, linearPlaybackControl)).get();
    };

    virtual NS_ZINC::Future< std::vector<NS_NICKEL_SYSTEM::Track> > getTracks()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getTracks, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< NS_NICKEL_SYSTEM::Track > getVideoTrack()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getVideoTrack, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< NS_NICKEL_SYSTEM::Track > getSubtitleTrack()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getSubtitleTrack, linearPlaybackControl)).get();
    }

//------------------------
// Accessing what's on now
//------------------------
public:
    virtual NS_ZINC::Future< NS_COBALT_SYSTEM::UnifiedEvent > getCurrentEvent()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::getCurrentEvent, linearPlaybackControl)).get();
    }

//---------------------------
// Accessing ParentalControls
//---------------------------
public:
    virtual NS_ZINC::Future< bool > isLocked()
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::isLocked, linearPlaybackControl)).get();
    }

    virtual NS_ZINC::Future< void > allowRestrictedContent(const uint32_t autoAcceptSeconds)
    {
        return asyncInvoke(*zincDispatcher,
            boost::bind(&LinearPlaybackControlAsync::allowRestrictedContent,
                            linearPlaybackControl, autoAcceptSeconds)).get();
    }

private:
    boost::shared_ptr< LinearPlaybackControlAsync > linearPlaybackControl;
    boost::shared_ptr< NS_ZINC::Dispatcher >        zincDispatcher;
};

NS_NICKELTUNER_SYSTEM_CLOSE

#endif	/* NICKELTUNER_SYSTEM_PRODUCTION_LINEARPLAYBACKCONTROLPROXY_H */

