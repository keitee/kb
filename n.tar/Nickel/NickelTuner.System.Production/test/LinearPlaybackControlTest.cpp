/*
 * File:   LinearPlaybackControlTest.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 24 March 2014
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/Factory.h"
#include "../src/PlaybackHelpers.h"
#include "helpers/LinearPlaybackControlProxy.h"

#include <cobalt-system-api/MockUnifiedEventRepositoryAsync.h>

#include <copper-system-api/MockLocalStorageRepositoryAsync.h>

#include <mercury-system-api/MockUIManagerAsync.h>

#include <nickel-system-api/MockMediaRouterAsync.h>

#include <nickeltuner-system-api/MockTunerControlAsync.h>
#include <nickeltuner-system-api/MockLinearPlaybackControlEventListener.h>
#include <nickeltuner-system-api/LinearPlaybackControlAsync.h>
#include <nickeltuner-system-api/TunerControlStatus.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/PolledDispatcher.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/define_ostream_operator_for.h>
#include <zinc-common/testsupport/AtomicBool.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/FutureMockActions.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/VerifyAndClearDispatcher.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>
#include <zinc-common/ActionProcessor.h>

#include <boost/assign/list_of.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>

#include <gmock/gmock.h>
#include <stdexcept>
#include <string>
#include <vector>

using namespace NS_COBALT_SYSTEM;
using namespace NS_COPPER_SYSTEM;
using namespace NS_MERCURY_SYSTEM;
using namespace NS_NICKEL_SYSTEM;
using namespace NS_NICKELTUNER_SYSTEM;
using namespace NS_ZINC;

using boost::make_shared;
using boost::shared_ptr;

using testing::_;
using testing::Expectation;
using testing::Assign;
using testing::DoAll;
using testing::Return;

using std::string;
using std::vector;

NS_COBALT_SYSTEM_OPEN

ZINC_DEFINE_OSTREAM_OPERATOR_FOR(NS_NICKEL_SYSTEM::Position);
ZINC_DEFINE_OSTREAM_OPERATOR_FOR(NS_NICKEL_SYSTEM::Track);

NS_COBALT_SYSTEM_CLOSE

namespace
{

const VideoWindowRelativeRect SHRUNK_DESTINATION_VIDEO_WINDOW =
    VideoWindowRelativeRect(
        SHRUNK_WINDOW.destinationX,
        SHRUNK_WINDOW.destinationY,
        SHRUNK_WINDOW.destinationWidth,
        SHRUNK_WINDOW.destinationHeight);

const VideoWindowRelativeRect UNSHRUNK_DESTINATION_VIDEO_WINDOW =
    VideoWindowRelativeRect(
        UNSHRUNK_WINDOW.destinationX,
        UNSHRUNK_WINDOW.destinationY,
        UNSHRUNK_WINDOW.destinationWidth,
        UNSHRUNK_WINDOW.destinationHeight);

// TODO: DEVARCH-7713: Modify AtomicBool to be able to re-use NS_ZINC::assignTo
void assign(NS_ZINC::AtomicBool *atomicBool, bool value)
{
    *atomicBool = value;
}

struct FakeServiceData
{
    FakeServiceData(const string& serviceLocator_, // Subscription service
                    UnifiedServiceType::Enum serviceType)
    {
        service.serviceLocator      = serviceLocator_;
        service.serviceType         = serviceType;
        serviceLocator              = serviceLocator_;
    }

    UnifiedService  service;
    string          serviceLocator;
};


NS_NICKELTUNER_SYSTEM::TunerControlStatus getSuccessfulTuningStatus(const UnifiedService& service)
{
    return TunerControlStatus(
                TunerControlState::tuning,
                service,
                TuningReason::user_initiated,
                TuningErrorType::no_error,
                "");
}

NS_NICKELTUNER_SYSTEM::TunerControlStatus getSuccessfulTunedStatus(const UnifiedService& service)
{
    return TunerControlStatus(
                TunerControlState::tuned,
                service,
                TuningReason::user_initiated,
                TuningErrorType::no_error,
                "");
}

NS_NICKELTUNER_SYSTEM::TunerControlStatus getDeactivatingStatus(const UnifiedService& service)
{
    return TunerControlStatus(
                TunerControlState::deactivating,
                service,
                TuningReason::user_initiated,
                TuningErrorType::no_error,
                "");
}

NS_NICKELTUNER_SYSTEM::TunerControlStatus getDeactivatedStatus(const UnifiedService& service)
{
    return TunerControlStatus(
                TunerControlState::deactivated,
                service,
                TuningReason::user_initiated,
                TuningErrorType::no_error,
                "");
}

std::vector< PresentFollowingInfo > createDummyPF(const std::string& serviceLocator)
{
    UnifiedEvent dummyEvent;
    return std::vector< PresentFollowingInfo >(1, PresentFollowingInfo(serviceLocator, dummyEvent, dummyEvent));
}

std::vector< PresentFollowingInfo > createPF(
        const std::string& serviceLocator,
        const UnifiedEvent& presentEvent,
        const UnifiedEvent& followingEvent)
{
    return std::vector< PresentFollowingInfo >(1, PresentFollowingInfo(serviceLocator, presentEvent, followingEvent));
}

} // end anon namespace

class ZINC_LOCAL LinearPlaybackControlTest : public NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
private:
    shared_ptr< MockLocalStorageRepositoryAsync >           mockLocalStorageRepository;
    shared_ptr< MockUnifiedEventRepositoryAsync >           mockUnifiedEventRepository;
    shared_ptr< MockUIManagerAsync >                        mockUIManager;
    shared_ptr< MockMediaRouterAsync >                      mockDTTMediaRouter;
    shared_ptr< MockMediaRouterAsync >                      mockIPMediaRouter;
    shared_ptr< MockTunerControlAsync >                     mockTunerControl;
    shared_ptr< MockLinearPlaybackControlEventListener >    mockLinearPlaybackControlEventListener;

    shared_ptr< ActionProcessor >                           actionProcessor;
    shared_ptr< Dispatcher >                                dispatcher;
    shared_ptr< LinearPlaybackControlProxy >                linearPlaybackControl;


    const FakeServiceData dtt1;
    const FakeServiceData dtt2;
    const std::string dtt1EventLocator;
    const std::string dtt2EventLocator;

public:

    LinearPlaybackControlTest():
        dtt1(FakeServiceData("dvb://233a..1044", UnifiedServiceType::linear_service_broadcast_channel)),
        dtt2(FakeServiceData("dvb://233a..2045", UnifiedServiceType::linear_service_broadcast_channel)),
        dtt1EventLocator("dvb://233a..1044;03eb"),
        dtt2EventLocator("dvb://233a..2045;4664")
    {
    }

    void setupMockLSR()
    {
        // Values from https://svn.youview.co.uk/Canvas/PlatformConfig/trunk/datamodel/com.youview.gschema.html
        const std::string default_broadcast_sd_bitrate  = "3300000";
        const std::string default_restricted_ratings    =
            "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#fifteen " \
            "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#sixteen " \
            "http://refdata.youview.com/mpeg7cs/YouViewContentRatingCS/2010-11-25#eighteen " \
            "http://bbfc.org.uk/BBFCRatingCS/2002#15 http://bbfc.org.uk/BBFCRatingCS/2002#18 " \
            "http://bbfc.org.uk/BBFCRatingCS/2002#R18";
        const std::string default_timeshift_buffer_size = "";
        const std::string default_watershed_end_time    = "19800";
        const std::string default_watershed_start_time  = "72000";

        EXPECT_CALL(*mockLocalStorageRepository,
            getItem(_, _, BROADCAST_SD_BITRATE_KEY))
                .WillOnce( Return( completedFuture(default_broadcast_sd_bitrate) ) );
        EXPECT_CALL(*mockLocalStorageRepository,
            getItem(_, _, RESTRICTED_RATINGS_KEY))
                .WillOnce( Return( completedFuture(default_restricted_ratings) ) );
        EXPECT_CALL(*mockLocalStorageRepository,
            getItem(_, _, TIMESHIFT_BUFFER_SIZE_IN_BYTES_KEY))
                .WillOnce( Return( completedFuture(default_timeshift_buffer_size) ) );
        EXPECT_CALL(*mockLocalStorageRepository,
            getItem(_, _, WATERSHED_END_TIME_KEY))
                .WillOnce( Return( completedFuture(default_watershed_end_time) ) );
        EXPECT_CALL(*mockLocalStorageRepository,
            getItem(_, _, WATERSHED_START_TIME_KEY))
                .WillOnce( Return( completedFuture(default_watershed_start_time) ) );
    }

    virtual void setUpWithDispatcher(
        const shared_ptr< Dispatcher >& dispatcher_)
    {
        mockLocalStorageRepository              = make_shared< MockLocalStorageRepositoryAsync >();
        mockUnifiedEventRepository              = make_shared< MockUnifiedEventRepositoryAsync >();
        mockUIManager                           = make_shared< MockUIManagerAsync >();
        mockDTTMediaRouter                      = make_shared< MockMediaRouterAsync >();
        mockIPMediaRouter                       = make_shared< MockMediaRouterAsync >();
        mockTunerControl                        = make_shared< MockTunerControlAsync >();
        mockLinearPlaybackControlEventListener  = make_shared< MockLinearPlaybackControlEventListener >();

        // Voluntarily do not start ActionProcessor to prevent functors from executing during
        // test tear down (doUpdateParentalControls, doRefreshLinearEventTracker):
        // Ideally, LinearPlaybackControlImpl should use Scheduler but it is not yet available, see DEVARCH-6915.
        actionProcessor = boost::make_shared< NS_ZINC::ActionProcessor >();

        dispatcher = dispatcher_;
        NS_NICKELTUNER_SYSTEM::Factory factory(dispatcher);

        factory.setLocalStorageRepository(mockLocalStorageRepository);
        factory.setUnifiedEventRepository(mockUnifiedEventRepository);
        factory.setUIManager(mockUIManager);
        factory.setDTTMediaRouter(mockDTTMediaRouter);
        factory.setIPMediaRouter(mockIPMediaRouter);
        factory.setActionProcessor(actionProcessor);
        factory.setTunerControl(mockTunerControl);

        setupMockLSR();

        shared_ptr< LinearPlaybackControlAsync > realLinearPlaybackControl = factory.createLinearPlaybackControl();

        realLinearPlaybackControl->addListener(dispatcher, mockLinearPlaybackControlEventListener);

        linearPlaybackControl = make_shared< LinearPlaybackControlProxy >(realLinearPlaybackControl, dispatcher);
    }

    virtual void setUp()
    {
        setUpWithDispatcher(
            boost::make_shared< SingleThreadDispatcher >());
    }

    virtual void tearDown()
    {
        VERIFY_AND_CLEAR_MOCK(mockLinearPlaybackControlEventListener);
        VERIFY_AND_CLEAR_MOCK(mockTunerControl);
        VERIFY_AND_CLEAR_MOCK(mockIPMediaRouter);
        VERIFY_AND_CLEAR_MOCK(mockDTTMediaRouter);
        VERIFY_AND_CLEAR_MOCK(mockUIManager);
        VERIFY_AND_CLEAR_MOCK(mockUnifiedEventRepository);
        VERIFY_AND_CLEAR_MOCK(mockLocalStorageRepository);
    }

    void setupExpectationsForDTTInitialisation(
            const UnifiedService& service,
            Future< std::vector< PresentFollowingInfo > > pf,
            Future< Position > position,
            Future< NS_NICKEL_SYSTEM::VideoWindowDescriptor > mediaRouterVideoWindow,
            const UnifiedEvent& currentEvent,
            AtomicBool& getVideoWindowCalled)
    {
        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, service.serviceLocator) ))
            .WillOnce(Return(pf));
        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .WillOnce(Return(position));
        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoWindow())
            .WillOnce(
                DoAll(
                    Assign(&getVideoWindowCalled, true),
                    Return(mediaRouterVideoWindow)
                ));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            CurrentEventChanged(currentEvent));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::live));
    }

    void setupExpectationsForDTTInitialisation(
            const UnifiedService& service,
            Future< std::vector< PresentFollowingInfo > > pf,
            Future< Position > position,
            Future< NS_NICKEL_SYSTEM::VideoWindowDescriptor > mediaRouterVideoWindow,
            const UnifiedEvent& currentEvent)
    {
        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, service.serviceLocator) ))
            .WillOnce(Return(pf));
        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .WillOnce(Return(position));
        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoWindow())
                .WillOnce(Return(mediaRouterVideoWindow));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            CurrentEventChanged(currentEvent));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::live));
    }

    shared_ptr< PolledDispatcher > emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            boost::make_shared< PolledDispatcher >();
        setUpWithDispatcher(polledDispatcher);

        setupExpectationsForDTTInitialisation(
            dtt1.service,
            completedFuture(createDummyPF(dtt1.serviceLocator)),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());
        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));
        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));
        while (polledDispatcher->processNext())
        {
        }

        return polledDispatcher;
    }

    shared_ptr< PolledDispatcher > emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            boost::make_shared< PolledDispatcher >();
        setUpWithDispatcher(polledDispatcher);

        // Cannot use setupExpectationsForDTTInitialisation() as PlaybackModeChange
        // is not expected to be emitted when the initialisation fails.
        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, dtt1.service.serviceLocator) ))
            .WillOnce(Return(completedFuture(createDummyPF(dtt1.serviceLocator))));
        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .WillOnce(Return(completedFuture(Position(0, 0, 0))));
        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoWindow())
                .WillOnce(Return(
                    exceptionalFuture< NS_NICKEL_SYSTEM::VideoWindowDescriptor >(
                        std::runtime_error("Failed"))));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            CurrentEventChanged(UnifiedEvent()));

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));
        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));
        while (polledDispatcher->processNext())
        {
        }

        return polledDispatcher;
    }

    void test_mrMethods_whenUninitialised_returnsExceptionalFuture()
    {
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->pause().get(),std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->play().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->fastForward().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->rewind().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->seekPosition(
                NS_NICKEL_SYSTEM::SeekReference::start, 0,
                NS_NICKEL_SYSTEM::SeekMode::prioritise_speed).get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getTimeshiftFromLiveInMilliSeconds().get(),std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->minimise().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->maximise().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->isMaximised().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getSourceInformation().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getPosition().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getTracks().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getVideoTrack().get(), std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getSubtitleTrack().get(), std::runtime_error);
    }

    void test_eventTrackingMethods_whenUninitialised_returnsExceptionalFuture()
    {
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getEventTimeshiftFromLiveInMilliSeconds(dtt1EventLocator).get(),
                std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getCurrentEvent().get(),
                std::runtime_error);
    }

    void test_parentalControlsMethods_whenUninitialised_returnsExceptionalFuture()
    {
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->isLocked().get(),
                std::runtime_error);
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->allowRestrictedContent(0).get(),
                std::runtime_error);
    }

    void test_callingPause_whenPlaySpeedOne_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZero()
    {
        const double configuredPlaySpeed = 1.0;
        const double expectedPlaySpeed = 0.0;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        AtomicBool timeshiftingEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::timeshifting))
            .WillOnce(Assign(&timeshiftingEventReceived, true));
        Future< void > pauseFuture = linearPlaybackControl->pause();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        pauseFuture.get();

        CPPUNIT_ASSERT(timeshiftingEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingPlay_whenPlaySpeedZero_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedOne()
    {
        const double configuredPlaySpeed = 0.0;
        const double expectedPlaySpeed = 1.0;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        Future< void > playFuture = linearPlaybackControl->play();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        playFuture.get();
    }

    void test_callingFastForward_whenPlaySpeedTwo_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedSix()
    {
        const double configuredPlaySpeed = 2.0;
        const double expectedPlaySpeed = 6.0;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            getPlaySpeed())
            .WillOnce(Return(completedFuture(configuredPlaySpeed)));
        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        Future< void > fastForwardFuture = linearPlaybackControl->fastForward();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        fastForwardFuture.get();
    }

    void test_callingRewind_whenPlaySpeedMinusTwo_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedMinusSix()
    {
        const double configuredPlaySpeed = -2.0;
        const double expectedPlaySpeed = -6.0;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            getPlaySpeed())
            .WillOnce(Return(completedFuture(configuredPlaySpeed)));
        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        Future< void > rewindFuture = linearPlaybackControl->rewind();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        rewindFuture.get();
    }

    void test_callingSeekPosition_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterSeekPosition()
    {
        const SeekReference::Enum expectedSeekReference = SeekReference::end;
        const int32_t expectedOffset = 0;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        Future< void > seekPositionFuture = linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode);
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        seekPositionFuture.get();
    }

    void test_callingGetPlaybackMode_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsLive()
    {
        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< PlaybackMode::Enum > getPlaybackModeFuture =
            linearPlaybackControl->getPlaybackMode();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(
            PlaybackMode::live,
            getPlaybackModeFuture.get());
    }

    void test_callingGetTimeshiftFromLiveInMilliSeconds_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPositionAndReturnsEndMinusCurrent()
    {
        const Position configuredMediaRouterPosition = Position(100, 120, 200); // start, current, end

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;

        // Setup default expectation without MR getPosition
        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, dtt1.service.serviceLocator) ))
            .WillOnce(Return(delayedPresentFollowing.getFuture()));
        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoWindow())
            .WillOnce(Return(completedFuture(UNSHRUNK_WINDOW)));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            CurrentEventChanged(UnifiedEvent()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::live));

        // MR::getPosition() is going to be called twice:
        // once during initialisation and once when getTimeshiftFromLiveInMilliSeconds() is called)
        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .Times(2)
            .WillRepeatedly(returnNewCompletedFuture(configuredMediaRouterPosition));

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< uint32_t > getTimeshiftFromLiveFuture =
            linearPlaybackControl->getTimeshiftFromLiveInMilliSeconds();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(
            configuredMediaRouterPosition.end - configuredMediaRouterPosition.current,
            getTimeshiftFromLiveFuture.get());
    }

    void test_callingGetEventTimeshiftFromLiveInMilliSeconds_forCurrentEvent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsTimeshift()
    {
        UnifiedEvent currentEvent;
        currentEvent.data.eventType = NS_COBALT_SYSTEM::EventType::invalid;
        currentEvent.data.eventLocator = dtt1EventLocator;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            currentEvent);

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< uint32_t > getEventTimeshiftFuture =
            linearPlaybackControl->getEventTimeshiftFromLiveInMilliSeconds(dtt1EventLocator);
        delayedPresentFollowing.complete(createPF(dtt1.serviceLocator, currentEvent, UnifiedEvent()));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        // This is going to return monotonic_clock::now() - monotonic time of when
        // PresentFollowingArchive was constructed (i.e. when delayedPF is completed):
        // we can be sure that this is positive, so the future should complete without exception.
        getEventTimeshiftFuture.get();
    }

    void test_callingMinimise_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterSetVideoWindowShrunk()
    {
        const NS_NICKEL_SYSTEM::VideoWindowDescriptor expectedMediaRouterVideoWindow =
            SHRUNK_WINDOW;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        AtomicBool videoResizeEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(SHRUNK_DESTINATION_VIDEO_WINDOW))
            .WillOnce(Assign(&videoResizeEventReceived, true));
        EXPECT_CALL(*mockDTTMediaRouter,
            setVideoWindow(expectedMediaRouterVideoWindow))
            .WillOnce(Return(completedFuture()));
        Future< void > minimiseFuture = linearPlaybackControl->minimise();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        minimiseFuture.get();
        CPPUNIT_ASSERT(videoResizeEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingMaximise_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterSetVideoWindowUnshrunk()
    {
        const NS_NICKEL_SYSTEM::VideoWindowDescriptor expectedMediaRouterVideoWindow =
            UNSHRUNK_WINDOW;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        AtomicBool videoResizeEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(UNSHRUNK_DESTINATION_VIDEO_WINDOW))
            .WillOnce(Assign(&videoResizeEventReceived, true));
        EXPECT_CALL(*mockDTTMediaRouter,
            setVideoWindow(expectedMediaRouterVideoWindow))
            .WillOnce(Return(completedFuture()));
        Future< void > maximiseFuture = linearPlaybackControl->maximise();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        maximiseFuture.get();
        CPPUNIT_ASSERT(videoResizeEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue()
    {
        const NS_NICKEL_SYSTEM::VideoWindowDescriptor mediaRouterVideoWindow =
            UNSHRUNK_WINDOW;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(mediaRouterVideoWindow),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< bool > isMaximisedFuture = linearPlaybackControl->isMaximised();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(
            true, isMaximisedFuture.get());
    }

    void test_callingGetSourceInformation_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter()
    {
        const std::map< std::string, std::string > configuredSourceInformation =
            boost::assign::map_list_of("key1", "value1")("key2", "value2");

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            getSourceInformation())
            .WillOnce(Return(completedFuture(configuredSourceInformation)));
        Future< std::map< std::string, std::string > > getSourceInformationFuture =
            linearPlaybackControl->getSourceInformation();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(configuredSourceInformation, getSourceInformationFuture.get());
    }

    void test_callingGetPosition_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter()
    {
        const Position configuredMediaRouterPosition = Position(100, 120, 200); // start, current, end

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;

        // Setup default expectation without MR getPosition
        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, dtt1.service.serviceLocator) ))
            .WillOnce(Return(delayedPresentFollowing.getFuture()));
        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoWindow())
            .WillOnce(Return(completedFuture(UNSHRUNK_WINDOW)));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            CurrentEventChanged(UnifiedEvent()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::live));

        // MR::getPosition() is going to be called twice:
        // once during initialisation and once when getPosition() is called)
        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .Times(2)
            .WillRepeatedly(returnNewCompletedFuture(configuredMediaRouterPosition));

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< Position > getPositionFuture =
            linearPlaybackControl->getPosition();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(configuredMediaRouterPosition, getPositionFuture.get());
    }

    void test_callingGetTracks_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter()
    {
        const Track configuredTrack =
            Track(1, "language",
                  TrackFormat::audio_mpeg1l2,
                  TrackType::audio,
                  TrackUsage::audio_normal);

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            getTracks())
            .WillOnce(Return(completedFuture(std::vector<Track>(1, configuredTrack))));
        Future< std::vector< Track > > getTracksFuture =
            linearPlaybackControl->getTracks();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        std::vector<Track> returnedTracks = getTracksFuture.get();
        CPPUNIT_ASSERT_EQUAL(1, returnedTracks.size());
        CPPUNIT_ASSERT_EQUAL(configuredTrack, returnedTracks[0]);
    }

    void test_callingGetVideoTrack_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter()
    {
        const Track configuredTrack =
            Track(1, "language",
                  TrackFormat::audio_mpeg1l2,
                  TrackType::audio,
                  TrackUsage::audio_normal);

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoTrack())
            .WillOnce(Return(completedFuture(configuredTrack)));
        Future< Track > getVideoTrackFuture =
            linearPlaybackControl->getVideoTrack();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(configuredTrack, getVideoTrackFuture.get());
    }

    void test_callingGetSubtitleTrack_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter()
    {
        const Track configuredTrack =
            Track(1, "language",
                  TrackFormat::audio_mpeg1l2,
                  TrackType::audio,
                  TrackUsage::audio_normal);

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            getSubtitleTrack())
            .WillOnce(Return(completedFuture(configuredTrack)));
        Future< Track > getSubtitleTrackFuture =
            linearPlaybackControl->getSubtitleTrack();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(configuredTrack, getSubtitleTrackFuture.get());
    }

    void test_callingGetCurrentEvent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsCurrentEvent()
    {
        UnifiedEvent currentEvent;
        currentEvent.data.eventType = NS_COBALT_SYSTEM::EventType::invalid;
        currentEvent.data.eventLocator = dtt1EventLocator;

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            currentEvent);

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< UnifiedEvent > getCurrentEventFuture =
            linearPlaybackControl->getCurrentEvent();
        delayedPresentFollowing.complete(createPF(dtt1.serviceLocator, currentEvent, UnifiedEvent()));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        CPPUNIT_ASSERT_EQUAL(dtt1EventLocator, getCurrentEventFuture.get().data.eventLocator);
    }

    void test_callingIsLocked_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsFalse()
    {
        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< bool > isLockedFuture =
            linearPlaybackControl->isLocked();
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        // A DTT channel is never parentally protected
        CPPUNIT_ASSERT_EQUAL(false, isLockedFuture.get());
    }

    void test_callingAllowRestrictedContent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsExceptionalFuture()
    {
        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        Future< void > allowRestrictedContentFuture =
            linearPlaybackControl->allowRestrictedContent(0);
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        // A DTT channel is never parentally protected, so calling
        // allowRestrictedContent() does not make sense and throws.
        CPPUNIT_ASSERT_THROW(
            allowRestrictedContentFuture.get(), std::runtime_error);
    }

    void test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const double configuredPlaySpeed = 1.0;
        const double expectedPlaySpeed = 0.0;

        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        AtomicBool timeshiftingEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::timeshifting))
            .WillOnce(Assign(&timeshiftingEventReceived, true));
        linearPlaybackControl->pause().get();
        CPPUNIT_ASSERT(timeshiftingEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_setPlaySpeedFails_returnsExceptionalFutureWithoutEmittingTimeshiftingEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const double configuredPlaySpeed = 1.0;
        const double expectedPlaySpeed = 0.0;

        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(exceptionalFuture<void>(std::runtime_error("Failed"))));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);

        CPPUNIT_ASSERT(linearPlaybackControl->pause().getFutureValue().getError());
    }

    void test_callingPlay_whenPlaySpeedZero_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedOne()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const double configuredPlaySpeed = 0.0;
        const double expectedPlaySpeed = 1.0;

        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        linearPlaybackControl->play().get();
    }

    void test_callingFastForward_whenPlaySpeedTwo_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedSix()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const double configuredPlaySpeed = 2.0;
        const double expectedPlaySpeed = 6.0;

        EXPECT_CALL(*mockDTTMediaRouter,
            getPlaySpeed())
            .WillOnce(Return(completedFuture(configuredPlaySpeed)));
        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        linearPlaybackControl->fastForward().get();
    }

    void test_callingRewind_whenPlaySpeedMinusTwo_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedMinusSix()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const double configuredPlaySpeed = -2.0;
        const double expectedPlaySpeed = -6.0;

        EXPECT_CALL(*mockDTTMediaRouter,
            getPlaySpeed())
            .WillOnce(Return(completedFuture(configuredPlaySpeed)));
        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        linearPlaybackControl->rewind().get();
    }

    void test_callingSeekPositionWithoutOffsetFromEnd_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionWithoutEmittingEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const SeekReference::Enum expectedSeekReference = SeekReference::end;
        const int32_t expectedOffset = 0;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);
        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();
    }

    void test_callingSeekPositionWithNegativeOffsetFromCurrentPosition_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionAndEmitsTimeshiftingEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const SeekReference::Enum expectedSeekReference = SeekReference::current;
        const int32_t expectedOffset = -100;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));

        AtomicBool timeshiftingEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::timeshifting))
            .WillOnce(Assign(&timeshiftingEventReceived, true));

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();

        CPPUNIT_ASSERT(timeshiftingEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingSeekPositionWithPositiveOffsetFromCurrentPosition_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionWithoutEmittingEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const SeekReference::Enum expectedSeekReference = SeekReference::current;
        const int32_t expectedOffset = 100;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();
    }

    void test_callingSeekPositionWithoutOffsetFromStart_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionAndEmitsTimeshiftingEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const SeekReference::Enum expectedSeekReference = SeekReference::start;
        const int32_t expectedOffset = 0;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));

        AtomicBool timeshiftingEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::timeshifting))
            .WillOnce(Assign(&timeshiftingEventReceived, true));

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();

        CPPUNIT_ASSERT(timeshiftingEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingSeekPositionWithNonStandardPosition_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionWithoutEmittingEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const SeekReference::Enum expectedSeekReference = SeekReference::start;
        const int32_t expectedOffset = 100;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);
        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();
    }

    void test_callingGetPlaybackMode_whenInitialisedInDTT_whenNotTimeshifting_returnsLive()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        CPPUNIT_ASSERT_EQUAL(
            PlaybackMode::live,
            linearPlaybackControl->getPlaybackMode().get());
    }

    void test_callingGetPlaybackMode_whenInitialisedInDTT_whenTimeshifting_returnsTimeshifting()
    {
        // Wait for the end of initialisation and make sure playbackMode is timeshifting
        test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent();

        CPPUNIT_ASSERT_EQUAL(
            PlaybackMode::timeshifting,
            linearPlaybackControl->getPlaybackMode().get());
    }

    void test_callingGetTimeshiftFromLiveInMilliSeconds_whenInitialisedInDTT_callsDTTMediaRouterGetPositionAndReturnsEndMinusCurrent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const Position configuredMediaRouterPosition = Position(100, 120, 200); // start, current, end

        EXPECT_CALL(*mockDTTMediaRouter, getPosition())
            .WillOnce(Return(completedFuture(configuredMediaRouterPosition)));
        CPPUNIT_ASSERT_EQUAL(
            configuredMediaRouterPosition.end - configuredMediaRouterPosition.current,
            linearPlaybackControl->getTimeshiftFromLiveInMilliSeconds().get());
    }

    void test_callingGetEventTimeshiftFromLiveInMilliSeconds_forCurrentEvent_whenInitialisedInDTT_returnsTimeshift()
    {
        // Wait for the end of initialisation
        test_callingGetEventTimeshiftFromLiveInMilliSeconds_forCurrentEvent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsTimeshift();

        // This is going to return monotonic_clock::now() - monotonic time of when
        // PresentFollowingArchive was constructed (i.e. when delayedPF is completed):
        // we can be sure that this is positive, so the future should complete without exception.
        linearPlaybackControl->getEventTimeshiftFromLiveInMilliSeconds(dtt1EventLocator).get();
    }

    void test_callingMinimise_whenInitialisedInDTT_callsDTTMediaRouterSetVideoWindowShrunkAndEmitsMinimisedEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const NS_NICKEL_SYSTEM::VideoWindowDescriptor expectedMediaRouterVideoWindow =
            SHRUNK_WINDOW;

        EXPECT_CALL(*mockDTTMediaRouter,
            setVideoWindow(expectedMediaRouterVideoWindow))
            .WillOnce(Return(completedFuture()));

        VideoWindowRelativeRect window;
        window.x = SHRUNK_WINDOW.destinationX;
        window.y = SHRUNK_WINDOW.destinationY;
        window.width = SHRUNK_WINDOW.destinationWidth;
        window.height = SHRUNK_WINDOW.destinationHeight;
        AtomicBool videoResizeEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(window))
            .WillOnce(Assign(&videoResizeEventReceived, true));

        linearPlaybackControl->minimise().get();
        CPPUNIT_ASSERT(videoResizeEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingMaximise_whenInitialisedInDTT_callsDTTMediaRouterSetVideoWindowUnshrunkAndEmitsMaximisedEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const NS_NICKEL_SYSTEM::VideoWindowDescriptor expectedMediaRouterVideoWindow =
            UNSHRUNK_WINDOW;

        VideoWindowRelativeRect window;
        window.x = UNSHRUNK_WINDOW.destinationX;
        window.y = UNSHRUNK_WINDOW.destinationY;
        window.width = UNSHRUNK_WINDOW.destinationWidth;
        window.height = UNSHRUNK_WINDOW.destinationHeight;
        AtomicBool videoResizeEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(window))
            .WillOnce(Assign(&videoResizeEventReceived, true));
        EXPECT_CALL(*mockDTTMediaRouter,
            setVideoWindow(expectedMediaRouterVideoWindow))
            .WillOnce(Return(completedFuture()));
        linearPlaybackControl->maximise().get();
        CPPUNIT_ASSERT(videoResizeEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingIsMaximised_whenInitialisedInDTT_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const NS_NICKEL_SYSTEM::VideoWindowDescriptor mediaRouterVideoWindow =
            UNSHRUNK_WINDOW;

        CPPUNIT_ASSERT_EQUAL(
            true, linearPlaybackControl->isMaximised().get());
    }

    void test_callingGetSourceInformation_whenInitialisedInDTT_delegatesToDTTMediaRouter()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const std::map< std::string, std::string > configuredSourceInformation =
            boost::assign::map_list_of("key1", "value1")("key2", "value2");

        EXPECT_CALL(*mockDTTMediaRouter,
            getSourceInformation())
            .WillOnce(Return(completedFuture(configuredSourceInformation)));
        CPPUNIT_ASSERT_EQUAL(
            configuredSourceInformation,
            linearPlaybackControl->getSourceInformation().get());
    }

    void test_callingGetPosition_whenInitialisedInDTT_delegatesToDTTMediaRouter()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const Position configuredMediaRouterPosition = Position(100, 120, 200); // start, current, end

        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .WillOnce(Return(completedFuture(configuredMediaRouterPosition)));
        CPPUNIT_ASSERT_EQUAL(configuredMediaRouterPosition, linearPlaybackControl->getPosition().get());
    }

    void test_callingGetTracks_whenInitialisedInDTT_delegatesToDTTMediaRouter()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const Track configuredTrack =
            Track(1, "language",
                  TrackFormat::audio_mpeg1l2,
                  TrackType::audio,
                  TrackUsage::audio_normal);

        EXPECT_CALL(*mockDTTMediaRouter,
            getTracks())
            .WillOnce(Return(completedFuture(std::vector<Track>(1, configuredTrack))));
        std::vector<Track> returnedTracks = linearPlaybackControl->getTracks().get();
        CPPUNIT_ASSERT_EQUAL(1, returnedTracks.size());
        CPPUNIT_ASSERT_EQUAL(configuredTrack, returnedTracks[0]);
    }

    void test_callingGetVideoTrack_whenInitialisedInDTT_delegatesToDTTMediaRouter()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const Track configuredTrack =
            Track(1, "language",
                  TrackFormat::audio_mpeg1l2,
                  TrackType::audio,
                  TrackUsage::audio_normal);

        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoTrack())
            .WillOnce(Return(completedFuture(configuredTrack)));
        CPPUNIT_ASSERT_EQUAL(configuredTrack, linearPlaybackControl->getVideoTrack().get());
    }

    void test_callingGetSubtitleTrack_whenInitialisedInDTT_delegatesToDTTMediaRouter()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        const Track configuredTrack =
            Track(1, "language",
                  TrackFormat::audio_mpeg1l2,
                  TrackType::audio,
                  TrackUsage::audio_normal);

        EXPECT_CALL(*mockDTTMediaRouter,
            getSubtitleTrack())
            .WillOnce(Return(completedFuture(configuredTrack)));
        CPPUNIT_ASSERT_EQUAL(configuredTrack, linearPlaybackControl->getSubtitleTrack().get());
    }

    void test_callingGetCurrentEvent_whenInitialisedInDTT_returnsCurrentEvent()
    {
        // Wait for the end of initialisation
        test_callingGetCurrentEvent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsCurrentEvent();

        CPPUNIT_ASSERT_EQUAL(dtt1EventLocator, linearPlaybackControl->getCurrentEvent().get().data.eventLocator);
    }

    void test_callingIsLocked_whenInitialisedInDTT_returnsFalse()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        // A DTT channel is never parentally protected
        CPPUNIT_ASSERT_EQUAL(false, linearPlaybackControl->isLocked().get());
    }

    void test_callingAllowRestrictedContent_whenInitialisedInDTT_returnsExceptionalFuture()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        // A DTT channel is never parentally protected, so calling
        // allowRestrictedContent() does not make sense and throws.
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->allowRestrictedContent(0).get(), std::runtime_error);
    }

    void test_receivingBufferStatusEvent_whenInitialisationFailed_doesNotEmitAnyEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail();

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            BufferStatusEvent(_)).Times(0);
        mockDTTMediaRouter->emitBufferStatusEvent(BufferStatusEventValue::buffering_started);

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingDrmEvent_whenInitialisationFailed_doesNotEmitAnyEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail();

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            DrmEvent(_, _, _)).Times(0);
        mockDTTMediaRouter->emitDrmEvent(DrmEventValue::licence_required, "id", "url");

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingPositionChangeEvent_whenInitialisationFailed_doesNotEmitAnyEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail();

        const Position timeshiftedPosition(-10000, -5000, 0);
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PositionChangeEvent(_)).Times(0);
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);
        mockDTTMediaRouter->emitPositionChangeEvent(timeshiftedPosition);

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingSourceEvent_whenInitialisationFailed_doesNotEmitAnyEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail();

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            SourceEvent(_, _)).Times(0);
        mockDTTMediaRouter->emitSourceEvent(
            SourceEventValue::change_initiated,
            SetSourceReason::unspecified);

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingSpeedChangeEvent_whenInitialisationFailed_doesNotEmitAnyEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail();

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            SpeedChangeEvent(_)).Times(0);
        mockDTTMediaRouter->emitSpeedChangeEvent();

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingStatusEvent_whenInitialisationFailed_doesNotEmitAnyEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail();

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            StatusEvent(_)).Times(0);
        mockDTTMediaRouter->emitStatusEvent(StatusEventValue::started);

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingErrorEvent_whenInitialisationFailed_doesNotEmitAnyEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndCauseInitialisationToFail();

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            ErrorEvent(_, _, _)).Times(0);
        mockDTTMediaRouter->emitErrorEvent(
            ErrorEventValue::other,
            ErrorEventContext::other,
            "some info");

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingBufferStatusEvent_whenInitialisedInDTT_emitsBufferStatusEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        std::vector< BufferStatusEventValue::Enum > values =
            boost::assign::list_of
                (BufferStatusEventValue::buffering_started)
                (BufferStatusEventValue::reserved_1)
                (BufferStatusEventValue::buffering_complete)
                (BufferStatusEventValue::reserved_3)
                (BufferStatusEventValue::abr_segment_complete);

        BOOST_FOREACH(const BufferStatusEventValue::Enum value, values)
        {
            EXPECT_CALL(*mockLinearPlaybackControlEventListener,
                BufferStatusEvent(value)).Times(1).RetiresOnSaturation();
            mockDTTMediaRouter->emitBufferStatusEvent(value);

            while (polledDispatcher->processNext())
            {
            }

            VERIFY_AND_CLEAR_MOCK(mockLinearPlaybackControlEventListener);
        }
    }

    void test_receivingDrmEvent_whenInitialisedInDTT_emitsDrmEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        std::vector< DrmEventValue::Enum > values =
            boost::assign::list_of
                (DrmEventValue::licence_required)
                (DrmEventValue::system_error)
                (DrmEventValue::bad_request)
                (DrmEventValue::server_unreachable)
                (DrmEventValue::server_denied)
                (DrmEventValue::bad_server_response)
                (DrmEventValue::bad_content_format)
                (DrmEventValue::unmet_licence_requirement)
                (DrmEventValue::licence_format_error)
                (DrmEventValue::missing_credentials)
                (DrmEventValue::expired)
                (DrmEventValue::play_count_exceeded)
                (DrmEventValue::subscription_expired)
                (DrmEventValue::other);

        BOOST_FOREACH(const DrmEventValue::Enum value, values)
        {
            EXPECT_CALL(*mockLinearPlaybackControlEventListener,
                DrmEvent(value, "id", "url")).Times(1).RetiresOnSaturation();
            mockDTTMediaRouter->emitDrmEvent(value, "id", "url");

            while (polledDispatcher->processNext())
            {
            }

            VERIFY_AND_CLEAR_MOCK(mockLinearPlaybackControlEventListener);
        }
    }

    void test_receivingPositionChangeEvent_whenInitialisedInDTT_emitsPositionChangeEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        const Position testPosition(1, 2, 3);
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PositionChangeEvent(testPosition)).Times(1);
        mockDTTMediaRouter->emitPositionChangeEvent(testPosition);

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingSourceEvent_whenInitialisedInDTT_emitsSourceEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        std::vector< SourceEventValue::Enum > sourceEventValues =
            boost::assign::list_of
                (SourceEventValue::change_initiated)
                (SourceEventValue::change_complete)
                (SourceEventValue::source_information_change)
                (SourceEventValue::source_config_complete)
                (SourceEventValue::tracks_changed);
        std::vector< SetSourceReason::Enum > setSourceReasons =
            boost::assign::list_of
                (SetSourceReason::unspecified)
                (SetSourceReason::mhegstandard)
                (SetSourceReason::mhegquiet)
                (SetSourceReason::mhegnondestructive)
                (SetSourceReason::mhegnondestructivequiet);

        BOOST_FOREACH(const SourceEventValue::Enum sourceEventValue, sourceEventValues)
        {
            BOOST_FOREACH(const SetSourceReason::Enum setSourceReason, setSourceReasons)
            {
                EXPECT_CALL(*mockLinearPlaybackControlEventListener,
                    SourceEvent(sourceEventValue, setSourceReason)).Times(1).RetiresOnSaturation();
                mockDTTMediaRouter->emitSourceEvent(sourceEventValue, setSourceReason);

                while (polledDispatcher->processNext())
                {
                }

                VERIFY_AND_CLEAR_MOCK(mockLinearPlaybackControlEventListener);
            }
        }
    }

    void test_receivingSpeedChangeEvent_whenInitialisedInDTT_getsSpeedFromMR_andEmitsSpeedChangeEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        EXPECT_CALL(*mockDTTMediaRouter,
            getPlaySpeed())
            .WillOnce(Return(completedFuture(10.0)));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            SpeedChangeEvent(10.0)).Times(1);
        mockDTTMediaRouter->emitSpeedChangeEvent();

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingSpeedChangeEvent_whenInitialisedInDTT_failsToGetSpeedFromMR_doesNotEmitSpeedChangeEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        EXPECT_CALL(*mockDTTMediaRouter,
            getPlaySpeed())
            .WillOnce(Return(exceptionalFuture< double >(std::runtime_error("Failed"))));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            SpeedChangeEvent(_)).Times(0);
        mockDTTMediaRouter->emitSpeedChangeEvent();

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_receivingStatusEvent_whenInitialisedInDTT_emitsStatusEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        std::vector< StatusEventValue::Enum > values =
            boost::assign::list_of
                (StatusEventValue::started)
                (StatusEventValue::complete)
                (StatusEventValue::waiting)
                (StatusEventValue::stopped)
                (StatusEventValue::underflow)
                (StatusEventValue::seek_started);

        BOOST_FOREACH(const StatusEventValue::Enum value, values)
        {
            EXPECT_CALL(*mockLinearPlaybackControlEventListener,
                StatusEvent(value)).Times(1).RetiresOnSaturation();
            mockDTTMediaRouter->emitStatusEvent(value);

            while (polledDispatcher->processNext())
            {
            }

            VERIFY_AND_CLEAR_MOCK(mockLinearPlaybackControlEventListener);
        }
    }

    void test_receivingErrorEvent_whenInitialisedInDTT_emitsErrorEvent()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            emitTuningAndTunedStatusChangesForDTTAndWaitForEndOfInitialisation();

        std::vector< ErrorEventValue::Enum > errorEventValues =
            boost::assign::list_of
                (ErrorEventValue::other)
                (ErrorEventValue::locator)
                (ErrorEventValue::tag)
                (ErrorEventValue::language)
                (ErrorEventValue::linear_selection)
                (ErrorEventValue::network)
                (ErrorEventValue::server)
                (ErrorEventValue::data);
        std::vector< ErrorEventContext::Enum > errorEventContexts =
            boost::assign::list_of
                (ErrorEventContext::other)
                (ErrorEventContext::source)
                (ErrorEventContext::video_track)
                (ErrorEventContext::audio_track)
                (ErrorEventContext::subtitle_track)
                (ErrorEventContext::index_file)
                (ErrorEventContext::subtitle_file)
                (ErrorEventContext::sdp_file);

        BOOST_FOREACH(const ErrorEventValue::Enum errorEventValue, errorEventValues)
        {
            BOOST_FOREACH(const ErrorEventContext::Enum errorEventContext, errorEventContexts)
            {
                EXPECT_CALL(*mockLinearPlaybackControlEventListener,
                    ErrorEvent(errorEventValue, errorEventContext, "some info")).Times(1).RetiresOnSaturation();
                mockDTTMediaRouter->emitErrorEvent(errorEventValue, errorEventContext, "some info");

                while (polledDispatcher->processNext())
                {
                }

                VERIFY_AND_CLEAR_MOCK(mockLinearPlaybackControlEventListener);
            }
        }
    }

    void test_callingPause_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent()
    {
        // Wait for the end of initialisation and make sure playbackMode is timeshifting
        test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent();

        const double configuredPlaySpeed = 1.0;
        const double expectedPlaySpeed = 0.0;

        EXPECT_CALL(*mockDTTMediaRouter,
            setPlaySpeed(expectedPlaySpeed))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);

        linearPlaybackControl->pause().get();
    }

    void test_callingSeekPositionWithoutOffsetFromEnd_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterAndEmitsLiveEvent()
    {
        // Wait for the end of initialisation and make sure playbackMode is timeshifting
        test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent();

        const SeekReference::Enum expectedSeekReference = SeekReference::end;
        const int32_t expectedOffset = 0;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        AtomicBool liveEventReceived;
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::live))
            .WillOnce(Assign(&liveEventReceived, true));

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();

        CPPUNIT_ASSERT(liveEventReceived.waitUntilEqual(true, 5000));
    }

    void test_callingSeekPositionWithNegativeOffsetFromCurrentPosition_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent()
    {
        // Wait for the end of initialisation and make sure playbackMode is timeshifting
        test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent();

        const SeekReference::Enum expectedSeekReference = SeekReference::current;
        const int32_t expectedOffset = -100;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();
    }

    void test_callingSeekPositionWithPositiveOffsetFromCurrentPosition_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent()
    {
        // Wait for the end of initialisation and make sure playbackMode is timeshifting
        test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent();

        const SeekReference::Enum expectedSeekReference = SeekReference::current;
        const int32_t expectedOffset = 100;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();
    }

    void test_callingSeekPositionWithoutOffsetFromStart_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent()
    {
        // Wait for the end of initialisation and make sure playbackMode is timeshifting
        test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent();

        const SeekReference::Enum expectedSeekReference = SeekReference::start;
        const int32_t expectedOffset = 0;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();
    }

    void test_callingSeekPositionWithNonStandardPosition_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent()
    {
        // Wait for the end of initialisation and make sure playbackMode is timeshifting
        test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent();

        const SeekReference::Enum expectedSeekReference = SeekReference::start;
        const int32_t expectedOffset = 100;
        const SeekMode::Enum expectedSeekMode = SeekMode::prioritise_speed;

        EXPECT_CALL(*mockDTTMediaRouter,
            seekPosition(expectedSeekReference, expectedOffset, expectedSeekMode))
            .WillOnce(Return(completedFuture()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(_)).Times(0);

        linearPlaybackControl->seekPosition(
            expectedSeekReference, expectedOffset, expectedSeekMode).get();
    }

    void test_initialisation_mediaRouterIsNotCalled_beforeTunedStatusIsReceived()
    {
        shared_ptr< PolledDispatcher > polledDispatcher =
            boost::make_shared< PolledDispatcher >();
        setUpWithDispatcher(polledDispatcher);

        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, dtt1.service.serviceLocator) ))
            .WillOnce(
                returnNewCompletedFuture(createDummyPF(dtt1.serviceLocator))
            );

        EXPECT_CALL(*mockDTTMediaRouter, getPosition()).Times(0);
        EXPECT_CALL(*mockDTTMediaRouter, getVideoWindow()).Times(0);

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));

        while (polledDispatcher->processNext())
        {
        }
        VERIFY_AND_CLEAR_MOCK(mockDTTMediaRouter);

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .WillOnce(Return(completedFuture(Position(0, 0, 0))));
        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoWindow())
            .WillOnce(Return(completedFuture(UNSHRUNK_WINDOW)));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            CurrentEventChanged(UnifiedEvent()));
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::live));

        while (polledDispatcher->processNext())
        {
        }
    }

    void test_tunedSignalReceivedFromTunerControlWithoutPreviousTuningSignal_doesNotHaveAnyEffect()
    {
        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        // Wait for the signal to be processed
        NS_ZINC::AtomicBool statusChangeSignalProcessed;
        dispatcher->post(
            boost::bind(assign, &statusChangeSignalProcessed, true));
        statusChangeSignalProcessed.waitUntilEqual(true, 5000);
    }

    void test_callingGetCurrentEvent_afterDeactivatingSignalWasReceivedDuringInitialisation_waitsForEndOfInitialisationAndReturnsExceptionalFuture()
    {
        Promise< NS_NICKEL_SYSTEM::VideoWindowDescriptor > delayedVideoWindow;
        AtomicBool getVideoWindowCalled;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            completedFuture(createDummyPF(dtt1.serviceLocator)),
            completedFuture(Position(0, 0, 0)),
            delayedVideoWindow.getFuture(),
            UnifiedEvent(),
            getVideoWindowCalled);

        // Simulate a call to TunerControl.setTargetService()
        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));
        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        // Wait for Initialisation to be blocked on getVideoWindow
        CPPUNIT_ASSERT(getVideoWindowCalled.waitUntilEqual(true, 5000));

        // Simulate a call to TunerControl.deactivate())
        mockTunerControl->emitStatusChange(getDeactivatingStatus(dtt1.service));
        mockTunerControl->emitStatusChange(getDeactivatedStatus(dtt1.service));

        // Wait for both signals to be processed
        NS_ZINC::AtomicBool deactivationSignalsProcessed;
        dispatcher->post(
            boost::bind(assign, &deactivationSignalsProcessed, true));
        deactivationSignalsProcessed.waitUntilEqual(true, 5000);

        delayedVideoWindow.complete(UNSHRUNK_WINDOW);

        // getCurrentEvent() should throw as state is uninitialised
        CPPUNIT_ASSERT_THROW(
            linearPlaybackControl->getCurrentEvent().get(),
            std::runtime_error);
    }

    void test_callingIsMaximised_whenTwoChannelChangeInARowAndUERTakesALongTimeToReplyToGetPF_waitsForEndOfInitialisationAndReturnsTrue()
    {
        const NS_NICKELTUNER_SYSTEM::TunerControlStatus tuningStatus1(
            TunerControlState::tuning,
            dtt1.service,
            TuningReason::user_initiated,
            TuningErrorType::no_error,
            "");
        const NS_NICKELTUNER_SYSTEM::TunerControlStatus tunedStatus1(
            TunerControlState::tuned,
            dtt1.service,
            TuningReason::user_initiated,
            TuningErrorType::no_error,
            "");

        const NS_NICKELTUNER_SYSTEM::TunerControlStatus tuningStatus2(
            TunerControlState::tuning,
            dtt2.service,
            TuningReason::user_initiated,
            TuningErrorType::no_error,
            "");
        const NS_NICKELTUNER_SYSTEM::TunerControlStatus tunedStatus2(
            TunerControlState::tuned,
            dtt2.service,
            TuningReason::user_initiated,
            TuningErrorType::no_error,
            "");

        const UnifiedEvent noEvent;
        std::vector< PresentFollowingInfo > retPF1 =
            std::vector< PresentFollowingInfo > (1,
                PresentFollowingInfo(dtt1.serviceLocator, noEvent, noEvent));

        std::vector< PresentFollowingInfo > retPF2 =
            std::vector< PresentFollowingInfo > (1,
                PresentFollowingInfo(dtt2.serviceLocator, noEvent, noEvent));

        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        AtomicBool firstInitialisationBlockedOnGetPresentFollowing;
        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, dtt1.serviceLocator) ))
            .WillOnce(
                DoAll(
                    Assign(&firstInitialisationBlockedOnGetPresentFollowing, true),
                    Return(delayedPresentFollowing.getFuture())
                ));

        EXPECT_CALL(*mockDTTMediaRouter,
            getPosition())
            .Times(2)
            .WillRepeatedly(returnNewCompletedFuture(Position(0, 0, 0)));

        EXPECT_CALL(*mockDTTMediaRouter,
            getVideoWindow())
            .Times(2)
            .WillRepeatedly(returnNewCompletedFuture(UNSHRUNK_WINDOW));

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            CurrentEventChanged(noEvent))
            .Times(2);
        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            PlaybackModeChange(PlaybackMode::live))
            .Times(1); // only expect it for the first tune

        EXPECT_CALL(*mockUnifiedEventRepository,
            getPresentFollowing( std::vector<std::string>(1, dtt2.serviceLocator) ))
            .WillOnce(Return(completedFuture(retPF2)));

        mockTunerControl->emitStatusChange(tuningStatus1);
        mockTunerControl->emitStatusChange(tunedStatus1);

        CPPUNIT_ASSERT(
            firstInitialisationBlockedOnGetPresentFollowing.waitUntilEqual(true, 5000));
        Future< bool > isMaximisedFuture =
            linearPlaybackControl->isMaximised();

        mockTunerControl->emitStatusChange(tuningStatus2);
        mockTunerControl->emitStatusChange(tunedStatus2);

        delayedPresentFollowing.complete(retPF1);

        isMaximisedFuture.get();
    }

    void test_callingSetDestinationVideoWindow_resultsInVideoResizeEvent()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        VideoWindowDescriptor customWindow;
        customWindow.sourceX = 0.0;
        customWindow.sourceY = 0.0;
        customWindow.sourceWidth = 1.0;
        customWindow.sourceHeight = 1.0;
        customWindow.destinationX = 0.1;
        customWindow.destinationY = 0.1;
        customWindow.destinationWidth = 0.8;
        customWindow.destinationHeight = 0.8;

        VideoWindowRelativeRect dstRect;
        dstRect.x = customWindow.destinationX;
        dstRect.y = customWindow.destinationY;
        dstRect.width = customWindow.destinationWidth;
        dstRect.height = customWindow.destinationHeight;

        EXPECT_CALL(*mockDTTMediaRouter, setVideoWindow(customWindow))
            .WillOnce(Return(completedFuture()));

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(dstRect));

        linearPlaybackControl->setDestinationVideoWindow(
            dstRect.x, dstRect.y, dstRect.width, dstRect.height).get();

        waitForDispatcherToFinish(dispatcher, 5000);
    }

    void test_isMaximisedReturnsTrue_afterCallingSetDestinationVideoWindow_withFullScreenWindow()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        EXPECT_CALL(*mockDTTMediaRouter, setVideoWindow(UNSHRUNK_WINDOW))
            .WillOnce(Return(completedFuture()));

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(_));

        linearPlaybackControl->setDestinationVideoWindow(
            UNSHRUNK_WINDOW.destinationX, UNSHRUNK_WINDOW.destinationY,
            UNSHRUNK_WINDOW.destinationWidth, UNSHRUNK_WINDOW.destinationHeight).get();

        waitForDispatcherToFinish(dispatcher, 5000);

        CPPUNIT_ASSERT(linearPlaybackControl->isMaximised().get() == true);
    }

    void test_isMaximisedReturnsFalse_afterCallingSetDestinationVideoWindow_withShrunkWindow()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        EXPECT_CALL(*mockDTTMediaRouter, setVideoWindow(SHRUNK_WINDOW))
            .WillOnce(Return(completedFuture()));

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(_));

        linearPlaybackControl->setDestinationVideoWindow(
            SHRUNK_WINDOW.destinationX, SHRUNK_WINDOW.destinationY,
            SHRUNK_WINDOW.destinationWidth, SHRUNK_WINDOW.destinationHeight).get();

        waitForDispatcherToFinish(dispatcher, 5000);

        CPPUNIT_ASSERT(linearPlaybackControl->isMaximised().get() == false);
    }

    void test_VideoResizeEventNotEmitted_ifSetVideoWindowFails()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        EXPECT_CALL(*mockDTTMediaRouter, setVideoWindow(_))
            .WillOnce(returnNewExceptionalFuture(
                std::runtime_error("Failure for testing purposes")));

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(_)).Times(0);

        CPPUNIT_ASSERT_THROW(linearPlaybackControl->setDestinationVideoWindow(
            SHRUNK_WINDOW.destinationX, SHRUNK_WINDOW.destinationY,
            SHRUNK_WINDOW.destinationWidth, SHRUNK_WINDOW.destinationHeight).get(),
            std::runtime_error);

        waitForDispatcherToFinish(dispatcher, 5000);
    }

    void test_isMaximisedNotUpdated_ifSetVideoWindowFails()
    {
        // Wait for the end of initialisation
        test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue();

        EXPECT_CALL(*mockDTTMediaRouter, setVideoWindow(_))
            .WillOnce(returnNewExceptionalFuture(
                std::runtime_error("Failure for testing purposes")));

        EXPECT_CALL(*mockLinearPlaybackControlEventListener,
            VideoResizeEvent(_)).Times(0);

        CPPUNIT_ASSERT_THROW(linearPlaybackControl->setDestinationVideoWindow(
            SHRUNK_WINDOW.destinationX, SHRUNK_WINDOW.destinationY,
            SHRUNK_WINDOW.destinationWidth, SHRUNK_WINDOW.destinationHeight).get(),
            std::runtime_error);

        waitForDispatcherToFinish(dispatcher, 5000);

        // Here we rely on LinearControlPlayback to start with fullscreen video.
        CPPUNIT_ASSERT(linearPlaybackControl->isMaximised().get() == true);
    }

    void test_getPlaybackSpeed_whenUninitialised_returnsExceptionalFuture()
    {
        CPPUNIT_ASSERT_THROW(linearPlaybackControl->getPlaybackSpeed().get(), std::runtime_error);
    }

    void test_getPlaybackSpeed_ExpectedValue_whenInitialised()
    {
        // initialise LinearPlaybackControl
        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        // now mock and check the getPlaybackSpeed interface
        double configuredPlaySpeed = 3.4;
        EXPECT_CALL(*mockDTTMediaRouter,
                getPlaySpeed())
                    .WillOnce(Return(completedFuture(configuredPlaySpeed)));

        CPPUNIT_ASSERT_EQUAL(configuredPlaySpeed, linearPlaybackControl->getPlaybackSpeed().get());
    }

    void test_setPlaybackSpeed_whenUninitialised_returnsExceptionalFuture()
    {
        CPPUNIT_ASSERT_THROW(linearPlaybackControl->setPlaybackSpeed(1.0).get(), std::runtime_error);
    }

    void test_setPlaybackSpeed_ExpectedValue_whenInitialised()
    {
        // initialise LinearPlaybackControl
        Promise< std::vector< PresentFollowingInfo > > delayedPresentFollowing;
        setupExpectationsForDTTInitialisation(
            dtt1.service,
            delayedPresentFollowing.getFuture(),
            completedFuture(Position(0, 0, 0)),
            completedFuture(UNSHRUNK_WINDOW),
            UnifiedEvent());

        mockTunerControl->emitStatusChange(getSuccessfulTuningStatus(dtt1.service));
        delayedPresentFollowing.complete(createDummyPF(dtt1.serviceLocator));

        mockTunerControl->emitStatusChange(getSuccessfulTunedStatus(dtt1.service));

        // now mock and check the getPlaybackSpeed interface
        double configuredPlaySpeed = 3.4;
        EXPECT_CALL(*mockDTTMediaRouter,
                setPlaySpeed(configuredPlaySpeed))
                    .WillOnce(Return(completedFuture()));

        CPPUNIT_ASSERT_NO_THROW(linearPlaybackControl->setPlaybackSpeed(configuredPlaySpeed).get());
    }

    CPPUNIT_TEST_SUITE(LinearPlaybackControlTest);

    // Test Uninitialised state
    CPPUNIT_TEST(test_mrMethods_whenUninitialised_returnsExceptionalFuture);
    CPPUNIT_TEST(test_eventTrackingMethods_whenUninitialised_returnsExceptionalFuture);
    CPPUNIT_TEST(test_parentalControlsMethods_whenUninitialised_returnsExceptionalFuture);
    CPPUNIT_TEST(test_getPlaybackSpeed_whenUninitialised_returnsExceptionalFuture);
    CPPUNIT_TEST(test_setPlaybackSpeed_whenUninitialised_returnsExceptionalFuture);

    // Test Initialising state
    CPPUNIT_TEST(test_callingPause_whenPlaySpeedOne_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZero);
    CPPUNIT_TEST(test_callingPlay_whenPlaySpeedZero_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedOne);
    CPPUNIT_TEST(test_callingFastForward_whenPlaySpeedTwo_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedSix);
    CPPUNIT_TEST(test_callingRewind_whenPlaySpeedMinusTwo_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedMinusSix);
    CPPUNIT_TEST(test_callingSeekPosition_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterSeekPosition);
    CPPUNIT_TEST(test_callingGetPlaybackMode_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsLive);
    CPPUNIT_TEST(test_callingGetTimeshiftFromLiveInMilliSeconds_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterGetPositionAndReturnsEndMinusCurrent);
    CPPUNIT_TEST(test_callingGetEventTimeshiftFromLiveInMilliSeconds_forCurrentEvent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsTimeshift);
    CPPUNIT_TEST(test_callingMinimise_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterSetVideoWindowShrunk);
    CPPUNIT_TEST(test_callingMaximise_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndCallsDTTMediaRouterSetVideoWindowUnshrunk);
    CPPUNIT_TEST(test_callingIsMaximised_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue);
    CPPUNIT_TEST(test_callingGetSourceInformation_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetPosition_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetTracks_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetVideoTrack_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetSubtitleTrack_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndDelegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetCurrentEvent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsCurrentEvent);
    CPPUNIT_TEST(test_callingIsLocked_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsFalse);
    CPPUNIT_TEST(test_callingAllowRestrictedContent_afterDTTTuningSignalReceivedAndBeforeGetPFCompleted_waitsForTheEndOfInitialisationAndReturnsExceptionalFuture);

    // Test Initialised state
    CPPUNIT_TEST(test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedZeroAndEmitsTimeshiftingEvent);
    CPPUNIT_TEST(test_callingPause_whenPlaySpeedOne_whenInitialisedInDTT_setPlaySpeedFails_returnsExceptionalFutureWithoutEmittingTimeshiftingEvent);
    CPPUNIT_TEST(test_callingPlay_whenPlaySpeedZero_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedOne);
    CPPUNIT_TEST(test_callingFastForward_whenPlaySpeedTwo_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedSix);
    CPPUNIT_TEST(test_callingRewind_whenPlaySpeedMinusTwo_whenInitialisedInDTT_callsDTTMediaRouterGetPlaySpeedAndSetPlaySpeedMinusSix);
    CPPUNIT_TEST(test_callingSeekPositionWithoutOffsetFromEnd_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionWithoutEmittingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithNegativeOffsetFromCurrentPosition_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionAndEmitsTimeshiftingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithPositiveOffsetFromCurrentPosition_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionWithoutEmittingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithoutOffsetFromStart_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionAndEmitsTimeshiftingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithNonStandardPosition_whenInitialisedInDTT_callsDTTMediaRouterSeekPositionWithoutEmittingEvent);
    CPPUNIT_TEST(test_callingGetPlaybackMode_whenInitialisedInDTT_whenNotTimeshifting_returnsLive);
    CPPUNIT_TEST(test_callingGetPlaybackMode_whenInitialisedInDTT_whenTimeshifting_returnsTimeshifting);
    CPPUNIT_TEST(test_callingGetTimeshiftFromLiveInMilliSeconds_whenInitialisedInDTT_callsDTTMediaRouterGetPositionAndReturnsEndMinusCurrent);
    CPPUNIT_TEST(test_callingGetEventTimeshiftFromLiveInMilliSeconds_forCurrentEvent_whenInitialisedInDTT_returnsTimeshift);
    CPPUNIT_TEST(test_callingMinimise_whenInitialisedInDTT_callsDTTMediaRouterSetVideoWindowShrunkAndEmitsMinimisedEvent);
    CPPUNIT_TEST(test_callingMaximise_whenInitialisedInDTT_callsDTTMediaRouterSetVideoWindowUnshrunkAndEmitsMaximisedEvent);
    CPPUNIT_TEST(test_callingIsMaximised_whenInitialisedInDTT_withMediaRouterMaximised_waitsForTheEndOfInitialisationAndReturnsTrue);
    CPPUNIT_TEST(test_callingGetSourceInformation_whenInitialisedInDTT_delegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetPosition_whenInitialisedInDTT_delegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetTracks_whenInitialisedInDTT_delegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetVideoTrack_whenInitialisedInDTT_delegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetSubtitleTrack_whenInitialisedInDTT_delegatesToDTTMediaRouter);
    CPPUNIT_TEST(test_callingGetCurrentEvent_whenInitialisedInDTT_returnsCurrentEvent);
    CPPUNIT_TEST(test_callingIsLocked_whenInitialisedInDTT_returnsFalse);
    CPPUNIT_TEST(test_callingAllowRestrictedContent_whenInitialisedInDTT_returnsExceptionalFuture);

    // Test Media Router events
    CPPUNIT_TEST(test_receivingBufferStatusEvent_whenInitialisationFailed_doesNotEmitAnyEvent);
    CPPUNIT_TEST(test_receivingDrmEvent_whenInitialisationFailed_doesNotEmitAnyEvent);
    CPPUNIT_TEST(test_receivingPositionChangeEvent_whenInitialisationFailed_doesNotEmitAnyEvent);
    CPPUNIT_TEST(test_receivingSourceEvent_whenInitialisationFailed_doesNotEmitAnyEvent);
    CPPUNIT_TEST(test_receivingSpeedChangeEvent_whenInitialisationFailed_doesNotEmitAnyEvent);
    CPPUNIT_TEST(test_receivingStatusEvent_whenInitialisationFailed_doesNotEmitAnyEvent);
    CPPUNIT_TEST(test_receivingErrorEvent_whenInitialisationFailed_doesNotEmitAnyEvent);
    CPPUNIT_TEST(test_receivingBufferStatusEvent_whenInitialisedInDTT_emitsBufferStatusEvent);
    CPPUNIT_TEST(test_receivingDrmEvent_whenInitialisedInDTT_emitsDrmEvent);
    CPPUNIT_TEST(test_receivingPositionChangeEvent_whenInitialisedInDTT_emitsPositionChangeEvent);
    CPPUNIT_TEST(test_receivingSourceEvent_whenInitialisedInDTT_emitsSourceEvent);
    CPPUNIT_TEST(test_receivingSpeedChangeEvent_whenInitialisedInDTT_getsSpeedFromMR_andEmitsSpeedChangeEvent);
    CPPUNIT_TEST(test_receivingSpeedChangeEvent_whenInitialisedInDTT_failsToGetSpeedFromMR_doesNotEmitSpeedChangeEvent);
    CPPUNIT_TEST(test_receivingStatusEvent_whenInitialisedInDTT_emitsStatusEvent);
    CPPUNIT_TEST(test_receivingErrorEvent_whenInitialisedInDTT_emitsErrorEvent);

    // Test PlaybackMode changes
    CPPUNIT_TEST(test_callingPause_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithoutOffsetFromEnd_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterAndEmitsLiveEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithNegativeOffsetFromCurrentPosition_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithPositiveOffsetFromCurrentPosition_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithoutOffsetFromStart_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent);
    CPPUNIT_TEST(test_callingSeekPositionWithNonStandardPosition_whenInitialisedInDTT_whenTimeshifting_callsDTTMediaRouterWithoutEmittingEvent);

    // Test initialisation
    CPPUNIT_TEST(test_initialisation_mediaRouterIsNotCalled_beforeTunedStatusIsReceived);

    // Special scenarios
    CPPUNIT_TEST(test_tunedSignalReceivedFromTunerControlWithoutPreviousTuningSignal_doesNotHaveAnyEffect);
    CPPUNIT_TEST(test_callingGetCurrentEvent_afterDeactivatingSignalWasReceivedDuringInitialisation_waitsForEndOfInitialisationAndReturnsExceptionalFuture);
    CPPUNIT_TEST(test_callingIsMaximised_whenTwoChannelChangeInARowAndUERTakesALongTimeToReplyToGetPF_waitsForEndOfInitialisationAndReturnsTrue);
    CPPUNIT_TEST(test_getPlaybackSpeed_ExpectedValue_whenInitialised);
    CPPUNIT_TEST(test_setPlaybackSpeed_ExpectedValue_whenInitialised);

    // Video resizing
    CPPUNIT_TEST(test_callingSetDestinationVideoWindow_resultsInVideoResizeEvent);
    CPPUNIT_TEST(test_isMaximisedReturnsTrue_afterCallingSetDestinationVideoWindow_withFullScreenWindow);
    CPPUNIT_TEST(test_isMaximisedReturnsFalse_afterCallingSetDestinationVideoWindow_withShrunkWindow);
    CPPUNIT_TEST(test_VideoResizeEventNotEmitted_ifSetVideoWindowFails);
    CPPUNIT_TEST(test_isMaximisedNotUpdated_ifSetVideoWindowFails);

    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(LinearPlaybackControlTest);
