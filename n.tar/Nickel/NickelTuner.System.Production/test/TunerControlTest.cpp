/*
 * File:   TunerControlTest.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 28-Jun-2013
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/Factory.h"
#include "../src/TunerControlImpl.h"

#include <nickeltuner-system-api/MockTunerControlEventListener.h>
#include <nickeltuner-system-api/ServiceHiddenException.h>
#include <nickeltuner-system-api/ServiceRestrictedException.h>
#include <nickeltuner-system-api/TunerControlAsync.h>
#include <nickeltuner-system-api/TunerControlStatus.h>

#include <cadmium-system-api/MockLinearAcquisitionAsync.h>
#include <cadmium-system-api/ScheduledRecording.h>

#include <cobalt-system-api/MockProvisioningServiceAsync.h>
#include <cobalt-system-api/MockUnifiedServiceRepositoryAsync.h>
#include <cobalt-system-api/MockHiddenServicesStoreAsync.h>
#include <cobalt-system-api/MockUnifiedEventRepositoryAsync.h>
#include <cobalt-system-api/ProvisioningInformationRetrievalFailedException.h>
#include <cobalt-system-api/ServiceNotFoundException.h>

#include <copper-system-api/MockLocalStorageRepositoryAsync.h>

#include <neon-client-api/IPNetwork.h>

#include <nickel-system-api/MockMediaRouterAsync.h>
#include <nickel-system-api/PlayConflictException.h>
#include <nickeltuner-system-api/macros.h>

#include <zinc-common/async/async-helpers.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/AtomicBool.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/FutureMockActions.h>
#include <zinc-common/testsupport/MockProperty.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>

#include <boost/assign/list_of.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>

#include <gmock/gmock.h>

#include <map>
#include <string>
#include <vector>

using namespace NS_CADMIUM_SYSTEM;
using namespace NS_COBALT_SYSTEM;
using namespace NS_COPPER_SYSTEM;
using namespace NS_NEON_CLIENT;
using namespace NS_NICKEL_SYSTEM;
using namespace NS_NICKELTUNER_SYSTEM;
using namespace NS_ZINC;

using testing::_;
using testing::Expectation;
using testing::Assign;
using testing::DoAll;
using testing::Return;

using std::map;
using std::string;
using std::vector;

namespace
{

const string MEDIA_ROUTER_RESTRICTED_SERVICE_SET   = "RESTRICTED_SERVICE_SET";
const string FAKE_FIRST_SERVICE_IN_RESTRICTED_SET  = "dvb://firstServiceInRestrictedSet";
const string DEFAULT_MEDIA_ROUTER_SINK             = "decoder://0";

struct FakeServiceData
{
    FakeServiceData(const string& serviceLocator_, // Subscription service
                    const string& contentURL,
                    UnifiedServiceType::Enum serviceType,
                    EntitlementType::Enum entitlementType,
                    const string& sasURL_)
    {
        service.serviceLocator      = serviceLocator_;
        service.mediaContent.url    = contentURL;
        service.serviceType         = serviceType;
        service.entitlementType     = entitlementType;
        serviceLocator              = serviceLocator_;
        sasURL                      = sasURL_;
        mediaSourceURI              = "linear:" + sasURL_ + "#" + contentURL;
    }

    FakeServiceData(const string& serviceLocator_) // DTT service
    {
        service.serviceLocator      = serviceLocator_;
        service.serviceType         = UnifiedServiceType::linear_service_broadcast_channel;
        service.entitlementType     = EntitlementType::free_to_air;
        serviceLocator              = serviceLocator_;
        mediaSourceURI              = serviceLocator_;
    }

    UnifiedService  service;
    string          serviceLocator;
    string          sasURL;
    string          mediaSourceURI;
};

FakeServiceData createSubscriptionService(const string& serviceLocator, const string& contentURL,
                                          const string& sasURL)
{
    return FakeServiceData(serviceLocator, contentURL,
                           UnifiedServiceType::linear_service_ip_channel,
                           EntitlementType::subscription, sasURL);
}

FakeServiceData createDTTService(const string& serviceLocator)
{
    return FakeServiceData(serviceLocator);
}

map< string, string > createNonEmptyRestrictedServiceSet(const string& serviceLocator)
{
    map< string, string > sourceInformation;
    sourceInformation[MEDIA_ROUTER_RESTRICTED_SERVICE_SET] = "   " + FAKE_FIRST_SERVICE_IN_RESTRICTED_SET + " " + serviceLocator + "  serviceNotUsed2 serviceNotUsed  ";
    return sourceInformation;
}

map< string, string > createEmptyRestrictedServiceSet()
{
    map< string, string > sourceInformation;
    sourceInformation[MEDIA_ROUTER_RESTRICTED_SERVICE_SET] = "";
    return sourceInformation;
}

vector< string > createNonEmptyHiddenServiceList(const string& serviceLocator)
{
    vector< string > hiddenServices;
    hiddenServices.push_back(serviceLocator);
    return hiddenServices;
}

vector< string > createEmptyHiddenServiceList()
{
    return vector< string >();
}

void addScheduledRecordingFromEvent(const UnifiedEvent& ue,
                                    ScheduledRecordingStatus::Enum status,
                                    std::vector<ScheduledRecording>& recordings)
{
    ScheduledRecording sr;
    sr.eventLocator = ue.data.eventLocator;
    sr.status = status;
    recordings.push_back(sr);
}

std::vector< ScheduledRecording > createScheduledRecordingsFromEvents(
    const std::vector< UnifiedEvent > eventsToRecord,
    ScheduledRecordingStatus::Enum status)
{
    std::vector< ScheduledRecording > recordings;
    BOOST_FOREACH(const UnifiedEvent& ue, eventsToRecord)
    {
        addScheduledRecordingFromEvent(ue, status, recordings);
    }
    return recordings;
}

UnifiedEvent createUnifiedEvent(const std::string& eventLocator,
                                const std::string& serviceLocator)
{
    UnifiedEvent dummyEvent;
    dummyEvent.data.eventLocator = eventLocator;
    dummyEvent.data.serviceLocator = serviceLocator;
    return dummyEvent;
}

class ZINC_LOCAL MockIPNetwork: public IPNetwork
{
public:
    // TODO: Cleanup Neon Client IPNetwork to remove this nasty code.
    MockIPNetwork(): IPNetwork(boost::shared_ptr< Dispatcher >(), boost::shared_ptr< Dispatcher >())
    {
    }

    MOCK_CONST_METHOD0(getNetworkStatus, IPNetwork::Status ());

    MOCK_METHOD0(getInterfaces, Future< vector< boost::shared_ptr< NS_NEON_CLIENT::Interface > > > ());

    MOCK_METHOD0(getActiveInterface, Future< boost::shared_ptr< NS_NEON_CLIENT::Interface > > ());

    MOCK_METHOD4(ping,
        Future< NS_NEON_CLIENT::PingResult > (const uint32_t a, const uint32_t b, const uint32_t c, const uint32_t d));

    void emitNetworkStatusChange(const int32_t status)
    {
        produceEvent(
            boost::bind(&IPNetworkEventListener::NetworkStatusChange, _1, status));
    }
};

// This is to make it possible to access TunerControl from the thread used
// by the factory. TunerControl relies on that for thread safety.
class ZINC_LOCAL TunerControlProxy : public TunerControlAsync, public TunerControlEventListener
{
public:
    TunerControlProxy(boost::shared_ptr< TunerControlAsync > tunerControl_,
                       boost::shared_ptr< Dispatcher > zincDispatcher_):
        tunerControl(tunerControl_),
        zincDispatcher(zincDispatcher_)
    {
    }

    virtual Future< string > getTargetService() const
    {
        return asyncInvoke(zincDispatcher, *zincDispatcher,
            boost::bind(&TunerControlAsync::getTargetService, tunerControl)).get();
    }

    virtual Future< void > setTargetService(const string& serviceLocator,
        const TuningReason::Enum tuningReason)
    {
        return asyncInvoke(zincDispatcher, *zincDispatcher,
            boost::bind(&TunerControlAsync::setTargetService, tunerControl, serviceLocator, tuningReason)).get();
    }

    virtual Future< void > activate(const TuningReason::Enum tuningReason)
    {
        return asyncInvoke(zincDispatcher, *zincDispatcher,
            boost::bind(&TunerControlAsync::activate, tunerControl, tuningReason)).get();
    }

    virtual Future< void > deactivate(const TuningReason::Enum tuningReason)
    {
        return asyncInvoke(zincDispatcher, *zincDispatcher,
            boost::bind(&TunerControlAsync::deactivate, tunerControl, tuningReason)).get();
    }

    virtual Future< TunerControlStatus > getStatus()
    {
        return asyncInvoke(zincDispatcher, *zincDispatcher,
            boost::bind(&TunerControlAsync::getStatus, tunerControl)).get();
    }

    virtual void StatusChange(const TunerControlStatus& status)
    {

        produceEvent(
            boost::bind( &TunerControlEventListener::StatusChange,
                _1, status) );
    }

private:
    boost::shared_ptr< TunerControlAsync > tunerControl;
    boost::shared_ptr< Dispatcher >        zincDispatcher;
};

}


class ZINC_LOCAL TunerControlTest : public NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
private:
    boost::shared_ptr< MockProvisioningServiceAsync >          mockProvisioningService;
    boost::shared_ptr< MockUnifiedServiceRepositoryAsync >     mockUnifiedServiceRepository;
    boost::shared_ptr< MockHiddenServicesStoreAsync >          mockHiddenServicesStore;
    boost::shared_ptr< MockUnifiedEventRepositoryAsync >       mockUnifiedEventRepository;
    boost::shared_ptr< MockMediaRouterAsync >                  mockDTTMediaRouter;
    boost::shared_ptr< MockMediaRouterAsync >                  mockIPMediaRouter;
    boost::shared_ptr< MediaRouterAsync >                      mockDTTMediaRouterUpCasted;
    boost::shared_ptr< MediaRouterAsync >                      mockIPMediaRouterUpCasted;
    boost::shared_ptr< MockIPNetwork >                         mockIPNetwork;
    boost::shared_ptr< MockTunerControlEventListener >         mockTunerControlEventListener;
    boost::shared_ptr< MockLocalStorageRepositoryAsync >       mockLocalStorageRepository;
    boost::shared_ptr< MockLinearAcquisitionAsync >            mockLinearAcquisition;
    boost::shared_ptr< MockProperty< string > >                mockLastSelectedServiceProperty;
    boost::shared_ptr< MockProperty< int32_t > >               mockPlatformIPMaxStreamsProperty;
    boost::shared_ptr< MockProperty< int32_t > >               mockISPIPMaxStreamsProperty;
    boost::shared_ptr< MockProperty< int32_t > >               mockOEMIPMaxStreamsProperty;
    boost::shared_ptr< Dispatcher >                            dispatcher;
    boost::shared_ptr< TunerControlProxy >                     tunerControl;

    FakeServiceData sub1;
    FakeServiceData sub2;
    FakeServiceData sub3;
    FakeServiceData dtt1;
    FakeServiceData dtt2;

    UnifiedEvent ue1;
    UnifiedEvent ue2;

public:
    TunerControlTest()
        : sub1(createSubscriptionService("http://devarch/ipService1",
                                         "http://devarch/ipService1.sdp",
                                         "https://ms3.devarch/ipService1")),
          sub2(createSubscriptionService("http://devarch/ipService2",
                                         "http://devarch/ipService2.sdp",
                                         "https://ms3.devarch/ipService2")),
          sub3(createSubscriptionService("http://devarch/ipService3",
                                         "http://devarch/ipService3.sdp",
                                         "https://ms3.devarch/ipService3")),
          dtt1(createDTTService("dvb://devarchDTT1")),
          dtt2(createDTTService("dvb://devarchDTT2")),
          ue1(createUnifiedEvent("http://devarch/ipService1/unified.event", "http://devarch/ipService1")), // Associated with sub1 Service
          ue2(createUnifiedEvent("http://devarch/ipService2/unified.event", "http://devarch/ipService2")) // Associated with sub2 Service
    {
    }

    virtual void setUp()
    {
        mockProvisioningService             = boost::make_shared< MockProvisioningServiceAsync >();
        mockUnifiedServiceRepository        = boost::make_shared< MockUnifiedServiceRepositoryAsync >();
        mockHiddenServicesStore             = boost::make_shared< MockHiddenServicesStoreAsync >();
        mockUnifiedEventRepository          = boost::make_shared< MockUnifiedEventRepositoryAsync >();
        mockDTTMediaRouter                  = boost::make_shared< MockMediaRouterAsync >();
        mockIPMediaRouter                   = boost::make_shared< MockMediaRouterAsync >();
        mockIPNetwork                       = boost::make_shared< MockIPNetwork >();
        mockTunerControlEventListener       = boost::make_shared< MockTunerControlEventListener >();
        mockLocalStorageRepository          = boost::make_shared< MockLocalStorageRepositoryAsync >();
        mockLinearAcquisition               = boost::make_shared< MockLinearAcquisitionAsync >();
        mockLastSelectedServiceProperty     = boost::make_shared< MockProperty< string > >("");
        // Number of available IP tuners will be 2
        mockPlatformIPMaxStreamsProperty    = boost::make_shared< MockProperty< int32_t > >(2);
        mockISPIPMaxStreamsProperty         = boost::make_shared< MockProperty< int32_t > >(2);
        mockOEMIPMaxStreamsProperty         = boost::make_shared< MockProperty< int32_t > >(2);
        mockDTTMediaRouterUpCasted          = mockDTTMediaRouter;
        mockIPMediaRouterUpCasted           = mockIPMediaRouter;

        dispatcher = boost::make_shared< NS_ZINC::SingleThreadDispatcher >();
        NS_NICKELTUNER_SYSTEM::Factory factory(dispatcher);

        factory.setProvisioningService(mockProvisioningService);
        factory.setUnifiedServiceRepository(mockUnifiedServiceRepository);
        factory.setHiddenServicesStore(mockHiddenServicesStore);
        factory.setUnifiedEventRepository(mockUnifiedEventRepository);
        factory.setDTTMediaRouter(mockDTTMediaRouter);
        factory.setIPMediaRouter(mockIPMediaRouter);
        factory.setIPNetwork(mockIPNetwork);
        factory.setLocalStorageRepository(mockLocalStorageRepository);
        factory.setLinearAcquisition(mockLinearAcquisition);
        factory.setLastSelectedServiceProperty(mockLastSelectedServiceProperty);
        factory.setPlatformIPMaxStreamsProperty(mockPlatformIPMaxStreamsProperty);
        factory.setISPIPMaxStreamsProperty(mockISPIPMaxStreamsProperty);
        factory.setOEMIPMaxStreamsProperty(mockOEMIPMaxStreamsProperty);

        EXPECT_CALL(*mockIPNetwork, getNetworkStatus())
            .WillOnce( Return( IPNetwork::DISCONNECTED ));

        // Create a tunerControlProxy so that all the calls made to Tuner from the tests
        // are executed on dispatcher. This is what tunerd is doing by using mainloop.
        // getZincDispatcher() in the Factory.
        boost::shared_ptr< TunerControlAsync > realTunerControl = factory.createTunerControl();
        tunerControl = boost::make_shared< TunerControlProxy >(realTunerControl, dispatcher);
        realTunerControl->addListener(dispatcher, tunerControl);

        tunerControl->addListener(dispatcher, mockTunerControlEventListener);

        mockIPNetwork->emitNetworkStatusChange(IPNetwork::CONNECTED);
    }

    virtual void tearDown()
    {
        VERIFY_AND_CLEAR_MOCK(mockLastSelectedServiceProperty);
        VERIFY_AND_CLEAR_MOCK(mockLinearAcquisition);
        VERIFY_AND_CLEAR_MOCK(mockLocalStorageRepository);
        VERIFY_AND_CLEAR_MOCK(mockTunerControlEventListener);
        VERIFY_AND_CLEAR_MOCK(mockIPNetwork);
        VERIFY_AND_CLEAR_MOCK(mockIPMediaRouter);
        VERIFY_AND_CLEAR_MOCK(mockDTTMediaRouter);
        VERIFY_AND_CLEAR_MOCK(mockUnifiedServiceRepository);
        VERIFY_AND_CLEAR_MOCK(mockHiddenServicesStore);
        VERIFY_AND_CLEAR_MOCK(mockUnifiedEventRepository);
        VERIFY_AND_CLEAR_MOCK(mockProvisioningService);
    }

    Expectation setupSignalsExpectationsForTuning(
            const UnifiedService& service,
            const TuningReason::Enum tuningReason,
            const TuningErrorType::Enum errorType,
            const string& errorContext,
            AtomicBool& tunedStatusReceived)
    {
        EXPECT_CALL(*mockLocalStorageRepository,
            setItem(0, "", LAST_SELECTED_SERVICE_LOCATOR_KEY, service.serviceLocator))
                .WillOnce( Return( completedFuture() ) );

        // Tuning signal received
        TunerControlStatus expectedTuningStatus(TunerControlState::tuning,
                                                service,
                                                tuningReason,
                                                TuningErrorType::no_error, // Never any error in Tuning
                                                "");
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedTuningStatus))
            .Times(1);

        // Tuned signal received
        TunerControlStatus expectedTunedStatus(TunerControlState::tuned,
                                               service,
                                               tuningReason,
                                               errorType,
                                               errorContext);
        return EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedTunedStatus))
            .WillOnce(Assign(&tunedStatusReceived, true));
    }

    Expectation setupSignalsExpectationsForTuningSuccessful(
            const UnifiedService& service,
            const TuningReason::Enum tuningReason,
            AtomicBool& tunedStatusReceived)
    {
        return setupSignalsExpectationsForTuning(
            service, tuningReason, TuningErrorType::no_error, "", tunedStatusReceived);
    }

    Expectation setupSignalsExpectationsForDeactivation(
            const UnifiedService& service,
            const TuningReason::Enum tuningReason,
            AtomicBool& deactivatedStatusReceived)
    {
        // Expectation for Deactivating signal received
        TunerControlStatus expectedDeactivatingStatus(TunerControlState::deactivating,
                                                service,
                                                tuningReason,
                                                TuningErrorType::no_error, // Never any error when Deactivating
                                                "");
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedDeactivatingStatus))
            .Times(1);

        // Expectation for Deactivated signal received
        TunerControlStatus expectedDeactivatedStatus(TunerControlState::deactivated,
                                               service,
                                               tuningReason,
                                               TuningErrorType::no_error, // Never any error when Deactivated
                                               "");
        return EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedDeactivatedStatus))
            .WillOnce(Assign(&deactivatedStatusReceived, true));
    }

    void deactivate_whenTunedToDTT_andBlockOnDeactivating(
            Future< void > futureBlockingDeactivatingTransition,
            AtomicBool& deactivatedStatusReceived)
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        setupSignalsExpectationsForDeactivation(dtt1.service,
                TuningReason::user_initiated, deactivatedStatusReceived);

        // Make sure 2nd tune is called during Deactivating and not Deactivated
        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( futureBlockingDeactivatingTransition ) );
        tunerControl->deactivate(TuningReason::user_initiated).get();
    }

    void blockOnTuning_whenTuningToIP(
            Future< string > futureBlockingTuningTransition,
            AtomicBool& tunedStatusReceived)
    {
        setupSignalsExpectationsForTuningSuccessful(sub1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( futureBlockingTuningTransition ));

        EXPECT_CALL(*mockIPMediaRouter, recycle())
            .WillOnce( Return( completedFuture() ) );
        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( Return( completedFuture(string("")) ) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( completedFuture() ));
        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
    }

    TunerControlConfig createTunerControlConfig(const std::string& lastSelectedService,
                                                const int32_t& platformMaxStreams,
                                                const int32_t& ispMaxStreams,
                                                const int32_t& oemMaxStreams)
    {
        TunerControlConfig config =
            {
                boost::make_shared< MockProperty< string > >(lastSelectedService),
                boost::make_shared< MockProperty< int32_t > >(platformMaxStreams),
                boost::make_shared< MockProperty< int32_t > >(ispMaxStreams),
                boost::make_shared< MockProperty< int32_t > >(oemMaxStreams)
             };
        return config;
    }

    void test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter()
    {
        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockDTTMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt1.mediaSourceURI, _))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(dtt1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIP_whenUninitialised_configuresAndStartsIPMediaRouter()
    {
        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(sub1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.sasURL ) ));

        EXPECT_CALL(*mockIPMediaRouter, recycle())
            .WillOnce( returnNewCompletedFuture() );
        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToDTT_whenUninitialised_withDTTServiceInRestrictedSet_configuresAndStartsDTTMediaRouter()
    {
        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createNonEmptyRestrictedServiceSet(dtt1.serviceLocator) ) ));

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockDTTMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt1.mediaSourceURI, _))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(dtt1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToDTT_whenUninitialised_withDTTServiceNotInRestrictedSet_returnsServiceRestrictedExceptionWithFirstAvailableService()
    {
        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createNonEmptyRestrictedServiceSet("") ) ));

        bool gotException = false;
        try
        {
            tunerControl->setTargetService(dtt1.serviceLocator, TuningReason::user_initiated).get();
        }
        catch (const ServiceRestrictedException& e)
        {
            gotException = true;
        }
        CPPUNIT_ASSERT(gotException);
    }

    void test_tuneToDTT_whenUninitialised_getSourceInformationFails_returnsExceptionalFuture()
    {
        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( exceptionalFuture< map< string, string > >(std::runtime_error("Failed")) ) );

        CPPUNIT_ASSERT(tunerControl->setTargetService(dtt1.serviceLocator, TuningReason::user_initiated).getFutureValue().getError());

    }

    void test_tuneToDTT_whenTunedToDTT_onlyCallsSetSourceOnDTTMediaRouter()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt2.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( Return( completedFuture( dtt2.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt2.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(dtt2.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIP_whenTunedToDTT_stopsDTTMediaRouter()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(sub1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));

        EXPECT_CALL(*mockIPMediaRouter, recycle()) // This is not strictly required but causes no harm
            .WillOnce( Return( completedFuture() ));

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.sasURL ) ));

        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIP_whenAlreadyTunedToIP_recyclesIPMediaRouter()
    {
        test_tuneToIP_whenUninitialised_configuresAndStartsIPMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(sub2.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub2.serviceLocator))
            .WillOnce( Return( completedFuture( sub2.service ) ));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub2.serviceLocator))
            .WillOnce( Return( completedFuture( sub2.sasURL ) ));

        EXPECT_CALL(*mockIPMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, recycle())
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub2.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub2.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToDTT_whenTunedToIP_stopsIPMediaRouter()
    {
        test_tuneToIP_whenUninitialised_configuresAndStartsIPMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockIPMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockDTTMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(dtt1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_attemptToTuneToIPService_whenTunedToDTT_serviceNotFound_doesNotInitiateTuningAndReturnsExceptionalFuture()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService("doesNotExist"))
            .WillOnce( Return( exceptionalFuture< UnifiedService >( ServiceNotFoundException("") ) ));

        CPPUNIT_ASSERT_THROW(tunerControl->setTargetService("doesNotExist", TuningReason::user_initiated).get(), ServiceNotFoundException);
    }

    void test_tuneToDTTService_whenPreviousRequestFailed_callsSetSourceOnDTTMediaRouter()
    {
        test_attemptToTuneToIPService_whenTunedToDTT_serviceNotFound_doesNotInitiateTuningAndReturnsExceptionalFuture();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt2.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( Return( completedFuture( dtt2.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt2.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(dtt2.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToHiddenService_returns_exceptionalFutureWithServiceHiddenException()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createNonEmptyHiddenServiceList(sub1.serviceLocator)));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));

        // No expected Tuner control status changes
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(_)).Times(0);

        CPPUNIT_ASSERT_THROW(
            tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get(),
            ServiceHiddenException);
    }

    void test_tuneToService_and_gotExceptionRetrievingUnifiedService_returns_exceptionalFuture()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce(returnNewExceptionalFuture(std::runtime_error("")));

        // No expected Tuner control status changes
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(_)).Times(0);

        //tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT_THROW(
            tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get(),
            std::runtime_error);
    }

    void test_tuneToService_and_gotExceptionRetrievingHiddenServices_returns_exceptionalFuture()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewExceptionalFuture(std::runtime_error("")));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));

        // No expected Tuner control status changes
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(_)).Times(0);

        //tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT_THROW(
            tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get(),
            std::runtime_error);
    }

    void test_tuneToService_and_gotExceptionsRetrievingUnifiedServiceAndHiddenServices_returns_exceptionalFuture()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewExceptionalFuture(std::runtime_error("")));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce(returnNewExceptionalFuture(std::runtime_error("")));

        // No expected Tuner control status changes
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(_)).Times(0);

        //tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT_THROW(
            tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get(),
            std::runtime_error);
    }

    void test_tuneToIPService_whenTunedToDTT_noIPConnectivity_stopsDTTMediaRouterAndSignalsTunedWithNetworkError()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        mockIPNetwork->emitNetworkStatusChange(IPNetwork::DISCONNECTED);

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuning(
            sub1.service, TuningReason::user_initiated,
            TuningErrorType::network_error, "", tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture(sub1.service) ) );

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIPService_whenTunedToDTT_getSASURLFailsWithServiceNotProvisioned_stopsDTTMediaRouterAndSignalsTunedWithProvisioningInformationError()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuning(
            sub1.service, TuningReason::user_initiated,
            TuningErrorType::not_provisioned_error, "", tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture(sub1.service) ) );
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( exceptionalFuture< string >(
                ProvisioningInformationRetrievalFailedException(
                    ProvisioningInformationRetrievalFailureReason::not_provisioned) ) ));

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIPService_whenTunedToDTT_getSASURLFailsWithServerDenied_stopsDTTMediaRouterAndSignalsTunedWithProvisioningInformationError()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuning(
            sub1.service, TuningReason::user_initiated,
            TuningErrorType::provisioning_information_retrieval_error,
            "provisioning_information.server_denied",
            tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture(sub1.service) ) );
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( exceptionalFuture< string >(
                ProvisioningInformationRetrievalFailedException(
                    ProvisioningInformationRetrievalFailureReason::server_denied) ) ));

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIPService_whenTunedToDTT_stopFails_signalsTunedWithUnknownError()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuning(
            sub1.service, TuningReason::user_initiated,
            TuningErrorType::unknown_error, "MR error", tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.sasURL ) ));

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( exceptionalFuture< void >(std::runtime_error("MR error")) ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIPService_whenTunedToDTT_startFails_signalsTunedWithUnknownError()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuning(
            sub1.service, TuningReason::user_initiated,
            TuningErrorType::unknown_error, "MR error", tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.sasURL ) ));

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, recycle())
            .WillOnce( Return( completedFuture() ));

        // Any of the following call failing would cause the signal StatusChange with unknown_error
        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( exceptionalFuture< void >(std::runtime_error("MR error")) ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToDTTService_whenTunedToUnprovisionedIP_startsDTTMediaRouter()
    {
        test_tuneToIPService_whenTunedToDTT_getSASURLFailsWithServiceNotProvisioned_stopsDTTMediaRouterAndSignalsTunedWithProvisioningInformationError();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt2.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( Return( completedFuture( dtt2.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt2.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(dtt2.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIPTwice_whenTuningToIP_respectsTuningOrder()
    {
        AtomicBool sub1TunedStatusReceived, sub2TunedStatusReceived, sub3TunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(sub1.service,
                TuningReason::user_initiated, sub1TunedStatusReceived);
        setupSignalsExpectationsForTuningSuccessful(sub2.service,
                TuningReason::user_initiated, sub2TunedStatusReceived);
        setupSignalsExpectationsForTuningSuccessful(sub3.service,
                TuningReason::user_initiated, sub3TunedStatusReceived);

        // Setup all the non-service specific calls
        EXPECT_CALL(*mockIPMediaRouter, stop())
            .Times(2).WillRepeatedly( returnNewCompletedFuture() );
        EXPECT_CALL(*mockIPMediaRouter, recycle())
            .Times(3).WillRepeatedly( returnNewCompletedFuture() );
        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .Times(3).WillRepeatedly( returnNewCompletedFuture() );
        EXPECT_CALL(*mockIPMediaRouter, start())
            .Times(3).WillRepeatedly( returnNewCompletedFuture() );

        // Tuning requests
        EXPECT_CALL(*mockHiddenServicesStore, get())
            .Times(3).WillRepeatedly(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub2.serviceLocator))
            .WillOnce( Return( completedFuture( sub2.service ) ));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub3.serviceLocator))
            .WillOnce( Return( completedFuture( sub3.service ) ));

        // Tuning to sub1
        Promise< string > delayedSASURL;
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( delayedSASURL.getFuture() ));
        Expectation e1 =
            EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
                .WillOnce( Return( completedFuture() ));

        // Tuning to sub2
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub2.serviceLocator))
            .After(e1).WillOnce( Return( completedFuture( sub2.sasURL ) ));
        Expectation e2 =
            EXPECT_CALL(*mockIPMediaRouter, setSource(sub2.mediaSourceURI, SetSourceReason::unspecified))
                .WillOnce( Return( completedFuture() ) );

        // Tuning to sub3
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub3.serviceLocator))
            .After(e2).WillOnce( Return( completedFuture( sub3.sasURL ) ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub3.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ) );

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        tunerControl->setTargetService(sub2.serviceLocator, TuningReason::user_initiated).get();
        tunerControl->setTargetService(sub3.serviceLocator, TuningReason::user_initiated).get();

        // We are here once all the tuning requests have either been queued/started

        delayedSASURL.complete( sub1.sasURL );

        // Could check StatusChanges arrived in expected order instead of using .After above
        CPPUNIT_ASSERT(sub1TunedStatusReceived.waitUntilEqual(true, 5000));
        CPPUNIT_ASSERT(sub2TunedStatusReceived.waitUntilEqual(true, 5000));
        CPPUNIT_ASSERT(sub3TunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToDTT_whenDeactivatingFromDTT_waitsForDeactivatedStatusChangeAndRestartsMR()
    {
        // Make sure 2nd tune is called during Deactivating and not Deactivated
        Promise< void > delayedStop;
        AtomicBool deactivatedStatusReceived;
        deactivate_whenTunedToDTT_andBlockOnDeactivating(delayedStop.getFuture(), deactivatedStatusReceived);

        // Tune to DTT while deactivating
        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt2.service,
                TuningReason::user_initiated, tunedStatusReceived);
        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( Return( completedFuture( dtt2.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        tunerControl->setTargetService(dtt2.serviceLocator, TuningReason::user_initiated).get();

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( Return( completedFuture(string(DEFAULT_MEDIA_ROUTER_SINK)) ) );
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt2.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        delayedStop.complete();

        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToDTT_whenDeactivated_startsFailsWithPlayConflictError_signalsTunedWithPlayConflictError()
    {
        test_deactivate_whenTunedToDTT_callsMediaRouterStop();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuning(
            dtt2.service, TuningReason::user_initiated,
            TuningErrorType::play_conflict_error, "Play Conflict Error", tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( Return( completedFuture( dtt2.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( Return( completedFuture(string(DEFAULT_MEDIA_ROUTER_SINK)) ) );
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt2.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( exceptionalFuture< void >(NS_NICKEL_SYSTEM::PlayConflictException()) ));

        tunerControl->setTargetService(dtt2.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIP_whenDeactivated_startsFailsWithPlayConflictError_signalsTunedWithPlayConflictError()
    {
        test_deactivate_whenTunedToDTT_callsMediaRouterStop();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuning(
            sub1.service, TuningReason::user_initiated,
            TuningErrorType::play_conflict_error, "Play Conflict Error", tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.sasURL ) ));

        EXPECT_CALL(*mockIPMediaRouter, recycle())
            .WillOnce( Return( completedFuture() ));

        // Any of the following call failing would cause the signal StatusChange with unknown_error
        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( exceptionalFuture< void >(NS_NICKEL_SYSTEM::PlayConflictException()) ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToDTT_whenDeactivated_configuresAndStartsDTTMediaRouter()
    {
        test_deactivate_whenTunedToDTT_callsMediaRouterStop();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt2.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( Return( completedFuture( dtt2.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( Return( completedFuture(string(DEFAULT_MEDIA_ROUTER_SINK)) ) );
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt2.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(dtt2.serviceLocator, TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_deactivate_whenUninitialised_returnsExceptionalFuture()
    {
        CPPUNIT_ASSERT(tunerControl->deactivate(TuningReason::user_initiated).getFutureValue().getError());
    }

    void test_deactivate_whenTuningToIP_waitsForTunedStatusChangeAndCallsMediaRouterStop()
    {
        // Expectations for Tuning/Tuned signals received
        AtomicBool tunedStatusReceived;
        Expectation tunedStatusReceivedExpectation =
            setupSignalsExpectationsForTuningSuccessful(sub1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        // Expectation for Deactivating signal received
        AtomicBool deactivatedStatusReceived;
        UnifiedService service = sub1.service;
        TunerControlStatus expectedTuningStatus(TunerControlState::deactivating,
                                                service,
                                                TuningReason::user_initiated,
                                                TuningErrorType::no_error, // Never any error when Deactivating
                                                "");
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedTuningStatus))
            .Times(1).After(tunedStatusReceivedExpectation);

        // Expectation for Deactivated signal received
        TunerControlStatus expectedTunedStatus(TunerControlState::deactivated,
                                               service,
                                               TuningReason::user_initiated,
                                               TuningErrorType::no_error, // Never any error when Deactivated
                                               "");
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedTunedStatus))
            .WillOnce(Assign(&deactivatedStatusReceived, true));


        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));

        // Make sure deactivate is called during Tuning and not Tuned
        Promise< string > delayedSASURL;
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( delayedSASURL.getFuture() ));

        EXPECT_CALL(*mockIPMediaRouter, recycle())
            .WillOnce( Return( completedFuture() ) );
        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( Return( completedFuture(string("")) ) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::user_initiated).get();

        // Call deactivate when the Tuning is in progress (this is ensured thanks to delayedSASURL)
        tunerControl->deactivate(TuningReason::user_initiated).get();

        EXPECT_CALL(*mockIPMediaRouter, stop())
            .WillOnce( Return( completedFuture() ) );
        delayedSASURL.complete( sub1.sasURL );

        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_deactivate_whenTunedToDTT_callsMediaRouterStop()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool deactivatedStatusReceived;
        setupSignalsExpectationsForDeactivation(dtt1.service,
                TuningReason::user_initiated, deactivatedStatusReceived);

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ) );
        tunerControl->deactivate(TuningReason::user_initiated).get();

        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_deactivate_whenDeactivating_returnsExceptionalFuture()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool deactivatedStatusReceived;
        setupSignalsExpectationsForDeactivation(dtt1.service,
                TuningReason::user_initiated, deactivatedStatusReceived);

        // Make sure 2nd deactivate is called during Deactivating and not Deactivated
        Promise< void > delayedStop;
        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( delayedStop.getFuture() ) );
        tunerControl->deactivate(TuningReason::user_initiated).get();

        CPPUNIT_ASSERT(tunerControl->deactivate(TuningReason::user_initiated).getFutureValue().getError());
        delayedStop.complete();

        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_deactivate_whenDeactivated_returnsExceptionalFuture()
    {
        test_deactivate_whenTunedToDTT_callsMediaRouterStop();
        CPPUNIT_ASSERT(tunerControl->deactivate(TuningReason::user_initiated).getFutureValue().getError());
    }

    void test_deactivate_whenTunedToDTT_stopFails_signalsDeactivated()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool deactivatedStatusReceived;
        setupSignalsExpectationsForDeactivation(dtt1.service,
                TuningReason::user_initiated, deactivatedStatusReceived);

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( exceptionalFuture< void >( std::runtime_error("MR error") ) ) );
        tunerControl->deactivate(TuningReason::user_initiated).get();

        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_activate_whenUninitialised_noLastSelectedService_returnsExceptionalFuture()
    {
        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(""))
            .WillOnce( Return( exceptionalFuture< UnifiedService >( ServiceNotFoundException("") ) ));

        CPPUNIT_ASSERT_THROW(tunerControl->activate(TuningReason::user_initiated).get(), ServiceNotFoundException);
    }

    void test_activate_whenUninitialised_validLastSelectedService_tunesToLastSelectedService()
    {
        mockLastSelectedServiceProperty->change(dtt1.serviceLocator);

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockDTTMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->activate(TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_activate_whenUninitialised_invalidLastSelectedService_returnsExceptionalFuture()
    {
        mockLastSelectedServiceProperty->change("doesNotExist");

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService("doesNotExist"))
            .WillOnce( Return( exceptionalFuture< UnifiedService >( ServiceNotFoundException("") ) ));

        CPPUNIT_ASSERT_THROW(tunerControl->activate(TuningReason::user_initiated).get(), ServiceNotFoundException);
    }

    void test_activate_whenTuningToIP_returnsExceptionalFuture()
    {
        // Make sure getTargetService is called during Tuning and not Tuned
        Promise< string > promiseBlockingTuningTransition;
        AtomicBool tunedStatusReceived;
        blockOnTuning_whenTuningToIP(promiseBlockingTuningTransition.getFuture(), tunedStatusReceived);

        CPPUNIT_ASSERT(tunerControl->activate(TuningReason::user_initiated).getFutureValue().getError());

        promiseBlockingTuningTransition.complete(sub1.sasURL);
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_activate_whenTunedToDTT_returnsExceptionalFuture()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        CPPUNIT_ASSERT(tunerControl->activate(TuningReason::user_initiated).getFutureValue().getError());
    }

    void test_activate_whenDeactivating_waitsForDeactivatedStatusChangeAndReactivates()
    {
        // Make sure 2nd tune is called during Deactivating and not Deactivated
        Promise< void > delayedStop;
        AtomicBool deactivatedStatusReceived;
        deactivate_whenTunedToDTT_andBlockOnDeactivating(delayedStop.getFuture(), deactivatedStatusReceived);

        // Re-activate while deactivating
        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt1.service,
                TuningReason::user_initiated, tunedStatusReceived);
        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        tunerControl->activate(TuningReason::user_initiated).get();

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( Return( completedFuture(string(DEFAULT_MEDIA_ROUTER_SINK)) ) );
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        delayedStop.complete();

        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_activate_whenDeactivated_reactivates()
    {
        test_deactivate_whenTunedToDTT_callsMediaRouterStop();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt1.service,
                TuningReason::user_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( Return( completedFuture(string(DEFAULT_MEDIA_ROUTER_SINK)) ) );
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->activate(TuningReason::user_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_getTargetService_whenUninitialised_returnsExceptionalFuture()
    {
        CPPUNIT_ASSERT(tunerControl->getTargetService().getFutureValue().getError());
    }

    void test_getTargetService_whenTuningToIP_returnsCorrectService()
    {
        // Make sure getTargetService is called during Tuning and not Tuned
        Promise< string > promiseBlockingTuningTransition;
        AtomicBool tunedStatusReceived;
        blockOnTuning_whenTuningToIP(promiseBlockingTuningTransition.getFuture(), tunedStatusReceived);

        CPPUNIT_ASSERT_EQUAL(sub1.serviceLocator, tunerControl->getTargetService().get());
        promiseBlockingTuningTransition.complete(sub1.sasURL);
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_getTargetService_whenTuned_returnsCorrectService()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        CPPUNIT_ASSERT_EQUAL(dtt1.serviceLocator, tunerControl->getTargetService().get());
    }

    void test_getTargetService_whenDeactivatingFromDTT_returnsCorrectService()
    {
        // Make sure getTargetService is called during Deactivating and not Deactivated
        Promise< void > delayedStop;
        AtomicBool deactivatedStatusReceived;
        deactivate_whenTunedToDTT_andBlockOnDeactivating(delayedStop.getFuture(), deactivatedStatusReceived);

        CPPUNIT_ASSERT_EQUAL(dtt1.serviceLocator, tunerControl->getTargetService().get());
        delayedStop.complete();
        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_getTargetService_whenDeactivated_returnsCorrectService()
    {
        test_deactivate_whenTunedToDTT_callsMediaRouterStop();

        CPPUNIT_ASSERT_EQUAL(dtt1.serviceLocator, tunerControl->getTargetService().get());
    }

    void test_getStatus_whenUninitialised_returnsUninitialisedStatus()
    {
        CPPUNIT_ASSERT_EQUAL(TunerControlState::uninitialised, tunerControl->getStatus().get().state);
    }

    void test_getStatus_whenTuningToIP_returnsTuningStatus()
    {
         // Make sure getStatus is called during Tuning and not Tuned
        Promise< string > promiseBlockingTuningTransition;
        AtomicBool tunedStatusReceived;
        blockOnTuning_whenTuningToIP(promiseBlockingTuningTransition.getFuture(), tunedStatusReceived);

        TunerControlStatus tunedStatusExpected(TunerControlState::tuning, sub1.service,
                                               TuningReason::user_initiated, TuningErrorType::no_error, "");
        CPPUNIT_ASSERT(tunedStatusExpected == tunerControl->getStatus().get());

        promiseBlockingTuningTransition.complete(sub1.sasURL);
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_getStatus_whenTuned_returnsTunedStatus()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        TunerControlStatus tunedStatusExpected(TunerControlState::tuned, dtt1.service,
                                               TuningReason::user_initiated, TuningErrorType::no_error, "");
        CPPUNIT_ASSERT(tunedStatusExpected == tunerControl->getStatus().get());
    }

    void test_getStatus_whenDeactivating_returnsDeactivatingStatus()
    {
        // Make sure getStatus is called during Deactivating and not Deactivated
        Promise< void > delayedStop;
        AtomicBool deactivatedStatusReceived;
        deactivate_whenTunedToDTT_andBlockOnDeactivating(delayedStop.getFuture(), deactivatedStatusReceived);

        TunerControlStatus tunedStatusExpected(TunerControlState::deactivating, dtt1.service,
                                               TuningReason::user_initiated, TuningErrorType::no_error, "");
        CPPUNIT_ASSERT(tunedStatusExpected == tunerControl->getStatus().get());

        delayedStop.complete();
        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_getStatus_whenDeactivated_returnsDeactivatedStatus()
    {
        test_deactivate_whenTunedToDTT_callsMediaRouterStop();

        TunerControlStatus tunedStatusExpected(TunerControlState::deactivated, dtt1.service,
                                               TuningReason::user_initiated, TuningErrorType::no_error, "");
        CPPUNIT_ASSERT(tunedStatusExpected == tunerControl->getStatus().get());
    }

    void forceTuneWhenTunedToDTTImpl(SetSourceReason::Enum sourceReason, TuningReason::Enum expectedReason)
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tuningStatusReceived;
        TunerControlStatus expectedTuningStatus(TunerControlState::tuning,
                                                dtt2.service,
                                                TuningReason::unspecified,
                                                TuningErrorType::no_error,
                                                "");

        AtomicBool tunedStatusReceived;
        TunerControlStatus expectedTunedStatus(TunerControlState::tuned,
                                               dtt2.service,
                                               expectedReason,
                                               TuningErrorType::no_error,
                                               "");

        // TunerControl ignores SourceEvent signal with change_initiated reason.
        // We cannot rely that MediaRouter will return the service locator for
        // the new source before the channel change has completed.
        // see YVHUAWEI-5562
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(_)).Times(0);

        mockDTTMediaRouter->emitSourceEvent(SourceEventValue::change_initiated, sourceReason);

        EXPECT_CALL(*mockDTTMediaRouter, getSource())
            .WillOnce( Return( completedFuture( dtt2.serviceLocator ) ));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( Return( completedFuture( dtt2.service ) ));

        // There will be 2 TunerControl status changes. We can rely in the info
        // provided by MediaRouter.getSource() to detect a forced channel change
        // when it has been completed.
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedTuningStatus))
            .WillOnce(Assign(&tuningStatusReceived, true));
        EXPECT_CALL(*mockTunerControlEventListener, StatusChange(expectedTunedStatus))
            .WillOnce(Assign(&tunedStatusReceived, true));

        mockDTTMediaRouter->emitSourceEvent(SourceEventValue::change_complete, sourceReason);

        CPPUNIT_ASSERT(tuningStatusReceived.waitUntilEqual(true, 5000));
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_forcedTuneFromMHEG_whenTunedToDTT_signalsTargetServiceChanged()
    {
        forceTuneWhenTunedToDTTImpl(SetSourceReason::mhegstandard, TuningReason::mheg_initiated);
    }

    void test_forcedTuneFromDTTTunerExhaustion_whenTunedToDTT_signalsTargetServiceChanged()
    {
        forceTuneWhenTunedToDTTImpl(SetSourceReason::unspecified, TuningReason::forced_on_dtt_exhaustion);
    }

    void test_forcedTune_whenNotTuned_hasNoEffect()
    {
        // A forced tune should only happen when tuned to DTT.
        // When uninitialised/tuning/deactivating/deactivated, this signal is ignored.

        AtomicBool getServiceCalled;
        EXPECT_CALL(*mockDTTMediaRouter, getSource())
            .WillOnce( Return( completedFuture( dtt2.serviceLocator ) ));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt2.serviceLocator))
            .WillOnce( DoAll( Assign(&getServiceCalled, true), Return( completedFuture( dtt2.service ) ) ) );
        mockDTTMediaRouter->emitSourceEvent(SourceEventValue::change_complete, SetSourceReason::unspecified);

        // Sleep until all expectations are met (does not ensure that Continuation is over, but it is ok)
        CPPUNIT_ASSERT(getServiceCalled.waitUntilEqual(true, 5000));
    }

    void test_forcedTune_getSourceFails_hasNoEffect()
    {
        AtomicBool getSourceCalled;
        EXPECT_CALL(*mockDTTMediaRouter, getSource())
            .WillOnce( DoAll(
                Assign(&getSourceCalled, true),
                Return( exceptionalFuture<string>( std::runtime_error("getSource failed") ) )
                ) );
        mockDTTMediaRouter->emitSourceEvent(SourceEventValue::change_complete, SetSourceReason::unspecified);

        // Sleep until all expectations are met (does not ensure that Continuation is over, but it is ok)
        CPPUNIT_ASSERT(getSourceCalled.waitUntilEqual(true, 5000));
    }

    void test_ActivateAndDeactivateInitiatedByCRB_Returns_TunerControlStatusWithValidTuningReason()
    {
        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(dtt1.service,
                TuningReason::crb_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(dtt1.serviceLocator))
            .WillOnce( Return( completedFuture( dtt1.service ) ));
        EXPECT_CALL(*mockDTTMediaRouter, getSourceInformation())
            .WillOnce( Return( completedFuture( createEmptyRestrictedServiceSet() ) ));

        EXPECT_CALL(*mockDTTMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockDTTMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, setSource(dtt1.mediaSourceURI, _))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockDTTMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        // CRB / video-broadcast tag call activate() instead of setTargetService
        // but in order to simplify the test, setTargetService() is used
        // Note activate() is implemented in terms of setTargetService()
        tunerControl->setTargetService(dtt1.serviceLocator, TuningReason::crb_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));

        AtomicBool deactivatedStatusReceived;
        setupSignalsExpectationsForDeactivation(dtt1.service,
                TuningReason::crb_initiated, deactivatedStatusReceived);

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ) );
        tunerControl->deactivate(TuningReason::crb_initiated).get();

        CPPUNIT_ASSERT(deactivatedStatusReceived.waitUntilEqual(true, 5000));
    }

    void tuneToIP_whenTunedToDTT_InitiatedByVideoBroadcast_Returns_TunerControlStatusWithValidTuningReason()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        AtomicBool tunedStatusReceived;
        setupSignalsExpectationsForTuningSuccessful(sub1.service,
                TuningReason::video_broadcast_initiated, tunedStatusReceived);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.service ) ));
        ON_CALL(*mockLinearAcquisition, getScheduledRecordings())
            .WillByDefault(returnNewCompletedFuture(std::vector<ScheduledRecording>()));
        ON_CALL(*mockUnifiedEventRepository, getEvent(_))
            .WillByDefault(returnNewCompletedFuture(UnifiedEvent()));
        EXPECT_CALL(*mockProvisioningService, getSASURLForServiceLivePlayback(sub1.serviceLocator))
            .WillOnce( Return( completedFuture( sub1.sasURL ) ));

        EXPECT_CALL(*mockDTTMediaRouter, stop())
            .WillOnce( Return( completedFuture() ));

        EXPECT_CALL(*mockIPMediaRouter, recycle()) // This is not strictly required but causes no harm
            .WillOnce( Return( completedFuture() ));

        EXPECT_CALL(*mockIPMediaRouter, getSink())
            .WillOnce( returnNewCompletedFuture(string("")) )
            .WillRepeatedly( returnNewCompletedFuture(DEFAULT_MEDIA_ROUTER_SINK) );
        EXPECT_CALL(*mockIPMediaRouter, setSink(DEFAULT_MEDIA_ROUTER_SINK))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setCaptureMode(TimeShiftCaptureMode::enabled))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, setSource(sub1.mediaSourceURI, SetSourceReason::unspecified))
            .WillOnce( Return( completedFuture() ));
        EXPECT_CALL(*mockIPMediaRouter, start())
            .WillOnce( Return( completedFuture() ));

        tunerControl->setTargetService(sub1.serviceLocator, TuningReason::video_broadcast_initiated).get();
        CPPUNIT_ASSERT(tunedStatusReceived.waitUntilEqual(true, 5000));
    }

    void test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreNoRecordings_Returns_TunerControlStatusWithValidTuningReason()
    {
        EXPECT_CALL(*mockLinearAcquisition, getScheduledRecordings())
            .WillOnce(returnNewCompletedFuture(std::vector<ScheduledRecording>()));
        EXPECT_CALL(*mockUnifiedEventRepository, getEvent(_)).Times(0);

        tuneToIP_whenTunedToDTT_InitiatedByVideoBroadcast_Returns_TunerControlStatusWithValidTuningReason();
    }

    void test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereIsOneRecordingInProgress_And_TargetServiceIsNotRecording_Returns_TunerControlStatusWithValidTuningReason()
    {
        std::vector<UnifiedEvent> unifiedEvents = boost::assign::list_of(ue2);
        // Add ue2 to scheduled recordings with in_progress status
        std::vector<ScheduledRecording> recordings =
            createScheduledRecordingsFromEvents(unifiedEvents, ScheduledRecordingStatus::in_progress);

        EXPECT_CALL(*mockLinearAcquisition, getScheduledRecordings())
            .WillOnce(returnNewCompletedFuture(recordings));
        BOOST_FOREACH(const UnifiedEvent& ue, unifiedEvents)
        {
            EXPECT_CALL(*mockUnifiedEventRepository, getEvent(ue.data.eventLocator))
                .WillOnce( returnNewCompletedFuture( ue ) );
        }

        // Tune sub1 service
        tuneToIP_whenTunedToDTT_InitiatedByVideoBroadcast_Returns_TunerControlStatusWithValidTuningReason();
    }

    void test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreTwoRecordingInProgress_And_TargetServiceIsRecording_Returns_TunerControlStatusWithValidTuningReason()
    {
        std::vector<UnifiedEvent> unifiedEvents = boost::assign::list_of(ue1)(ue2);
        // Add ue2 to scheduled recordings with in_progress status
        std::vector<ScheduledRecording> recordings =
            createScheduledRecordingsFromEvents(unifiedEvents, ScheduledRecordingStatus::in_progress);

        EXPECT_CALL(*mockLinearAcquisition, getScheduledRecordings())
            .WillOnce(returnNewCompletedFuture(recordings));
        BOOST_FOREACH(const UnifiedEvent& ue, unifiedEvents)
        {
            EXPECT_CALL(*mockUnifiedEventRepository, getEvent(ue.data.eventLocator))
                .WillOnce( returnNewCompletedFuture( ue ) );
        }

        // Tune sub1 service
        tuneToIP_whenTunedToDTT_InitiatedByVideoBroadcast_Returns_TunerControlStatusWithValidTuningReason();
    }

    void test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreTwoRecordingInProgress_And_TargetServiceIsNotRecording_Returns_ExceptionalFuture()
    {
        test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter();

        std::vector<UnifiedEvent> unifiedEvents = boost::assign::list_of(ue1)(ue2);
        std::vector<ScheduledRecording> recordings =
            createScheduledRecordingsFromEvents(unifiedEvents, ScheduledRecordingStatus::in_progress);

        EXPECT_CALL(*mockHiddenServicesStore, get())
            .WillOnce(returnNewCompletedFuture(createEmptyHiddenServiceList()));
        EXPECT_CALL(*mockUnifiedServiceRepository, getService(sub3.serviceLocator))
            .WillOnce( Return( completedFuture( sub3.service ) ));
        EXPECT_CALL(*mockLinearAcquisition, getScheduledRecordings())
            .WillOnce(returnNewCompletedFuture(recordings));
        BOOST_FOREACH(const UnifiedEvent& ue, unifiedEvents)
        {
            EXPECT_CALL(*mockUnifiedEventRepository, getEvent(ue.data.eventLocator))
                .WillOnce( returnNewCompletedFuture( ue ) );
        }

        CPPUNIT_ASSERT_THROW(tunerControl->setTargetService(sub3.serviceLocator, TuningReason::video_broadcast_initiated).get(),
                ServiceRestrictedException);
    }

    void test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreTwoRecordingInProgress_And_TargetServiceIsRecording_AndThereAreDuplicatedRecordings_Returns_TunerControlStatusWithValidTuningReason()
    {
        std::vector<UnifiedEvent> unifiedEvents = boost::assign::list_of(ue1)(ue2);
        // Add ue1 and ue2 to scheduled recordings with in_progress status
        std::vector<ScheduledRecording> recordings =
            createScheduledRecordingsFromEvents(unifiedEvents, ScheduledRecordingStatus::in_progress);

        // Add duplicated scheduled recording
        addScheduledRecordingFromEvent(ue1, ScheduledRecordingStatus::in_progress_in_series, recordings);

        EXPECT_CALL(*mockLinearAcquisition, getScheduledRecordings())
            .WillOnce(returnNewCompletedFuture(recordings));
        // Only one getEvent() call is expected per event locator even if
        // it is duplicated in scheduled recordings
        BOOST_FOREACH(const UnifiedEvent& ue, unifiedEvents)
        {
            EXPECT_CALL(*mockUnifiedEventRepository, getEvent(ue.data.eventLocator))
                .WillOnce( returnNewCompletedFuture( ue ) );
        }

        // Tune sub1 service
        tuneToIP_whenTunedToDTT_InitiatedByVideoBroadcast_Returns_TunerControlStatusWithValidTuningReason();
    }

    void test_TunerControlConfigGetIPTunersCount_returnsValueFromPlatformKey()
    {
        TunerControlConfig config = createTunerControlConfig("", 1, 2, 3);
        CPPUNIT_ASSERT(config.getIPTunersCount() == 1);
    }

    void test_TunerControlConfigGetIPTunersCount_WhenPlatformKeyIsNotValid_returnsValueFromISPKey()
    {
        TunerControlConfig config = createTunerControlConfig("", -1, 2, 3);
        CPPUNIT_ASSERT(config.getIPTunersCount() == 2);
    }

    void test_TunerControlConfigGetIPTunersCount_WhenPlatformAndISPKeysAreNotValid_returnsValueFromOEMKey()
    {
        TunerControlConfig config = createTunerControlConfig("", -1, -1, 3);
        CPPUNIT_ASSERT(config.getIPTunersCount() == 3);
    }

    void test_TunerControlConfigGetIPTunersCount_WhenPlatformAndISPAndOEMKeysAreNotValid_returnsDefaultValue()
    {
        TunerControlConfig config = createTunerControlConfig("", -1, -1, -1);
        CPPUNIT_ASSERT(config.getIPTunersCount() == DEFAULT_IP_TUNERS_COUNT);
    }

    CPPUNIT_TEST_SUITE(TunerControlTest);

    // Uninitialised -> Tuning to DTT / IP
    CPPUNIT_TEST(test_tuneToDTT_whenUninitialised_configuresAndStartsDTTMediaRouter);
    CPPUNIT_TEST(test_tuneToIP_whenUninitialised_configuresAndStartsIPMediaRouter);
    CPPUNIT_TEST(test_tuneToDTT_whenUninitialised_withDTTServiceInRestrictedSet_configuresAndStartsDTTMediaRouter);
    CPPUNIT_TEST(test_tuneToDTT_whenUninitialised_withDTTServiceNotInRestrictedSet_returnsServiceRestrictedExceptionWithFirstAvailableService);
    CPPUNIT_TEST(test_tuneToDTT_whenUninitialised_getSourceInformationFails_returnsExceptionalFuture);

    // Tuned to DTT / IP -> Tuning to DTT / IP
    CPPUNIT_TEST(test_tuneToDTT_whenTunedToDTT_onlyCallsSetSourceOnDTTMediaRouter);
    CPPUNIT_TEST(test_tuneToIP_whenTunedToDTT_stopsDTTMediaRouter);
    CPPUNIT_TEST(test_tuneToIP_whenAlreadyTunedToIP_recyclesIPMediaRouter);
    CPPUNIT_TEST(test_tuneToDTT_whenTunedToIP_stopsIPMediaRouter);

    // Tuned to DTT - Invalid tuning requests when tuning from DTT to IP
    CPPUNIT_TEST(test_attemptToTuneToIPService_whenTunedToDTT_serviceNotFound_doesNotInitiateTuningAndReturnsExceptionalFuture);
    CPPUNIT_TEST(test_tuneToDTTService_whenPreviousRequestFailed_callsSetSourceOnDTTMediaRouter);

    // Tuning requests returning error
    CPPUNIT_TEST(test_tuneToHiddenService_returns_exceptionalFutureWithServiceHiddenException);
    CPPUNIT_TEST(test_tuneToService_and_gotExceptionRetrievingUnifiedService_returns_exceptionalFuture);
    CPPUNIT_TEST(test_tuneToService_and_gotExceptionRetrievingHiddenServices_returns_exceptionalFuture);
    CPPUNIT_TEST(test_tuneToService_and_gotExceptionsRetrievingUnifiedServiceAndHiddenServices_returns_exceptionalFuture);

    // Tuned to DTT -> Tuned with error
    CPPUNIT_TEST(test_tuneToIPService_whenTunedToDTT_noIPConnectivity_stopsDTTMediaRouterAndSignalsTunedWithNetworkError);
    CPPUNIT_TEST(test_tuneToIPService_whenTunedToDTT_getSASURLFailsWithServiceNotProvisioned_stopsDTTMediaRouterAndSignalsTunedWithProvisioningInformationError);
    CPPUNIT_TEST(test_tuneToIPService_whenTunedToDTT_getSASURLFailsWithServerDenied_stopsDTTMediaRouterAndSignalsTunedWithProvisioningInformationError);
    CPPUNIT_TEST(test_tuneToIPService_whenTunedToDTT_stopFails_signalsTunedWithUnknownError);
    CPPUNIT_TEST(test_tuneToIPService_whenTunedToDTT_startFails_signalsTunedWithUnknownError);

    // Tuned to IP with error -> Tuning to DTT works
    CPPUNIT_TEST(test_tuneToDTTService_whenTunedToUnprovisionedIP_startsDTTMediaRouter);

    // Test tuning requests are queued
    CPPUNIT_TEST(test_tuneToIPTwice_whenTuningToIP_respectsTuningOrder);

    // Deactivating from DTT -> Tuned to DTT
    CPPUNIT_TEST(test_tuneToDTT_whenDeactivatingFromDTT_waitsForDeactivatedStatusChangeAndRestartsMR);

    // Deactivated -> Tuned to DTT
    CPPUNIT_TEST(test_tuneToDTT_whenDeactivated_startsFailsWithPlayConflictError_signalsTunedWithPlayConflictError);
    CPPUNIT_TEST(test_tuneToIP_whenDeactivated_startsFailsWithPlayConflictError_signalsTunedWithPlayConflictError);
    CPPUNIT_TEST(test_tuneToDTT_whenDeactivated_configuresAndStartsDTTMediaRouter);

    // Test deactivate
    CPPUNIT_TEST(test_deactivate_whenUninitialised_returnsExceptionalFuture);
    CPPUNIT_TEST(test_deactivate_whenTuningToIP_waitsForTunedStatusChangeAndCallsMediaRouterStop);
    CPPUNIT_TEST(test_deactivate_whenTunedToDTT_callsMediaRouterStop);
    CPPUNIT_TEST(test_deactivate_whenDeactivating_returnsExceptionalFuture);
    CPPUNIT_TEST(test_deactivate_whenDeactivated_returnsExceptionalFuture);
    CPPUNIT_TEST(test_deactivate_whenTunedToDTT_stopFails_signalsDeactivated);

    // Test activate
    CPPUNIT_TEST(test_activate_whenUninitialised_noLastSelectedService_returnsExceptionalFuture);
    CPPUNIT_TEST(test_activate_whenUninitialised_validLastSelectedService_tunesToLastSelectedService);
    CPPUNIT_TEST(test_activate_whenUninitialised_invalidLastSelectedService_returnsExceptionalFuture);
    CPPUNIT_TEST(test_activate_whenTuningToIP_returnsExceptionalFuture);
    CPPUNIT_TEST(test_activate_whenTunedToDTT_returnsExceptionalFuture);
    CPPUNIT_TEST(test_activate_whenDeactivating_waitsForDeactivatedStatusChangeAndReactivates);
    CPPUNIT_TEST(test_activate_whenDeactivated_reactivates);

    // Test getters
    CPPUNIT_TEST(test_getTargetService_whenUninitialised_returnsExceptionalFuture);
    CPPUNIT_TEST(test_getTargetService_whenTuningToIP_returnsCorrectService);
    CPPUNIT_TEST(test_getTargetService_whenTuned_returnsCorrectService);
    CPPUNIT_TEST(test_getTargetService_whenDeactivatingFromDTT_returnsCorrectService);
    CPPUNIT_TEST(test_getTargetService_whenDeactivated_returnsCorrectService);

    CPPUNIT_TEST(test_getStatus_whenUninitialised_returnsUninitialisedStatus);
    CPPUNIT_TEST(test_getStatus_whenTuningToIP_returnsTuningStatus);
    CPPUNIT_TEST(test_getStatus_whenTuned_returnsTunedStatus);
    CPPUNIT_TEST(test_getStatus_whenDeactivating_returnsDeactivatingStatus);
    CPPUNIT_TEST(test_getStatus_whenDeactivated_returnsDeactivatedStatus);

    // Test forced tune due to Tuner Exhaustion / MHEG
    CPPUNIT_TEST(test_forcedTuneFromMHEG_whenTunedToDTT_signalsTargetServiceChanged);
    CPPUNIT_TEST(test_forcedTuneFromDTTTunerExhaustion_whenTunedToDTT_signalsTargetServiceChanged);
    CPPUNIT_TEST(test_forcedTune_whenNotTuned_hasNoEffect);
    CPPUNIT_TEST(test_forcedTune_getSourceFails_hasNoEffect);

    // Test Tuning Reason inTunerControlStatus signal
    CPPUNIT_TEST(test_ActivateAndDeactivateInitiatedByCRB_Returns_TunerControlStatusWithValidTuningReason);

    // Test IP Tuner exhaustion prevention when tuning IP initiated by Video Broadcast
    CPPUNIT_TEST(test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreNoRecordings_Returns_TunerControlStatusWithValidTuningReason);
    CPPUNIT_TEST(test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereIsOneRecordingInProgress_And_TargetServiceIsNotRecording_Returns_TunerControlStatusWithValidTuningReason);
    CPPUNIT_TEST(test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreTwoRecordingInProgress_And_TargetServiceIsRecording_Returns_TunerControlStatusWithValidTuningReason);
    CPPUNIT_TEST(test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreTwoRecordingInProgress_And_TargetServiceIsNotRecording_Returns_ExceptionalFuture);
    CPPUNIT_TEST(test_tuneToIPInitiatedByVideoBroadcast_WhenIPTunersCountIsTwo_And_ThereAreTwoRecordingInProgress_And_TargetServiceIsRecording_AndThereAreDuplicatedRecordings_Returns_TunerControlStatusWithValidTuningReason);

    // Test calculating number of IP tuners availables
    CPPUNIT_TEST(test_TunerControlConfigGetIPTunersCount_returnsValueFromPlatformKey);
    CPPUNIT_TEST(test_TunerControlConfigGetIPTunersCount_WhenPlatformKeyIsNotValid_returnsValueFromISPKey);
    CPPUNIT_TEST(test_TunerControlConfigGetIPTunersCount_WhenPlatformAndISPKeysAreNotValid_returnsValueFromOEMKey);
    CPPUNIT_TEST(test_TunerControlConfigGetIPTunersCount_WhenPlatformAndISPAndOEMKeysAreNotValid_returnsDefaultValue);

    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(TunerControlTest);
