/*
 * Author: kris@youview.com
 *
 * Copyright(C) 2013 YouView TV Ltd
 */

#include <nickelonscreenid-system-api/nickelonscreenid-system-exceptions.h>
#include <nickelonscreenid-system-api/osid-misc.h>
#include <nickelonscreenid-system-api/Renderer.h>
#include <nickelonscreenid-system-api/SystemFactory.h>

#include <zinc-common/FixedPluginConfig.h>
#include <zinc-common/PluginFactory.h>

#include <boost/assign/list_of.hpp>
#include <boost/filesystem/path.hpp>

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <stdexcept>

using namespace Zinc::OnScreenId;

namespace {

void usage(const char *const argv0, std::ostream& out)
{
    const boost::filesystem::path execPath(argv0);
    const std::string exec = execPath.leaf();

    out
        << "Send a command to the OnScreen ID service\n\n"
        << "Usage:\n"
        << "  " << exec << " help\n"
        << "  " << exec << " session create [<file 1>..<file n>]\n"
        << "  " << exec << " session destroy\n"
        << "  " << exec << " trigger [<file 1>..<file n>]\n"
        << "  " << exec << " trigger --empty\n"
        << "  " << exec << " enable\n"
        << "  " << exec << " disable\n"
        << "\nwhere:\n"
        << "  [<file 1>..<file n>] is an optional list of one or more files\n"
        << "                       containing one binary payload each, e.g.\n"
        << "                       SAS extension(`session create`) or ECM\n"
        << "                       Access Criteria Descriptor(`trigger`).\n"
        << "                       If no input files are given only one payload\n"
        << "                       is read from the standard input.\n"
        << "\n\n";

    out
        << "Examples:\n"
        << "  <other tool> | " << exec << " session create\n"
        << "  " << exec << " session create /tmp/sas-ext1 /tmp/sas-ext2\n"
        << "  " << exec << " enable\n"
        << "  <other tool> | " << exec << " trigger\n"
        << "  " << exec << " trigger /tmp/ecm-acd1 /tmp/ecm-acd2\n"
        << "  " << exec << " trigger --empty\n"
        << "  " << exec << " disable\n"
        << "  " << exec << " session destroy\n"
        ;
}

int rtfm(const std::string& why, const char* const argv0)
{
    std::cerr << "Error: " << why << ".  Try `" << argv0 << " help` first"
              << std::endl;
    return EXIT_FAILURE;
}

bool isHelpRequested(const std::string& arg)
{
    return arg == "-h" || arg == "-help" || arg == "--help" || arg == "help";
}

int cmdSession(RendererAsync& renderer, int argc, char* argv[])
{
    if (argc < 3)
    {
        return rtfm("Missing subcommand", argv[0]);
    }

    const std::string subcmd = argv[2];

    if ("create" == subcmd)
    {
        renderer.createSession(readAllPayloads(argv + 3, argv + argc)).get();
        return EXIT_SUCCESS;

    }
    else if("destroy" == subcmd)
    {
        renderer.destroySession().get();
        return EXIT_SUCCESS;
    }

    return rtfm("Unknown subcommand `" + subcmd + "`", argv[0]);
}

int cmdTrigger(RendererAsync& renderer, int argc, char* argv[])
{
    renderer.trigger(
        argc == 3 && 0 == std::strcmp(argv[2], "--empty") ?
        std::vector<std::vector<uint8_t> >() :
        readAllPayloads(argv + 2, argv + argc)).get();
    return EXIT_SUCCESS;
}

int cmdEnable(RendererAsync& renderer, int, char**)
{
    renderer.setState(RendererState::enabled).get();
    return EXIT_SUCCESS;
}

int cmdDisable(RendererAsync& renderer, int, char**)
{
    renderer.setState(RendererState::disabled).get();
    return EXIT_SUCCESS;
}

} // namespace

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        usage(argv[0], std::cerr);
        return EXIT_FAILURE;
    }
    else if (isHelpRequested(argv[1]))
    {
        usage(argv[0], std::cout);
        return EXIT_SUCCESS;
    }

    try
    {
        std::map<std::string, int(*) (RendererAsync&, int, char**)> commands =
            boost::assign::map_list_of
            ("session", cmdSession)
            ("trigger", cmdTrigger)
            ("enable" , cmdEnable )
            ("disable", cmdDisable)
            ;

        const std::string cmd = argv[1];

        if (0 == commands.count(cmd))
        {
            return rtfm("Unknown command `" + cmd + "`", argv[0]);
        }

        const NS_ZINC::FixedPluginConfig config(
            "libNickelOnScreenIdSystemDbusClient.so",
            "createDbusSystemFactory");

        boost::shared_ptr<RendererAsync> renderer =
            NS_ZINC::PluginFactory::getInstance<SystemFactory>(config)
                .createRenderer();

        return commands[cmd] (*renderer, argc, argv);

    }
    catch(const ParseFailureException& e)
    {
        std::cerr << "OSID service rejected payload: " << e.what() << '\n';
    }
    catch(const ResourceFailureException& e)
    {
        std::cerr << "OSID service reported resource error: "
                  << e.what() << '\n';
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << '\n';
    }
    catch(...)
    {
        std::cerr << "Unknown error\n";
    }

    return EXIT_FAILURE;
}
