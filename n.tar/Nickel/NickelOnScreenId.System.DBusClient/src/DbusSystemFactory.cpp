/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "RendererDBusToSyncAndAsync.h"

#include <nickelonscreenid-system-api/Renderer.h>
#include <nickelonscreenid-system-api/SystemFactory.h>

#include <nickelonscreenid-system-dbus/BusName.h>
#include <nickelonscreenid-system-dbus/ObjectPath.h>

#include <zinc-binding-runtime/dbus/dbus-runtime.h>

#include <zinc-common/zinc-common.h>

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

namespace Zinc {
namespace OnScreenId {

class DbusSystemFactory :
    public NS_ZINC_DBUS_BINDING::AbstractDbusSystemFactory<SystemFactory>
{

public:

    virtual boost::shared_ptr<Renderer> createRenderer();

private:

    /**
     * Cache service instances. This prevents a lot of unnecessary
     * re-registration for signals, which would otherwise happen EVERY TIME the
     * service create methods were called.
     */
    boost::weak_ptr<Renderer> renderer;
};

boost::shared_ptr<Renderer> DbusSystemFactory::createRenderer()
{
    boost::recursive_mutex::scoped_lock lock(mutex);
    boost::shared_ptr<Renderer> strong(renderer.lock());
    if (!strong)
    {
        strong =
            RendererDBusToSyncAndAsync::create(getDBusSessionConnection(),
                                               BusName::ONSCREENID,
                                               ObjectPath::ONSCREENID_RENDERER,
                                               getFutureDispatcher());
        renderer = strong;
    }

    return strong;
}

extern "C"
NS_ZINC::Plugin* createDbusSystemFactory() ZINC_EXPORT;

NS_ZINC::Plugin* createDbusSystemFactory()
{
    return new DbusSystemFactory();
}

} // namespace OnScreenId
} // namespace Zinc
