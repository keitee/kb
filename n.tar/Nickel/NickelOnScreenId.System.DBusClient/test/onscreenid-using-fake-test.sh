#!/bin/bash

##
# Unit tests for On-Screen ID service (`onscreenidd` daemon [1]) using fake
# components.
#
# There's enough generic logic in the daemon to test on it's own.  A bit harder
# to set up and control components (image downloader, DirectFB renderer) have
# been replaced with their fake counterparts which print their activity into
# the console.  This in turn is used to verify the outcome by simply `grep`-ing
# the output.
#
# [1] https://wiki.youview.co.uk/display/IPCHAN/Daemon
#
# Author: kris@youview.com
#
# Copyright 2013 YouView TV Ltd.

# Exit immediately if any unexpected error occurs
set -e

#/ Usage: onscreenid-fake-test.sh [options] [testnames...]
#/
#/        -l      Leave the scratch dir created in /tmp, rather than removing
#/                it during test tear-down (useful for debugging).
#/        -s      Stop on first test failure.
#/        -v      Verbose (don't suppress console output from tests).
#/
#/        If any test names are specified, only those test cases will be run.
while getopts "hlsv" option; do
    case $option in
        l) leave_scratch_dir=true;;
        s) stop_on_failure=true;;
        v) verbose=true;;
        *) grep '^#/' < "$0" | cut -c 4-; exit 1;; # Print above usage comment
    esac
done
shift $(($OPTIND-1))

# The zinc script sourced by `config.h` uses `let something=0`
# so it fails by default
set +e
if [ -n "${srcdir}" ]; then
    source test/config.sh

    # OK, this is a non-recursive project which runs a test script from the
    # source directory.  Need to help it a bit to find libs
    complete_lib_path=$PWD/src/.libs:$complete_lib_path

    osid_dbus_cmd=$PWD/yv-osid-dbus
else
    source $(dirname $BASH_SOURCE[0])/../share/config.sh
    osid_dbus_cmd=$final_prefix/devel/bin/yv-osid-dbus
fi
set -e

function kill_and_wait() {
    local kill_list="$@"

    kill $kill_list
    # suppress background job status message (don't care about the status)
    wait $kill_list 2>/dev/null || :
}

function setup_suite() {
    setUpResourceSandbox

    export $(dbus-launch)

    if [ ! -z "$ZINC_TEST_ENABLE_INLINE_DBUS_MONITOR" ]; then
        dbus-monitor &
        dbus_monitor_pid=$!
    fi

    tmpdir_suite=$(mktemp -d)

    sas0_static_img="${tmpdir_suite}/sas.0"
    sas1_dynamic_text="${tmpdir_suite}/sas.1"

    ecm1="${tmpdir_suite}/ecm.1"

    $final_prefix/devel/bin/yv-sas-extension-gen --binary \
        --static --reference 0 --url https://test.tld/1.png \
        > $sas0_static_img
    $final_prefix/devel/bin/yv-sas-extension-gen --binary \
        --reference 1 --text "this is a test" \
        --pos-x 10 --pos-y 20 \
        --width 50 --height 20 \
        --font-size 14 --fg-colour FF00FF00 --bg-colour 01010101 \
        > $sas1_dynamic_text

    $final_prefix/devel/bin/yv-ecm-extension-gen --binary \
        --reference 1 --pos-x 1100 --pos-y 600 \
        > $ecm1
}

function teardown_suite() {
    kill_and_wait "$DBUS_SESSION_BUS_PID $dbus_monitor_pid"
    tearDownResourceSandbox
}

function setup_test() {
    scratchdir="${tmpdir_suite}/${1}"
    logfile="${scratchdir}/log"

    mkdir $scratchdir

    $final_prefix/bin/onscreenidd &> $logfile &
    osid_pid=$!

    $final_prefix/bin/dbuswaitbusname --timeout 5 Zinc.OnScreenId &> $logfile
}

function teardown_test() {
    kill_and_wait "$osid_pid"
}

function match_output() {
    grep -q "${1}" "${logfile}"
}

setup_suite

function test_that_prerenders_ids() {
    $osid_dbus_cmd session create $sas0_static_img $sas1_dynamic_text && \
    match_output "rendering ID 0" && \
    match_output "rendering ID 1"
}

function test_that_downloads_image() {
    $osid_dbus_cmd session create $sas0_static_img && \
    match_output "image download"
}

function test_that_reads_attributes() {
    $osid_dbus_cmd session create $sas1_dynamic_text && \
    match_output "position[ :]\+10, 20" && \
    match_output "box size[ :]\+50, 20" &&
    match_output "font size[ :]\+14" &&
    match_output "text[ :]\+this is a test"
}

function test_that_enables_static_id() {
    $osid_dbus_cmd session create $sas0_static_img $sas1_dynamic_text && \
    $osid_dbus_cmd enable && \
    match_output "Enabling static ID 0"
}

function test_that_triggers_dynamic_id() {
    $osid_dbus_cmd session create $sas1_dynamic_text && \
    $osid_dbus_cmd enable && \
    $osid_dbus_cmd trigger $ecm1 && \
    match_output "Enabling dynamic ID 1" &&
    match_output "position[ :]\+1100, 600"
}

function test_that_disables_ids() {
    $osid_dbus_cmd session create $sas0_static_img $sas1_dynamic_text && \
    $osid_dbus_cmd enable && \
    $osid_dbus_cmd trigger $ecm1 && \
    $osid_dbus_cmd disable && \
    match_output "Disabling ID 0" && \
    match_output "Disabling ID 1"
}

function test_that_disposes_resources() {
    $osid_dbus_cmd session create $sas0_static_img $sas1_dynamic_text && \
    $osid_dbus_cmd enable && \
    $osid_dbus_cmd session destroy && \
    match_output "Disposing rendering resources" && \
    match_output "Disposing downloader resources"
}

function test_that_receives_error_when_max_ids_exceeded() {
    # 2 IDs are allowed by default.
    # See YouView "IP Channels" (rev. 0.6), Annex F, section F.2
    ! $osid_dbus_cmd session create \
         $sas1_dynamic_text $sas0_static_img $sas1_dynamic_text && \
    match_output "exceeded"
}

function test_that_receives_error_when_multiple_sessions_created() {
    $osid_dbus_cmd session create $sas0_static_img && \
    ! $osid_dbus_cmd session create $sas0_static_img && \
    match_output "session is already created"
}

function test_that_receives_error_when_text_too_long() {
    # 30 characters max
    # See YouView "IP Channels" (rev. 0.6), Annex F, section F.3

    ! {
        $final_prefix/devel/bin/yv-sas-extension-gen --binary --text \
            "This is way too long text and it exceeds 30 characters" | \
        $osid_dbus_cmd session create
    } && \
    match_output "Text data too long"
}

##
# Run all functions named test_* (or specific tests named on the command line).
#
failed=0
for test in ${*:-$(compgen -A function test_)}; do
    set +e # So that a failing test doesn't terminate this script.
    ( # Run each test in a sub-shell to minimize side-effects.
        echo -n "$test ... "
        # &>> not supported by the bash on the box
        setup_test $test && ( set -e; $test; ) >> "${logfile}" 2>&1
        status=$?

        teardown_test

        [ $status -eq 0 ] && echo "OK" || echo "FAIL" >&2
        [[ "$verbose" = "true" || $status -ne 0 ]] && { cat "${logfile}"; echo; }
        exit $status
    ) || {
        ((++failed))
        [ "$stop_on_failure" != "true" ] || exit 1
    }
done

teardown_suite

[[ "$leave_scratch_dir" = "true" ]] ||
    rm -rf $tmpdir_suite

exit $((failed != 0))
