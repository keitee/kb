/* 
 * File:   DbusSystemFactory.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 19 Aug 2013
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKELTUNER_SYSTEM_DBUSCLIENT_DBUSSYSTEMFACTORY_H_
#define NICKELTUNER_SYSTEM_DBUSCLIENT_DBUSSYSTEMFACTORY_H_

#include <zinc-common/macros.h>

#include <nickeltuner-system-api/macros.h>

#include <boost/shared_ptr.hpp>

NS_ZINC_OPEN
    class Dispatcher;
NS_ZINC_CLOSE

namespace DBus
{
    class Connection;
}

NS_NICKELTUNER_SYSTEM_OPEN

class LinearPlaybackControlAsync;
class TunerControlAsync;

ZINC_EXPORT
boost::shared_ptr<LinearPlaybackControlAsync>
    createLinearPlaybackControlProxy(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher, DBus::Connection connection);

ZINC_EXPORT
boost::shared_ptr<TunerControlAsync>
    createTunerControlProxy(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher, DBus::Connection connection);

NS_NICKELTUNER_SYSTEM_CLOSE

#endif /* NICKELTUNER_SYSTEM_DBUSCLIENT_DBUSSYSTEMFACTORY_H_ */
