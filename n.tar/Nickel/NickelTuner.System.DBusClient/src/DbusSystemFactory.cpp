/*
 * File:   DbusSystemFactory.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 19 Aug 2013
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/DbusSystemFactory.h"

#include "LinearPlaybackControlDBusToSyncAndAsync.h"
#include "TunerControlDBusToSyncAndAsync.h"

#include <nickeltuner-system-api/LinearPlaybackControlAsync.h>
#include <nickeltuner-system-api/SystemFactory.h>
#include <nickeltuner-system-api/TunerControlAsync.h>

#include <zinc-binding-runtime/dbus/dbus-runtime.h>
#include <zinc-binding-runtime/dbus/ObjectProxy.h>

#include <zinc-common/async/Dispatcher.h>

#include <boost/make_shared.hpp>
#include <boost/weak_ptr.hpp>

using NS_ZINC::Dispatcher;

NS_NICKELTUNER_SYSTEM_OPEN

const std::string TUNER_BUS_NAME = "Zinc.Tuner";
const std::string LINEAR_PLAYBACK_CONTROL_PATH = "/Zinc/Tuner/LinearPlaybackControl";
const std::string TUNER_CONTROL_PATH = "/Zinc/Tuner/TunerControl";

class DbusSystemFactory :
    public NS_ZINC_DBUS_BINDING::AbstractDbusSystemFactory<SystemFactory>
{

public:

    virtual boost::shared_ptr<TunerControlAsync> createTunerControl();

    virtual boost::shared_ptr<LinearPlaybackControlAsync> createLinearPlaybackControl();
private:

    boost::weak_ptr<TunerControlAsync> tc;
    boost::weak_ptr<LinearPlaybackControlAsync> lpc;
};

boost::shared_ptr<TunerControlAsync> DbusSystemFactory::createTunerControl()
{
    boost::recursive_mutex::scoped_lock lock(mutex);
    boost::shared_ptr<TunerControlAsync> strong(tc.lock());
    if (!strong)
    {
        strong = createTunerControlProxy(getFutureDispatcher(),
                                         getDBusSessionConnection());
        tc = strong;
    }

    return strong;
}

boost::shared_ptr<LinearPlaybackControlAsync>
DbusSystemFactory::createLinearPlaybackControl()
{
    boost::recursive_mutex::scoped_lock lock(mutex);
    boost::shared_ptr<LinearPlaybackControlAsync> strong(lpc.lock());
    if (!strong)
    {
        strong = createLinearPlaybackControlProxy(getFutureDispatcher(),
                                                  getDBusSessionConnection());
        lpc = strong;
    }

    return strong;
}

boost::shared_ptr<LinearPlaybackControlAsync> createLinearPlaybackControlProxy(
        boost::shared_ptr<Dispatcher> dispatcher,
        DBus::Connection connection)
{
    return NS_ZINC_DBUS_BINDING::applyInterface<Zinc::Tuner::LinearPlaybackControlAsync>(
        boost::make_shared<NS_ZINC_DBUS_BINDING::ObjectProxy>(
            connection,
            TUNER_BUS_NAME,
            LINEAR_PLAYBACK_CONTROL_PATH,
            dispatcher,
            dispatcher));
}

boost::shared_ptr<TunerControlAsync> createTunerControlProxy(
        boost::shared_ptr<Dispatcher> dispatcher,
        DBus::Connection connection)
{
    return NS_ZINC_DBUS_BINDING::applyInterface<Zinc::Tuner::TunerControlAsync>(
        boost::make_shared<NS_ZINC_DBUS_BINDING::ObjectProxy>(
            connection,
            TUNER_BUS_NAME,
            TUNER_CONTROL_PATH,
            dispatcher,
            dispatcher));
}

extern "C"
NS_ZINC::Plugin* createDbusSystemFactory() ZINC_EXPORT;

NS_ZINC::Plugin* createDbusSystemFactory()
{
    return new DbusSystemFactory();
}

NS_NICKELTUNER_SYSTEM_CLOSE
