#include <boost/shared_ptr.hpp>
#include <nickel-common/NickelLogger.h>
#include <exception>

#include <zinc-system-api/zinc-system-api.h>
#include <zinc-common/zinc-common.h>
#include <nickel-system-api/MediaRouterConvertToSync.h>
#include <nickel-system-api/MediaRouterFactoryConvertToSync.h>

#include "DbusSystemFactory.h"

using namespace NS_ZINC;
using namespace NS_NICKEL_SYSTEM;
using namespace std;

int main(int argc,char *argv[])
{
	boost::shared_ptr<SystemFactory> factory;
	factory.reset(new DbusSystemFactory(NULL));

	boost::shared_ptr<MediaRouterFactorySync> mediaRouterFactory;
	
	mediaRouterFactory = convertToSync( factory->createMediaRouterFactory() );
	boost::shared_ptr<MediaRouterSync> mediaRouter = convertToSync(mediaRouterFactory->createMediaRouter());

	mediaRouter->setSink("klaff");
	mediaRouter->setSource("test", SetSourceReason::unspecified);
	mediaRouter->getSource();
	NICKEL_INFO("getPlaySpeed: " << mediaRouter->getPlaySpeed());
	mediaRouter->start();
	NICKEL_INFO("getPlaySpeed: " << mediaRouter->getPlaySpeed());
	mediaRouter->setPlaySpeed(2);
	NICKEL_INFO("getPlaySpeed: " << mediaRouter->getPlaySpeed());
	mediaRouter->stop();
	NICKEL_INFO("getPlaySpeed: " << mediaRouter->getPlaySpeed());
}

