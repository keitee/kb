/*
 * DbusSystemFactory.cpp
 *
 *  Created on: 26-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#include "DbusSystemFactory.h"
#include "LocalMediaLibraryDBusToSyncAndAsync.h"
#include "MediaRouterFactoryDBusToSyncAndAsync.h"
#include "MediaSettingsDBusToSyncAndAsync.h"
#include "OutputManagerDBusToSyncAndAsync.h"
#include "ServiceListBuilderDBusToSyncAndAsync.h"

#include <nickel-system-dbus/BusName.h>
#include <nickel-system-dbus/ObjectPath.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-system-dbus/ObjectPath.h>

#include <boost/make_shared.hpp>
#include <boost/algorithm/string/trim.hpp>

#include <string>
#include <stdexcept>

using boost::shared_ptr;
using boost::recursive_mutex;

using namespace NS_NICKEL_SYSTEM;
using namespace NS_ZINC;

DbusSystemFactory::DbusSystemFactory(const char* busName)
    : theBusName("Zinc.Media")
{
    if(busName)
    {
        std::string suppliedBusName(busName);
        boost::algorithm::trim(suppliedBusName);
        if(!suppliedBusName.empty())
        {
            theBusName = suppliedBusName;
        }
    }
        
    NICKEL_TRACE("Using DBus name: [" << theBusName << "]");
}

shared_ptr<LocalMediaLibrary> DbusSystemFactory::createLocalMediaLibrary()  {
	NICKEL_FUNC_TRACE;

	recursive_mutex::scoped_lock lock(mutex);
	boost::shared_ptr<LocalMediaLibrary> strong(theLocalMediaLibrary.lock());
	if (!strong) {
		strong = LocalMediaLibraryDBusToSyncAndAsync::create(getDBusSessionConnection(),
		                                             theBusName,
		                                             NS_NICKEL_SYSTEM::ObjectPath::LOCAL_MEDIA_LIBRARY,
                                                     getFutureDispatcher());
		strong->setDispatcher(getEventDispatcher());
		theLocalMediaLibrary = strong;
	}
	return strong;
}

shared_ptr<MediaRouterFactory> DbusSystemFactory::createMediaRouterFactory() {
	NICKEL_FUNC_TRACE;

	recursive_mutex::scoped_lock lock(mutex);
	boost::shared_ptr<MediaRouterFactory> strong(theMediaRouterFactory.lock());
	if (!strong) {
	    DBus::Connection conn = getDBusSessionConnection();
        if (!mediaRouterCollection) {
            mediaRouterCollection = boost::make_shared<NS_ZINC_DBUS_BINDING::ProxyFactory<MediaRouterDBusToSyncAndAsync> >(
                    NS_ZINC_DBUS_BINDING::ObjectWithEventsProxyFactory<MediaRouterDBusToSyncAndAsync>(
                        getEventDispatcher(), getFutureDispatcher()));
        }
        strong = MediaRouterFactoryDBusToSyncAndAsync::create(conn,
                                                      theBusName,
                                                      NS_NICKEL_SYSTEM::ObjectPath::MEDIA_ROUTER_FACTORY,
                                                      getFutureDispatcher(),
                                                      mediaRouterCollection);
		theMediaRouterFactory = strong;
	}
	return strong;
}

shared_ptr<MediaRouter> DbusSystemFactory::createDefaultMediaRouter() {
	NICKEL_FUNC_TRACE;

	recursive_mutex::scoped_lock lock(mutex);
	boost::shared_ptr<MediaRouter> strong(theDefaultMediaRouter.lock());
	if (!strong) {
		DBus::Connection conn = getDBusSessionConnection();
		strong = MediaRouterDBusToSyncAndAsync::create(conn,
                                                       theBusName,
		                                               NS_NICKEL_SYSTEM::ObjectPath::DEFAULT_MEDIA_ROUTER,
		                                               getFutureDispatcher());
		strong->setDispatcher(getEventDispatcher());
		theDefaultMediaRouter = strong;
	}
	return strong;
}

boost::shared_ptr<MediaSettings> DbusSystemFactory::createMediaSettings() {
	NICKEL_FUNC_TRACE;

	recursive_mutex::scoped_lock lock(mutex);
	boost::shared_ptr<MediaSettings> strong(theMediaSettings.lock());
	if (!strong) {
        strong = MediaSettingsDBusToSyncAndAsync::create(getDBusSessionConnection(),
                                                 theBusName,
                                                 NS_NICKEL_SYSTEM::ObjectPath::MEDIA_SETTINGS,
                                                 getFutureDispatcher());
		strong->setDispatcher(getEventDispatcher());
		theMediaSettings = strong;
	}
	return strong;
}

shared_ptr<OutputManager> DbusSystemFactory::createOutputManager()  {
	NICKEL_FUNC_TRACE;

	recursive_mutex::scoped_lock lock(mutex);
	boost::shared_ptr<OutputManager> strong(theOutputManager.lock());
	if (!strong) {
        strong = OutputManagerDBusToSyncAndAsync::create(getDBusSessionConnection(),
                theBusName,
                NS_NICKEL_SYSTEM::ObjectPath::OUTPUT_MANAGER,
                getFutureDispatcher());
		strong->setDispatcher(getEventDispatcher());
		theOutputManager = strong;
	}
	return strong;
}


shared_ptr<ServiceListBuilder> DbusSystemFactory::createServiceListBuilder() {
	NICKEL_FUNC_TRACE;

	recursive_mutex::scoped_lock lock(mutex);
	boost::shared_ptr<ServiceListBuilder> strong(theServiceListBuilder.lock());
	if (!strong) {
        strong = ServiceListBuilderDBusToSyncAndAsync::create(getDBusSessionConnection(),
                theBusName,
                NS_NICKEL_SYSTEM::ObjectPath::SERVICE_LIST_BUILDER,
                getFutureDispatcher());
        strong->setDispatcher(getEventDispatcher());
		theServiceListBuilder = strong;
	}
	return strong;
}

Plugin *createDbusSystemFactory(const char* busName) {
	return new DbusSystemFactory(busName);
}
