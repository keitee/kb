#include <boost/shared_ptr.hpp>
#include <iostream>
#include <exception>

#include <zinc-system-api/zinc-system-api.h>
#include <zinc-common/zinc-common.h>

#include "DbusSystemFactory.h"

using namespace NS_ZINC;
using namespace NS_NICKEL_SYSTEM;
using namespace std;

int main(int argc,char *argv[])
{
	boost::shared_ptr<SystemFactory> factory;
	factory.reset(new DbusSystemFactory(NULL));

	boost::shared_ptr<ServiceListBuilder> servicelistbuilder;
	servicelistbuilder = factory->createServiceListBuilder();

	// Put some tests here
}

