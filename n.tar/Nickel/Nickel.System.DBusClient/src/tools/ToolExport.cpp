/*
 * ToolExport.cpp
 *
 *  Created on: 24 Jan 2012
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2012 YouView TV Ltd
 */

#include "Tool.h"

NS_NICKEL_SYSTEM_OPEN

class ToolExport : public Tool
{
public:

	ToolExport()
	{

	}

	virtual void addOptions( po::options_description& desc )
	{
	}

	virtual int validateOptions( po::variables_map& vm )
	{
		return 0;
	}


	virtual std::string getName() const
	{
		return "export";
	}

	virtual int execute()
	{
		boost::shared_ptr<LocalMediaLibrarySync> localMediaLibrary = getLocalMediaLibrary();

		try
		{
			std::vector<MediaRecord> mediaRecords;

			int pageStart = 0;
			int pageSize = 10;
			bool isFinished = false;

			do
			{
				std::vector<MediaRecord> page = localMediaLibrary->getMediaRecords(
						FilterByType::recordings_and_downloads,
						FilterByPlayed::played_and_unplayed,
						SortBy::title_a_to_z,
						true,
						pageStart,
						pageSize
						);

				mediaRecords.insert( mediaRecords.end(), page.begin(), page.end() );

				isFinished = page.size() < pageSize;

				pageStart += page.size();

			}
			while ( !isFinished );

			output() << NS_ZINC::serialize::makeNode( "MediaRecords", mediaRecords );
		}
		catch (const std::exception& e)
		{
			output() << NS_ZINC::serialize::Error( "Exception", e.what() );
			return 1;
		}

		return 0;
	}

private:

	std::string interface;

};

NS_NICKEL_SYSTEM_CLOSE

int main(int argc, char* argv[])
{
	NS_NICKEL_SYSTEM::ToolExport tool;

	return tool.main( argc, argv );
}
