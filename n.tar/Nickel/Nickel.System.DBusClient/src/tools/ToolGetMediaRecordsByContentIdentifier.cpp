/*
 * ToolGetMediaRecordsByContentIdentifier.cpp
 *
 *  Created on: 2 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#include "Tool.h"

NS_NICKEL_SYSTEM_OPEN

class ToolGetMediaRecordsByContentIdentifier : public Tool
{
public:

	ToolGetMediaRecordsByContentIdentifier()
	{

	}

	virtual void addOptions( po::options_description& desc )
	{
		desc.add_options()
			("contentidentifier,c", po::value<std::string>(&contentIdentifier),
					"The identifier of the required MediaRecord. In the case where the identifier is an event locator, "\
					"as per ETSI TS 102 812 Clause 14.1 - the transport_stream_id field is optional so may be excluded e.g. "\
					"dvb://233a.1004.1084:1af6 or dvb://233a..1084:1af6 should both indicate the same MediaRecord.")
			;
	}

	virtual int validateOptions( po::variables_map& vm )
	{
		CHECK_CMDLINE_HAS_OPTION("contentidentifier");

		return 0;
	}

	virtual std::string getName() const
	{
		return "getMediaRecordsByContentIdentifier";
	}

	virtual int execute()
	{

		boost::shared_ptr<LocalMediaLibrarySync> localMediaLibrary = getLocalMediaLibrary();

		std::vector< MediaRecord> mediaRecords = localMediaLibrary->getMediaRecordsByContentIdentifier( contentIdentifier );

		output() << NS_ZINC::serialize::makeNode( "MediaRecords", mediaRecords );

		return 0;
	}

private:

	std::string contentIdentifier;
};

NS_NICKEL_SYSTEM_CLOSE

int main(int argc, char* argv[])
{
	NS_NICKEL_SYSTEM::ToolGetMediaRecordsByContentIdentifier tool;
	return tool.main( argc, argv );
}
