/*
 * ToolGetStorageSpace.cpp
 *
 *  Created on: 2 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#include "Tool.h"

NS_NICKEL_SYSTEM_OPEN

class ToolGetStorageSpace : public Tool
{
public:

	ToolGetStorageSpace()
	{

	}

	virtual void addOptions( po::options_description& desc )
	{
	}

	virtual int validateOptions( po::variables_map& vm )
	{

		return 0;
	}

	virtual std::string getName() const
	{
		return "getStorageSpace";
	}

	virtual int execute()
	{
		boost::shared_ptr<LocalMediaLibrarySync> localMediaLibrary = getLocalMediaLibrary();

		MediaStorageSpace mediaStorageSpace = localMediaLibrary->getStorageSpace();

		output() << NS_ZINC::serialize::makeNode( mediaStorageSpace );

		return 0;
	}

private:

};

NS_NICKEL_SYSTEM_CLOSE

int main(int argc, char* argv[])
{
	NS_NICKEL_SYSTEM::ToolGetStorageSpace tool;
	return tool.main( argc, argv );
}
