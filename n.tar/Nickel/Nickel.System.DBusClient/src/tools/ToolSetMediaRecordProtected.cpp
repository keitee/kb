/*
 * ToolSetMediaRecordProtected.cpp
 *
 *  Created on: 2 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#include "Tool.h"

NS_NICKEL_SYSTEM_OPEN

class ToolSetMediaRecordProtected : public Tool
{
public:

	ToolSetMediaRecordProtected()
	{

	}

	virtual void addOptions( po::options_description& desc )
	{
		desc.add_options()
			("mediarecord,m", po::value<std::string>(&mediaRecordIdentifier),"The identifier of the required MediaRecord.")
			("protected,p", po::value<bool>(&isProtected)->default_value(true),"If true the MediaRecord should be protected.")
			;
	}

	virtual int validateOptions( po::variables_map& vm )
	{
		CHECK_CMDLINE_HAS_OPTION( "mediarecord");

		return 0;
	}

	virtual std::string getName() const
	{
		return "setMediaRecordProtected";
	}

	virtual int execute()
	{
		boost::shared_ptr<LocalMediaLibrarySync> localMediaLibrary = getLocalMediaLibrary();

		try
		{
			bool success = localMediaLibrary->setMediaRecordProtected( mediaRecordIdentifier, isProtected );
			output() << NS_ZINC::serialize::makeNode( "Success", success );
		}
		catch (MediaRecordNotFound)
		{
			output() << NS_ZINC::serialize::Error( "Exception", "MediaRecordNotFound" );
			return 1;
		}

		return 0;
	}

private:

	std::string mediaRecordIdentifier;
	bool isProtected;
};

NS_NICKEL_SYSTEM_CLOSE

int main(int argc, char* argv[])
{
	NS_NICKEL_SYSTEM::ToolSetMediaRecordProtected tool;
	return tool.main( argc, argv );
}
