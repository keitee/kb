/*
 * ToolGetMediaRecords.cpp
 *
 *  Created on: 2 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#include "Tool.h"

NS_NICKEL_SYSTEM_OPEN

class ToolGetMediaRecords : public Tool
{
public:

	ToolGetMediaRecords() : filterByType( FilterByType::recordings ), filterByPlayed( FilterByPlayed::played_and_unplayed), sortBy( SortBy::title_a_to_z )
	{

	}

	virtual void addOptions( po::options_description& desc )
	{
		desc.add_options()
			("filterbytype,t", po::value<std::string>(&strFilterByType)->default_value("recordings"),"[ recordings | downloads | recordings_and_downloads ]")
			("filterbyplayed,p", po::value<std::string>(&strFilterByPlayed)->default_value("played_and_unplayed"),"[ played | unplayed | played_and_unplayed ]")
			("sortby,s", po::value<std::string>(&strSortBy)->default_value("title_a_to_z"),
					"[ least_recently_acquired | most_recently_acquired | least_recently_watched | most_recently_watched | title_a_to_z | title_z_to_a ]")
			("includeadult,a", po::value<bool>(&includeAdult)->default_value(true),
					"If true the list will include MediaRecords that correspond to adult content. If false no adult content will be returned.")
			("start,o", po::value<uint32_t>(&start)->default_value(0),
					"Indicate the index (offset) of the item (within the result set) from which the results should start. The first item in the result set has index = 1.")
			("size,c", po::value<uint32_t>(&size)->default_value(10),"Specify the maximum number (count) of MediaRecords that the method should return.")
			;
	}

	virtual int validateOptions( po::variables_map& vm )
	{
		CHECK_CMDLINE_ENUM( "filterbytype", filterByType );
		CHECK_CMDLINE_ENUM( "filterbyplayed", filterByPlayed );
		CHECK_CMDLINE_ENUM( "sortby", sortBy );

		return 0;
	}

	virtual std::string getName() const
	{
		return "getMediaRecords";
	}

	virtual int execute()
	{
		enum_from_string( filterByType, strFilterByType.c_str() );
		enum_from_string( filterByPlayed, strFilterByPlayed.c_str() );
		enum_from_string( sortBy, strSortBy.c_str() );

		boost::shared_ptr<LocalMediaLibrarySync> localMediaLibrary = getLocalMediaLibrary();

		std::vector< MediaRecord> mediaRecords = localMediaLibrary->getMediaRecords( filterByType, filterByPlayed, sortBy, includeAdult, start, size );

		output() << NS_ZINC::serialize::makeNode( "MediaRecords", mediaRecords );

		return 0;
	}

private:

	std::string strFilterByType;
	std::string strFilterByPlayed;
	std::string strSortBy;

	FilterByType::Enum filterByType;
	FilterByPlayed::Enum filterByPlayed;
	SortBy::Enum sortBy;
	bool includeAdult;
	uint32_t start;
	uint32_t size;
};

NS_NICKEL_SYSTEM_CLOSE

int main(int argc, char* argv[])
{
	NS_NICKEL_SYSTEM::ToolGetMediaRecords tool;
	return tool.main( argc, argv );
}
