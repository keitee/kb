/*
 * ToolGetMediaRecord.cpp
 *
 *  Created on: 2 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#include "Tool.h"

NS_NICKEL_SYSTEM_OPEN

class ToolGetMediaRecord : public Tool
{
public:

	ToolGetMediaRecord()
	{

	}

	virtual void addOptions( po::options_description& desc )
	{
		desc.add_options()
			("mediarecord,m", po::value<std::string>(&mediaRecordIdentifier),"The identifier of the required MediaRecord.")
			;
	}

	virtual int validateOptions( po::variables_map& vm )
	{
		CHECK_CMDLINE_HAS_OPTION( "mediarecord");

		return 0;
	}

	virtual std::string getName() const
	{
		return "getMediaRecord";
	}

	virtual int execute()
	{
		boost::shared_ptr<LocalMediaLibrarySync> localMediaLibrary = getLocalMediaLibrary();

		try
		{
			MediaRecord mediaRecord = localMediaLibrary->getMediaRecord( mediaRecordIdentifier);
			output() << NS_ZINC::serialize::makeNode( mediaRecord );
		}
		catch (MediaRecordNotFound)
		{
			output() << NS_ZINC::serialize::Error( "Exception", "MediaRecordNotFound" );
			return 1;
		}

		return 0;
	}

private:

	std::string mediaRecordIdentifier;
};

NS_NICKEL_SYSTEM_CLOSE

int main(int argc, char* argv[])
{
	NS_NICKEL_SYSTEM::ToolGetMediaRecord tool;
	return tool.main( argc, argv );
}
