/*
 * ToolDeleteMediaRecord.cpp
 *
 *  Created on: 2 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#include "Tool.h"

NS_NICKEL_SYSTEM_OPEN

class ToolDeleteMediaRecord : public Tool
{
public:

	ToolDeleteMediaRecord()
	{

	}

	virtual void addOptions( po::options_description& desc )
	{
		desc.add_options()
			("mediarecord,m", po::value<std::string>(&mediaRecordIdentifier),"The mediaRecordIdentifier of the MediaRecord to be deleted.")
			;
	}

	virtual int validateOptions( po::variables_map& vm )
	{
		CHECK_CMDLINE_HAS_OPTION( "mediarecord" );

		return 0;
	}

	virtual std::string getName() const
	{
		return "deleteMediaRecord";
	}

	virtual int execute()
	{
		boost::shared_ptr<LocalMediaLibrarySync> localMediaLibrary = getLocalMediaLibrary();

		try
		{
			bool success = localMediaLibrary->deleteMediaRecord( mediaRecordIdentifier );
			output() << NS_ZINC::serialize::makeNode( "success", success );
		}
		catch (MediaRecordNotFound)
		{
			output() << NS_ZINC::serialize::makeNode( "Exception", "MediaRecordNotFound" );
			return 1;
		}

		return 0;
	}

private:
	std::string mediaRecordIdentifier;
};

NS_NICKEL_SYSTEM_CLOSE

int main(int argc, char* argv[])
{
	NS_NICKEL_SYSTEM::ToolDeleteMediaRecord tool;
	return tool.main( argc, argv );
}
