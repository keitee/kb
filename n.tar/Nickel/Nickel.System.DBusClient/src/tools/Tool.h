/*
 * Tool.h
 *
 *  Created on: 2 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#ifndef NICKEL_SYSTEM_DBUSCLIENT__TOOLS__TOOL_H
#define NICKEL_SYSTEM_DBUSCLIENT__TOOLS__TOOL_H

#include <zinc-common/zinc-common.h>
#include <zinc-common/async/Future.h>

#include <nickel-system-api/Serialize.h>
#include <nickel-system-api/LocalMediaLibraryConvertToSync.h>

#include <fstream>
#include <iostream>
#include <string>

#include <boost/program_options.hpp>
#include <boost/foreach.hpp>

namespace po = boost::program_options;

NS_NICKEL_SYSTEM_OPEN

enum OutputFormat
{
	outputformat_txt = 0,
	outputformat_xml
};

static OutputFormat outputFormat = outputformat_txt;

void outputTXT( std::ostream& os, const NS_ZINC::serialize::Node& node )
{
	os << node.createTXT();
}

void outputXML( std::ostream& os, const NS_ZINC::serialize::Node& node )
{
	xmlChar *xmlbuff;
	int buffersize;

	xmlDocPtr doc = xmlNewDoc( BAD_CAST "1.0" );
	xmlNodePtr root = xmlNewNode( NULL, BAD_CAST "root" );
	xmlDocSetRootElement( doc, root );

	if (node.key == "root")
	{
		BOOST_FOREACH( const NS_ZINC::serialize::Node& child, node.children )
		{
			xmlAddChild( root, child.createXML() );
		}
	}
	else
	{
		xmlAddChild( root, node.createXML() );
	}

	// output to ostream
	xmlDocDumpFormatMemory( doc, &xmlbuff, &buffersize, 1 );
	os << xmlbuff;

	// Free associated memory.
	xmlFree( xmlbuff );
	xmlFreeDoc( doc );
}

std::ostream& operator << (std::ostream& os, const NS_ZINC::serialize::Node& node )
{
	switch (outputFormat)
	{
	case outputformat_txt:
		outputTXT( os, node );
		break;
	case outputformat_xml:
		outputXML( os, node );
		break;
	}

	return os;
}

/*
 * Make sure that this argument has been supplied on the command line
 */
#define CHECK_CMDLINE_HAS_OPTION( _option ) 	\
	if (!vm.count( _option )) \
	{ \
		output() << NS_ZINC::serialize::Error( "command line option was not set",  _option); \
		return 2; \
	}

/*
 * Make sure that this argument has been supplied on the command line & that it is a valid element of this enumeration
 */
#define CHECK_CMDLINE_ENUM( _option, _enum )	\
	if (vm.count( _option ) && !enum_from_string(_enum, (boost::any_cast<std::string>( vm[ _option ].value() )).c_str() )) \
	{ \
		output() << NS_ZINC::serialize::Error("command line option set incorrectly ", _option ); \
		return 2; \
	}

class Tool
{
public:
	virtual ~Tool() {}

	int main( int argc, char* argv[] )
	{

		po::options_description desc("Allowed options");
		desc.add_options()
			("help,?", "produce help message")
			("xml,x", "produce output in XML")
			("file,f", po::value< std::string >(&filename), "filename of the file to store output in")
			;

		po::positional_options_description positional_options_desc;

		/**
		 * Derived classes implement one or other of the following functions
		 *
		 * The second form allows positional arguments
		 *
		 * The first form retained for compatibility
		 *
		 */
		addOptions( desc );
		addOptions( desc, positional_options_desc );

		po::variables_map vm;
		po::store(po::command_line_parser( argc, argv ).options(desc).positional(positional_options_desc).run(), vm );
		po::notify(vm);

		if (vm.count("help"))
		{
			std::cout << desc << std::endl;
			return 1;
		}

		if (vm.count("xml"))
		{
			// xml output
			outputFormat = outputformat_xml;
		}

		createDefaultOutput();

		int result = validateOptions( vm );
		if (result != 0)
		{
			return result;
		}

		createOutput();

		if (outputFormat != outputformat_xml)
		{
			outputArgs( desc, vm );
		}

		// get connection to LocalMediaLibrary
		createLocalMediaLibrary();

		// do the tool's work
		return execute();
	}

	virtual void addOptions( po::options_description& /*desc*/ ) {}
	virtual void addOptions( po::options_description& /*desc*/, po::positional_options_description & /*po_desc*/ ) {}
	virtual int validateOptions( po::variables_map& vm ) = 0;
	virtual std::string getName() const = 0;
	virtual int execute() = 0;

	boost::shared_ptr<LocalMediaLibrarySync> getLocalMediaLibrary()
	{
		return ::Zinc::Media::convertToSync( localMediaLibrary );
	}

	std::ostream& output()
	{
		return *outputStream;
	}

private:

	void createDefaultOutput()
	{
		outputStream = &std::cout;
	}

	void createOutput()
	{
		if (filename.empty())
		{
			outputStream = &std::cout;
		}
		else
		{
			outputFileStream.open( filename.c_str(), std::ios_base::out );
			outputStream = &outputFileStream;
		}

	}

	std::string toString( boost::any& value )
	{
		// JK - this sucks, surely I can do a better cast to std::string than this?
		if (value.type() == typeid(int))
		{
			return boost::lexical_cast<std::string>( boost::any_cast<int>( value ));
		}
		else if (value.type() == typeid(uint32_t))
		{
			return boost::lexical_cast<std::string>( boost::any_cast<uint32_t>( value ));
		}
		else if (value.type() == typeid(std::string))
		{
			return boost::any_cast<std::string>( value );
		}
		else if (value.type() == typeid(bool))
		{
			return boost::any_cast<bool>( value ) ? "true" : "false";
		}
		else if (value.type() == typeid(std::vector<std::string>))
		{
			std::vector< std::string > vec = boost::any_cast< std::vector<std::string> >(value);

			std::string str;

			BOOST_FOREACH( std::string& val, vec )
			{
				if (!str.empty())
				{
					str += ", ";
				}

				str += val;
			}

			str = "[ " + str + " ]";

			return str;
		}
		else
		{
			BOOST_ASSERT(!"unsupported value type");
			return "<<UNSUPPORTED VALUE TYPE>>";
		}
	}
	void createLocalMediaLibrary()
	{
		// use the instance of Nickel attached to DBUS
		NS_ZINC::FixedPluginConfig pluginConfig( "libNickelSystemDbusClient.so","createDbusSystemFactory" );

		SystemFactory& factory = NS_ZINC::PluginFactory::getInstance<SystemFactory>(pluginConfig);
		localMediaLibrary = factory.createLocalMediaLibrary();
	}

	void outputArgs( po::options_description& desc, po::variables_map& vm )
	{
		NS_ZINC::serialize::Node args( "Command", getName() );

		const std::vector< boost::shared_ptr<po::option_description> > options = desc.options();

		BOOST_FOREACH( const boost::shared_ptr<po::option_description> option, options )
		{
			if (option->long_name() == "help")
			{
				continue;
			}

			std::string name = option->long_name();

			if ( ((name == "xml") || (name == "file")) && (!vm.count( name )) )
			{
				continue;
			}

			boost::any value = vm[ name ].value();
			std::string strValue = toString( value );

			args.children.push_back( NS_ZINC::serialize::Node( name, strValue ) );

		}

		output() << args;
	}

	boost::shared_ptr<LocalMediaLibrary> localMediaLibrary;

	std::string filename;

	std::ostream* outputStream;
	std::ofstream outputFileStream;
};

NS_NICKEL_SYSTEM_CLOSE

#endif
