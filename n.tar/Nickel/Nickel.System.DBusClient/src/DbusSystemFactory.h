/*
 * DbusSystemFactory.h
 *
 *  Created on: 26-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_DBUSSYSTEMFACTORY_H_
#define NICKEL_DBUSSYSTEMFACTORY_H_

#include "MediaRouterDBusToSyncAndAsync.h"

#include <nickel-system-api/nickel-system-api.h>
#include <zinc-binding-runtime/dbus/dbus-runtime.h>
#include <zinc-binding-runtime/dbus/ProxyFactory.h>
#include <zinc-common/zinc-common.h>

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

NS_NICKEL_SYSTEM_OPEN

class ZINC_EXPORT DbusSystemFactory : public NS_ZINC_DBUS_BINDING::AbstractDbusSystemFactory<SystemFactory> {

public:
    DbusSystemFactory(const char* busName);

	boost::shared_ptr<LocalMediaLibrary>  createLocalMediaLibrary();
	boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory();
	boost::shared_ptr<MediaRouter>        createDefaultMediaRouter();
	boost::shared_ptr<MediaSettings>      createMediaSettings();
	boost::shared_ptr<OutputManager>      createOutputManager();
	boost::shared_ptr<ServiceListBuilder> createServiceListBuilder();

private:

	/**
	 * Cache service instances. This prevents a lot of unnecessary re-registration
	 * for signals, which would otherwise happen EVERY TIME the service
	 * create methods were called.
	 */
	boost::weak_ptr<LocalMediaLibrary>  theLocalMediaLibrary;
	boost::weak_ptr<MediaRouterFactory> theMediaRouterFactory;
	boost::weak_ptr<MediaRouter>        theDefaultMediaRouter;
	boost::weak_ptr<MediaSettings>      theMediaSettings;
	boost::weak_ptr<OutputManager>      theOutputManager;
	boost::weak_ptr<ServiceListBuilder> theServiceListBuilder;
    boost::shared_ptr< NS_ZINC_DBUS_BINDING::ProxyFactory<MediaRouterDBusToSyncAndAsync> > mediaRouterCollection;

    std::string theBusName;
};

NS_NICKEL_SYSTEM_CLOSE

extern "C" {
	NS_ZINC::Plugin* createDbusSystemFactory(const char* busName) ZINC_EXPORT;
}

#endif /* NICKEL_DDBUSSYSTEMFACTORY_H_ */
