/*
 * DbusOutputManagerTest.cpp
 *
 *  Created on: Mar 3, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_OUTPUT_MANAGER_TEST
#define NICKEL_SYSTEM_FAKE_OUTPUT_MANAGER_TEST

#include <zinc-common/zinc-common.h>

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-dbus/BusName.h>

#include <nickel-system-fake/testsupport/FakeOutputManagerTestCommon.h>

#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>


using namespace NS_ZINC;
using namespace NS_ZINC_DBUS_BINDING;

NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL DbusOutputManagerTest
	: IntegrationTestSandbox,	public DBusPluginTestFixture< FakeOutputManagerTestCommon > {
public:
	DbusOutputManagerTest()
		:	DBusPluginTestFixture< FakeOutputManagerTestCommon >("media-daemon.plugin-config", "nickelmediad", BusName::OUTPUT_MANAGER) {}

	CPPUNIT_TEST_SUITE(DbusOutputManagerTest);

	ZINC_REGISTER_COMMON_TESTS(FakeOutputManagerTestCommon);

	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(DbusOutputManagerTest);

NS_NICKEL_SYSTEM_CLOSE

ZINC_CONFIGURE_DBUS_TEST_FIXTURE_FACTORY_PLUGIN(NS_NICKEL_SYSTEM::FakeOutputManagerTestCommon,
												 "libNickelSystemDbusClient.so",
												 "createDbusSystemFactory");

#endif /* NICKEL_SYSTEM_FAKE_OUTPUT_MANAGER_TEST */
