/*
 * DbusLocalMediaLibraryTest.cpp
 *
 *  Created on: Mar 18, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_LOCAL_MEDIA_LIBRARY_TEST
#define NICKEL_SYSTEM_FAKE_LOCAL_MEDIA_LIBRARY_TEST

#include <zinc-common/zinc-common.h>

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-dbus/BusName.h>

#include <nickel-system-fake/testsupport/FakeLocalMediaLibraryTestCommon.h>

#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>


using namespace NS_ZINC;
using namespace NS_ZINC_DBUS_BINDING;

NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL DbusLocalMediaLibraryTest
	: IntegrationTestSandbox,	public DBusPluginTestFixture< FakeLocalMediaLibraryTestCommon > {
public:
	DbusLocalMediaLibraryTest()
		:	DBusPluginTestFixture< FakeLocalMediaLibraryTestCommon >("media-daemon.plugin-config", "nickelmediad", BusName::LOCAL_MEDIA_LIBRARY) {}

	CPPUNIT_TEST_SUITE(DbusLocalMediaLibraryTest);

	ZINC_REGISTER_COMMON_TESTS(FakeLocalMediaLibraryTestCommon);

	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(DbusLocalMediaLibraryTest);

NS_NICKEL_SYSTEM_CLOSE

ZINC_CONFIGURE_DBUS_TEST_FIXTURE_FACTORY_PLUGIN(NS_NICKEL_SYSTEM::FakeLocalMediaLibraryTestCommon,
												 "libNickelSystemDbusClient.so",
												 "createDbusSystemFactory");

#endif /* NICKEL_SYSTEM_FAKE_LOCAL_MEDIA_LIBRARY_TEST */
