/*
 * DbusServiceListBuilderTest.cpp
 *
 *  Created on: 15 Jun, 2010
 *      Author: Mark Nicoll
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_FAKE_SERVICELISTBUILDER_TEST
#define NICKEL_SYSTEM_FAKE_SERVICELISTBUILDER_TEST

#include <zinc-common/zinc-common.h>

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-dbus/BusName.h>

#include <nickel-system-fake/testsupport/FakeServiceListBuilderTestCommon.h>

#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>


using namespace NS_ZINC;
using namespace NS_ZINC_DBUS_BINDING;

NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL DbusServiceListBuilderTest
	: IntegrationTestSandbox,	public DBusPluginTestFixture< FakeServiceListBuilderTestCommon > {
public:
	DbusServiceListBuilderTest()
		:	DBusPluginTestFixture< FakeServiceListBuilderTestCommon >("media-daemon.plugin-config", "nickelmediad", BusName::MEDIA) {}

	CPPUNIT_TEST_SUITE(DbusServiceListBuilderTest);

	ZINC_REGISTER_COMMON_TESTS(FakeServiceListBuilderTestCommon);

	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(DbusServiceListBuilderTest);

NS_NICKEL_SYSTEM_CLOSE

ZINC_CONFIGURE_DBUS_TEST_FIXTURE_FACTORY_PLUGIN(NS_NICKEL_SYSTEM::FakeServiceListBuilderTestCommon,
												 "libNickelSystemDbusClient.so",
												 "createDbusSystemFactory");

#endif /* NICKEL_SYSTEM_FAKE_SERVICELISTBUILDER_TEST */
