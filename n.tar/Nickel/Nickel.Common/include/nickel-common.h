/* Copyright (C) 2010 British Broadcasting Corporation */
#ifndef NICKEL_COMMON_H_
#define NICKEL_COMMON_H_

#include "macros.h"

#include "NickelLogger.h"

#endif
