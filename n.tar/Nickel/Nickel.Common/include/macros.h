/* Copyright (C) 2010 British Broadcasting Corporation */
#ifndef NICKEL_COMMON_MACROS_H_
#define NICKEL_COMMON_MACROS_H_

#define NS_NICKEL_OPEN namespace nickel {
#define NS_NICKEL_CLOSE }
#define NS_NICKEL ::nickel

#endif
