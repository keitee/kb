/* 
 * File:   NickelProfiler.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 2 August 2013
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_COMMON_NICKELPROFILER_H_
#define NICKEL_COMMON_NICKELPROFILER_H_

#include "macros.h"
#include <zinc-common/profile/Profile.h>

NS_NICKEL_OPEN

#ifdef ENABLE_NICKEL_PROFILER

const char * const profilerName = "nickel.profiler";

extern boost::shared_ptr<NS_ZINC::Profiler> profiler;

#define NICKEL_PROFILE_FUNC  ZINC_PROFILE_FUNC(NS_NICKEL::profilerName)
#define NICKEL_PROFILE_SCOPE(name) ZINC_PROFILE_SCOPE(NS_NICKEL::profilerName, (name))

#else

#define NICKEL_PROFILE_FUNC
#define NICKEL_PROFILE_SCOPE(name)

#endif

NS_NICKEL_CLOSE


#endif /* NICKEL_COMMON_NICKELPROFILER_H_ */
