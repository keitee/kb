/* Copyright (C) 2010 British Broadcasting Corporation */

#ifndef NICKEL_COMMON_NICKELLOGGER_H_
#define NICKEL_COMMON_NICKELLOGGER_H_

#include "macros.h"

#include <zinc-common/Logger.h>

ZINC_DECLARE_LOGGER(nickel);

#define NICKEL_FUNC_TRACE ZINC_FUNC_TRACE(ZINC_GET_LOGGER(nickel))
#define NICKEL_FUNC_DEBUG ZINC_FUNC_DEBUG(ZINC_GET_LOGGER(nickel))

#define NICKEL_SCOPE_TRACE(a) ZINC_SCOPE_TRACE(ZINC_GET_LOGGER(nickel), a)
#define NICKEL_SCOPE_DEBUG(a) ZINC_SCOPE_DEBUG(ZINC_GET_LOGGER(nickel), a)

#define NICKEL_TRACE(a) ZINC_TRACE(ZINC_GET_LOGGER(nickel), a)
#define NICKEL_DEBUG(a) ZINC_DEBUG(ZINC_GET_LOGGER(nickel), a)
#define NICKEL_INFO(a) ZINC_INFO(ZINC_GET_LOGGER(nickel), a)
#define NICKEL_WARN(a) ZINC_WARN(ZINC_GET_LOGGER(nickel), a)
#define NICKEL_ERROR(a) ZINC_ERROR(ZINC_GET_LOGGER(nickel), a)
#define NICKEL_FATAL(a) ZINC_FATAL(ZINC_GET_LOGGER(nickel), a)

#endif
