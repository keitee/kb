/* 
 * File:   NickelProfiler.cpp
 * Author: hubert.lacote@youview.com
 *
 * Created on 2 August 2013
 * 
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "../include/NickelProfiler.h"

NS_NICKEL_OPEN

#ifdef ENABLE_NICKEL_PROFILER
boost::shared_ptr<NS_ZINC::Profiler> profiler = ZINC_CREATE_PROFILER(profilerName);
#endif

NS_NICKEL_CLOSE
