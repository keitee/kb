/*
 * SystemAudioOutput.h
 *
 *  Created on: Jun 6, 2010
 *      Author: zbigniew.mandziejewicz@youview.com 
 *
 *   Copyright (C) 2010 Youview TV 
 */

#ifndef NICKEL_CLIENT_SYSTEM_SYSTEMAUDIOOUTPUT_H_
#define NICKEL_CLIENT_SYSTEM_SYSTEMAUDIOOUTPUT_H

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/EnumConv.h>

#include <boost/shared_ptr.hpp>

NS_NICKEL_CLIENT_OPEN

typedef std::vector<AudioFormat::Enum> AudioFormats;

class SystemAudioOutput: public NS_NICKEL_CLIENT::AudioOutput
{
public:
	SystemAudioOutput(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager, const uint32_t id, const AudioOutputType::Enum outputType);

    virtual ~SystemAudioOutput();

	virtual AudioOutputType::Enum getType() const;
	virtual AudioFormats getFormats() const;
	virtual AudioFormat::Enum getFormatPreference() const;
	virtual void setFormatPreference(const AudioFormat::Enum format);
	virtual int32_t getDelay() const;
	virtual void setDelay(const int32_t delay);

private:
	boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> _manager;
	uint32_t _id;
	AudioOutputType::Enum _outputType;

}; // SystemAudioOutput

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::AudioOutputType, Enum,
	NS_NICKEL_CLIENT::AudioOutputType, Enum,
	(analogue_rca)
	(analogue_scart)
	(spdif)
	(hdmi)
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::AudioFormat, Enum,
	NS_NICKEL_CLIENT::AudioFormat, Enum,
	(analogue)
	(pcm_2ch)
	(pcm_5_1)
	(ac3)
	(dts)
	(e_ac3)
);

NS_NICKEL_CLIENT_CLOSE

#endif

