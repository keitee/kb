/*
 * SystemAspectRatio.h
 *
 *  Created on: Jun 6, 2010
 *      Author: zbigniew.mandziejewicz@youview.com 
 *
 *   Copyright (C) 2010 Youview TV 
 */

#ifndef NICKEL_CLIENT_SYSTEM_SYSTEMASPECTRATIO_H_
#define NICKEL_CLIENT_SYSTEM_SYSTEMASPECTRATIO_H_

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/EnumConv.h>

NS_NICKEL_CLIENT_OPEN

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::AspectRatio, Enum,
	NS_NICKEL_CLIENT::AspectRatio, Enum,
	(_4_3)
	(_16_9)
);

NS_NICKEL_CLIENT_CLOSE

#endif
