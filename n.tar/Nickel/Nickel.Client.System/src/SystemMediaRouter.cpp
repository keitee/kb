/* Copyright (C) 2009 British Broadcasting Corporation */

#include "SystemMediaRouter.h"
#include "SystemClientFactory.h"

#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/MediaRouterConvertToSync.h>
#include <nickel-system-api/DrmEventValue.h>
#include <nickel-system-api/TrackFormat.h>
#include <nickel-client-api/Track.h>
#include <zinc-common/EnumConv.h>
#include <nickel-system-api/BufferConstraint.h>
#include <nickel-system-api/AdaptiveMode.h>
#include <nickel-system-api/BufferMode.h>

#include <boost/make_shared.hpp>
#include <boost/foreach.hpp>

#include <stdexcept>
#include <iostream>

//using namespace NS_NICKEL_SYSTEM;
using namespace NS_ZINC;
using namespace std;


NS_NICKEL_CLIENT_OPEN

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::TrackFormat, Enum,
	NS_NICKEL_CLIENT::TrackFormat, Enum,
	(other)
	(audio_mpeg1l2)
	(audio_mpeg1l3)
	(audio_eac3)
	(audio_heaac)
	(video_mpeg2)
	(video_h264)
	(video_h265)
	(subtitle_dvb)
	(subtitle_ttml)
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::TrackType, Enum,
	NS_NICKEL_CLIENT::TrackType, Enum,
	(audio)
	(video)
	(subtitle)
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::TrackUsage, Enum,
	NS_NICKEL_CLIENT::TrackUsage, Enum,
	(undefined)
	(audio_normal)
	(audio_description)
	(audio_description_premixed)
	(subtitle_normal)
	(subtitle_hard_of_hearing)
);

ZINC_ENUM_IDENTITY(
		NS_NICKEL_SYSTEM::BufferConstraint, Enum,
		NS_NICKEL_CLIENT::BufferConstraint, Enum,
		(threshold)
		(unlimited)
		(fixed)
);

ZINC_ENUM_IDENTITY(
		NS_NICKEL_SYSTEM::AdaptiveMode, Enum,
		NS_NICKEL_CLIENT::AdaptiveMode, Enum,
		(repeat)
		(waitfordecision)
);

NS_NICKEL_CLIENT_CLOSE





namespace {
boost::shared_ptr<NS_NICKEL_CLIENT::Track> sysToCliTrack(const NS_NICKEL_SYSTEM::Track& sysTrack) {
    NICKEL_FUNC_TRACE;

    boost::shared_ptr<NS_NICKEL_CLIENT::Track> cliTrack = boost::make_shared<NS_NICKEL_CLIENT::Track>();

    cliTrack->setTag(sysTrack.tag);
    cliTrack->setLanguage(sysTrack.language);
    cliTrack->setFormat(NS_ZINC::enum_convert<NS_NICKEL_CLIENT::TrackFormat::Enum>(sysTrack.format));
    cliTrack->setType(NS_ZINC::enum_convert<NS_NICKEL_CLIENT::TrackType::Enum>(sysTrack.type));
    cliTrack->setUsage(NS_ZINC::enum_convert<NS_NICKEL_CLIENT::TrackUsage::Enum>(sysTrack.usage));

    return cliTrack;
}
} // namespace

NS_NICKEL_CLIENT_OPEN

SystemMediaRouter::SystemMediaRouter(boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter> mediaRouter) : router( mediaRouter ) {
    NICKEL_FUNC_TRACE;
}

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::SetSourceReason, Enum,
	NS_NICKEL_CLIENT::SetSourceReason, Enum,
	(unspecified)
	(mhegstandard)
	(mhegquiet)
	(mhegnondestructive)
	(mhegnondestructivequiet)
);

void SystemMediaRouter::setSource(const std::string &source,const SetSourceReason::Enum reason) {
    NICKEL_FUNC_TRACE;
    try {
        router->setSource(source, NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::SetSourceReason::Enum>(reason)).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidLocator&) {
        throw InvalidLocator();
    } catch (const NS_NICKEL_SYSTEM::InvalidEnumeration&) {
        throw InvalidEnumeration();
    } catch (const NS_NICKEL_SYSTEM::IllegalReconfiguration&) {
        throw IllegalReconfiguration();
    }
}

void SystemMediaRouter::setAudioTrack(const int32_t tag) {
    NICKEL_FUNC_TRACE;
    try {
        router->setAudioTrack(tag).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidTag&) {
        throw InvalidTag();
    }
}

boost::shared_ptr<NS_NICKEL_CLIENT::Track> SystemMediaRouter::getAudioTrack() const
{
    NICKEL_FUNC_TRACE;

    return sysToCliTrack(router->getAudioTrack().get());
}

void SystemMediaRouter::setSubtitleTrack(const int32_t tag,const std::string& language) {
    NICKEL_FUNC_TRACE;

    try {
        router->setSubtitleTrack(tag,language).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidLanguage&) {
        throw InvalidLanguage();
    } catch (const NS_NICKEL_SYSTEM::InvalidTag&) {
        throw InvalidTag();
    }
}

boost::shared_ptr<NS_NICKEL_CLIENT::Track> SystemMediaRouter::getSubtitleTrack() const
{
    NICKEL_FUNC_TRACE;

    return sysToCliTrack(router->getSubtitleTrack().get());
}
void SystemMediaRouter::setSink(const std::string &sink) {
        NICKEL_FUNC_TRACE;
    try {
        router->setSink(sink).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidLocator&) {
        throw InvalidLocator();
    } catch (const NS_NICKEL_SYSTEM::IllegalReconfiguration&) {
        throw IllegalReconfiguration();
    }
}

void SystemMediaRouter::setPlaySpeed(const double speed) {
        NICKEL_FUNC_TRACE;
        NICKEL_TRACE("speed "<<speed);
        router->setPlaySpeed(speed).get();
}

double SystemMediaRouter::getPlaySpeed() const
{
        NICKEL_FUNC_TRACE;
        return router->getPlaySpeed().get();
}

std::string SystemMediaRouter::getSource() const
{
        NICKEL_FUNC_TRACE;
        return router->getSource().get();
}

std::string SystemMediaRouter::getSink() const
{
        NICKEL_FUNC_TRACE;
        return router->getSink().get();
}

int32_t SystemMediaRouter::getEndTime() const
{
    NICKEL_FUNC_TRACE;
    return router->getEndTime().get();
}

void SystemMediaRouter::setEndTime(const int32_t end) {
    NICKEL_FUNC_TRACE;
    try {
        router->setEndTime(end).get();
    } catch (const NS_NICKEL_SYSTEM::StopConflict&) {
        throw StopConflict();
    }
}

boost::shared_ptr<NS_NICKEL_CLIENT::Position> SystemMediaRouter::getPosition() const
{
        NICKEL_FUNC_TRACE;
        NS_NICKEL_SYSTEM::Position pos = router->getPosition().get();
        boost::shared_ptr<NS_NICKEL_CLIENT::Position> result = boost::make_shared<NS_NICKEL_CLIENT::Position>();
        result->setStart(pos.start);
        result->setCurrent(pos.current);
        result->setEnd(pos.end);
        return(result);
}


ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::SeekReference, Enum,
	NS_NICKEL_CLIENT::SeekReference, Enum,
	((start, sr_start))
	((current, sr_current))
	((end, sr_end))
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::SeekMode, Enum,
	NS_NICKEL_CLIENT::SeekMode, Enum,
	(prioritise_accuracy)
	(prioritise_speed)
);

void SystemMediaRouter::seekPosition(const SeekReference::Enum whence, const int32_t offset, const SeekMode::Enum mode) {
        NICKEL_FUNC_TRACE;
    try {
        router->seekPosition(
        	NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::SeekReference::Enum>(whence),
        	offset,
            NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::SeekMode::Enum>(mode)).get();
    } catch (const NS_NICKEL_SYSTEM::NotConfigured&) {
        throw NotConfigured();
    } catch (const NS_NICKEL_SYSTEM::StopConflict&) {
        throw StopConflict();
    } catch (const NS_NICKEL_SYSTEM::IllegalSeek&) {
        throw IllegalSeek();
    } catch (const NS_NICKEL_SYSTEM::InvalidEnumeration&) {
        throw InvalidEnumeration();
    }
}

void SystemMediaRouter::start() {
        NICKEL_FUNC_TRACE;
    try {
        router->start().get();
    } catch (const NS_NICKEL_SYSTEM::NotConfigured&) {
        throw NotConfigured();
    } catch (const NS_NICKEL_SYSTEM::PlayConflict&) {
        throw PlayConflict();
    } catch (const NS_NICKEL_SYSTEM::StopConflict&) {
        throw StopConflict();
    }
}

void SystemMediaRouter::startDeferred() {
        NICKEL_FUNC_TRACE;
    try {
        router->startDeferred().get();
    } catch (const NS_NICKEL_SYSTEM::NotConfigured&) {
        throw NotConfigured();
    } catch (const NS_NICKEL_SYSTEM::PlayConflict&) {
        throw PlayConflict();
    } catch (const NS_NICKEL_SYSTEM::StopConflict&) {
        throw StopConflict();
    }
}

void SystemMediaRouter::stop() {
	NICKEL_FUNC_TRACE;
	router->stop().get();
}

NS_ZINC::Future<void> SystemMediaRouter::stopAsync() {
    NICKEL_FUNC_TRACE;
    return router->stop();
}

boost::shared_ptr<std::map<std::string,std::string> > SystemMediaRouter::getSourceInformation() const
{
	NICKEL_FUNC_TRACE;
	return boost::make_shared<std::map<std::string,std::string> >(router->getSourceInformation().get());
}

NS_ZINC::Future<std::map<std::string,std::string> > SystemMediaRouter::getSourceInformationAsync() const
{
	NICKEL_FUNC_TRACE;
	/* Technically speaking I should create a new Promise/Future pair here
	   using this MediaRouter's dispatcher but clients will always be providing
	   their own dispatchers to setCallabck and we're hoping to remove the
	   dispatcher from the Promise side soon anyway. */
	return router->getSourceInformation();
}

boost::shared_ptr<NS_NICKEL_CLIENT::BufferStatus> SystemMediaRouter::getBufferStatus() const
{
    NICKEL_FUNC_TRACE;
    try {
        boost::shared_ptr<NS_NICKEL_CLIENT::BufferStatus> buffer(new NS_NICKEL_CLIENT::BufferStatus);
        NS_NICKEL_SYSTEM::BufferStatus sysBuffer = router->getBufferStatus().get();
        buffer->setBufferedBytes(sysBuffer.bufferedBytes);
        buffer->setTotalBytesRemaining(sysBuffer.totalBytesRemaining);
        buffer->setTotalStreamBytes(sysBuffer.totalStreamBytes);
        buffer->setArrivalBytesPerSecond(sysBuffer.arrivalBytesPerSecond);
        buffer->setStreamBytesPerSecond(sysBuffer.streamBytesPerSecond);
        buffer->setBufferedMilliseconds(sysBuffer.bufferedMilliseconds);
        return buffer;
    } catch (const NS_NICKEL_SYSTEM::NotApplicable&) {
        throw NotApplicable();
    }
}

void SystemMediaRouter::startBuffering() {
    NICKEL_FUNC_TRACE;
    try {
        router->startBuffering().get();
    } catch (const NS_NICKEL_SYSTEM::NotConfigured&) {
        throw NotConfigured();
    } catch (const NS_NICKEL_SYSTEM::StopConflict&) {
        throw StopConflict();
    }
}

void SystemMediaRouter::stopBuffering() {
    NICKEL_FUNC_TRACE;
        router->stopBuffering().get();
}


ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::BufferStatusEventValue, Enum,
	NS_NICKEL_CLIENT::BufferStatusEventValue, Enum,
	(buffering_started)
	(reserved_1)
	(buffering_complete)
	(reserved_3)
	(abr_segment_complete)
);

void SystemMediaRouter::BufferStatusEvent(const NS_NICKEL_SYSTEM::BufferStatusEventValue::Enum event_) {
    NICKEL_FUNC_TRACE;

    produceEvent( boost::bind(&NS_NICKEL_CLIENT::MediaRouterEventListener::BufferStatusEvent, _1, NS_ZINC::enum_convert<BufferStatusEventValue::Enum>(event_) ) );
}


ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::DrmEventValue, Enum,
	NS_NICKEL_CLIENT::DrmEventValue, Enum,
	((licence_required, licence_required))
	((system_error, system_error))
	((bad_request, bad_request))
	((server_unreachable, server_unreachable))
	((server_denied, server_denied))
	((bad_server_response, bad_server_response))
	((bad_content_format, bad_content_format))
	((unmet_licence_requirement, unmet_licence_requirement))
	((licence_format_error, licence_format_error))
	((missing_credentials, missing_credentials))
	((expired, expired))
	((play_count_exceeded, play_count_exceeded))
	((subscription_expired, subscription_expired))
	((other, other_drm_event))
);

void SystemMediaRouter::DrmEvent(const NS_NICKEL_SYSTEM::DrmEventValue::Enum event,const std::string& drmMediaIdentifier,const std::string& rightsIssuerUrl) {
    NICKEL_FUNC_TRACE;

    produceEvent( boost::bind(&NS_NICKEL_CLIENT::MediaRouterEventListener::DrmEvent, _1, NS_ZINC::enum_convert<DrmEventValue::Enum>(event) ,drmMediaIdentifier,rightsIssuerUrl) );
}

void SystemMediaRouter::PositionChangeEvent(const NS_NICKEL_SYSTEM::Position& position) {
        NICKEL_FUNC_TRACE;
        boost::shared_ptr<NS_NICKEL_CLIENT::Position> clientPosition = boost::make_shared<NS_NICKEL_CLIENT::Position>();
        clientPosition->setStart(position.start);
        clientPosition->setCurrent(position.current);
        clientPosition->setEnd(position.end);

        produceEvent(  boost::bind(&NS_NICKEL_CLIENT::MediaRouterEventListener::PositionChangeEvent, _1, clientPosition) );
}


ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::SourceEventValue, Enum,
	NS_NICKEL_CLIENT::SourceEventValue, Enum,
	(change_initiated)
	(change_complete)
	(source_information_change)
	(source_config_complete)
	(tracks_changed)
);

void SystemMediaRouter::SourceEvent(const NS_NICKEL_SYSTEM::SourceEventValue::Enum event_, const NS_NICKEL_SYSTEM::SetSourceReason::Enum reason_) {
    NICKEL_FUNC_TRACE;

    produceEvent( boost::bind(&NS_NICKEL_CLIENT::MediaRouterEventListener::SourceEvent, _1, NS_ZINC::enum_convert<SourceEventValue::Enum>(event_), NS_ZINC::enum_convert<SetSourceReason::Enum>(reason_)) );
}

void SystemMediaRouter::SpeedChangeEvent() {
    NICKEL_FUNC_TRACE;

    produceEvent( boost::bind(&NS_NICKEL_CLIENT::MediaRouterEventListener::SpeedChangeEvent, _1) );
}

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::StatusEventValue, Enum,
	NS_NICKEL_CLIENT::StatusEventValue, Enum,
	(started)
	(complete)
	(waiting)
	(stopped)
	(underflow)
	(seek_started)
);

void SystemMediaRouter::StatusEvent(const NS_NICKEL_SYSTEM::StatusEventValue::Enum event_) {
    NICKEL_FUNC_TRACE;

    produceEvent(  boost::bind(&NS_NICKEL_CLIENT::MediaRouterEventListener::StatusEvent, _1, NS_ZINC::enum_convert<StatusEventValue::Enum>(event_)) );
}


ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::ErrorEventValue, Enum,
	NS_NICKEL_CLIENT::ErrorEventValue, Enum,
	((other, other_error_event))
	((locator, locator))
	((tag, tag))
	((language, language))
	((linear_selection, linear_selection))
	((network, network))
	((server, server))
	((data, data))
);

ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::ErrorEventContext, Enum,
	NS_NICKEL_CLIENT::ErrorEventContext, Enum,
	((other, other_error_context))
	((source, source))
	((video_track, video_track))
	((audio_track, audio_track))
	((subtitle_track, subtitle_track))
	((index_file, index_file))
	((subtitle_file, subtitle_file))
	((sdp_file, sdp_file))
);

void SystemMediaRouter::ErrorEvent(const NS_NICKEL_SYSTEM::ErrorEventValue::Enum error,
            const NS_NICKEL_SYSTEM::ErrorEventContext::Enum context,
            const std::string& info)
{
    NICKEL_FUNC_TRACE;

    produceEvent(boost::bind(&NS_NICKEL_CLIENT::MediaRouterEventListener::ErrorEvent,
            _1,
            NS_ZINC::enum_convert<ErrorEventValue::Enum>(error),
            NS_ZINC::enum_convert<ErrorEventContext::Enum>(context),
            info));
}

void SystemMediaRouter::setVolume(const int32_t volume) {
    NICKEL_FUNC_TRACE;
    try {
        router->setVolume(volume).get();
    } catch (const NS_NICKEL_SYSTEM::OutOfBounds&) {
        throw OutOfBounds();
    }
}

int32_t SystemMediaRouter::getVolume() const
{
    NICKEL_FUNC_TRACE;
    return router->getVolume().get();
}

void SystemMediaRouter::setAudioTrackExternal(const std::string& mediaLocator,const int32_t tag) {
    NICKEL_FUNC_TRACE;
    try {
        router->setAudioTrackExternal(mediaLocator,tag).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidLocator&) {
        throw InvalidLocator();
    } catch (const NS_NICKEL_SYSTEM::InvalidTag&) {
        throw InvalidTag();
    }
}

void SystemMediaRouter::setVideoTrack(const int32_t tag) {
    NICKEL_FUNC_TRACE;
    try {
        router->setVideoTrack(tag).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidTag&) {
        throw InvalidTag();
    }
}

void SystemMediaRouter::setVideoTrackExternal(const std::string& mediaLocator,const int32_t tag) {
    NICKEL_FUNC_TRACE;
    try {
        router->setVideoTrackExternal(mediaLocator,tag).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidLocator&) {
        throw InvalidLocator();
    } catch (const NS_NICKEL_SYSTEM::InvalidTag&) {
        throw InvalidTag();
    }
}

boost::shared_ptr<Track> SystemMediaRouter::getVideoTrack() const
{
    NICKEL_FUNC_TRACE;
    return sysToCliTrack(router->getVideoTrack().get());
}

int32_t SystemMediaRouter::addSubtitleTrack(const std::string& subtitleLocator) {
    NICKEL_FUNC_TRACE
    try {
        return router->addSubtitleTrack(subtitleLocator).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidLocator&) {
        throw InvalidLocator();
    }
}

boost::shared_ptr<std::vector<boost::shared_ptr<Track> > > SystemMediaRouter::getTracks() const
{
    NICKEL_FUNC_TRACE;
    std::vector<NS_NICKEL_SYSTEM::Track> sysTracks = router->getTracks().get();
    boost::shared_ptr<std::vector<boost::shared_ptr<Track> > > cliTracks = boost::make_shared<std::vector<boost::shared_ptr<Track> > >();
    cliTracks->reserve(sysTracks.size());
    BOOST_FOREACH(const NS_NICKEL_SYSTEM::Track& t, sysTracks) {
        cliTracks->push_back(sysToCliTrack(t));
    }
    return cliTracks;
}

void SystemMediaRouter::setVideoWindow(boost::shared_ptr<VideoWindowDescriptor> videoWindow) {
    NICKEL_FUNC_TRACE;
    NS_NICKEL_SYSTEM::VideoWindowDescriptor sysVW = NS_NICKEL_SYSTEM::VideoWindowDescriptor();
    if(videoWindow) {
        sysVW.sourceX = videoWindow->getSourceX();
        sysVW.sourceY = videoWindow->getSourceY();
        sysVW.sourceWidth = videoWindow->getSourceWidth();
        sysVW.sourceHeight = videoWindow->getSourceHeight();
        sysVW.destinationX = videoWindow->getDestinationX();
        sysVW.destinationY = videoWindow->getDestinationY();
        sysVW.destinationWidth = videoWindow->getDestinationWidth();
        sysVW.destinationHeight = videoWindow->getDestinationHeight();
    }
    try {
        router->setVideoWindow(sysVW).get();
    } catch (const NS_NICKEL_SYSTEM::OutOfBounds&) {
        throw OutOfBounds();
    }
}

boost::shared_ptr<VideoWindowDescriptor> SystemMediaRouter::getVideoWindow() const
{
    NICKEL_FUNC_TRACE;
    boost::shared_ptr<VideoWindowDescriptor> cliVW(new VideoWindowDescriptor());
    NS_NICKEL_SYSTEM::VideoWindowDescriptor sysVW(router->getVideoWindow().get());
    cliVW->setSourceX(sysVW.sourceX);
    cliVW->setSourceY(sysVW.sourceY);
    cliVW->setSourceWidth(sysVW.sourceWidth);
    cliVW->setSourceHeight(sysVW.sourceHeight);
    cliVW->setDestinationX(sysVW.destinationX);
    cliVW->setDestinationY(sysVW.destinationY);
    cliVW->setDestinationWidth(sysVW.destinationWidth);
    cliVW->setDestinationHeight(sysVW.destinationHeight);
    return cliVW;
}

boost::shared_ptr<ControlCapabilities> SystemMediaRouter::getControlCapabilities() const
{
    NICKEL_FUNC_TRACE;
    boost::shared_ptr<ControlCapabilities> cliCC(new ControlCapabilities());
    NS_NICKEL_SYSTEM::ControlCapabilities sysCC(router->getControlCapabilities().get());
    cliCC->setFastForwardRange(boost::make_shared<std::vector<int32_t> >(sysCC.fastForwardRange));
    cliCC->setFastReverseRange(boost::make_shared<std::vector<int32_t> >(sysCC.fastReverseRange));
    cliCC->setSlowSpeeds(boost::make_shared<std::vector<double> >(sysCC.slowSpeeds));
    return cliCC;
}


ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::VideoTerminationMode, Enum,
	NS_NICKEL_CLIENT::VideoTerminationMode, Enum,
	(freeze)
	(disappear)
);

VideoTerminationMode::Enum SystemMediaRouter::getVideoTerminationMode() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::enum_convert<VideoTerminationMode::Enum>(router->getVideoTerminationMode().get());
}

void SystemMediaRouter::setVideoTerminationMode(const VideoTerminationMode::Enum mode) {
    NICKEL_FUNC_TRACE;
    try {
        router->setVideoTerminationMode( NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::VideoTerminationMode::Enum>(mode)).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidEnumeration&) {
        throw InvalidEnumeration();
    }
}

boost::shared_ptr<std::map< std::string, std::string > > SystemMediaRouter::getBufferingMode() const
{
    NICKEL_FUNC_TRACE;
    return boost::shared_ptr<std::map< std::string, std::string > >(new std::map< std::string, std::string >(router->getBufferingMode().get()));
}

void SystemMediaRouter::setBufferingMode(boost::shared_ptr<std::map<std::string,std::string> > bufferingMode) {
    NICKEL_FUNC_TRACE;
    router->setBufferingMode(*bufferingMode).get();
}

void SystemMediaRouter::setBufferConstraint( BufferConstraint::Enum bufferConstraint )
{
	std::map<std::string,std::string> bm;
	bm[ NS_NICKEL_SYSTEM::BufferMode::BUFFER_CONSTRAINT ] = enum_to_string( NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::BufferConstraint::Enum>( bufferConstraint ) );
	router->setBufferingMode( bm ).get();
}

BufferConstraint::Enum SystemMediaRouter::getBufferConstraint()
{
	std::map<std::string,std::string> bm = router->getBufferingMode().get();
	NS_NICKEL_SYSTEM::BufferConstraint::Enum bc = NS_NICKEL_SYSTEM::BufferConstraint::threshold;
	enum_from_string( bc, bm[ NS_NICKEL_SYSTEM::BufferMode::BUFFER_CONSTRAINT ].c_str() ); // ignore error
	return NS_ZINC::enum_convert<BufferConstraint::Enum>(bc);
}

void SystemMediaRouter::setBufferAdaptiveMode( AdaptiveMode::Enum adaptiveMode )
{
	std::map<std::string,std::string> bm;
	bm[ NS_NICKEL_SYSTEM::BufferMode::ADAPTIVE_MODE ] = enum_to_string( NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::AdaptiveMode::Enum>( adaptiveMode ) );
	router->setBufferingMode( bm ).get();
}

AdaptiveMode::Enum SystemMediaRouter::getBufferAdaptiveMode()
{
	std::map<std::string,std::string> bm = router->getBufferingMode().get();
	NS_NICKEL_SYSTEM::AdaptiveMode::Enum am = NS_NICKEL_SYSTEM::AdaptiveMode::repeat;
	enum_from_string( am, bm[ NS_NICKEL_SYSTEM::BufferMode::ADAPTIVE_MODE ].c_str() ); // ignore error
	return NS_ZINC::enum_convert<AdaptiveMode::Enum>(am);
}


void SystemMediaRouter::setMediaDuration(const int32_t duration)
{
    NICKEL_FUNC_TRACE;
    try {
        router->setMediaDuration(duration).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidDuration&) {
        throw InvalidDuration();
    }
}

int32_t SystemMediaRouter::getMediaDuration() const
{
    NICKEL_FUNC_TRACE;
    return router->getMediaDuration().get();
}

boost::shared_ptr<ABRStreamSet> SystemMediaRouter::getABRStreamSet() const
{
    NICKEL_FUNC_TRACE;
    boost::shared_ptr<ABRStreamSet> ass(new ABRStreamSet());
    NS_NICKEL_SYSTEM::ABRStreamSet sysAss = router->getABRStreamSet().get();
    ass->setStreamCount(sysAss.streamCount);
    ass->setStreamBitrates(boost::shared_ptr<std::vector< int32_t > >(new std::vector< int32_t >(sysAss.streamBitrates)));
    ass->setStreamCharacteristics(boost::shared_ptr<std::map< std::string, std::string > >(
                new std::map< std::string, std::string >(sysAss.streamCharacteristics)));
    return ass;
}

boost::shared_ptr<ABRStatus> SystemMediaRouter::getABRStatus() const
{
    NICKEL_FUNC_TRACE;
    boost::shared_ptr<ABRStatus> as(new ABRStatus());
    NS_NICKEL_SYSTEM::ABRStatus sysAs = router->getABRStatus().get();
    as->setStreamIndex(sysAs.streamIndex);
    as->setSegmentIndex(sysAs.segmentIndex);
    as->setExistingSegment(sysAs.existingSegment);
    as->setSegmentDuration(sysAs.segmentDuration);
    as->setNextSegmentDuration(sysAs.nextSegmentDuration);
    as->setDurationAcquired(sysAs.durationAcquired);
    as->setArrivalBitrate(sysAs.arrivalBitrate);
    as->setLastSegmentBitrate(sysAs.lastSegmentBitrate);
    as->setBufferedMilliseconds(sysAs.bufferedMilliseconds);
    return as;
}

void SystemMediaRouter::setABRStream(const int32_t streamIndex, const bool deferred)
{
    NICKEL_FUNC_TRACE;
    try {
        router->setABRStream(streamIndex,deferred).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidStreamIndex&) {
        throw InvalidStreamIndex();
    }
}

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::TimeShiftCaptureMode, Enum,
	NS_NICKEL_CLIENT::TimeShiftCaptureMode, Enum,
	(disabled)
	(enabled)
);

void SystemMediaRouter::setCaptureMode(const TimeShiftCaptureMode::Enum mode)
{
    NICKEL_FUNC_TRACE;
    try {
        router->setCaptureMode(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::TimeShiftCaptureMode::Enum>(mode)).get();
    } catch (const NS_NICKEL_SYSTEM::InvalidEnumeration&) {
        throw InvalidEnumeration();
    }
}

TimeShiftCaptureMode::Enum SystemMediaRouter::getCaptureMode() const
{
    NICKEL_FUNC_TRACE;
    return NS_ZINC::enum_convert<TimeShiftCaptureMode::Enum>(router->getCaptureMode().get());
}

boost::shared_ptr<MediaRouter> wrapSystemRouter(boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter> sysRouter,
                                                boost::shared_ptr<EventDispatcher> dispatcher)
{
    NICKEL_FUNC_DEBUG;
    boost::shared_ptr<SystemMediaRouter> cliSysRouter = boost::make_shared<SystemMediaRouter>(sysRouter);
    cliSysRouter->setDispatcher(dispatcher);
    sysRouter->addListener(cliSysRouter);
    NICKEL_DEBUG("cli "<<cliSysRouter<<" sys "<<sysRouter);
    return cliSysRouter;
}

boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter> unwrapSystemRouter(boost::shared_ptr<MediaRouter> cliSysRouter)
{
    boost::shared_ptr<SystemMediaRouter> smr = boost::dynamic_pointer_cast<SystemMediaRouter>(cliSysRouter);
    if (!smr)
    {
        return boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter>();
    }
    return smr->router;
}


void SystemMediaRouter::recycle()
{
    NICKEL_FUNC_TRACE;
    router->recycle().get();
}

NS_NICKEL_CLIENT_CLOSE

