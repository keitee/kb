/*
 * SystemClientFactory.cpp
 *
 *  Created on: Mar 27, 2009
 *      Author: jsadler
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#include "SystemClientFactory.h"
#include "SystemClientLocator.h"
#include "SystemMediaRouter.h"
#include "SystemMediaRouterFactory.h"
#include "SystemMediaSettings.h"
#include "SystemOutputManager.h"
#include "SystemAudioFeedback.h"
#include "SystemServiceListBuilder.h"

#include <copper-system-api/LocalStorageRepositoryConvertToSync.h>
#include <copper-system-api/LocalStorageRepositorySync.h>
#include <copper-system-api/LSRHelpers.h>
#include <copper-system-api/Registry.h>
#include <copper-system-api/SystemFactory.h>

#include <nickel-system-api/nickel-system-api.h>
#include <zinc-common/zinc-common.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <nickel-system-api/MediaRouterFactoryConvertToSync.h>
#include <nickel-system-api/OutputManagerConvertToSync.h>
#include <nickel-audio-feedback/DBusClientFactory.h>

#include <boost/lexical_cast.hpp>

using namespace NS_ZINC;
using namespace std;
using NS_COPPER_SYSTEM::getLSRItem;

const char * const AUDIO_FEEDBACK_ENABLED_KEY = "platform.settings.audiofeedback.enabled";
const bool AUDIO_FEEDBACK_ENABLED_DEFAULT = false;

NS_NICKEL_CLIENT_OPEN

SystemClientFactory::SystemClientFactory() : defaultDispatcher(new MultipleListenerEventDispatcher()) {
}

SystemClientFactory::~SystemClientFactory() {}

boost::shared_ptr<EventDispatcher> SystemClientFactory::getDefaultDispatcher() const
{
    NICKEL_FUNC_TRACE;
    if (!defaultDispatcher.get())
        throw runtime_error("No default dispatcher set");
    return defaultDispatcher;
}

void SystemClientFactory::setDefaultDispatcher(boost::shared_ptr<EventDispatcher> dispatcher) {
    NICKEL_FUNC_TRACE;
    if (!dispatcher.get())
        throw invalid_argument("Dispatcher is null");
    defaultDispatcher = dispatcher;
}

boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouterFactory> SystemClientFactory::createMediaRouterFactory() {

    boost::mutex::scoped_lock lock(mutex);
    if(mediaRouterFactory == NULL) {
        NICKEL_FUNC_TRACE;
        boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouterFactorySync> sysMRFactory( convertToSync( getSystemFactory().createMediaRouterFactory() ) );
        boost::shared_ptr<NS_NICKEL_CLIENT::SystemMediaRouterFactory> cliMRFactory(new NS_NICKEL_CLIENT::SystemMediaRouterFactory(sysMRFactory, defaultDispatcher, *this));
        mediaRouterFactory = cliMRFactory;
    }
    return(mediaRouterFactory);
}

boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouter> SystemClientFactory::getDefaultMediaRouter() {

    boost::mutex::scoped_lock lock(mutex);
    if(defaultMediaRouter == NULL) {
        NICKEL_FUNC_TRACE;
        defaultMediaRouter = wrapSystemRouter(getSystemFactory().createDefaultMediaRouter(), defaultDispatcher);
    }
    return(defaultMediaRouter);
}

boost::shared_ptr<MediaSettings> SystemClientFactory::createMediaSettings() {
    boost::mutex::scoped_lock lock(mutex);
    if(mediaSettings == NULL) {
        NICKEL_FUNC_TRACE;
        boost::shared_ptr<NS_NICKEL_SYSTEM::MediaSettings> mediaSettingsService(getSystemFactory().createMediaSettings());
        boost::shared_ptr<NS_NICKEL_CLIENT::SystemMediaSettings> cliMS(new NS_NICKEL_CLIENT::SystemMediaSettings(mediaSettingsService));
        mediaSettings = cliMS;
        mediaSettingsService->addListener(cliMS);
        cliMS->setDispatcher(defaultDispatcher);
    }
    return(mediaSettings);
}

boost::shared_ptr<NS_NICKEL_CLIENT::OutputManager> SystemClientFactory::createOutputManager() {
    boost::mutex::scoped_lock lock(mutex);
    if(outputManager == NULL) {
        NICKEL_FUNC_TRACE;
        boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> outputManagerService( convertToSync( getSystemFactory().createOutputManager() ) );
        boost::shared_ptr<NS_NICKEL_CLIENT::SystemOutputManager> sysOM( new NS_NICKEL_CLIENT::SystemOutputManager(outputManagerService) );
        outputManager = sysOM;
        outputManagerService->addListener(sysOM);
        outputManager->setDispatcher(defaultDispatcher);
    }
    return(outputManager);
}

boost::shared_ptr<NS_NICKEL_CLIENT::ServiceListBuilder> SystemClientFactory::createServiceListBuilder() {
    boost::mutex::scoped_lock lock(mutex);
    if(serviceListBuilder == NULL) {
        NICKEL_FUNC_TRACE;
        boost::shared_ptr<NS_NICKEL_SYSTEM::ServiceListBuilder> serviceListBuilderService(getSystemFactory().createServiceListBuilder());
        boost::shared_ptr<NS_NICKEL_CLIENT::SystemServiceListBuilder> sysCliSLB(new NS_NICKEL_CLIENT::SystemServiceListBuilder(serviceListBuilderService));
        serviceListBuilder = sysCliSLB;
        serviceListBuilderService->addListener(sysCliSLB);
        serviceListBuilder->setDispatcher(defaultDispatcher);
    }
    return(serviceListBuilder);
}

boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> SystemClientFactory::createAudioFeedback()
{
    if (!audioFeedback) {
        bool enabled = getLSRItem< bool >(
            *createLocalStorageRepositorySync(),
            AUDIO_FEEDBACK_ENABLED_KEY, AUDIO_FEEDBACK_ENABLED_DEFAULT);
        audioFeedback =
            NS_NICKEL_AUDIO_CLIENT::createSystemAudioFeedback(
                NS_NICKEL_AUDIOFEEDBACK::create(defaultDispatcher), enabled);
    }
    return audioFeedback;
}

boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > SystemClientFactory::createLocalStorageRepositoryAsync()
{
    if (!localStorageRepositoryAsync)
    {
        localStorageRepositoryAsync = getCopperSystemFactory().createLocalStorageRepository();
    }
    return localStorageRepositoryAsync;
}

boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > SystemClientFactory::createLocalStorageRepositorySync()
{
    if (!localStorageRepositorySync)
    {
        localStorageRepositorySync = NS_COPPER_SYSTEM::convertToSync(createLocalStorageRepositoryAsync());
    }
    return localStorageRepositorySync;
}

NS_COPPER_SYSTEM::SystemFactory & SystemClientFactory::getCopperSystemFactory()
{
    NICKEL_FUNC_TRACE;
    std::string copperConfigFilePath(NS_ZINC::PackageDataFinder().find("copper-system-factory.plugin-config"));
    NICKEL_DEBUG("Factory::getCopperSystemFactory - Using configuration file: " << copperConfigFilePath);
    const NS_ZINC::FilePluginConfig pluginConfig(copperConfigFilePath);
    return NS_ZINC::PluginFactory::getInstance< NS_COPPER_SYSTEM::SystemFactory >(pluginConfig);
}

boost::shared_ptr<Locator> SystemClientFactory::createLocator() {
    NICKEL_FUNC_TRACE;
    static boost::shared_ptr<Locator> locator;
    if(!locator)
    {
        locator.reset(
            new SystemClientLocator(
                createMediaRouterFactory(),
                createMediaSettings(),
                createOutputManager(),
                createServiceListBuilder(),
                createAudioFeedback()
            )
        );
    }
    return locator;
}

Zinc::Media::SystemFactory& SystemClientFactory::getSystemFactory() {
    NICKEL_FUNC_TRACE;
    static const NS_ZINC::FilePluginConfig SYSTEM_FACTORY_PLUGIN_CONFIG(PackageDataFinder().find("nickel-system-factory.plugin-config"));
    return PluginFactory::getInstance<Zinc::Media::SystemFactory>(SYSTEM_FACTORY_PLUGIN_CONFIG);
}

NS_NICKEL_CLIENT_CLOSE

Plugin* createSystemClientFactory() {
    return new NS_NICKEL_CLIENT::SystemClientFactory();
}


