/*
 * SystemMediaSettins.cpp
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#include "SystemMediaSettings.h"
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-client-api/nickel-client-api.h>
#include <nickel-common/NickelLogger.h>

using namespace NS_NICKEL_CLIENT;

SystemMediaSettings::SystemMediaSettings(boost::shared_ptr<NS_NICKEL_SYSTEM::MediaSettings> mediaSettings_)
	:	mediaSettings(mediaSettings_)
{
	NICKEL_FUNC_TRACE;
}

bool SystemMediaSettings::getADEnabled() const
{
	NICKEL_FUNC_TRACE;
	return mediaSettings->getADEnabled().get();
}

void SystemMediaSettings::setADEnabled(bool value) {
	NICKEL_FUNC_TRACE;
	mediaSettings->setADEnabled(value).get();
}

bool SystemMediaSettings::getSubtitlesEnabled() const
{
	NICKEL_FUNC_TRACE;
	return mediaSettings->getSubtitlesEnabled().get();
}

void SystemMediaSettings::setSubtitlesEnabled(bool value) {
	NICKEL_FUNC_TRACE;
	mediaSettings->setSubtitlesEnabled(value).get();
}

std::string SystemMediaSettings::getPreferredAudioLanguage() const
{
	NICKEL_FUNC_TRACE;
	return mediaSettings->getPreferredAudioLanguage().get();
}

void SystemMediaSettings::setPreferredAudioLanguage(const std::string& value)
{
	NICKEL_FUNC_TRACE;
	mediaSettings->setPreferredAudioLanguage(value).get();
}

std::string SystemMediaSettings::getPreferredSubtitleLanguage() const
{
	NICKEL_FUNC_TRACE;
	return mediaSettings->getPreferredSubtitleLanguage().get();
}

void SystemMediaSettings::setPreferredSubtitleLanguage(const std::string& value)
{
	NICKEL_FUNC_TRACE;
	mediaSettings->setPreferredSubtitleLanguage(value).get();
}

void SystemMediaSettings::MediaSettingsChange() {
	NICKEL_FUNC_TRACE;

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::MediaSettingsListener::MediaSettingsChange, _1) );
}
