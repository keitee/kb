/*
 * SystemClientLocator.h
 *
 *  Created on: 8 Apr 2010
 *      Author: mark.nicoll1@bbc.co.uk
 *
 *  Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_SYSTEM_LOCATOR_H_
#define NICKEL_CLIENT_SYSTEM_LOCATOR_H_


#include <nickel-client-api/nickel-client-api.h>

#include <boost/shared_ptr.hpp>


NS_NICKEL_CLIENT_OPEN

class SystemClientLocator : virtual public Locator {

public:
	SystemClientLocator(
			boost::shared_ptr<MediaRouterFactory> mediaRouterFactory,
            boost::shared_ptr<MediaSettings> mediaSettings,
            boost::shared_ptr<OutputManager> outputManager,
            boost::shared_ptr<ServiceListBuilder> serviceListBuilder,
            boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> audioFeedback
            );

	boost::shared_ptr<MediaRouterFactory> getMediaRouterFactory() const;
	boost::shared_ptr<MediaSettings> getMediaSettings() const;
	boost::shared_ptr<OutputManager> getOutputManager() const;
	boost::shared_ptr<ServiceListBuilder> getServiceListBuilder() const;
	boost::shared_ptr<MediaRouter> getDefaultMediaRouter() const;
	boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> getAudioFeedback() const;

private:
	boost::shared_ptr<MediaRouterFactory> mediaRouterFactory;
	boost::shared_ptr<MediaSettings> mediaSettings;
	boost::shared_ptr<OutputManager> outputManager;
	boost::shared_ptr<ServiceListBuilder> serviceListBuilder;
	boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> audioFeedback;
};

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_SYSTEM_LOCATOR_H_ */
