/*
 * SystemOutputManager.cpp
 *
 *  Created on: Mar 3, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */


#include "SystemOutputManager.h"

#include "SystemAudioOutput.h"
#include "SystemHDMIDisplay.h"
#include "SystemAnalogueDisplay.h"

#include "SystemAspectRatio.h"
#include "SystemHDMIStatus.h"

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/nickel-system-exceptions.h>
#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/OutputManagerConvertToSync.h>

#include <boost/bind.hpp>
#include <boost/make_shared.hpp>

#include <zinc-common/EnumConv.h>
#include <nickel-common/NickelLogger.h>

using namespace NS_NICKEL_CLIENT;

NS_NICKEL_CLIENT_OPEN

// enum mappings

SystemOutputManager::SystemOutputManager(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager): _manager(manager)
{
	NICKEL_FUNC_TRACE;
}

void SystemOutputManager::incVolume()
{
	NICKEL_FUNC_TRACE;
	_manager->incVolume();
}

void SystemOutputManager::decVolume()
{
	NICKEL_FUNC_TRACE;
	_manager->decVolume();
}

int32_t SystemOutputManager::getVolume() const
{
	NICKEL_FUNC_TRACE;
	return _manager->getVolume();
}

void SystemOutputManager::setVolume(int32_t volume)
{
	NICKEL_FUNC_TRACE;

    try
    {
        _manager->setVolume(volume);
    }
    catch(const NS_NICKEL_SYSTEM::OutOfBounds&)
    {
        throw OutOfBounds();
    }
}

void SystemOutputManager::muteVolume()
{
	NICKEL_FUNC_TRACE;
	_manager->muteVolume();
}

void SystemOutputManager::unmuteVolume()
{
	NICKEL_FUNC_TRACE;
	_manager->unmuteVolume();
}

bool SystemOutputManager::isMuted() const
{
	NICKEL_FUNC_TRACE;
	return _manager->isMuted();
}

DisplayType::Enum SystemOutputManager::getPrimaryDisplayPreference() const
{
	NICKEL_FUNC_TRACE;
	return NS_ZINC::enum_convert<DisplayType::Enum>(_manager->getPrimaryDisplayPreference());
}

void SystemOutputManager::setPrimaryDisplayPreference(const DisplayType::Enum preference)
{
	NICKEL_FUNC_TRACE;
	_manager->setPrimaryDisplayPreference(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::DisplayType::Enum>(preference));
}

void SystemOutputManager::disableOutputs() {
	NICKEL_FUNC_TRACE;
	_manager->disableOutputs();
}

void SystemOutputManager::enableOutputs() {
	NICKEL_FUNC_TRACE;
	_manager->enableOutputs();
}

DisplayResolution::Enum SystemOutputManager::getPrimaryDisplayResolution() const
{
	NICKEL_FUNC_TRACE;
	return NS_ZINC::enum_convert<DisplayResolution::Enum>(_manager->getPrimaryDisplayResolution());
}

AspectRatio::Enum SystemOutputManager::getPrimaryDisplayAspectRatio() const
{
	NICKEL_FUNC_TRACE;
	return NS_ZINC::enum_convert<AspectRatio::Enum>(_manager->getPrimaryDisplayAspectRatio());
}

int32_t SystemOutputManager::getRelativeADVolume() const
{
	NICKEL_FUNC_TRACE;
    return _manager->getRelativeADVolume();
}

void SystemOutputManager::setRelativeADVolume(const int32_t vol)
{
	NICKEL_FUNC_TRACE;

    try
    {
        _manager->setRelativeADVolume(vol);
    }
    catch(const NS_NICKEL_SYSTEM::OutOfBounds&)
    {
        throw OutOfBounds();
    }
}

VideoConversions SystemOutputManager::getVideoConversionPreference() const
{
	NICKEL_FUNC_TRACE;

	NS_NICKEL_SYSTEM::VideoConversions source = _manager->getVideoConversionPreference();

	return VideoConversions(
        NS_ZINC::enum_convert<Conversion_4_3_To_16_9::Enum>(source.standardToWide),
        NS_ZINC::enum_convert<Conversion_16_9_To_4_3::Enum>(source.wideToStandard));
}

void SystemOutputManager::setVideoConversionPreference(const VideoConversions preference)
{
	NICKEL_FUNC_TRACE;
	NS_NICKEL_SYSTEM::VideoConversions value;

    enum_convert(preference.getStandardToWide(), value.standardToWide);
    enum_convert(preference.getWideToStandard(), value.wideToStandard);

	_manager->setVideoConversionPreference(value);
};

GraphicsResolution SystemOutputManager::getGraphicsLayerResolution() const
{
	NICKEL_FUNC_TRACE;
	NS_NICKEL_SYSTEM::GraphicsResolution source = _manager->getGraphicsLayerResolution();
	return GraphicsResolution(source.width, source.height);
};

ADRouting::Enum SystemOutputManager::getADRouting() const
{
	NICKEL_FUNC_TRACE;
	return NS_ZINC::enum_convert<ADRouting::Enum>(_manager->getADRouting());
}

void SystemOutputManager::setADRouting(const ADRouting::Enum routing)
{
	NICKEL_FUNC_TRACE;
	_manager->setADRouting(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::ADRouting::Enum>(routing));
};

namespace
{
template <typename SourceT, typename DestT>
struct ConvertEnumWrapper
{
	DestT operator()(const SourceT source)
	{
		return NS_ZINC::enum_convert<DestT>(source);
	}
};

/**
 * Utility for converting iterables containing enums
 *
 * Free function convert_enum(const SourceT, DestT&) must be available in translation unit
 */
template <typename DestT, typename SourceT>
DestT convert_enum_iterable(const SourceT& source)
{
	DestT dest;
	dest.reserve(source.size());
	std::transform(source.begin(), source.end(), std::back_inserter(dest), ConvertEnumWrapper<typename SourceT::value_type, typename DestT::value_type>());
	return dest;
};

typedef std::map<uint32_t, NS_NICKEL_SYSTEM::AudioOutputType::Enum> SystemAudioOutputs;
class TransformAudioOutput
{
public:
	TransformAudioOutput(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager): _manager(manager) { }

	boost::shared_ptr<AudioOutput> operator()(const SystemAudioOutputs::value_type& value)
	{
		AudioOutputType::Enum outputType = NS_ZINC::enum_convert<AudioOutputType::Enum>(value.second);
		return boost::make_shared<SystemAudioOutput>(_manager, value.first, outputType);
	};

private:
	boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> _manager;

}; // TransformAudioOutput

/**
 * Create Client.API AudioOutput for given System.API output id.
 *
 * @param manager System.API output manager
 * @param id System.API Audio output id
 */
boost::shared_ptr<AudioOutput> createAudioOutput(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager, uint32_t id)
{
    const SystemAudioOutputs outputs = manager->getAudioOutputs();

    // search for pair in which .first matches outputId
    SystemAudioOutputs::const_iterator iter = std::find_if(
        outputs.begin(),
        outputs.end(),
        boost::bind(&SystemAudioOutputs::value_type::first, _1) == id
    );

    if(iter == outputs.end())
    {
        throw InvalidOutput();
    };

    return boost::make_shared<SystemAudioOutput>(manager, iter->first, NS_ZINC::enum_convert<AudioOutputType::Enum>(iter->second));
};

}; // anonymous namespace

AudioOutputs SystemOutputManager::getAudioOutputs() const
{
    NICKEL_FUNC_TRACE;

    SystemAudioOutputs source = _manager->getAudioOutputs();

    std::vector<boost::shared_ptr<AudioOutput> > dest;
    dest.reserve(source.size()); // reserve space for all elements

    std::transform(source.begin(), source.end(), std::back_inserter(dest), TransformAudioOutput(_manager)); // transform system audio outputs to client ones

    return dest;
};

boost::shared_ptr<HDMIDisplay> SystemOutputManager::getHDMIDisplay() const
{
	NICKEL_FUNC_TRACE;
    return boost::make_shared<SystemHDMIDisplay>(_manager);
};

boost::shared_ptr<AnalogueDisplay> SystemOutputManager::getAnalogueDisplay() const
{
	NICKEL_FUNC_TRACE;
    return boost::make_shared<SystemAnalogueDisplay>(_manager);
};

// EVENTS

void SystemOutputManager::OutputStatusEvent(const bool enabled)
{
	NICKEL_FUNC_TRACE;

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::OutputManagerEventListener::OutputStatusEvent, _1, enabled) );
}

void SystemOutputManager::AudioPreferenceChange(const uint32_t outputId)
{
	NICKEL_FUNC_TRACE;

    boost::shared_ptr<AudioOutput> output = createAudioOutput(_manager, outputId);

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::OutputManagerEventListener::AudioPreferenceChange, _1, output) );
}

void SystemOutputManager::DisplayPreferenceChange()
{
	NICKEL_FUNC_TRACE;

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::OutputManagerEventListener::DisplayPreferenceChange, _1) );
}

void SystemOutputManager::HDMICECEvent(const NS_NICKEL_SYSTEM::HDMICECEventType::Enum eventType)
{
	NICKEL_FUNC_TRACE;

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::OutputManagerEventListener::HDMICECEvent, _1, NS_ZINC::enum_convert<HDMICECEventType::Enum>(eventType)) );
}

void SystemOutputManager::HDMIEvent(const NS_NICKEL_SYSTEM::HDMIStatus::Enum status)
{
	NICKEL_FUNC_TRACE;

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::OutputManagerEventListener::HDMIEvent, _1, NS_ZINC::enum_convert<HDMIStatus::Enum>(status)) );
}

void SystemOutputManager::PrimaryDisplayChange() {
	NICKEL_FUNC_TRACE;

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::OutputManagerEventListener::PrimaryDisplayChange, _1) );
}

void SystemOutputManager::VolumeChange(const uint32_t volume, const bool muted) {
	NICKEL_FUNC_TRACE;

	produceEvent( boost::bind(&NS_NICKEL_CLIENT::OutputManagerEventListener::VolumeChange, _1, volume, muted) );
}

NS_NICKEL_CLIENT_CLOSE
