
#include "SystemClientFactory.h"

#include <nickel-client-api/nickel-client-api.h>
#include <boost/shared_ptr.hpp>
#include <iostream>

using namespace NS_NICKEL_CLIENT;
using namespace boost;
using namespace std;

const std::string HTTPURL1="http://blank.itv.com/IT2-01026-012-A_AIRLINE-USA_TX280709_Canvas_1500_4x3.ts";
const std::string HTTPURL2="http://blank.itv.com/1-7783-0006-001_BRITISH-TOURING-CAR-CHAMPIONSHIP_TX040809_Canvas_1500.ts";
const std::string HTTPURL3="http://blank.itv.com/1-0694-7134-001_CORONATION-STREET_TX030809_Canvas_1500.ts";
const std::string fileURL1="file:///media/data0/20090927_013500_bbctwo_inside_f1.ts";
const std::string fileURL2="file:///media/data0/1-7783-0006-001_BRITISH-TOURING-CAR-CHAMPIONSHIP_TX040809_Canvas_1500.ts";
const std::string badFileURL="file:///junk";
const std::string badHTTPURL="http:///junk";
const std::string badProtocolURL="ftp://junk";
const std::string badCharsURL="http://junk&sdsd&sfsdfsd#2342344?3434342345343452345#345345&&2342342342342342342342342334534555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555554234234234234234234234234234";

const int sleepTime=(getenv("NICKEL_MEDIA_ROUTER_TEST_SLEEP_TIME")?atol(getenv("NICKEL_MEDIA_ROUTER_TEST_SLEEP_TIME")):15);

shared_ptr<SystemClientFactory> factory(new SystemClientFactory());

void testGetAndSetSource() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testGetAndSetSource" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	string const expected = "http://www.bbc.co.uk/radio79";

	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());

	router->setSink("klaff");
	router->setSource(expected);
	std::cout << "getSource: " << router->getSource() << std::endl;

	string actual = router->getSource();
}

// These tests are taken from https://confluence-res.dev.bbc.co.uk/display/canvas/System+API+Acceptance+Test+-+Play+Media
void testScenarioPlayFileBasedMediaForValidFile() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testScenarioPlayFileBasedMediaForValidFile" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(fileURL1);
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testScenarioPlayHttpStreamedMediaForAValidStream() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testScenarioPlayHttpStreamedMediaForAValidStream" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(HTTPURL1);
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testStartVideoPlaying() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testStartVideoPlaying" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(HTTPURL2);
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	router->start();
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	std::cout << "Sleeping for " << sleepTime << " seconds while video playing" << std::endl;
	sleep(sleepTime);
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testStartVideo2Playing() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testStartVideo2Playing" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(HTTPURL1);
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	router->start();
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	std::cout << "Sleeping for " << sleepTime << " seconds while video playing" << std::endl;
	sleep(sleepTime);
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testStopVideoPlaying() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testStopVideoPlaying" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(HTTPURL3);
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	router->start();
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	std::cout << "Sleeping for " << sleepTime << " seconds while video playing" << std::endl;
	sleep(sleepTime);
	std::cout << "Stopping video now" << std::endl;
	router->stop();
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testChangePlaySpeed() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testChangePlaySpeed" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(HTTPURL1);
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	router->start();
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	std::cout << "Sleeping for " << sleepTime << " seconds while video playing" << std::endl;
	sleep(sleepTime);
	std::cout << "Changing speed to -1 now" << std::endl;
	router->setPlaySpeed(-1);
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	sleep(2);
	std::cout << "Changing speed to 2 now" << std::endl;
	router->setPlaySpeed(2);
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	sleep(2);
	std::cout << "Changing speed to 1 now" << std::endl;
	router->setPlaySpeed(1);
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	sleep(2);
	std::cout << "Stopping video now" << std::endl;
	router->stop();
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testStartVideoWhenNoSourceSet() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testStartVideoWhenNoSourceSet" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	std::cout << "calling start now" << std::endl;
	router->start();
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testStopVideoWhenNoSourceSet() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testStopVideoWhenNoSourceSet" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	std::cout << "calling stop now" << std::endl;
	router->stop();
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testPlayFileBasedMediaForAnInvalidFile() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testPlayFileBasedMediaForAnInvalidFile" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(badFileURL);
	std::cout << "getSource: " << router->getSource() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testPlayHttpStreamedMediaForAnInvalidResource() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testPlayHttpStreamedMediaForAnInvalidResource" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(badHTTPURL);
	std::cout << "getSource: " << router->getSource() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testPassingABadProtocolToSetSource() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testPassingABadProtocolToSetSource" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(badProtocolURL);
	std::cout << "getSource: " << router->getSource() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testPassingBadCharactersInURLToSetSource() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testPassingBadCharactersInURLToSetSource" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSink("klaff");
	router->setSource(badCharsURL);
	std::cout << "getSource: " << router->getSource() << std::endl;
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

void testPlayingAVideoWhenSetSinkHasNotBeenSetProperly() {
	std::cout << "**************************************************************************************" << std::endl;
	std::cout << "testPlayingAVideoWhenSetSinkHasNotBeenSetProperly" << std::endl;
	std::cout << "**************************************************************************************" << std::endl;
	boost::shared_ptr<MediaRouterFactory> mrf = factory->createMediaRouterFactory();
	shared_ptr<MediaRouter> router(mrf->createMediaRouter());
	router->setSource(HTTPURL3);
	std::cout << "getSource: " << router->getSource() << std::endl;
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	router->start();
	std::cout << "getPlaySpeed: " << router->getPlaySpeed() << std::endl;
	std::cout << "Sleeping for " << sleepTime << " seconds while video playing" << std::endl;
	sleep(sleepTime);
	// Set the URL to a bad URL and play to reset the media router to a blank screen at the end of the tests
	router->setSource(badFileURL);
	router->start();
	router->stop();
	mrf->destroyMediaRouter(router);
}

int main(int argc, char *argv[]) {
	testPlayingAVideoWhenSetSinkHasNotBeenSetProperly();
	testGetAndSetSource();
	testScenarioPlayFileBasedMediaForValidFile();
	testScenarioPlayHttpStreamedMediaForAValidStream();
	testStartVideoPlaying();
	testStartVideo2Playing();
	testStopVideoPlaying();
	testChangePlaySpeed();
	testStartVideoWhenNoSourceSet();
	testStopVideoWhenNoSourceSet();
	testPlayFileBasedMediaForAnInvalidFile();
	testPlayHttpStreamedMediaForAnInvalidResource();
	testPassingABadProtocolToSetSource();
	testPassingBadCharactersInURLToSetSource();
}
