/*
 * SystemOutputManager.h
 *
 *  Created on: Mar 3, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_SYSTEM_SSYSTEMOUTPUTMANAGER_H_
#define NICKEL_CLIENT_SYSTEM_SSYSTEMOUTPUTMANAGER_H_

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/EnumConv.h>

#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

typedef std::vector<boost::shared_ptr<NS_NICKEL_CLIENT::AudioOutput> > AudioOutputs;

NS_NICKEL_CLIENT_OPEN

class SystemOutputManager
	:	public virtual NS_NICKEL_CLIENT::OutputManager
	,	public virtual NS_NICKEL_SYSTEM::OutputManagerEventListener
	,	public boost::enable_shared_from_this<SystemOutputManager> {

public:
	SystemOutputManager(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager);

public: // from OutputManager
	virtual DisplayType::Enum getPrimaryDisplayPreference() const;
	virtual void setPrimaryDisplayPreference(const DisplayType::Enum preference);
	virtual DisplayResolution::Enum getPrimaryDisplayResolution() const;
	virtual AspectRatio::Enum getPrimaryDisplayAspectRatio() const;

	virtual AudioOutputs getAudioOutputs() const;
	virtual boost::shared_ptr<HDMIDisplay> getHDMIDisplay() const;
	virtual boost::shared_ptr<AnalogueDisplay> getAnalogueDisplay() const;

	virtual VideoConversions getVideoConversionPreference() const;
	virtual void setVideoConversionPreference(const VideoConversions preference);
	virtual GraphicsResolution getGraphicsLayerResolution() const;

	virtual void disableOutputs();
	virtual void enableOutputs();
    virtual int32_t getRelativeADVolume() const;
    virtual void setRelativeADVolume(const int32_t vol);

    virtual void incVolume();
    virtual void decVolume();
    virtual int32_t getVolume() const;
    virtual void setVolume(const int32_t volume);
    virtual void muteVolume();
    virtual void unmuteVolume();
    virtual bool isMuted() const;

    virtual ADRouting::Enum getADRouting() const;
    virtual void setADRouting(const ADRouting::Enum routing);

public: // from OutputManagerEventListener
    virtual void DisplayPreferenceChange();
    virtual void HDMIEvent(const NS_NICKEL_SYSTEM::HDMIStatus::Enum status);
    virtual void HDMICECEvent(const NS_NICKEL_SYSTEM::HDMICECEventType::Enum eventType);
    virtual void PrimaryDisplayChange();
    virtual void AudioPreferenceChange(const uint32_t outputId);
    virtual void VolumeChange(const uint32_t volume, const bool muted);
    virtual void OutputStatusEvent(bool enabled);

private:
	boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> _manager;

};	// class SystemOutputManager

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::Conversion_16_9_To_4_3, Enum,
	NS_NICKEL_CLIENT::Conversion_16_9_To_4_3, Enum,
	(letterbox_14_9)
	(letterbox_16_9)
	(cutout_4_3)
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::Conversion_4_3_To_16_9, Enum,
	NS_NICKEL_CLIENT::Conversion_4_3_To_16_9, Enum,
	(automatic)
);

ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::DisplayType, Enum,
	NS_NICKEL_CLIENT::DisplayType, Enum,
	((hdmi, dt_hdmi))
	((analogue, dt_analogue))
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::ADRouting, Enum,
	NS_NICKEL_CLIENT::ADRouting, Enum,
	(ad_all_outputs)
	(ad_spdif_only)
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::HDMICECEventType, Enum,
	NS_NICKEL_CLIENT::HDMICECEventType, Enum,
	(standby_request)
	(activated)
	(deactivated)
);

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_SYSTEM_SSYSTEMOUTPUTMANAGER_H_ */
