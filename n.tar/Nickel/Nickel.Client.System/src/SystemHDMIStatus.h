/*
 * SystemHDMIStatus.h
 *
 *  Created on: Jun 6, 2010
 *      Author: zbigniew.mandziejewicz@youview.com 
 *
 *   Copyright (C) 2010 Youview TV 
 */

#ifndef NICKEL_CLIENT_SYSTEM_SYSTEMHDMISTATUS_H_
#define NICKEL_CLIENT_SYSTEM_SYSTEMHDMISTATUS_H_

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/EnumConv.h>

NS_NICKEL_CLIENT_OPEN

ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::HDMIStatus, Enum,
	NS_NICKEL_CLIENT::HDMIStatus, Enum,
	((disabled, hs_disabled))
	((not_connected, not_connected))
	((active_hdcp_off, active_hdcp_off))
	((active_hdcp_failed, active_hdcp_failed))
	((active_hdcp_on, active_hdcp_on))
);

NS_NICKEL_CLIENT_CLOSE

#endif
