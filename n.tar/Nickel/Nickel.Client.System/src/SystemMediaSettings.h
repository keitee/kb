/*
 * SystemMediaSetttings.h
 *
 *  Created on: Feb 23, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_SYSTEM_SYSTEMMEDIASETTTINGS_H_
#define NICKEL_CLIENT_SYSTEM_SYSTEMMEDIASETTTINGS_H_

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>

#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

NS_NICKEL_CLIENT_OPEN

class SystemMediaSettings
	:	public virtual NS_NICKEL_CLIENT::MediaSettings
	,	public virtual NS_NICKEL_SYSTEM::MediaSettingsEventListener
	,	public boost::enable_shared_from_this<SystemMediaSettings> {

public:
	SystemMediaSettings(boost::shared_ptr<NS_NICKEL_SYSTEM::MediaSettings> mediaSettings_);

public:
	virtual bool getADEnabled() const;
	virtual void setADEnabled(bool value);
	virtual bool getSubtitlesEnabled() const;
	virtual void setSubtitlesEnabled(bool value);
	virtual std::string getPreferredAudioLanguage() const;
	virtual void setPreferredAudioLanguage(const std::string& value);
	virtual std::string getPreferredSubtitleLanguage() const;
	virtual void setPreferredSubtitleLanguage(const std::string& value);

public:
	virtual void MediaSettingsChange();

private:
	boost::shared_ptr<NS_NICKEL_SYSTEM::MediaSettings> mediaSettings;

};	// class SystemMediaSettings

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_SYSTEM_SYSTEMMEDIASETTTINGS_H_ */
