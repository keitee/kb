/* Copyright (C) 2009 British Broadcasting Corporation */

#ifndef NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_H_
#define NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_H_

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>
#include <boost/shared_ptr.hpp>
#include <nickel-system-api/MediaRouterSync.h>

NS_NICKEL_CLIENT_OPEN

class SystemMediaRouter :
     public virtual NS_NICKEL_CLIENT::MediaRouter,
     virtual public NS_NICKEL_SYSTEM::MediaRouterEventListener {

public:
    SystemMediaRouter(boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter> mediaRouter);

    // Client API methods
    virtual void setSource(const std::string& mediaLocator,const SetSourceReason::Enum reason);
    virtual std::string getSource() const;
    virtual void setVolume(const int32_t volume);
    virtual int32_t getVolume() const;
    virtual void setAudioTrack(const int32_t tag);
    virtual void setAudioTrackExternal(const std::string& mediaLocator,const int32_t tag);
    virtual boost::shared_ptr<Track> getAudioTrack() const;
    virtual void setVideoTrack(const int32_t tag);
    virtual void setVideoTrackExternal(const std::string& mediaLocator,const int32_t tag);
    virtual boost::shared_ptr<Track> getVideoTrack() const;
    virtual void setSubtitleTrack(const int32_t tag,const std::string& language);
    virtual boost::shared_ptr<Track> getSubtitleTrack() const;
    virtual int32_t addSubtitleTrack(const std::string& subtitleLocator);
    virtual boost::shared_ptr<std::vector<boost::shared_ptr<Track> > > getTracks() const;
    virtual void setVideoWindow(boost::shared_ptr<VideoWindowDescriptor> videoWindow);
    virtual boost::shared_ptr<VideoWindowDescriptor> getVideoWindow() const;
    virtual void setPlaySpeed(const double speed);
    virtual double getPlaySpeed() const;
    virtual void seekPosition(const SeekReference::Enum whence,const int32_t offset, const SeekMode::Enum mode);
    virtual boost::shared_ptr<Position> getPosition() const;
    virtual void setSink(const std::string& mediaLocator);
    virtual std::string getSink() const;
    virtual int32_t getEndTime() const;
    virtual void setEndTime(const int32_t end);
    virtual void start();
    virtual void startDeferred();
    virtual boost::shared_ptr<ControlCapabilities> getControlCapabilities() const;
    virtual void stop();
    virtual NS_ZINC::Future<void> stopAsync();
    virtual boost::shared_ptr<std::map< std::string, std::string > > getBufferingMode() const;
    virtual void setBufferingMode(boost::shared_ptr<std::map<std::string,std::string> > bufferingMode);
    virtual void setBufferConstraint( BufferConstraint::Enum bufferConstraint );
    virtual BufferConstraint::Enum getBufferConstraint();
    virtual void setBufferAdaptiveMode( AdaptiveMode::Enum adaptiveMode );
    virtual AdaptiveMode::Enum getBufferAdaptiveMode();
    virtual void startBuffering();
    virtual void stopBuffering();
    virtual boost::shared_ptr<BufferStatus> getBufferStatus() const;
    virtual void setVideoTerminationMode(const VideoTerminationMode::Enum mode);
    virtual VideoTerminationMode::Enum getVideoTerminationMode() const;
    virtual boost::shared_ptr<std::map<std::string,std::string> > getSourceInformation() const;
    virtual NS_ZINC::Future<std::map<std::string,std::string> > getSourceInformationAsync() const;
    virtual void setMediaDuration(const int32_t duration);
    virtual int32_t getMediaDuration() const;
    virtual boost::shared_ptr<ABRStreamSet> getABRStreamSet() const;
    virtual boost::shared_ptr<ABRStatus> getABRStatus() const;
    virtual void setABRStream(const int32_t streamIndex, const bool deferred);
    virtual void setCaptureMode(const TimeShiftCaptureMode::Enum mode);
    virtual TimeShiftCaptureMode::Enum getCaptureMode() const;
    virtual void recycle();


    // System API events
    virtual void BufferStatusEvent(const NS_NICKEL_SYSTEM::BufferStatusEventValue::Enum event);
    virtual void DrmEvent(const NS_NICKEL_SYSTEM::DrmEventValue::Enum resultRef,const std::string& drmMediaIdentifier,const std::string& rightsIssuerUrl);
    virtual void PositionChangeEvent(const NS_NICKEL_SYSTEM::Position& position);
    virtual void SourceEvent(const NS_NICKEL_SYSTEM::SourceEventValue::Enum event,const NS_NICKEL_SYSTEM::SetSourceReason::Enum reason);
    virtual void SpeedChangeEvent();
    virtual void StatusEvent(const NS_NICKEL_SYSTEM::StatusEventValue::Enum event);
    virtual void ErrorEvent(const NS_NICKEL_SYSTEM::ErrorEventValue::Enum error,
            const NS_NICKEL_SYSTEM::ErrorEventContext::Enum context,
            const std::string& info);
private:
    boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouterAsync> router;

    friend boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter> 
            unwrapSystemRouter(boost::shared_ptr<MediaRouter> sysRouter);
};

boost::shared_ptr<MediaRouter> wrapSystemRouter(boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter> sysRouter,
                                                boost::shared_ptr<NS_ZINC::EventDispatcher> dispatcher);

boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouter> unwrapSystemRouter(boost::shared_ptr<MediaRouter> cliSysRouter);

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_H_ */
