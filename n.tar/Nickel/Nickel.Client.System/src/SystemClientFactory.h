/*
 * SystemClientFactory.h
 *
 *  Created on: Mar 27, 2009
 *      Author: jsadler
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_CLIENT_FACTORY_H_
#define NICKEL_SYSTEM_CLIENT_FACTORY_H_

#include <copper-system-api/macros.h>
#include <nickel-client-api/ClientFactory.h>
#include <nickel-system-api/nickel-system-api.h>
#include <zinc-common/zinc-common.h>
#include <boost/shared_ptr.hpp>
#include <boost/thread/mutex.hpp>

namespace Zinc
{
namespace System
{
class LocalStorageRepositoryAsync;
class LocalStorageRepositorySync;
class SystemFactory;
} // namespace System
} // namespace Zinc

NS_NICKEL_CLIENT_OPEN

class SystemClientFactory : virtual public ClientFactory {
public:
    static Zinc::Media::SystemFactory& getSystemFactory();

    SystemClientFactory();

    ~SystemClientFactory();

    boost::shared_ptr<NS_ZINC::EventDispatcher> getDefaultDispatcher() const;
    void setDefaultDispatcher(boost::shared_ptr<NS_ZINC::EventDispatcher> dispatcher);

    boost::shared_ptr<Locator> createLocator();

    boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory();

    boost::shared_ptr<MediaRouter> getDefaultMediaRouter();

    boost::shared_ptr<MediaSettings> createMediaSettings();

    boost::shared_ptr<OutputManager> createOutputManager();

    boost::shared_ptr<ServiceListBuilder> createServiceListBuilder();

    boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> createAudioFeedback();

private:

    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > createLocalStorageRepositoryAsync();

    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > createLocalStorageRepositorySync();

    NS_COPPER_SYSTEM::SystemFactory & getCopperSystemFactory();

    // N.B: These don't need to be static. The Factory itself is a singleton.
    boost::mutex mutex;

    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositoryAsync > localStorageRepositoryAsync;
    boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageRepositorySync > localStorageRepositorySync;
    boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouterFactory> mediaRouterFactory;
    boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouter> defaultMediaRouter;
    boost::shared_ptr<NS_NICKEL_CLIENT::MediaSettings> mediaSettings;
    boost::shared_ptr<NS_NICKEL_CLIENT::OutputManager> outputManager;
    boost::shared_ptr<NS_NICKEL_CLIENT::ServiceListBuilder> serviceListBuilder;
    boost::shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> audioFeedback;
    boost::shared_ptr<NS_ZINC::EventDispatcher> defaultDispatcher;
};

NS_NICKEL_CLIENT_CLOSE

extern "C" {
    ZINC_EXPORT NS_ZINC::Plugin* createSystemClientFactory();
};


#endif /* NICKEL_SYSTEM_CLIENT_FACTORY_H_ */

