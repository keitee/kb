/*
 * SystemAudioFeedback.cpp
 *
 *  Created on: 23 October 2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Limited
 */

#include "SystemAudioFeedback.h"

#include <nickel-client-api/AudioFeedback.h>

#include <nickel-audio-feedback/AudioFeedback.h>
#include <nickel-audio-feedback/AudioSample.h>

#include <nickel-common/NickelLogger.h>

#include <boost/foreach.hpp>
#include <boost/make_shared.hpp>
#include <boost/shared_ptr.hpp>

#include <vector>

NS_NICKEL_AUDIO_CLIENT_OPEN

class ZINC_LOCAL SystemAudioFeedback : virtual public AudioFeedback
{
public:

    SystemAudioFeedback(boost::shared_ptr<NS_NICKEL_AUDIOFEEDBACK::AudioFeedbackAsync> af, bool enabled_)
        : systemAf(af), enabled(enabled_)
    {
    }

    virtual void playSamples(const std::vector<AudioSample> &clientSamples, bool flush) const
    {
        std::vector< NS_NICKEL_AUDIOFEEDBACK::AudioSample > sysSamples;
        sysSamples.reserve(clientSamples.size());
        BOOST_FOREACH(const AudioSample &clientSample, clientSamples)
        {
            sysSamples.push_back(
                NS_NICKEL_AUDIOFEEDBACK::AudioSample(
                    clientSample.getSampleName(),
                    clientSample.getLengthInMilliSeconds()));
        }
        // Block until the sample is queued and throws std::invalid_argument
        // if any of the sample requested is not loaded.
        systemAf->playSamples(sysSamples, flush).get();
    }

    virtual void setRelativeVolume(int value)
    {
        systemAf->setRelativeVolume(value);
    }

    virtual int getRelativeVolume() const
    {
        return systemAf->getRelativeVolume().get();
    }

    virtual void setEnabled(bool enabled_)
    {
        enabled = enabled_;
        systemAf->setEnabled(enabled);
        // TODO: we could even kill audiofeedbackd when disabling audiofeedback
        // or call exit() from the daemon if setEnabled(false) is received.
    }

    virtual bool getEnabled() const
    {
        // Do not call systemAf->getEnabled() as it could start up the system daemon for nothing
        return enabled;
    }

    virtual AudioSample makeSample(const std::string &sampleName, uint32_t lengthInMilliSeconds) const
    {
        return AudioSample(sampleName, lengthInMilliSeconds);
    }

private:
    boost::shared_ptr<NS_NICKEL_AUDIOFEEDBACK::AudioFeedbackAsync> systemAf;
    bool enabled;
};

boost::shared_ptr< AudioFeedback > createSystemAudioFeedback(
    boost::shared_ptr<NS_NICKEL_AUDIOFEEDBACK::AudioFeedbackAsync> systemAf, bool enabled)
{
    return boost::make_shared<SystemAudioFeedback>(systemAf, enabled);
}

NS_NICKEL_AUDIO_CLIENT_CLOSE
