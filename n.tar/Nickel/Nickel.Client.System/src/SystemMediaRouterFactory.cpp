/* Copyright (C) 2009 British Broadcasting Corporation */

#include "SystemMediaRouterFactory.h"
#include "SystemMediaRouter.h"
#include <nickel-common/NickelLogger.h>

using namespace NS_ZINC;
using namespace boost;
using namespace std;

NS_NICKEL_CLIENT_OPEN

SystemMediaRouterFactory::SystemMediaRouterFactory(
        boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouterFactorySync> sysFactory_,
        boost::shared_ptr<EventDispatcher> dispatcher,
        NS_NICKEL_CLIENT::ClientFactory& clientFactory_) :

        sysFactory(sysFactory_), clientFactory(&clientFactory_), dispatcher(dispatcher) {
    NICKEL_FUNC_DEBUG;
}

boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouter> SystemMediaRouterFactory::createMediaRouter(void) {
    NICKEL_FUNC_DEBUG;
    try {
        boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouter> p =
                wrapSystemRouter(sysFactory->createMediaRouter(), dispatcher);
        return p;

    } catch (const NS_NICKEL_SYSTEM::InsufficientResources&) {
        throw InsufficientResources();
    }
}

boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouter> SystemMediaRouterFactory::getDefaultMediaRouter() const
{
    NICKEL_FUNC_DEBUG;
    return clientFactory->getDefaultMediaRouter();
}

NS_NICKEL_CLIENT_CLOSE

