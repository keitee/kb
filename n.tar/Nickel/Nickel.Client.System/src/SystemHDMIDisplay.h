/*
 * SystemHDMIDisplay.h
 *
 *  Created on: Jun 6, 2010
 *      Author: zbigniew.mandziejewicz@youview.com 
 *
 *   Copyright (C) 2010 Youview TV 
 */

#ifndef NICKEL_CLIENT_SYSTEM_SYSTEMHDMIDISPLAY_H_
#define NICKEL_CLIENT_SYSTEM_SYSTEMHDMIDISPLAY_H

#include "SystemHDMIStatus.h"

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/EnumConv.h>

NS_NICKEL_CLIENT_OPEN

typedef std::vector<DisplayResolution::Enum> DisplayResolutions;

class SystemHDMIDisplay: public NS_NICKEL_CLIENT::HDMIDisplay
{
public:
	SystemHDMIDisplay(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager);

	virtual DisplayResolution::Enum getResolutionPreference() const;
	virtual void setResolutionPreference(const DisplayResolution::Enum preference);
	virtual DisplayResolutions getResolutions() const;
	virtual HDCPPreference::Enum getHDCPPreference() const;
	virtual void setHDCPPreference(const HDCPPreference::Enum preference);
	virtual HDMIStatus::Enum getStatus() const;
	virtual void requestStandby();

private:
	boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> _manager;

}; // SystemHDMIDisplay

ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::DisplayResolution, Enum,
	NS_NICKEL_CLIENT::DisplayResolution, Enum,
	((undefined, dr_undefined))
	((sd, sd))
	((hd1280x720p50, hd1280x720p50))
	((hd1920x1080i25, hd1920x1080i25))
	((hd1920x1080p50, hd1920x1080p50))
        ((uhd3840x2160p25c8, uhd3840x2160p25c8))
        ((uhd3840x2160p25c10, uhd3840x2160p25c10))
        ((uhd3840x2160p50c8, uhd3840x2160p50c8))
        ((uhd3840x2160p50c10, uhd3840x2160p50c10))
);

ZINC_ENUM_IDENTITY(
    NS_NICKEL_SYSTEM::HDCPPreference, Enum,
    NS_NICKEL_CLIENT::HDCPPreference, Enum,
	(always_on)
	(when_required)
);

NS_NICKEL_CLIENT_CLOSE

#endif
