/*
 * SystemAnalogueDisplay.h
 *
 *  Created on: Jun 6, 2010
 *      Author: zbigniew.mandziejewicz@youview.com 
 *
 *   Copyright (C) 2010 Youview TV 
 */

#ifndef NICKEL_CLIENT_SYSTEM_SYSTEMANALOGUEDISPLAY_H_
#define NICKEL_CLIENT_SYSTEM_SYSTEMANALOGUEDISPLAY_H

#include "SystemAspectRatio.h"

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/EnumConv.h>

#include <boost/shared_ptr.hpp>

NS_NICKEL_CLIENT_OPEN

class SystemAnalogueDisplay: public NS_NICKEL_CLIENT::AnalogueDisplay
{

public:
	SystemAnalogueDisplay(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager);
    ~SystemAnalogueDisplay();

	virtual AspectRatio::Enum getAspectRatio() const;
	virtual void setAspectRatio(const AspectRatio::Enum ratio);
	virtual VideoStandard::Enum getVideoStandard() const;
	virtual void setVideoStandard(const VideoStandard::Enum standard);
	virtual ColourMode::Enum getSCARTColourPreference() const;
	virtual void setSCARTColourPreference(const ColourMode::Enum colourMode);

private:
	boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> _manager;

}; // SystemAnalogueDisplay

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::VideoStandard, Enum,
	NS_NICKEL_CLIENT::VideoStandard, Enum,
	(pal)
	(secam)
	(ntsc)
);

ZINC_ENUM_IDENTITY(
	NS_NICKEL_SYSTEM::ColourMode, Enum,
	NS_NICKEL_CLIENT::ColourMode, Enum,
	(composite)
	(yc)
	(rgb)
);

NS_NICKEL_CLIENT_CLOSE

#endif
