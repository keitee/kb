#include "SystemAnalogueDisplay.h"

NS_NICKEL_CLIENT_OPEN

SystemAnalogueDisplay::SystemAnalogueDisplay(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager):
    _manager(manager) 
{ 
}

SystemAnalogueDisplay::~SystemAnalogueDisplay()
{
}

AspectRatio::Enum SystemAnalogueDisplay::getAspectRatio() const
{
    return NS_ZINC::enum_convert<AspectRatio::Enum>(_manager->getAnalogueDisplayAspectRatio());
}

void SystemAnalogueDisplay::setAspectRatio(const AspectRatio::Enum ratio)
{
    _manager->setAnalogueDisplayAspectRatio(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::AspectRatio::Enum>(ratio));
}

VideoStandard::Enum SystemAnalogueDisplay::getVideoStandard() const
{
    return NS_ZINC::enum_convert<VideoStandard::Enum>(_manager->getAnalogueVideoStandard());
}

void SystemAnalogueDisplay::setVideoStandard(const VideoStandard::Enum standard)
{
    try
    {
        _manager->setAnalogueVideoStandard(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::VideoStandard::Enum>(standard));
    }
    catch(const NS_NICKEL_SYSTEM::NotSupported&)
    {
        throw NotSupported();
    };
}

ColourMode::Enum SystemAnalogueDisplay::getSCARTColourPreference() const
{
    return NS_ZINC::enum_convert<ColourMode::Enum>(_manager->getSCARTColourPreference());
}

void SystemAnalogueDisplay::setSCARTColourPreference(const ColourMode::Enum colourMode)
{
    _manager->setSCARTColourPreference(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::ColourMode::Enum>(colourMode));
}

NS_NICKEL_CLIENT_CLOSE
