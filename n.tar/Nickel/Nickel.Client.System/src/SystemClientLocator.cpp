/*
 * SystemClientLocator.cpp
 *
 *  Created on: 8 Apr 2010
 *      Author: mark.nicoll1@bbc.co.uk
 *
 *  Copyright (C) 2010 British Broadcasting Corporation
 */

#include "SystemClientLocator.h"

using namespace NS_NICKEL_CLIENT;
using boost::shared_ptr;



SystemClientLocator::SystemClientLocator(
        shared_ptr<MediaRouterFactory> mrf,
        shared_ptr<MediaSettings> ms,
        shared_ptr<OutputManager> om,
        shared_ptr<ServiceListBuilder> slb,
        shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> af)
	:	mediaRouterFactory(mrf)
	,	mediaSettings(ms)
	,	outputManager(om)
	,	serviceListBuilder(slb)
	,	audioFeedback(af)
{
}

shared_ptr<MediaRouterFactory> SystemClientLocator::getMediaRouterFactory() const {
	return mediaRouterFactory;
}

shared_ptr<MediaSettings> SystemClientLocator::getMediaSettings() const {
	return mediaSettings;
}

shared_ptr<OutputManager> SystemClientLocator::getOutputManager() const {
	return outputManager;
}

shared_ptr<ServiceListBuilder> SystemClientLocator::getServiceListBuilder() const {
	return serviceListBuilder;
}

shared_ptr<MediaRouter> SystemClientLocator::getDefaultMediaRouter() const {
	/**
	 * TODO MediaRouterFactory::getDefaultMediaRouter is deprecated
	 */
	return getMediaRouterFactory()->getDefaultMediaRouter();
}

shared_ptr<NS_NICKEL_AUDIO_CLIENT::AudioFeedback> SystemClientLocator::getAudioFeedback() const {
	return audioFeedback;
}
