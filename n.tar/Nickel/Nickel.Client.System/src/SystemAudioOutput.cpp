#include "SystemAudioOutput.h"

NS_NICKEL_CLIENT_OPEN

SystemAudioOutput::SystemAudioOutput(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager, const uint32_t id, const AudioOutputType::Enum outputType):
    _manager(manager), _id(id), _outputType(outputType)
{
}

SystemAudioOutput::~SystemAudioOutput()
{
}

AudioOutputType::Enum SystemAudioOutput::getType() const
{
    return _outputType;
}

AudioFormats SystemAudioOutput::getFormats() const
{
    std::vector<NS_NICKEL_SYSTEM::AudioFormat::Enum> source = _manager->getAudioFormatOptions(_id);

    AudioFormats result;
    result.reserve(source.size());

    std::transform(
        source.begin(),
        source.end(),
        std::back_inserter(result),
        NS_ZINC::enum_convert<AudioFormat::Enum, NS_NICKEL_SYSTEM::AudioFormat::Enum>
    );

    return result; 
}

AudioFormat::Enum SystemAudioOutput::getFormatPreference() const
{
    return NS_ZINC::enum_convert<AudioFormat::Enum>(_manager->getAudioFormatPreference(_id));
}

void SystemAudioOutput::setFormatPreference(const AudioFormat::Enum format)
{
    _manager->setAudioFormatPreference(_id, NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::AudioFormat::Enum>(format));
}

int32_t SystemAudioOutput::getDelay() const
{
    return _manager->getAudioDelay(_id);
}

void SystemAudioOutput::setDelay(const int32_t delay)
{
    try
    {
        _manager->setAudioDelay(_id, delay);
    }
    catch(const NS_NICKEL_SYSTEM::OutOfBounds&)
    {
        throw OutOfBounds();
    }
    catch(const NS_NICKEL_SYSTEM::NotSupported&)
    {
        throw NotSupported();
    };
}

NS_NICKEL_CLIENT_CLOSE
