/* Copyright (C) 2009 British Broadcasting Corporation */

#ifndef NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_FACTORY_H_
#define NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_FACTORY_H_

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

#include <zinc-common/zinc-common.h>
#include <zinc-common/ActionProcessor.h>

#include "SystemClientFactory.h"

#include <boost/thread/mutex.hpp>

NS_NICKEL_CLIENT_OPEN

class SystemMediaRouterFactory
    : public virtual NS_NICKEL_CLIENT::MediaRouterFactory,
      public boost::enable_shared_from_this<SystemMediaRouterFactory> {

public:
    SystemMediaRouterFactory(
            boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouterFactorySync> sysFactory_,
            boost::shared_ptr<NS_ZINC::EventDispatcher> dispatcher,
            NS_NICKEL_CLIENT::ClientFactory& clientFactory_);

    virtual boost::shared_ptr<MediaRouter> createMediaRouter();
    virtual boost::shared_ptr<MediaRouter> getDefaultMediaRouter() const;

private:
    boost::shared_ptr<NS_NICKEL_SYSTEM::MediaRouterFactorySync> sysFactory;
    // The clientFactory contains this object so this pointer should be valid
    // beyond the lifetime of this object
    NS_NICKEL_CLIENT::ClientFactory* clientFactory;
    boost::shared_ptr<NS_ZINC::EventDispatcher> dispatcher;
};


NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_H_ */
