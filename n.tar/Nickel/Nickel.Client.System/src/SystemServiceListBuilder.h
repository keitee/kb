/*
 * SystemServiceListBuilder.h
 *
 *  Created on: 11 Feb 2010
 *      Author: mark.nicoll1@bbc.co.uk
 *
 *  Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_CLIENT_SERVICELISTBUILDER_H
#define NICKEL_SYSTEM_CLIENT_SERVICELISTBUILDER_H

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>
#include <zinc-common/zinc-common.h>
#include <boost/shared_ptr.hpp>

NS_NICKEL_CLIENT_OPEN

class SystemServiceListBuilder
    : virtual public ServiceListBuilder,
      virtual public NS_NICKEL_SYSTEM::ServiceListBuilderEventListener {
public:
    SystemServiceListBuilder(
            boost::shared_ptr<NS_NICKEL_SYSTEM::ServiceListBuilder> sysSLB_);

    // Method calls from Client API
	virtual void serviceScan();
	virtual void stopServiceScan();

    // Events from System API
	virtual void ScanningProgress(const int32_t progress,
            const NS_NICKEL_SYSTEM::ScanningProgressStatus::Enum status,
            const uint32_t channelsScanned,
            const uint32_t totalChannels,
            const std::map< uint32_t, uint32_t >& servicesFound);

private:
    boost::shared_ptr<NS_NICKEL_SYSTEM::ServiceListBuilder> sysSLB;
};

NS_NICKEL_CLIENT_CLOSE

#endif // NICKEL_SYSTEM_CLIENT_SERVICELISTBUILDER_H

