/*
 * SystemAudioFeedback.h
 *
 *  Created on: 23 October 2013
 *      Author: hubert.lacote@youview.com
 *
 *   Copyright (C) 2013 YouView TV Limited
 */

#ifndef NICKEL_SYSTEM_AUDIO_FEEDBACK_H_
#define NICKEL_SYSTEM_AUDIO_FEEDBACK_H_

#include <nickel-audio-feedback/macros.h>

#include <nickel-client-api/macros.h>

#include <zinc-common/macros.h>

#include <boost/shared_ptr.hpp>

namespace Zinc
{
namespace Audio
{
class AudioFeedbackAsync;
} // namespace Audio
} // namespace Zinc

NS_NICKEL_AUDIO_CLIENT_OPEN

class AudioFeedback;

ZINC_LOCAL boost::shared_ptr< AudioFeedback > createSystemAudioFeedback(
    boost::shared_ptr<NS_NICKEL_AUDIOFEEDBACK::AudioFeedbackAsync>, bool);

NS_NICKEL_AUDIO_CLIENT_CLOSE

#endif /* NICKEL_SYSTEM_AUDIO_FEEDBACK_H_ */
