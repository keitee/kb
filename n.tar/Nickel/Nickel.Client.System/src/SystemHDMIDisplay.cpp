#include "SystemHDMIDisplay.h"

#include <algorithm>
#include <iterator>

NS_NICKEL_CLIENT_OPEN

SystemHDMIDisplay::SystemHDMIDisplay(boost::shared_ptr<NS_NICKEL_SYSTEM::OutputManagerSync> manager):
    _manager(manager) 
{ 
}

DisplayResolution::Enum SystemHDMIDisplay::getResolutionPreference() const
{
    return NS_ZINC::enum_convert<DisplayResolution::Enum>(_manager->getHDMIResolutionPreference());
}

void SystemHDMIDisplay::setResolutionPreference(const DisplayResolution::Enum preference)
{
    try
    {
        _manager->setHDMIResolutionPreference(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::DisplayResolution::Enum>(preference));
    }
    catch(const NS_NICKEL_SYSTEM::NotSupported&)
    {
        throw NotSupported();
    };
}

DisplayResolutions SystemHDMIDisplay::getResolutions() const
{
    std::vector<NS_NICKEL_SYSTEM::DisplayResolution::Enum> source = _manager->getHDMIResolutionOptions();

    DisplayResolutions result;
    result.reserve(source.size());

    std::transform(
        source.begin(),
        source.end(),
        std::back_inserter(result),
        NS_ZINC::enum_convert<DisplayResolution::Enum, NS_NICKEL_SYSTEM::DisplayResolution::Enum>
    );

    return result; 
}

HDCPPreference::Enum SystemHDMIDisplay::getHDCPPreference() const
{
    return NS_ZINC::enum_convert<HDCPPreference::Enum>(_manager->getHDMIHDCPPreference());
}

void SystemHDMIDisplay::setHDCPPreference(const HDCPPreference::Enum preference)
{
    _manager->setHDMIHDCPPreference(NS_ZINC::enum_convert<NS_NICKEL_SYSTEM::HDCPPreference::Enum>(preference));
}

HDMIStatus::Enum SystemHDMIDisplay::getStatus() const
{
    return NS_ZINC::enum_convert<HDMIStatus::Enum>(_manager->getHDMIStatus());
}

void SystemHDMIDisplay::requestStandby()
{
    _manager->requestHDMIStandby();
}

NS_NICKEL_CLIENT_CLOSE
