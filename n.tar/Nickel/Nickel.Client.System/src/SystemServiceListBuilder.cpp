/* Copyright (C) 2010 British Broadcasting Corporation 
 *
 * SystemServiceListBuilder.cpp
 *
 *  Created on: 11 Feb 2010
 *      Author: mark.nicoll1@bbc.co.uk
 */
#include "SystemServiceListBuilder.h"
#include <zinc-common/Event.h>
#include <zinc-common/EnumConv.h>

using namespace NS_ZINC;

NS_NICKEL_CLIENT_OPEN

SystemServiceListBuilder::SystemServiceListBuilder(boost::shared_ptr<NS_NICKEL_SYSTEM::ServiceListBuilder> sysSLB_)
    : sysSLB(sysSLB_)
{
}

void SystemServiceListBuilder::serviceScan() {
    sysSLB->serviceScan();
}

void SystemServiceListBuilder::stopServiceScan() {
    sysSLB->stopServiceScan();
}

ZINC_ENUM_BIMAPPING(
	NS_NICKEL_SYSTEM::ScanningProgressStatus, Enum,
	NS_NICKEL_CLIENT::ScanningProgressStatus, Enum,
	((in_progress, IN_PROGRESS))
	((success, SUCCESS))
	((aborted, ABORTED))
	((failure, FAILURE))
);

void SystemServiceListBuilder::ScanningProgress(const int32_t progress,
        const NS_NICKEL_SYSTEM::ScanningProgressStatus::Enum status,
        const uint32_t channelsScanned,
        const uint32_t totalChannels,
        const std::map< uint32_t, uint32_t >& servicesFound)
{
    produceEvent( boost::bind(&NS_NICKEL_CLIENT::ServiceListBuilderEventListener::ScanningProgress, _1,
            progress,
            NS_ZINC::enum_convert<ScanningProgressStatus::Enum>(status),
            channelsScanned,
            totalChannels,
            boost::shared_ptr<std::map<uint32_t,uint32_t> >(new std::map<uint32_t,uint32_t>(servicesFound)))
    		);
}

NS_NICKEL_CLIENT_CLOSE

