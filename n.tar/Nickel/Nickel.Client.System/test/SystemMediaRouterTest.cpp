/* Copyright (C) 2009 British Broadcasting Corporation */
#ifndef NICKEL_CLIENT_SYSTEM_MediaRouterTest
#define NICKEL_CLIENT_SYSTEM_MediaRouterTest

#include "../src/SystemMediaRouter.h"

#include "mocks/MockClientMediaRouterEventListener.h"

#include <nickel-client-api/nickel-client-api.h>
#include <zinc-common/zinc-common.h>
#include <zinc-common/async/PolledDispatcher.h>
#include <zinc-common/async/Promise.h>
#include <cppunit/extensions/HelperMacros.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/testsupport/AsynchronousEventProbe.h>
#include <zinc-common/testsupport/FutureMockActions.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-common/testsupport/AtomicBool.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-system-dbus/BusName.h>

#include <nickel-system-api/MediaRouterEventListener.h>
#include <nickel-system-api/MediaRouter.h>
#include <nickel-system-api/MockMediaRouterAsync.h>

#include <gmock/gmock.h>

#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>
#include <boost/thread.hpp>

#include <iostream>
#include <string>
#include <vector>
#include <utility>

using namespace NS_ZINC;
using namespace NS_ZINC_DBUS_BINDING;
using namespace std;
using namespace testing;

namespace {

int32_t const timeout = 3000;

}

NS_NICKEL_CLIENT_OPEN

enum EventType {
    ET_BufferStatusEvent,
    ET_DrmEvent,
    ET_PositionChangeEvent,
    ET_SourceEvent,
    ET_SpeedChangeEvent,
    ET_StatusEvent
};

struct Result {
    EventType type;
    int32_t value;
    boost::shared_ptr<Position> position;
};

class MREventListener : public MediaRouterEventListener {
public:
    MREventListener() : nReqEvnts(1) {}

    virtual void BufferStatusEvent(const BufferStatusEventValue::Enum event) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_BufferStatusEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void DrmEvent(const DrmEventValue::Enum event,const std::string& drmMediaIdentifier,const std::string& rightsIssuerUrl) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_DrmEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void PositionChangeEvent(boost::shared_ptr<Position> position) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_PositionChangeEvent;
        result->position = position;
        results.push_back(result);
    }
    virtual void SourceEvent(const SourceEventValue::Enum event,const SetSourceReason::Enum reason) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_SourceEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void SpeedChangeEvent() {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_SpeedChangeEvent;
        result->value = 0;
        results.push_back(result);
    }
    virtual void StatusEvent(const StatusEventValue::Enum event) {
        NICKEL_FUNC_DEBUG;
        boost::shared_ptr<Result> result(new Result);
        result->type = ET_StatusEvent;
        result->value = event;
        results.push_back(result);
    }
    virtual void ErrorEvent(const ErrorEventValue::Enum event, const ErrorEventContext::Enum error, const string& info) {
        NICKEL_FUNC_DEBUG;
    }

    void lock() { theMutex.lock(); }
    void unlock() { theMutex.unlock(); }
    bool wasResultReceived() { return (results.size() >= nReqEvnts); }
    void setNumberEventsRequired(int32_t i) { nReqEvnts = i; }
    void resetResult() { results.clear(); nReqEvnts = 1; }
    std::vector<boost::shared_ptr<Result> >& getResult() { return results; }
private:
    boost::mutex theMutex;
    std::vector<boost::shared_ptr<Result> > results;
    int32_t nReqEvnts;
};

class ZINC_LOCAL MediaRouterTest : IntegrationTestSandbox, TestUsingDbus,  TestUsingServiceDaemon, public CppUnit::TestFixture {
    private:
        ClientFactory *factory;
        boost::shared_ptr<MediaRouterFactory> mrf;
        boost::shared_ptr<MediaRouter> router;

    public:

        MediaRouterTest() :
            TestUsingServiceDaemon("media-daemon.plugin-config", "nickelmediad", NS_NICKEL_SYSTEM::BusName::MEDIA_ROUTER)
        {
        }

        static const PluginConfig &getClientFactoryPluginConfig(void) {
            static const FixedPluginConfig pluginConfig("libNickelClientSystem.so", "createSystemClientFactory");
            return(pluginConfig);
        }

        void setUp() {
            NICKEL_FUNC_DEBUG;
            startService();

            factory = &PluginFactory::getInstance<ClientFactory>(getClientFactoryPluginConfig());
            mrf = factory->createMediaRouterFactory();
        }

        void tearDown() {
            NICKEL_FUNC_DEBUG;
            stopService();
            router.reset();
            mrf.reset();
            PluginFactory::clearInstance(getClientFactoryPluginConfig());
            resetFilesystemSandbox();
        }

        void testStartStopPlay() {
            NICKEL_FUNC_DEBUG;

            router = mrf->createMediaRouter();

            boost::shared_ptr<MREventListener> lListener(new MREventListener());
            router->addListener(lListener);

            std::string expectedSink = "klaff";
            router->setSink(expectedSink);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected sink",expectedSink, router->getSink());

            string expectedSource = "http://www.bbc.co.uk/radio79";
            router->setSource(expectedSource,SetSourceReason::unspecified);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected source",expectedSource, router->getSource());

            // receive started event
            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> setSourceProbe(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            lListener->setNumberEventsRequired(2);
            // Wait for EventResult
            CPPUNIT_ASSERT(setSourceProbe.waitForEvent());

            // Verify result
            std::vector<boost::shared_ptr<Result> >& results = setSourceProbe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(1)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(SourceEventValue::change_complete),results.at(1)->value);
            lListener->resetResult();

            double expectedPlaySpeed = 2.250;
            router->setPlaySpeed(expectedPlaySpeed);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",expectedPlaySpeed, router->getPlaySpeed());

            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> playSpeedProbe(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(playSpeedProbe.waitForEvent());

            // Verify result
            results = playSpeedProbe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
            lListener->resetResult();

            // Set it back to 1 for the test
            expectedPlaySpeed = 1.0;
            router->setPlaySpeed(expectedPlaySpeed);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",expectedPlaySpeed, router->getPlaySpeed());

            // Wait for EventResult
            CPPUNIT_ASSERT(playSpeedProbe.waitForEvent());

            // Verify result
            results = playSpeedProbe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
            lListener->resetResult();

            // Test playing - note buffering and playing are independent
            router->start();

            // receive started event
            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe1(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(probe1.waitForEvent());

            // Verify result
            results = probe1.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_StatusEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(StatusEventValue::started),results.at(0)->value);
            lListener->resetResult();

            // receive position change events
            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe2(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(probe2.waitForEvent());

            // Verify result
            results = probe2.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,router->getPosition()->getCurrent());
            lListener->resetResult();

            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe3(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(probe3.waitForEvent());

            // Verify result
            results = probe3.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",2000,router->getPosition()->getCurrent());
            lListener->resetResult();

            // receive complete event
            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe4(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            lListener->setNumberEventsRequired(2);
            // Wait for EventResult
            CPPUNIT_ASSERT(probe4.waitForEvent());

            // Verify result
            results = probe4.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_StatusEvent,results.at(1)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(StatusEventValue::complete),results.at(1)->value);
            lListener->resetResult();

            router->removeListener(lListener);

            lListener.reset();

            mrf->destroyMediaRouter(router);

        }

        void testNotifyOnSignalLoss() {
            NICKEL_FUNC_TRACE;

            boost::shared_ptr<map<string,string> > info;
            map<string,string>::const_iterator infoIter;

            router = mrf->createMediaRouter();
            boost::shared_ptr<MREventListener> lListener(new MREventListener());
            router->addListener(lListener);

            // write trigger file
            std::string testFileName = NS_ZINC::getMutableDataPath("nickel-system-fake") + "send_signal_strength_signal";
            NICKEL_DEBUG("Writing trigger file: " << testFileName);
            std::ofstream outFile(testFileName.c_str(), std::ios::ate);
            outFile<<"0 1 1\n";
            outFile.close();

            // check get 2 signals one good, one bad
            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe1(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(probe1.waitForEvent());

            // Verify result
            std::vector<boost::shared_ptr<Result> >& results = probe1.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong result received in event", int32_t(SourceEventValue::source_information_change),results.at(0)->value);
            lListener->resetResult();

            info = router->getSourceInformation();
            infoIter = info->find("QUALITY");
            CPPUNIT_ASSERT_MESSAGE("No QUALITY property received", (infoIter != info->end()));
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong QUALITY", string("0"), infoIter->second);

            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe2(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(probe2.waitForEvent());

            // Verify result
            results = probe2.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong result received in event", int32_t(SourceEventValue::source_information_change),results.at(0)->value);
            lListener->resetResult();

            info = router->getSourceInformation();
            infoIter = info->find("QUALITY");
            CPPUNIT_ASSERT_MESSAGE("No QUALITY property received", (infoIter != info->end()));
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong QUALITY", string("100"), infoIter->second);

            infoIter = info->find("STRENGTH");
            CPPUNIT_ASSERT_MESSAGE("No STRENGTH property received", (infoIter != info->end()));
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong STRENGTH", string("100"), infoIter->second);

            router->removeListener(lListener);

            lListener.reset();

            mrf->destroyMediaRouter(router);

        }

        void testBuffering() {
            NICKEL_FUNC_TRACE;

            router = mrf->createMediaRouter();

            boost::shared_ptr<MREventListener> lListener(new MREventListener());
            router->addListener(lListener);

            // startBuffering
            router->startBuffering();

            // buffering started event
            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> bufferProbe1(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(bufferProbe1.waitForEvent());

            // Verify result
            std::vector<boost::shared_ptr<Result> >& results = bufferProbe1.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_BufferStatusEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(BufferStatusEventValue::buffering_started),results.at(0)->value);
            lListener->resetResult();

            // getBufferStatus()
            // when got enough start - but buffering and starting are independent
            timespec tv = {1,100000000};
            nanosleep(&tv,NULL);
            boost::shared_ptr<BufferStatus> buffer = router->getBufferStatus();
            CPPUNIT_ASSERT_MESSAGE("No buffer",buffer);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong bufferedBytes",int32_t(100000),buffer->getBufferedBytes());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong totalBytesRemaining",int32_t(100000),buffer->getTotalBytesRemaining());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong totalStreamBytes",int32_t(200000),buffer->getTotalStreamBytes());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong arrivalBytesPerSecond",int32_t(100000),buffer->getArrivalBytesPerSecond());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong streamBytesPerSecond",int32_t(10000),buffer->getStreamBytesPerSecond());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong bufferedMilliseconds",int32_t(1000),buffer->getBufferedMilliseconds());

            // receive buffering complete event
            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> bufferProbe2(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            // Wait for EventResult
            CPPUNIT_ASSERT(bufferProbe2.waitForEvent());

            // Verify result
            results = bufferProbe2.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_BufferStatusEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(BufferStatusEventValue::buffering_complete),results.at(0)->value);
            lListener->resetResult();

            router->removeListener(lListener);

            lListener.reset();

            mrf->destroyMediaRouter(router);

        }

        void testAudioDescriptionTrack() {
            NICKEL_FUNC_TRACE;

            router = mrf->createMediaRouter();

            int32_t const tag = 1;
            router->setAudioTrack(tag);
            boost::shared_ptr<Track> track = router->getAudioTrack();

            CPPUNIT_ASSERT_MESSAGE("No track",track);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong tag",tag,track->getTag());

            mrf->destroyMediaRouter(router);

        }

        void testVideoTrack() {
            NICKEL_FUNC_TRACE;

            router = mrf->createMediaRouter();
            // Fake sets the video format to video_h265 when it sees
            // the tag to be equal to 265
            int32_t tag = 265;
            router->setVideoTrack(tag);
            boost::shared_ptr<Track> track = router->getVideoTrack();
            CPPUNIT_ASSERT_MESSAGE("No track",track);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong tag", tag, track->getTag());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong format",
                    TrackFormat::video_h265, track->getFormat());
            // Fake sets the video format to video_h264 when it sees
            // the tag to be equal to 264
            tag = 264;
            router->setVideoTrack(tag);
            track = router->getVideoTrack();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong format",
                    TrackFormat::video_h264, track->getFormat());
            // Fake sets the video format to video_h264 when it sees
            // the tag to be equal to 264
            tag = 266;
            router->setVideoTrack(tag);
            track = router->getVideoTrack();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong format",
                    TrackFormat::other, track->getFormat());
            mrf->destroyMediaRouter(router);
        }

        void testSubtitlesTrack() {
            NICKEL_FUNC_TRACE;

            router = mrf->createMediaRouter();

            int32_t const tag = 2;
            router->setAudioTrack(tag);
            boost::shared_ptr<Track> track = router->getAudioTrack();

            CPPUNIT_ASSERT_MESSAGE("No track",track);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong tag",tag,track->getTag());

            mrf->destroyMediaRouter(router);

        }

        void testSeekPosition() {
            NICKEL_FUNC_TRACE;

            router = mrf->createMediaRouter();

            boost::shared_ptr<Position> position = router->getPosition();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),     position->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(0),  position->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position->getEnd());

            router->seekPosition(SeekReference::sr_start, 1000, SeekMode::prioritise_accuracy);

            position = router->getPosition();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),     position->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(1000),  position->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position->getEnd());

            router->seekPosition(SeekReference::sr_current, 1000, SeekMode::prioritise_accuracy);

            position = router->getPosition();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),     position->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(2000),  position->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position->getEnd());

            router->seekPosition(SeekReference::sr_end, -2000, SeekMode::prioritise_accuracy);

            position = router->getPosition();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/start time is wrong",   int32_t(0),     position->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/current time is wrong", int32_t(1000),  position->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("getPosition/end time is wrong",     int32_t(3000), position->getEnd());

            mrf->destroyMediaRouter(router);

        }

        void testDVBWithBuffering() {
            NICKEL_FUNC_DEBUG;

            router = mrf->createMediaRouter();

            boost::shared_ptr<MREventListener> lListener(new MREventListener());
            router->addListener(lListener);

            // setSink
            std::string expectedSink = "klaff";
            router->setSink(expectedSink);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected sink",expectedSink, router->getSink());

            // setSource
            string expectedSource = "dvb://fish";
            router->setSource(expectedSource, SetSourceReason::unspecified);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected source",expectedSource, router->getSource());

            NS_ZINC::AsynchronousEventProbe<std::vector<boost::shared_ptr<Result> >&, MREventListener> probe(
                    lListener, &MREventListener::wasResultReceived,
                    &MREventListener::getResult,
                    timeout);
            lListener->setNumberEventsRequired(2);
            // Wait for EventResult
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            std::vector<boost::shared_ptr<Result> >& results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SourceEvent,results.at(1)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(SourceEventValue::change_complete),results.at(1)->value);
            lListener->resetResult();

            boost::shared_ptr<Position> position = router->getPosition();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position start",0,position->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position current",0,position->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position end",0,position->getEnd());

            // start
            router->start();

            // receive started event
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_StatusEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event status",int32_t(StatusEventValue::started),results.at(0)->value);
            lListener->resetResult();

            // check position
            // Wait for EventResult
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);

            position = router->getPosition();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",0,position->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,position->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,position->getEnd());

            lListener->resetResult();

            // rewind to start
            router->setPlaySpeed(-2);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",double(-2), router->getPlaySpeed());

            // Wait for EventResult
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
            lListener->resetResult();


            // pause
            router->setPlaySpeed(0);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",double(0), router->getPlaySpeed());

            // Wait for EventResult
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
            lListener->resetResult();

            // check position
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",0,router->getPosition()->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",1000,router->getPosition()->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",2000,router->getPosition()->getEnd());
            lListener->resetResult();

            // XXX wait for buffer to fill and see start moving

            // ff to end of buffer
            router->setPlaySpeed(2);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Unexpected play speed",double(2), router->getPlaySpeed());

            // Wait for EventResult
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(1),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
            lListener->resetResult();

            // check position
            lListener->setNumberEventsRequired(2);
            CPPUNIT_ASSERT(probe.waitForEvent());

            // Verify result
            results = probe.retrieveArtifactNoWait();
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number results",size_t(2),results.size());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_SpeedChangeEvent,results.at(0)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong event type",ET_PositionChangeEvent,results.at(1)->type);
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",0,router->getPosition()->getStart());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",3000,router->getPosition()->getCurrent());
            CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong position",3000,router->getPosition()->getEnd());
            lListener->resetResult();



            router->removeListener(lListener);

            lListener.reset();

            mrf->destroyMediaRouter(router);

        }

        void testExceptions()
        {
            NICKEL_FUNC_DEBUG;

            router = mrf->createMediaRouter();

            CPPUNIT_ASSERT_THROW_MESSAGE(
                    "Should have thrown exception", router->setSource("TestThrowIllegalReconfiguration", SetSourceReason::unspecified),
                    IllegalReconfiguration);

            mrf->destroyMediaRouter(router);
        }

        void checkErrorMapping(NS_NICKEL_CLIENT::ErrorEventValue::Enum cv,
            NS_NICKEL_CLIENT::ErrorEventContext::Enum cc,
            NS_NICKEL_SYSTEM::ErrorEventValue::Enum sv,
            NS_NICKEL_SYSTEM::ErrorEventContext::Enum sc, const std::string& info)
        {
            boost::shared_ptr<NS_ZINC::PolledDispatcher> dispatcher
                = boost::make_shared<NS_ZINC::PolledDispatcher>();
            boost::shared_ptr<NS_NICKEL_SYSTEM::MockMediaRouterAsync> mock
                = boost::make_shared<NS_NICKEL_SYSTEM::MockMediaRouterAsync>();
            mock->setDispatcher(dispatcher);
            boost::shared_ptr<MockClientMediaRouterEventListener> listener
                = boost::make_shared<MockClientMediaRouterEventListener>();

            boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouter> testee
                = wrapSystemRouter(mock, dispatcher);
            testee->addListener(dispatcher, listener);

            EXPECT_CALL(*listener, ErrorEvent(cv, cc, info));
            mock->emitErrorEvent(sv, sc, info);
            while (dispatcher->processNext()) {
                /*pass*/
            }
            CPPUNIT_ASSERT(Mock::VerifyAndClear(listener.get()));
        }

        void test_thatErrorEventsAreMappedFromSystemToClientAPI()
        {
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::other_error_event,
                NS_NICKEL_CLIENT::ErrorEventContext::subtitle_file,
                NS_NICKEL_SYSTEM::ErrorEventValue::other,
                NS_NICKEL_SYSTEM::ErrorEventContext::subtitle_file,
                "touch");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::locator,
                NS_NICKEL_CLIENT::ErrorEventContext::index_file,
                NS_NICKEL_SYSTEM::ErrorEventValue::locator,
                NS_NICKEL_SYSTEM::ErrorEventContext::index_file,
                "see");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::tag,
                NS_NICKEL_CLIENT::ErrorEventContext::subtitle_track,
                NS_NICKEL_SYSTEM::ErrorEventValue::tag,
                NS_NICKEL_SYSTEM::ErrorEventContext::subtitle_track,
                "taste");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::language,
                NS_NICKEL_CLIENT::ErrorEventContext::audio_track,
                NS_NICKEL_SYSTEM::ErrorEventValue::language,
                NS_NICKEL_SYSTEM::ErrorEventContext::audio_track,
                "feel");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::linear_selection,
                NS_NICKEL_CLIENT::ErrorEventContext::video_track,
                NS_NICKEL_SYSTEM::ErrorEventValue::linear_selection,
                NS_NICKEL_SYSTEM::ErrorEventContext::video_track,
                "love");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::network,
                NS_NICKEL_CLIENT::ErrorEventContext::source,
                NS_NICKEL_SYSTEM::ErrorEventValue::network,
                NS_NICKEL_SYSTEM::ErrorEventContext::source,
                "hate");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::server,
                NS_NICKEL_CLIENT::ErrorEventContext::other_error_context,
                NS_NICKEL_SYSTEM::ErrorEventValue::server,
                NS_NICKEL_SYSTEM::ErrorEventContext::other,
                "distrust");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::data,
                NS_NICKEL_CLIENT::ErrorEventContext::subtitle_file,
                NS_NICKEL_SYSTEM::ErrorEventValue::data,
                NS_NICKEL_SYSTEM::ErrorEventContext::subtitle_file,
                "save");
            checkErrorMapping(
                NS_NICKEL_CLIENT::ErrorEventValue::data,
                NS_NICKEL_CLIENT::ErrorEventContext::sdp_file,
                NS_NICKEL_SYSTEM::ErrorEventValue::data,
                NS_NICKEL_SYSTEM::ErrorEventContext::sdp_file,
                "give");
        }
        void test_thatgetSourceInformationAsyncForwardsCallToSystemAPI()
        {
            boost::shared_ptr<NS_ZINC::PolledDispatcher> dispatcher
                = boost::make_shared<NS_ZINC::PolledDispatcher>();
            boost::shared_ptr<NS_NICKEL_SYSTEM::MockMediaRouterAsync> mock
                = boost::make_shared<NS_NICKEL_SYSTEM::MockMediaRouterAsync>();
            mock->setDispatcher(dispatcher);

            boost::shared_ptr<NS_NICKEL_CLIENT::MediaRouter> testee
                = wrapSystemRouter(mock, dispatcher);

            std::map<std::string, std::string> value;
            value["testing"] = "testing";
            value["one"] = "two three";
            EXPECT_CALL(*mock, getSourceInformation())
                .WillOnce(returnNewCompletedFuture(value));
            CPPUNIT_ASSERT_EQUAL(value, testee->getSourceInformationAsync().get());
            CPPUNIT_ASSERT(Mock::VerifyAndClear(mock.get()));
        }

        CPPUNIT_TEST_SUITE(MediaRouterTest);

        CPPUNIT_TEST(testBuffering);
        CPPUNIT_TEST(testStartStopPlay);
        CPPUNIT_TEST(testNotifyOnSignalLoss);
        CPPUNIT_TEST(testAudioDescriptionTrack);
        CPPUNIT_TEST(testVideoTrack);
        CPPUNIT_TEST(testSubtitlesTrack);
        CPPUNIT_TEST(testSeekPosition);
        CPPUNIT_TEST(testDVBWithBuffering);
        CPPUNIT_TEST(testExceptions);
        CPPUNIT_TEST(test_thatErrorEventsAreMappedFromSystemToClientAPI);
        CPPUNIT_TEST(test_thatgetSourceInformationAsyncForwardsCallToSystemAPI);

        CPPUNIT_TEST_SUITE_END();

    private:
};

CPPUNIT_TEST_SUITE_REGISTRATION(MediaRouterTest);

NS_NICKEL_CLIENT_CLOSE

#endif

