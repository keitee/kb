/* 
 * File:   MockClientMediaRouterEventListener.h
 * Author: hubert.lacote@youview.com
 *
 * Created on 09 July 2013
 * 
 * Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKEL_CLIENT_MOCK_CLIENT_MEDIAROUTER_EVENT_LISTENER_H_
#define NICKEL_CLIENT_MOCK_CLIENT_MEDIAROUTER_EVENT_LISTENER_H_

#include <nickel-client-api/MediaRouterEventListener.h>

#include <gmock/gmock.h>

NS_NICKEL_CLIENT_OPEN

struct MockClientMediaRouterEventListener :
            public NS_NICKEL_CLIENT::MediaRouterEventListener
{
    MOCK_METHOD1(BufferStatusEvent, void(const BufferStatusEventValue::Enum));
    MOCK_METHOD3(DrmEvent, void(const DrmEventValue::Enum,
        const std::string&, const std::string&));
    MOCK_METHOD1(PositionChangeEvent,
        void (boost::shared_ptr<Position> position));
    MOCK_METHOD2(SourceEvent, void (const SourceEventValue::Enum,
        const SetSourceReason::Enum));
    MOCK_METHOD0(SpeedChangeEvent, void(void));
    MOCK_METHOD1(StatusEvent, void (const StatusEventValue::Enum));
    MOCK_METHOD3(ErrorEvent, void (const ErrorEventValue::Enum,
        const ErrorEventContext::Enum, const std::string&));
};

NS_NICKEL_CLIENT_CLOSE

#endif	/* NICKEL_CLIENT_MOCK_CLIENT_MEDIAROUTER_EVENT_LISTENER_H_ */

