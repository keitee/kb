/* Copyright (C) 2010 British Broadcasting Corporation */

#ifndef NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_FACTORY_TEST
#define NICKEL_CLIENT_SYSTEM_MEDIA_ROUTER_FACTORY_TEST

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>
#include <zinc-common/zinc-common.h>

#include <cppunit/extensions/HelperMacros.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/testsupport/AsynchronousEventProbe.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-system-dbus/BusName.h>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>

#include <vector>
#include <sstream>

using namespace NS_NICKEL_CLIENT;
using namespace NS_ZINC;
using namespace NS_ZINC_DBUS_BINDING;
using namespace std;

class ZINC_LOCAL SystemMediaRouterFactoryTest :  IntegrationTestSandbox, TestUsingDbus,  TestUsingServiceDaemon, public CppUnit::TestFixture {
public:
    ClientFactory *factory;
    boost::shared_ptr<MediaRouterFactory> mediaRouterFactory;

    SystemMediaRouterFactoryTest() :
        TestUsingServiceDaemon("media-daemon.plugin-config", "nickelmediad", NS_NICKEL_SYSTEM::BusName::MEDIA_ROUTER) {}

    static const PluginConfig &getClientFactoryPluginConfig(void) {
        static const FixedPluginConfig pluginConfig("libNickelClientSystem.so", "createSystemClientFactory");
        return(pluginConfig);
    }

    void setUp() {
        startService();
        factory = &PluginFactory::getInstance<ClientFactory>(getClientFactoryPluginConfig());
        mediaRouterFactory = factory->createMediaRouterFactory();
    }

    void tearDown() {
        mediaRouterFactory.reset();
        PluginFactory::clearInstance(getClientFactoryPluginConfig());
        stopService();
    }

    void testGetDefaultMediaRouter() {
        boost::shared_ptr<MediaRouter> router = mediaRouterFactory->getDefaultMediaRouter();
        CPPUNIT_ASSERT_MESSAGE("Invalid media router returned", router != NULL);
        CPPUNIT_ASSERT_EQUAL(std::string("http://anything/#5"), router->getSource());
    }

    void testDefaultMediaRouter() {
        boost::shared_ptr<MediaRouter> router = mediaRouterFactory->getDefaultMediaRouter();
        CPPUNIT_ASSERT_MESSAGE("Invalid media router returned", router != NULL);
        router->setSink("klaff");
        router->setSource("http://anything/#5", SetSourceReason::unspecified);
        CPPUNIT_ASSERT_EQUAL(std::string("http://anything/#5"), router->getSource());
        boost::shared_ptr<MediaRouter> router2 = mediaRouterFactory->getDefaultMediaRouter();
        CPPUNIT_ASSERT_MESSAGE("Different sources returned", router->getSource() == router2->getSource());
        CPPUNIT_ASSERT_MESSAGE("Different default media router returned", router == router2);
    }

    void testDefaultMediaRouterCalls() {
        testDefaultMediaRouter();
        testGetDefaultMediaRouter();
    }

    void testMediaRouterCreateDestroy() {

        boost::shared_ptr<MediaRouter> router = mediaRouterFactory->createMediaRouter();
        CPPUNIT_ASSERT_MESSAGE("Router should not be null",router);

        mediaRouterFactory->destroyMediaRouter(router);

        router.reset();

    }

    CPPUNIT_TEST_SUITE(SystemMediaRouterFactoryTest);

    CPPUNIT_TEST(testDefaultMediaRouter);
    CPPUNIT_TEST(testDefaultMediaRouterCalls);
    CPPUNIT_TEST(testMediaRouterCreateDestroy);

    CPPUNIT_TEST_SUITE_END();

private:
};

CPPUNIT_TEST_SUITE_REGISTRATION(SystemMediaRouterFactoryTest);

#endif
