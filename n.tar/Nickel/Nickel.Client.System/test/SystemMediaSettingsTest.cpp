/* Copyright (C) 2010 British Broadcasting Corporation */

#ifndef NICKEL_CLIENT_SYSTEM_MEDIA_SETTINGS_TEST
#define NICKEL_CLIENT_SYSTEM_MEDIA_SETTINGS_TEST

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>
#include <zinc-common/zinc-common.h>

#include <cppunit/extensions/HelperMacros.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/testsupport/AsynchronousEventProbe.h>
#include <zinc-common/testsupport/IntegrationTestSandbox.h>
#include <zinc-binding-runtime/dbus/dbus-test-support.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-system-dbus/BusName.h>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>

#include <vector>
#include <sstream>

using namespace NS_NICKEL_CLIENT;
using namespace NS_ZINC;
using namespace NS_ZINC_DBUS_BINDING;
using namespace std;

namespace {
    int const timeout = 10000;
}

class TestListener : virtual public MediaSettingsListener {
public:
	TestListener();
	virtual ~TestListener();

	virtual void MediaSettingsChange();

	bool eventOccured();
	int  eventCount();
	void resetEventOccured();

private:
	boost::recursive_mutex m_mutex;
	int m_eventCount, m_lastCount;
};

TestListener::TestListener()
	:	m_eventCount(0)
	,	m_lastCount(0)
{
	NICKEL_FUNC_TRACE;
}
TestListener::~TestListener() {
	NICKEL_FUNC_TRACE;
}

void TestListener::MediaSettingsChange() {
	NICKEL_FUNC_TRACE;

	boost::recursive_mutex::scoped_lock lock(m_mutex);
	++m_eventCount;

	NICKEL_DEBUG("m_eventCount == " << m_eventCount);
}

bool TestListener::eventOccured() {
	NICKEL_FUNC_TRACE;

	boost::recursive_mutex::scoped_lock lock(m_mutex);
	return m_eventCount != m_lastCount;
}

int TestListener::eventCount() {
	return m_eventCount;
}

void TestListener::resetEventOccured() {
	NICKEL_FUNC_TRACE;

	m_lastCount = m_eventCount;
}

class ZINC_LOCAL SystemMediaSettingsTest :  IntegrationTestSandbox,TestUsingDbus, TestUsingServiceDaemon, public CppUnit::TestFixture {
public:
    ClientFactory *factory;
    boost::shared_ptr<MediaSettings> mediaSettings;
	boost::shared_ptr<TestListener>  listener;

    SystemMediaSettingsTest() :
        TestUsingServiceDaemon("media-daemon.plugin-config", "nickelmediad", NS_NICKEL_SYSTEM::BusName::MEDIA_ROUTER) {}

    static const PluginConfig &getClientFactoryPluginConfig(void) {
        static const FixedPluginConfig pluginConfig("libNickelClientSystem.so", "createSystemClientFactory");
        return(pluginConfig);
    }

    void setUp() {
        startService();
        factory = &PluginFactory::getInstance<ClientFactory>(getClientFactoryPluginConfig());
        mediaSettings = factory->createMediaSettings();
        listener.reset(new TestListener());
        mediaSettings->addListener(listener);
    }

    void tearDown() {
        mediaSettings->removeListener(listener);
        mediaSettings.reset();
        listener.reset();
        PluginFactory::clearInstance(getClientFactoryPluginConfig());
        stopService();
    }

// XXX     void testGetDefaultMediaRouter() {
// XXX         boost::shared_ptr<MediaRouter> router = mediaRouterFactory->getDefaultMediaRouter();
// XXX         CPPUNIT_ASSERT_MESSAGE("Invalid media router returned", router != NULL);
// XXX         CPPUNIT_ASSERT_EQUAL(std::string("http://anything/#5"), router->getSource());
// XXX     }
// XXX
// XXX     void testDefaultMediaRouter() {
// XXX         boost::shared_ptr<MediaRouter> router = mediaRouterFactory->getDefaultMediaRouter();
// XXX         CPPUNIT_ASSERT_MESSAGE("Invalid media router returned", router != NULL);
// XXX         router->setSink("klaff");
// XXX         router->setSource("http://anything/#5",UNSPECIFIED);
// XXX         CPPUNIT_ASSERT_EQUAL(std::string("http://anything/#5"), router->getSource());
// XXX         boost::shared_ptr<MediaRouter> router2 = mediaRouterFactory->getDefaultMediaRouter();
// XXX         CPPUNIT_ASSERT_MESSAGE("Different sources returned", router->getSource() == router2->getSource());
// XXX         CPPUNIT_ASSERT_MESSAGE("Different default media router returned", router == router2);
// XXX     }
// XXX
// XXX     void testDefaultMediaRouterCalls() {
// XXX         testDefaultMediaRouter();
// XXX         testGetDefaultMediaRouter();
// XXX     }
// XXX
// XXX     void testMediaRouterCreateDestroy() {
// XXX         boost::shared_ptr<MRFListener> listener(new MRFListener());
// XXX         mediaRouterFactory->addListener(listener);
// XXX
// XXX         boost::shared_ptr<MediaRouter> router = mediaRouterFactory->createMediaRouter();
// XXX         CPPUNIT_ASSERT_MESSAGE("Router should not be null",router);
// XXX
// XXX         mediaRouterFactory->destroyMediaRouter(router);
// XXX
// XXX         router.reset();
// XXX
// XXX         mediaRouterFactory->removeListener(listener);
// XXX     }

    void testAudioDescriptionsEnabled() {
        NICKEL_FUNC_TRACE;

        listener->resetEventOccured();

        CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

        int changes = 0;

        CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Audio Description Enabled not as expected", mediaSettings->getADEnabled(), false);
        mediaSettings->setADEnabled(true);
        ++changes;

        AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
        CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe1.retrieveArtifact(), changes);
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getADEnabled(), true);
        listener->resetEventOccured();

        mediaSettings->setADEnabled(false);
        ++changes;

        AsynchronousEventProbe<int, TestListener> probe2(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
        CPPUNIT_ASSERT_MESSAGE("No event received", probe2.waitForEvent());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe2.retrieveArtifact(), changes);
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getADEnabled(), false);
        listener->resetEventOccured();
    }

    void testSubtitlesEnabled() {
        NICKEL_FUNC_TRACE;

        listener->resetEventOccured();

        CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

        int changes = 0;

        CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Subtitles Enabled not as expected", mediaSettings->getSubtitlesEnabled(), false);
        mediaSettings->setSubtitlesEnabled(true);
        ++changes;

        AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
        CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe1.retrieveArtifact(), changes);
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getSubtitlesEnabled(), true);
        listener->resetEventOccured();

        mediaSettings->setSubtitlesEnabled(false);
        ++changes;

        AsynchronousEventProbe<int, TestListener> probe2(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
        CPPUNIT_ASSERT_MESSAGE("No event received", probe2.waitForEvent());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", probe2.retrieveArtifact(), changes);
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitles Enabled not as expected", mediaSettings->getSubtitlesEnabled(), false);
        listener->resetEventOccured();
    }

    void testPreferredAudioLanguage() {
        NICKEL_FUNC_TRACE;

        listener->resetEventOccured();

        CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

        int changes = 0;
        std::string value = "xxx";

        CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Audio Language not as expected", std::string(), mediaSettings->getPreferredAudioLanguage());
        mediaSettings->setPreferredAudioLanguage(value);
        ++changes;

        AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
        CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", changes, probe1.retrieveArtifact());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Audio Language not as expected", value, mediaSettings->getPreferredAudioLanguage());
        listener->resetEventOccured();

    }

    void testPreferredSubtitleLanguage() {
        NICKEL_FUNC_TRACE;

        listener->resetEventOccured();

        CPPUNIT_ASSERT_MESSAGE("mediaSettings is NULL", mediaSettings != NULL);

        int changes = 0;
        std::string value = "xxx";

        CPPUNIT_ASSERT_EQUAL_MESSAGE("Default value for Subtitle Language not as expected", std::string(), mediaSettings->getPreferredSubtitleLanguage());
        mediaSettings->setPreferredSubtitleLanguage(value);
        ++changes;

        AsynchronousEventProbe<int, TestListener> probe1(listener, &TestListener::eventOccured, &TestListener::eventCount, timeout);
        CPPUNIT_ASSERT_MESSAGE("No event received", probe1.waitForEvent());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Number of changes not as expected", changes, probe1.retrieveArtifact());
        CPPUNIT_ASSERT_EQUAL_MESSAGE("Value for Subtitle Language not as expected", value, mediaSettings->getPreferredSubtitleLanguage());
        listener->resetEventOccured();

    }

    CPPUNIT_TEST_SUITE(SystemMediaSettingsTest);

    CPPUNIT_TEST(testAudioDescriptionsEnabled);
    CPPUNIT_TEST(testSubtitlesEnabled);
    CPPUNIT_TEST(testPreferredAudioLanguage);
    CPPUNIT_TEST(testPreferredSubtitleLanguage);

    CPPUNIT_TEST_SUITE_END();

private:
};

CPPUNIT_TEST_SUITE_REGISTRATION(SystemMediaSettingsTest);

#endif
