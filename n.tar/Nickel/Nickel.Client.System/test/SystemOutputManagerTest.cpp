/*
 * SystemOutputManagerTest.cpp
 *
 *  Created on: Mar 2, 2010
 *      Author: Ben Haskins
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_CLIENT_SYSTEM_OUTPUT_MANAGER_TEST
#define NICKEL_CLIENT_SYSTEM_OUTPUT_MANAGER_TEST

#include "../src/SystemOutputManager.h"

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/MockOutputManagerSync.h>

#include <nickel-common/NickelLogger.h>

#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/MultipleListenerEventDispatcher.h>

#include <gmock/gmock.h>

#include <boost/make_shared.hpp>
#include <boost/assign.hpp>

using namespace std;
using namespace boost::assign;

using namespace testing;

NS_NICKEL_CLIENT_OPEN

class MockSystemOutputManagerListener : public OutputManagerEventListener {
public:
    MOCK_METHOD0(DisplayPreferenceChange, void());
    MOCK_METHOD1(HDMIEvent, void(const HDMIStatus::Enum));
    MOCK_METHOD1(HDMICECEvent, void(const HDMICECEventType::Enum));
    MOCK_METHOD0(PrimaryDisplayChange, void());
    MOCK_METHOD1(AudioPreferenceChange, void(boost::shared_ptr<AudioOutput>));
    MOCK_METHOD2(VolumeChange, void(const uint32_t, const bool));
    MOCK_METHOD1(OutputStatusEvent, void(const bool));

    virtual ~MockSystemOutputManagerListener() { };
};

class ZINC_LOCAL SystemOutputManagerTest
    : NS_ZINC::UnitTestSandbox, public CppUnit::TestFixture
{
private:
	ClientFactory *factory;
	boost::shared_ptr<NS_NICKEL_CLIENT::SystemOutputManager> outputManager;
	boost::shared_ptr<NS_NICKEL_SYSTEM::MockOutputManagerSync> source;
	boost::shared_ptr<MockSystemOutputManagerListener> listener;

public:
	SystemOutputManagerTest()
    {
    }

    void setUp()
    {
    	NICKEL_FUNC_TRACE;

        source.reset(new NS_NICKEL_SYSTEM::MockOutputManagerSync());

        outputManager.reset(new SystemOutputManager(source));
        outputManager->setDispatcher(boost::make_shared<NS_ZINC::MultipleListenerEventDispatcher>());

        listener.reset(new MockSystemOutputManagerListener());
        outputManager->addListener(listener);
    }

    void tearDown()
    {
    	NICKEL_FUNC_TRACE;

        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(source.get()));
        CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(listener.get()));
    }

    void testVolume()
    {
    	NICKEL_FUNC_TRACE;

        // exception transmission
        EXPECT_CALL(*source, setVolume(101)).WillOnce(Throw(NS_NICKEL_SYSTEM::OutOfBounds()));
        CPPUNIT_ASSERT_THROW(outputManager->setVolume(101), OutOfBounds);

        // signal transmission
        EXPECT_CALL(*listener, VolumeChange(60, false));
        outputManager->VolumeChange(60, false);
    }

    void testOutputs()
    {
        NICKEL_FUNC_TRACE;

        EXPECT_CALL(*listener, OutputStatusEvent(false));
        outputManager->OutputStatusEvent(false);
    }

    void testAudioOutputs()
    {
        NICKEL_FUNC_TRACE;

        // data transformation
        map<uint32_t, NS_NICKEL_SYSTEM::AudioOutputType::Enum> outputsData =
            map_list_of(1, NS_NICKEL_SYSTEM::AudioOutputType::analogue_scart)
                       (2, NS_NICKEL_SYSTEM::AudioOutputType::hdmi);
        EXPECT_CALL(*source, getAudioOutputs()).WillRepeatedly(Return(outputsData));

        std::vector<boost::shared_ptr<AudioOutput> > outputs = outputManager->getAudioOutputs();
        CPPUNIT_ASSERT_EQUAL(outputs.size(), size_t(2));

        boost::shared_ptr<AudioOutput> first(outputs[0]);
        boost::shared_ptr<AudioOutput> second(outputs[1]);

        CPPUNIT_ASSERT_EQUAL(first->getType(), AudioOutputType::analogue_scart);

        std::vector<NS_NICKEL_SYSTEM::AudioFormat::Enum> formats =
            list_of(NS_NICKEL_SYSTEM::AudioFormat::analogue);
        EXPECT_CALL(*source, getAudioFormatOptions(1)).WillRepeatedly(Return(formats));
        CPPUNIT_ASSERT_EQUAL(first->getFormats().size(), size_t(1));
        CPPUNIT_ASSERT_EQUAL(first->getFormats().at(0), AudioFormat::analogue);

        EXPECT_CALL(*source, getAudioFormatPreference(1)).WillOnce(Return(NS_NICKEL_SYSTEM::AudioFormat::analogue));
        CPPUNIT_ASSERT_EQUAL(first->getFormatPreference(), AudioFormat::analogue);

        CPPUNIT_ASSERT_EQUAL(second->getType(), AudioOutputType::hdmi);

        // exceptions
        EXPECT_CALL(*source, setAudioDelay(1, 10)).WillOnce(Throw(NS_NICKEL_SYSTEM::NotSupported()));
        CPPUNIT_ASSERT_THROW(first->setDelay(10), NotSupported);

        EXPECT_CALL(*source, setAudioDelay(2, 251)).WillOnce(Throw(NS_NICKEL_SYSTEM::OutOfBounds()));
        CPPUNIT_ASSERT_THROW(second->setDelay(251), OutOfBounds);

        // signals
        EXPECT_CALL(*listener, AudioPreferenceChange(_));
        outputManager->AudioPreferenceChange(1);
    }

    void testHDMIDisplay()
    {
        NICKEL_FUNC_TRACE;
    }

    void testAnalogueDisplay()
    {
        NICKEL_FUNC_TRACE;
    }

	CPPUNIT_TEST_SUITE(SystemOutputManagerTest);
	CPPUNIT_TEST(testVolume);
	CPPUNIT_TEST(testOutputs);
	CPPUNIT_TEST(testAudioOutputs);
    CPPUNIT_TEST(testHDMIDisplay);
    CPPUNIT_TEST(testAnalogueDisplay);

	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(SystemOutputManagerTest);

NS_NICKEL_CLIENT_CLOSE

#endif /* NICKEL_CLIENT_SYSTEM_OUTPUT_MANAGER_TEST */
