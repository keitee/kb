#!/usr/bin/env python

################################################################################
# media-router-probe.py
#
# Created on: Jan 31, 2015
#     Author: Tom Bailey
#
#
# Copyright 2015, YouView TV Ltd.
################################################################################

# This script can be run on a box and will print a report listing the 'sticky'
# and non-'sticky' media router attributes. 'Sticky' attributes can be set on an
# unsourced media router. This is important for the media router proxy because
# before setSource is called it doesn't know the media router implementation to
# forward the call to, so to preserve the semantics of the real media router it
# has to cache any "sticky" attributes that are set while it's unsourced and
# then forward them to the real media router once setSource is called.
#
# By default only prints the stciky attributes. Run with -v to see all
# attributes

from dbus.mainloop.glib import DBusGMainLoop
from dbus.exceptions import DBusException
import dbus
import sys
import re
import copy

dest = '''Zinc.Media'''
path = '''/Zinc/Media/DefaultMediaRouter'''

simpleMethods = {
    'setSink': 'decoder://0',
    'setVolume': -5,
    'setPlaySpeed': 2.0,
    'setEndTime': 100000,
    'setVideoTerminationMode': 1,
    'setMediaDuration': 10000,
    'setCaptureMode': 1
};

def isSticky(method):
    print "%s is sticky" % method

def isntSticky(method):
    if len(sys.argv) > 1 and sys.argv[1] == '-v':
        print "%s is non-sticky" % method

def callSetMethod(iface, method, args):
    retVal = getattr(iface, method)(*args)

    if retVal is not None:
        raise Exception("Error calling %s: %s" % (method, str(arg)))

def callGetMethod(iface, method):
    # Translate to get
    getMethod = re.sub('^set', 'get', method)
    return getattr(iface, getMethod)()

def callSimpleMethod(iface, method, arg):
    # Set
    callSetMethod(iface, method, (arg,))
    storedValue = callGetMethod(iface, method)

    if storedValue == arg:
        isSticky(method)
    else:
        isntSticky(method)

def callSetAudioTrack(iface):
    method = 'setAudioTrack'
    arg = -2
    callSetMethod(iface, method, (arg,))
    storedValue = callGetMethod(iface, method)
    if storedValue[0] == arg:
        isSticky(method)
    else:
        isntSticky(method)

def callSetVideoTrack(iface):
    method = 'setVideoTrack'
    arg = 1
    callSetMethod(iface, method, (arg,))
    storedValue = callGetMethod(iface, method)
    if storedValue[0] == arg:
        isSticky(method)
    else:
        isntSticky(method)

def callSetSubtitleTrack(iface):
    method = 'setSubtitleTrack'
    tag = 0
    lang = 'eng'
    callSetMethod(iface, method, (tag, lang))
    storedValue = callGetMethod(iface, method)
    if storedValue[0] == tag or storedValue[1] == lang:
        isSticky(method)
    else:
        isntSticky(method)

def callSetVideoWindow(iface):
    method = 'setVideoWindow'
    window = (0.0, 0.0, 1.0, 1.0, 0.5, 0.0, 0.5, 0.5)
    callSetMethod(iface, method, (window,))
    storedValue = callGetMethod(iface, method)
    if storedValue == window:
        isSticky(method)
    else:
        isntSticky(method)

def callSeekPosition(iface):
    method = 'seekPosition'
    args = (0, 10000, 1)
    callSetMethod(iface, method, args)
    storedValue = iface.getPosition()
    if storedValue == args:
        isSticky(method)
    else:
        isntSticky(method)

def callSetBufferingMode(iface):
    method = 'setBufferingMode'
    currentModes = iface.getBufferingMode()
    newModes = copy.deepcopy(currentModes)
    if currentModes['adaptivemode'] == 'auto':
        newModes['adaptivemode'] = 'default'
    else:
        newModes['adaptivemode'] = 'waitfordecision'
    callSetMethod(iface, method, (newModes,))
    currentModes = iface.getBufferingMode()
    if currentModes == newModes:
        isSticky(method)
    else:
        isntSticky(method)

def throws(method, exception):
    print "%s throws a %s" % (method, exception)

def doesntThrow(method):
    print "%s doesn't throws an exception" % method

def unknownEx(method):
    print "%s throws an unknown exception %s" % (method, type(exception))

def callThrowingMethod(iface, method, args):
    try:
        getattr(iface, method)(*args)
        doesntThrow(method)
    except DBusException, e:
        throws(method, e)
    except Exception, e:
        unknownEx(method, e)

def callSeekPosition(iface):
    callThrowingMethod(iface, 'seekPosition', (0, 10000, 1))

def callStart(iface):
    callThrowingMethod(iface, 'start', ())

def callStartDeferred(iface):
    callThrowingMethod(iface, 'startDeferred', ())

def callStartBuffering(iface):
    callThrowingMethod(iface, 'startBuffering', ())

def main(argv):
    try:
        bus = dbus.SessionBus(mainloop = DBusGMainLoop())
        obj = bus.get_object(dest, path)
        iface = dbus.Interface(obj, dbus_interface = 'Zinc.Media.MediaRouter')

        for method, arg in simpleMethods.iteritems():
            callSimpleMethod(iface, method, arg)

        callSetAudioTrack(iface)
        callSetVideoTrack(iface)
        callSetSubtitleTrack(iface)
        callSetVideoWindow(iface)
        callSetBufferingMode(iface)
        callSeekPosition(iface)
        callStart(iface)
        callStartDeferred(iface)
        callStartBuffering(iface)
    except Exception, e:
        pass
    finally:
        iface.recycle()

if __name__ == '__main__':
    sys.exit(main(sys.argv))
