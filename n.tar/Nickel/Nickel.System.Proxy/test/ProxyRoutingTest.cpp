/**
 * ProxyRoutingTest.cpp
 *
 * Created on: May 06, 2015
 *     Author: tom.bailey@youview.com
 *
 *
 * Copyright 2015, YouView TV Ltd.
 */

#include "../src/ProxyMediaRouter.h"

#include "../src/ProxySystemFactory.h"
#include "../include/testsupport/StubMediaRouterFactory.h"
#include "../include/testsupport/StubSystemFactory.h"
#include <nickel-system-api/InvalidLocatorException.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/VerifyAndClearDispatcher.h>
#include <zinc-common/FixedPluginConfig.h>
#include <zinc-common/PluginFactory.h>

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;

using testing::_;
using testing::Expectation;
using testing::Assign;
using testing::Return;
using testing::Invoke;
using testing::InSequence;
using testing::StrictMock;

class ZINC_LOCAL ProxyRoutingTest : private UnitTestSandbox,
    public CppUnit::TestFixture
{
public:
    typedef std::map<std::string, std::string> SourceInfoMap;

    ProxyRoutingTest()
        : httpDashSource("http://dash.bidi.int.bbc.co.uk/e/pseudolive/bbb/client_manifest.mpd"),
        httpHlsSource("http://cp143012-i.akamaihd.net/i/iplayerstream/secure_aut"
                "h/,800kbps/modav/bUnknown-02cea1c4-f7fe-48f1-8a2b-9bbfc161b22c_"
                "b061xy60_1435936923785,1500kbps/modav/bUnknown-02cea1c4-f7fe-48"
                "f1-8a2b-9bbfc161b22c_b061xy60_1435936925263,.mp4.csmil/master."
                "m3u8?hdnea=st=1436453685~exp=1436475285~acl=/*800kbps/modav/bUn"
                "known-02cea1c4-f7fe-48f1-8a2b-9bbfc161b22c_b061xy60_14359369237"
                "85,1500kbps/modav/bUnknown-02cea1c4-f7fe-48f1-8a2b-9bbfc161b22c"
                "_b061xy60_1435936925263*~hmac=d38d56cdfd55a6bf822cbf64868e0934b"
                "5bbc3cb05d8f8add4d1eb2600687e28"),
        httpsHlsSource("https://cp143012-i.akamaihd.net/i/iplayerstream/secure_aut"
                "h/,800kbps/modav/bUnknown-02cea1c4-f7fe-48f1-8a2b-9bbfc161b22c_"
                "b061xy60_1435936923785,1500kbps/modav/bUnknown-02cea1c4-f7fe-48"
                "f1-8a2b-9bbfc161b22c_b061xy60_1435936925263,.mp4.csmil/master."
                "m3u8?hdnea=st=1436453685~exp=1436475285~acl=/*800kbps/modav/bUn"
                "known-02cea1c4-f7fe-48f1-8a2b-9bbfc161b22c_b061xy60_14359369237"
                "85,1500kbps/modav/bUnknown-02cea1c4-f7fe-48f1-8a2b-9bbfc161b22c"
                "_b061xy60_1435936925263*~hmac=d38d56cdfd55a6bf822cbf64868e0934b"
                "5bbc3cb05d8f8add4d1eb2600687e28"),
        ms3DashSource("https://drm.youviewms3.c4.aws.redbeemedia.com/"
                "ms3/sas/1109635?bt=_wAAMgAAD6EAAAAAVVB7-AAAAlgAAAAAAL6D2RdYWkk"
                "fJyG_bXw484cSEM6jAAAAwAAAAB8B9zNArjHX6uNAvDksgjOGr7wZGy0#"
                "http://ak.yv.uat.c4assets.com/youview_assets/CH4_23_02_21_59392015001002_001.mpd"),
        ms3HlsSource("https://drm.youviewms3.c4.aws.redbeemedia.com/ms3/sas/1109635"
                "?bt=_wAAMgAAD6EAAAAAVVB7-AAAAlgAAAAAAL6D2RdYWkkfJyG_bXw484cSEM"
                "6jAAAAwAAAAB8B9zNArjHX6uNAvDksgjOGr7wZGy0#"
                "http://ak.yv.uat.c4assets.com/youview_assets/CH4_23_02_21_59392015001002_001.m3u8"),
        httpHlsRouter("http-application/vnd.apple.mpegurl"),
        httpDashRouter("http-application/dash+xml"),
        defaultRouter("mediarouter-default"),
        httpDefaultRouter("http-default")
    {}

    void setUp()
    {
        theDispatcher.reset(new SingleThreadDispatcher);
    }

    void tearDown()
    {
        VERIFY_AND_CLEAR_DISPATCHER(*theDispatcher, 100);
        theDispatcher.reset();
    }

    void testSetSource(const std::string& mediaLocator, const std::string& mimeType)
    {
        SystemFactory& systemFactory = loadFactory();
        boost::shared_ptr<MediaRouter> proxy
            = systemFactory.createMediaRouterFactory()->createMediaRouter().get();

        proxy->setSource(mediaLocator, SetSourceReason::mhegstandard).get();

        // StubMediaRouterFactory places the stub name in the source information
        // map
        SourceInfoMap sourceInfo = proxy->getSourceInformation().get();

        CPPUNIT_ASSERT_EQUAL(mimeType, sourceInfo["STUB_NAME"]);
    }

    void test_httpDashSourceRoutesToDashMediaRouter()
    {
        testSetSource(httpDashSource, httpDashRouter);
    }

    void test_httpHlsSourceRoutesToHlsMediaRouter()
    {
        testSetSource(httpHlsSource, httpHlsRouter);
    }

    void test_httpsHlsSourceRoutesToHlsMediaRouter()
    {
        testSetSource(httpsHlsSource, "https-application/vnd.apple.mpegurl");
    }

    void test_dvbSourceRoutesToDefaultMediaRouter()
    {
        testSetSource("dvb://233a..1044", defaultRouter);
    }

    void test_linearSourceRoutesToLinearMediaRouter()
    {
        testSetSource("linear:http://54.225.86.153/INT01_LCN_400.sdp", "linear-default");
    }

    void test_unknownProtocolRoutesToDefaultMediaRouter()
    {
        testSetSource("mymadeupprotocol://host/media.mpd", defaultRouter);
    }

    void test_missingHostRoutesToDefaultMediaRouter()
    {
        testSetSource("http:///media", httpDefaultRouter);
    }

    void test_missingProtocolGeneratesException()
    {
        CPPUNIT_ASSERT_THROW(testSetSource("invalidurl/media.ts", ""), InvalidLocatorException);
    }

    void test_emptySourceGeneratesException()
    {
        CPPUNIT_ASSERT_THROW(testSetSource("", ""), InvalidLocatorException);
    }

    void test_dashCompoundURIRoutesToDashMediaRouter()
    {
        testSetSource(ms3DashSource, httpDashRouter);
    }

    void test_hlsCompoundURIRoutesToHlsMediaRouter()
    {
        testSetSource(ms3HlsSource, httpHlsRouter);
    }

    void test_queryUriIsParsedCorrectly()
    {
        // Test that the routing logic looks at the .mpd part (dash) rather than
        // the .ts part
        testSetSource("http://assets.broadcaster.com/cms.mpd?q=eastenders.ts",
            httpDashRouter);
    }

    void test_filenameIsExtractedFromNonMS3UriWithFragment()
    {
        testSetSource("http://assets.broadcaster.com/media.m3u8#t=10,20",
            httpHlsRouter);
    }

    void test_emptyQueryURLRoutesToHttpDefault()
    {
        testSetSource("http://assets.broadcaster.com/cms.jsp?q=", httpDefaultRouter);
    }

    void test_dashFileWithNoStemRoutesToDashRouter()
    {
        testSetSource("http://vs-hls-uk-stage.edgesuite.net/pool_1/live/bbc_parliament/bbc_parliament.isml/.mpd",
                httpDashRouter);
    }

private:
    SystemFactory& loadFactory() {
		SystemFactory* factory = createSystemFactory();
        return *factory;
    }

    const std::string httpDashSource;
    const std::string httpHlsSource;
    const std::string httpsHlsSource;
    const std::string ms3DashSource;
    const std::string ms3HlsSource;
    const std::string httpHlsRouter;
    const std::string httpDashRouter;
    const std::string defaultRouter;
    const std::string httpDefaultRouter;

    boost::shared_ptr<NS_ZINC::SingleThreadDispatcher> theDispatcher;

    CPPUNIT_TEST_SUITE(ProxyRoutingTest);
    CPPUNIT_TEST(test_httpDashSourceRoutesToDashMediaRouter);
    CPPUNIT_TEST(test_httpHlsSourceRoutesToHlsMediaRouter);
    CPPUNIT_TEST(test_httpsHlsSourceRoutesToHlsMediaRouter);
    CPPUNIT_TEST(test_dvbSourceRoutesToDefaultMediaRouter);
    CPPUNIT_TEST(test_linearSourceRoutesToLinearMediaRouter);
    CPPUNIT_TEST(test_unknownProtocolRoutesToDefaultMediaRouter);
    CPPUNIT_TEST(test_missingHostRoutesToDefaultMediaRouter);
    CPPUNIT_TEST(test_missingProtocolGeneratesException);
    CPPUNIT_TEST(test_emptySourceGeneratesException);
    CPPUNIT_TEST(test_dashCompoundURIRoutesToDashMediaRouter);
    CPPUNIT_TEST(test_hlsCompoundURIRoutesToHlsMediaRouter);
    CPPUNIT_TEST(test_queryUriIsParsedCorrectly);
    CPPUNIT_TEST(test_filenameIsExtractedFromNonMS3UriWithFragment);
    CPPUNIT_TEST(test_emptyQueryURLRoutesToHttpDefault);
    CPPUNIT_TEST(test_dashFileWithNoStemRoutesToDashRouter);
    CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(ProxyRoutingTest);

NS_NICKEL_SYSTEM_CLOSE
