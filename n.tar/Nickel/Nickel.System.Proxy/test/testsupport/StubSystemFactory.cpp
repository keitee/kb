/*
 * StubSystemFactory.cpp
 *
 *  Created on: Aug 9, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2012, Youview TV Ltd.
 */

#include "../include/testsupport/Stub.h"
#include "../include/testsupport/StubSystemFactory.h"

#include <nickel-system-api/SystemFactory.h>
#include <zinc-common/async/SingleThreadDispatcher.h>

#include <boost/make_shared.hpp>


NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;
using namespace std;

Stub::Stub(const std::string& stubName_, boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_) :
	stubName(stubName_),
    dispatcher(dispatcher_)
{
}

Stub::~Stub() {}

NS_NICKEL_SYSTEM_CLOSE

namespace
{
    boost::shared_ptr<NS_ZINC::SingleThreadDispatcher> dispatcher;
}

extern "C" {
	NS_NICKEL_SYSTEM::SystemFactory* createSystemFactory(const char* stubName) ZINC_EXPORT;
	NS_NICKEL_SYSTEM::SystemFactory* createSystemFactory(const char* stubName)
    {
        if(!dispatcher.get())
        {
            dispatcher.reset(new NS_ZINC::SingleThreadDispatcher);
        }
		return new NS_NICKEL_SYSTEM::StubSystemFactory(stubName, dispatcher);
	}
}
