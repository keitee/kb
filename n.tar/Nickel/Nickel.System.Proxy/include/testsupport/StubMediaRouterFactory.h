#ifndef STUBMEDIAROUTERFACTORY_H
#define STUBMEDIAROUTERFACTORY_H

/**
 * StubMediaRouterFactory.h
 *
 * Created on: Dec 29, 2014
 *     Author: Tom Bailey
 *
 *
 * Copyright 2014, YouView TV Ltd.
 */

#include "Stub.h"
#include <nickel-system-api/MediaRouterFactory.h>
#include <nickel-system-api/MockMediaRouterAsync.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-common/async/async-helpers.h>

namespace Zinc
{
    class Dispatcher;
}

NS_NICKEL_SYSTEM_OPEN

using testing::_;
using testing::Return;

class ZINC_LOCAL StubMediaRouterFactory : public MediaRouterFactory, public Stub {

public:

	StubMediaRouterFactory(const std::string& stubName_, boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_) :
		Stub(stubName_, dispatcher_) {
	}

	virtual NS_ZINC::Future<boost::shared_ptr<MediaRouter> > createMediaRouter()
    {
        NICKEL_FUNC_TRACE;

        boost::shared_ptr<MockMediaRouterAsync> mock
            = boost::make_shared<MockMediaRouterAsync>();
        mock->setDispatcher(dispatcher);

        // Make use of the ever-versatile getSourceInformation call to provide
        // a way for unit test code to check what kind of media router has
        // been created. See also ProxyRoutingTest.cpp
        EXPECT_CALL(*mock, setSource(_, SetSourceReason::mhegstandard))
            .WillRepeatedly(Return(NS_ZINC::completedFuture(*dispatcher)));
        std::map<std::string, std::string> sourceInfo;
        sourceInfo["STUB_NAME"] = stubName;
        EXPECT_CALL(*mock, getSourceInformation()).WillRepeatedly(Return(
                    NS_ZINC::completedFuture(*dispatcher, sourceInfo)));

        // We need to force instantiation of the template returning
        // Future<shared_ptr<MediaRouter> > rather than
        // Future<shared_ptr<MockMediaRouterAsync> >. Need to add a template
        // ctor to Future to solve this.
        return NS_ZINC::completedFuture(*dispatcher, boost::shared_ptr<MediaRouter>(mock));
	}
};

NS_NICKEL_SYSTEM_CLOSE
#endif // STUBMEDIAROUTERFACTORY_H
