#ifndef NICKEL_SYSTEM_PROXY_SIMPLEMEDIAROUTERFACTORY_H
#define NICKEL_SYSTEM_PROXY_SIMPLEMEDIAROUTERFACTORY_H

/**
 * SimpleMediaRouterFactory.h
 *
 * Created on: May 15, 2015
 *     Author: tom.bailey@youview.com
 *
 *
 * Copyright 2015, YouView TV Ltd.
 */

#include "Stub.h"
#include <nickel-system-api/MediaRouterFactory.h>
#include <nickel-common/NickelLogger.h>

NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL SimpleMediaRouterFactory : public MediaRouterFactory, public Stub {

public:

	SimpleMediaRouterFactory(const std::string& stubName_,
            boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_) :
		Stub(stubName_, dispatcher_)
    {}

	virtual NS_ZINC::Future<boost::shared_ptr<MediaRouter> > createMediaRouter()
    {
        NICKEL_FUNC_TRACE;

        return NS_ZINC::completedFuture(*dispatcher, mediaRouter);
	}

    void setMockMediaRouter(boost::shared_ptr<MockMediaRouterAsync> mediaRouter_)
    {
        mediaRouter_->setDispatcher(dispatcher);
        mediaRouter = mediaRouter_;
    }

private:
    boost::shared_ptr<MediaRouter> mediaRouter;
};

NS_NICKEL_SYSTEM_CLOSE
#endif // NICKEL_SYSTEM_PROXY_SIMPLEMEDIAROUTERFACTORY_H
