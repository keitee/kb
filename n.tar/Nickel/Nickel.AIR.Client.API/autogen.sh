#!/bin/sh

ln -sf ${ZINC_DESTDIR}${ZINC_HOST_PREFIX}/devel/share/zinc-binding-runtime/air/CommonMakefile.am CommonMakefile.am

echo "Generating configure files... may take a while."

autoreconf --install --force && \
  echo "Preparing was successful if there was no error messages above." && \
  echo "Now type:" && \
  echo "  ./configure && make"  && \
  echo "Run './configure --help' for more information"

