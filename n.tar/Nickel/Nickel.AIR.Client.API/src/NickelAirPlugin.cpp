/*
 * NickelAirPlugin.cpp
 *
 *  Created on: 04-May-2010
 *      Author: jsadler
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#include "macros.h"

#include <nickel-client-api/nickel-client-api.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-binding-runtime/air/air-runtime.h>
#include <zinc-binding-runtime/air/GenericAirPlugin.h>


// Bindings
#include "ABRStatusBinding.h"
#include "ABRStreamSetBinding.h"
#include "BufferStatusBinding.h"
#include "ControlCapabilitiesBinding.h"
#include "VideoWindowDescriptorBinding.h"
#include "MediaRouterBinding.h"
#include "MediaRouterFactoryBinding.h"
#include "MediaSettingsBinding.h"
#include "AudioOutputBinding.h"
#include "HDMIDisplayBinding.h"
#include "AnalogueDisplayBinding.h"
#include "OutputManagerBinding.h"
#include "PositionBinding.h"
#include "LocatorBinding.h"
#include "ServiceListBuilderBinding.h"
#include "TrackBinding.h"
#include "IllegalReconfigurationBinding.h"
#include "IllegalSeekBinding.h"
#include "InsufficientResourcesBinding.h"
#include "InvalidDurationBinding.h"
#include "InvalidEnumerationBinding.h"
#include "InvalidLanguageBinding.h"
#include "InvalidLocatorBinding.h"
#include "InvalidStreamIndexBinding.h"
#include "InvalidTagBinding.h"
#include "InvalidOutputBinding.h"
#include "NotApplicableBinding.h"
#include "NotConfiguredBinding.h"
#include "NotSupportedBinding.h"
#include "OutOfBoundsBinding.h"
#include "PlayConflictBinding.h"
#include "StopConflictBinding.h"
#include "GraphicsResolutionBinding.h"
#include "VideoConversionsBinding.h"

#include "AudioFeedbackBinding.h"
#include "AudioSampleBinding.h"

// Reverse Bindings
#include "MediaRouterEventListenerReverseBinding.h"
#include "MediaSettingsListenerReverseBinding.h"
#include "OutputManagerEventListenerReverseBinding.h"
#include "ServiceListBuilderEventListenerReverseBinding.h"



using namespace NS_NICKEL_AIR_CLIENT;
using namespace NS_NICKEL_AUDIO_AIR_CLIENT;
using namespace NS_NICKEL_CLIENT;
using namespace NS_ZINC_AIR_BINDING;

using namespace boost;

NS_NICKEL_AIR_CLIENT_OPEN
class ZINC_LOCAL NickelAirPlugin : public GenericAirPlugin<NickelAirPlugin, ClientFactory> {

    void registerBindings() {

        registerBinding<LocatorBinding>();

        registerBinding<ABRStatusBinding>();

        registerBinding<ABRStreamSetBinding>();

        registerBinding<BufferStatusBinding>();

        registerBinding<ControlCapabilitiesBinding>();

        registerBinding<VideoWindowDescriptorBinding>();

        registerBinding<MediaRouterBinding>();

        registerBinding<MediaRouterFactoryBinding>();

        registerBinding<MediaSettingsBinding>();

        registerBinding<AudioOutputBinding>();

        registerBinding<HDMIDisplayBinding>();

        registerBinding<AnalogueDisplayBinding>();

        registerBinding<OutputManagerBinding>();

        registerBinding<PositionBinding>();

        registerBinding<ServiceListBuilderBinding>();

        registerBinding<TrackBinding>();

        registerBinding<GraphicsResolutionBinding>();

        registerBinding<VideoConversionsBinding>();

        // NS_NICKEL_AUDIO_AIR_CLIENT
        registerBinding<AudioFeedbackBinding>();

        registerBinding<AudioSampleBinding>();
    }

    void registerReverseBindings() {

        registerReverseBinding<MediaRouterEventListenerReverseBinding>();

        registerReverseBinding<MediaSettingsListenerReverseBinding>();

        registerReverseBinding<OutputManagerEventListenerReverseBinding>();

        registerReverseBinding<ServiceListBuilderEventListenerReverseBinding>();
    }

    void initSingletons(ClientFactory& clientFactory) {

        // Locator is singleton, so we set the instance here. All AScript method calls will delegate to
        // this single instance.
        LocatorBinding::setSingletonInstance(clientFactory.createLocator());
    }

    void registerExceptionBindings() {

        registerExceptionBinding<IllegalReconfigurationBinding>();

        registerExceptionBinding<IllegalSeekBinding>();

        registerExceptionBinding<InsufficientResourcesBinding>();

        registerExceptionBinding<InvalidDurationBinding>();

        registerExceptionBinding<InvalidEnumerationBinding>();

        registerExceptionBinding<InvalidLanguageBinding>();

        registerExceptionBinding<InvalidLocatorBinding>();

        registerExceptionBinding<InvalidStreamIndexBinding>();

        registerExceptionBinding<InvalidTagBinding>();

        registerExceptionBinding<InvalidOutputBinding>();

        registerExceptionBinding<NotApplicableBinding>();

        registerExceptionBinding<NotConfiguredBinding>();

        registerExceptionBinding<NotSupportedBinding>();

        registerExceptionBinding<OutOfBoundsBinding>();

        registerExceptionBinding<PlayConflictBinding>();

        registerExceptionBinding<StopConflictBinding>();
    }

};

NS_NICKEL_AIR_CLIENT_CLOSE

ZINC_AIR_BINDING_REGISTER_PLUGIN(NS_NICKEL_AIR_CLIENT::NickelAirPlugin);

