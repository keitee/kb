/*
 * macros.h
 *
 *  Created on: 04-May-2010
 *      Author: jsadler
 *
 *   Copyright (C) 2010 British Broadcasting Corporation
 */

#ifndef NICKEL_AIR_CLIENT_API_MACROS_H_
#define NICKEL_AIR_CLIENT_API_MACROS_H_

#include <nickel-client-api/macros.h>

#define NS_NICKEL_AIR_CLIENT_OPEN NS_NICKEL_CLIENT_OPEN namespace air {
#define NS_NICKEL_AIR_CLIENT_CLOSE NS_NICKEL_CLIENT_CLOSE }
#define NS_NICKEL_AIR_CLIENT NS_NICKEL_CLIENT::air

#define NS_NICKEL_AUDIO_AIR_CLIENT_OPEN NS_NICKEL_AUDIO_CLIENT_OPEN namespace air {
#define NS_NICKEL_AUDIO_AIR_CLIENT_CLOSE NS_NICKEL_AUDIO_CLIENT_CLOSE }
#define NS_NICKEL_AUDIO_AIR_CLIENT NS_NICKEL_AUDIO_CLIENT::air

#endif /* NICKEL_AIR_CLIENT_API_MACROS_H_ */
