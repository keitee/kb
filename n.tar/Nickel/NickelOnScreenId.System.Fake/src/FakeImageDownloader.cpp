/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "FakeImageDownloader.h"

#include <boost/make_shared.hpp>

#include <iostream>
#include <map>

namespace Zinc {
namespace OnScreenId {

namespace {

class FakeImageDownloader : public ImageDownloader
{
public:

    virtual ~FakeImageDownloader() {}

    virtual void download(uint8_t ref, const std::string& url);

    virtual std::string getPath(uint8_t ref);

    virtual void dispose();

private:
    std::map<uint8_t, std::string> downloaded;
};

void FakeImageDownloader::download(uint8_t ref, const std::string& url)
{
    std::clog << "Scheduling image download job (ID "
              << static_cast<uint32_t>(ref) << "): " << url
              << std::endl;

    // let's pretend we downloaded it into /tmp
    downloaded[ref] = std::string(url).replace(0, url.rfind('/'), "/tmp");
}

std::string FakeImageDownloader::getPath(uint8_t ref)
{
    return downloaded[ref];
}

void FakeImageDownloader::dispose()
{
    std::clog << "Disposing downloader resources" << std::endl;
    downloaded.clear();
}

} // namespace

boost::shared_ptr<ImageDownloader> createFakeImageDownloader()
{
    return boost::make_shared<FakeImageDownloader>();
}

} // namespace OnScreenId
} // namespace Zinc
