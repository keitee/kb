/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include <nickelonscreenid-system-api/Factory.h>

#include <cstdlib>
#include <iostream>

namespace Zinc {
namespace OnScreenId {

extern boost::shared_ptr<ImageDownloader> createFakeImageDownloader();
extern boost::shared_ptr<RenderEngine> createFakeRenderEngine();

namespace {

class FakeFactory : public Factory
{
public:
    virtual ~FakeFactory() {}

    virtual boost::shared_ptr<ImageDownloader> createImageDownloader(
        const boost::shared_ptr<NS_ZINC::FutureDispatcher>& disp) const;

    virtual boost::shared_ptr<RenderEngine> createRenderEngine() const;
};

boost::shared_ptr<ImageDownloader> FakeFactory::createImageDownloader(
    const boost::shared_ptr<NS_ZINC::FutureDispatcher>&) const
{
    return createFakeImageDownloader();
}

boost::shared_ptr<RenderEngine> FakeFactory::createRenderEngine() const
{
    return createFakeRenderEngine();
}

} // namespace

extern "C"
NS_ZINC::Plugin* createFakeFactory() ZINC_EXPORT;

NS_ZINC::Plugin* createFakeFactory()
{
    try
    {
        return new FakeFactory();
    }
    catch (const std::exception& e)
    {
        std::cerr << "Error while creating FakeFactory: " << e.what() << '\n';
    }
    catch (...)
    {
        std::cerr << "Unknown error while creating FakeFactory\n";
    }

    std::abort();
}

} // namespace OnScreenId
} // namespace Zinc
