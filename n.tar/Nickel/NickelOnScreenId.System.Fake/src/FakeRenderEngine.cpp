/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#include "FakeRenderEngine.h"

#include <boost/make_shared.hpp>
#include <boost/io/ios_state.hpp>

#include <iomanip>
#include <iostream>

namespace Zinc {
namespace OnScreenId {

namespace {

class FakeRenderEngine : public RenderEngine
{
public:

    virtual ~FakeRenderEngine();

    virtual void prerenderImage(uint8_t ref,
                                const position_t& pos,
                                const box_t& box,
                                const std::string& path);

    virtual void prerenderText(uint8_t ref,
                               const position_t& pos,
                               const box_t& box,
                               uint8_t fontSize,
                               const colours_t& fontColours,
                               const std::string& text);

    virtual void show(uint8_t ref);
    virtual void show(uint8_t ref,
                      const position_t& pos);

    virtual void hide(uint8_t ref);

    virtual void dispose();
};

FakeRenderEngine::~FakeRenderEngine()
{
}

void FakeRenderEngine::prerenderImage(uint8_t ref,
                                      const position_t& pos,
                                      const box_t& box,
                                      const std::string& path)
{
    std::clog << "Pre-rendering ID " << static_cast<uint32_t>(ref) << '\n'
              << "  position: " << pos.first << ", " << pos.second << '\n'
              << "  box size: " << box.first << ", " << box.second << '\n'
              << "  image   : " << path
              << std::endl;
}

void FakeRenderEngine::prerenderText(uint8_t ref,
                                     const position_t& pos,
                                     const box_t& box,
                                     uint8_t fontSize,
                                     const colours_t& fontColours,
                                     const std::string& text)
{
    std::clog << "Pre-rendering ID " << static_cast<uint32_t>(ref) << '\n'
              << "  position : " << pos.first << ", " << pos.second << '\n'
              << "  box size : " << box.first << ", " << box.second << '\n'
              << "  font size: " << static_cast<uint32_t>(fontSize) << '\n';

    {
        boost::io::ios_flags_saver ifs(std::clog);
        std::clog << std::hex
                  << "  fg colour: " << fontColours.first << '\n'
                  << "  bg colour: " << fontColours.second << '\n';
    }
     
    std::clog << "  text     : " << text
              << std::endl;
}

void FakeRenderEngine::show(uint8_t ref)
{
    std::clog << "Enabling static ID " << static_cast<uint32_t>(ref)
              << std::endl;
}

void FakeRenderEngine::show(uint8_t ref,
                            const position_t& pos)
{
    std::clog << "Enabling dynamic ID " << static_cast<uint32_t>(ref) << '\n'
              << "  position: " << pos.first << ", " << pos.second
              << std::endl;
}

void FakeRenderEngine::hide(uint8_t ref)
{
    std::clog << "Disabling ID " << static_cast<uint32_t>(ref) << std::endl;
}

void FakeRenderEngine::dispose()
{
    std::clog << "Disposing rendering resources" << std::endl;
}

} // namespace

boost::shared_ptr<RenderEngine> createFakeRenderEngine()
{
    return boost::make_shared<FakeRenderEngine>();
}

} // namespace OnScreenId
} // namespace Zinc
