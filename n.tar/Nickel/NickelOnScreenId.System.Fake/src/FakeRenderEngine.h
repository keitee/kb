/*
 * Author: kris@youview.com
 *
 * Copyright (C) 2013 YouView TV Ltd
 */

#ifndef NICKEL_ONSCREENID_SYSTEM_FAKE_FAKERENDERENGINE_H_
#define NICKEL_ONSCREENID_SYSTEM_FAKE_FAKERENDERENGINE_H_

#include <nickelonscreenid-system-api/RenderEngine.h>

#include <boost/shared_ptr.hpp>

namespace Zinc {
namespace OnScreenId {

boost::shared_ptr<RenderEngine> createFakeRenderEngine();

} // namespace OnScreenId
} // namespace Zinc

#endif // NICKEL_ONSCREENID_SYSTEM_FAKE_FAKERENDERENGINE_H_
