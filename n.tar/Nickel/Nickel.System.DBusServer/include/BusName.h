/*
 * BusName.h
 *
 *  Created on: 05-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#ifndef NICKEL_SYSTEM_DBUS_BUSNAME_H_
#define NICKEL_SYSTEM_DBUS_BUSNAME_H_

#include <nickel-system-api/macros.h>

NS_NICKEL_SYSTEM_OPEN

class ZINC_EXPORT BusName {
public:
	static char const * const LOCAL_MEDIA_LIBRARY;
	static char const * const MEDIA_ROUTER;
	static char const * const MEDIA_ROUTER_FACTORY;
	static char const * const DEFAULT_MEDIA_ROUTER;
	static char const * const MEDIA_SETTINGS;
	static char const * const OUTPUT_MANAGER;
    static char const * const SERVICE_LIST_BUILDER;
	static char const * const MEDIA;
private:
	BusName();
};

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_DBUS_BUSNAME_H_ */
