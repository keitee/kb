/* Copyright (C) 2009 British Broadcasting Corporation */
/*
 * ObjectPath.h
 *
 *  Created on: 05-Mar-2009
 *      Author: thomas.gutteridge@bbc.co.uk
 */

#ifndef NICKEL_SYSTEM_DBUS_OBJECTPATH_H_
#define NICKEL_SYSTEM_DBUS_OBJECTPATH_H_

#include <nickel-system-api/macros.h>

NS_NICKEL_SYSTEM_OPEN

namespace ObjectPath {
	const char* const LOCAL_MEDIA_LIBRARY = "/Zinc/Media/LocalMediaLibrary";
	const char* const MEDIA_ROUTER_FACTORY = "/Zinc/Media/MediaRouterFactory";
	const char* const DEFAULT_MEDIA_ROUTER = "/Zinc/Media/DefaultMediaRouter";
	const char* const MEDIA_ROUTER = "/Zinc/Media/MediaRouter";
	const char* const MEDIA_SETTINGS = "/Zinc/Media/MediaSettings";
	const char* const OUTPUT_MANAGER = "/Zinc/Media/OutputManager";
	const char* const SERVICE_LIST_BUILDER = "/Zinc/Media/ServiceListBuilder";
}

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_DBUS_OBJECTPATH_H_ */
