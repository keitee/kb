/*
 * BusName.cpp
 *
 *  Created on: Mar 17, 2009
 *      Author: thomas.gutteridge@bbc.co.uk
 *
 *  Copyright (C) 2009 British Broadcasting Corporation
 */

#include "../include/BusName.h"

NS_NICKEL_SYSTEM_OPEN

char const * const BusName::MEDIA = "Zinc.Media";

// The following are deprecated.  Dont use. Use BusName::MEDIA instead
char const * const BusName::LOCAL_MEDIA_LIBRARY = BusName::MEDIA;
char const * const BusName::MEDIA_ROUTER = BusName::MEDIA;
char const * const BusName::MEDIA_ROUTER_FACTORY = BusName::MEDIA;
char const * const BusName::DEFAULT_MEDIA_ROUTER = BusName::MEDIA;
char const * const BusName::MEDIA_SETTINGS = BusName::MEDIA;
char const * const BusName::OUTPUT_MANAGER = BusName::MEDIA;
char const * const BusName::SERVICE_LIST_BUILDER = BusName::MEDIA;

NS_NICKEL_SYSTEM_CLOSE
