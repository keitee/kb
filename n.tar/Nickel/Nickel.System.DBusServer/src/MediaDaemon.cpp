/*
 * MediaDaemon.cpp
 *
 *  Created on: Aug 18, 2009
 *      Author: thomas.gutteridge@bbc.co.uk
 *
 * Copyright (C) 2013 YouView TV Ltd.
 */

/**
 * See usage()
 */

#include "../include/BusName.h"
#include "../include/ObjectPath.h"
#include "LocalMediaLibraryAsyncToDBus.h"
#include "MediaRouterFactoryAsyncToDBus.h"
#include "MediaSettingsAsyncToDBus.h"
#include "OutputManagerAsyncToDBus.h"
#include "ServiceListBuilderSyncToDBus.h"
#include "ServiceListBuilderAsyncToDBus.h"

#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/Position.h>
#include <zinc-binding-runtime/dbus/dbus-runtime.h>
#include <zinc-binding-runtime/dbus/DBusService.h>
#include <zinc-binding-runtime/dbus/MainLoop.h>
#include <zinc-binding-runtime/dbus/SignalReceiver.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>

#include <boost/foreach.hpp>
#include <boost/program_options.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>
#include <boost/noncopyable.hpp>

#include <iostream>
#include <stdexcept>

using namespace NS_NICKEL_SYSTEM;
using namespace NS_ZINC_DBUS_BINDING;
using namespace std;
using namespace boost;
using NS_NICKEL_SYSTEM::Position;

namespace{
class MediaDaemon : boost::noncopyable {
public:
	MediaDaemon(MainLoop& mainloop_);
	~MediaDaemon();
	void start(int argc, char *argv[]);
	void stop();

private:
	MainLoop& mainloop;
	SignalReceiver sr;
	DBusService dbus;

	boost::scoped_ptr<NS_ZINC_DBUS_BINDING::BusNameMonitor> bnm;

	std::string busName;
	std::string args;
	std::string configFilePath;

	bool mediaRoutersEnabled;
	bool mediaSettingsEnabled;
	bool outputManagerEnabled;
	bool serviceListBuilderEnabled;
	bool localMediaLibraryEnabled;

	void parseArgs( int argc, char* argv[] );

};

MediaDaemon::MediaDaemon(MainLoop& mainloop_):
		mainloop(mainloop_),
		sr(mainloop_, createExitSignalHandler(boost::bind(&MediaDaemon::stop, this))),
		dbus(mainloop_),
		mediaRoutersEnabled(true),
		mediaSettingsEnabled(true),
		outputManagerEnabled(true),
		serviceListBuilderEnabled(true),
		localMediaLibraryEnabled(true)
{
}

MediaDaemon::~MediaDaemon()
{
}

void MediaDaemon::start(int argc, char *argv[])
{
	sr.start();
	dbus.start();

	parseArgs(argc, argv);

	NS_ZINC::FilePluginConfig filePluginConfig(configFilePath);

	// combine file plugin with command-line-arguments
	NS_ZINC::FixedPluginConfig pluginConfig( filePluginConfig.getLibraryName(),
											filePluginConfig.getCreateFunctionName(),
											filePluginConfig.getCreateParameters() + std::string(" ") + args );

	SystemFactory& factory = NS_ZINC::PluginFactory::getInstance<SystemFactory>(pluginConfig);

	DBus::Connection conn = dbus.getConnection();
	bnm.reset(new NS_ZINC_DBUS_BINDING::BusNameMonitor(conn));

	// Expose the objects on the bus
	// Check command line options for exposing each object
	if (mediaRoutersEnabled)
	{
		dbus.expose(ObjectPath::MEDIA_ROUTER_FACTORY, factory.createMediaRouterFactory(),
				boost::make_shared<NonInheritingAdaptorFactory<MediaRouter> >(
						NS_ZINC_DBUS_BINDING::RefCountedAdaptorFactory<MediaRouter>(*bnm), conn, "/Zinc/Media/MediaRouters/"));
		dbus.expose(ObjectPath::DEFAULT_MEDIA_ROUTER, factory.createDefaultMediaRouter());
	}
	if (mediaSettingsEnabled)
	{
		dbus.expose(ObjectPath::MEDIA_SETTINGS, factory.createMediaSettings());
	}
	if (outputManagerEnabled)
	{
		dbus.expose(ObjectPath::OUTPUT_MANAGER, factory.createOutputManager());
	}
	if (serviceListBuilderEnabled)
	{
		dbus.expose(ObjectPath::SERVICE_LIST_BUILDER, factory.createServiceListBuilder());
	}
	if (localMediaLibraryEnabled)
	{
		boost::shared_ptr<Zinc::Media::LocalMediaLibrary> localMediaLibrary = factory.createLocalMediaLibrary();
		dbus.expose(ObjectPath::LOCAL_MEDIA_LIBRARY, localMediaLibrary);
	}

	// Publish our objects on the bus at a well known busname
	dbus.request_name( busName.c_str() );
}

void MediaDaemon::stop()
{
	dbus.stop();
	sr.stop();
}

void MediaDaemon::parseArgs( int argc, char* argv[] )
{
	namespace po = boost::program_options;

	std::string defaultConfigFilePath = NS_ZINC::PackageDataFinder().find("media-daemon.plugin-config");
	std::string defaultBusName = BusName::MEDIA;

	po::options_description desc("Allowed options", 120);
	desc.add_options()
		("help,h", "produce help message")
		("config-file,f", po::value<std::string>(&configFilePath)->default_value(defaultConfigFilePath), "filepath of plugin config file")
		("busname,b", po::value<std::string>(&busName)->default_value(defaultBusName), "DBus connection name")
		("no-mediarouters", "disable mediarouters")
		("no-mediasettings", "disable mediasettings")
		("no-localmedialibrary", "disable localmedialibrary")
		("no-outputmanager", "disable outputmanager")
		("no-servicelistbuilder", "disable servicelistbuilder")
		("localmedialibrary-xml", po::value<std::string>(), "filepath of XML standing data to inject")
		;

	po::positional_options_description po_desc;
	po_desc.add("config-file", 1 );

	po::variables_map vm;
	po::parsed_options parsed = po::basic_command_line_parser<char>( argc, argv ).options(desc).positional( po_desc ).allow_unregistered().run();
	po::store(parsed, vm );
	po::notify(vm);

	if (vm.count("help"))
	{
		std::cerr << desc << std::endl;
		throw std::runtime_error("displaying help");
	}

	mediaRoutersEnabled = !bool( vm.count("no-mediarouters") );
	mediaSettingsEnabled = !bool( vm.count("no-mediasettings"));
	localMediaLibraryEnabled = !bool( vm.count( "no-localmedialibrary"));
	outputManagerEnabled = !bool( vm.count( "no-outputmanager"));
	serviceListBuilderEnabled = !bool( vm.count( "no-servicelistbuilder"));

	std::vector<std::string> extraArgs = collect_unrecognized(parsed.options, po::exclude_positional);
	BOOST_FOREACH( const std::string& extraArg, extraArgs )
	{
		args += extraArg + " ";
	}

	if (vm.count("localmedialibrary-xml"))
	{
		// pass through to plugin args as "--localmedialibrary-xml=FILENAME"
		args += std::string("--localmedialibrary-xml=") + vm["localmedialibrary-xml"].as<std::string>();
	}

	NICKEL_INFO("Using configuration file: " << configFilePath);
}

} // anon namespace


int main(int argc, char *argv[]) {
	NICKEL_INFO("Launching Fake Media Router Service Daemon...");
	int result = EXIT_SUCCESS;

	try {
		MainLoop mainloop(BusName::MEDIA);
		MediaDaemon daemon(mainloop);
		mainloop.post(boost::bind(&MediaDaemon::start, &daemon, argc, argv));
		result = mainloop.run();
	} catch (std::exception& e) {
		std::cerr << e.what() << endl;
		result = EXIT_FAILURE;
	}

	NICKEL_INFO("Fake Media Router Service Daemon shutting down...");
	return result;
}

