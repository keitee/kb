/*
 * MinimalMediaFileSystem.cpp
 *
 *  Created on: 20 Feb 2012
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2012 YouView TV Ltd
 */

#include "MinimalMediaFileSystem.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/statvfs.h>

NS_NICKEL_SYSTEM_OPEN

MinimalMediaFileSystem::MinimalMediaFileSystem( const std::string& _mediaPath )
{
	mediaPath = _mediaPath;
}

uint32_t MinimalMediaFileSystem::getDuration( const MediaRecordEx& mediaRecord )
{
	/// @todo use Mpeg TS parsing to get duration of file

	if (mediaRecord.mediaLocator.empty())
	{
		return 0;
	}

	const std::string mediaFilename = getMediaFilename( mediaRecord );

	return 0;
}

int64_t MinimalMediaFileSystem::getSize( const MediaRecordEx& mediaRecord )
{
	if (mediaRecord.mediaLocator.empty())
	{
		return 0;
	}

	const std::string mediaFilename = getMediaFilename( mediaRecord );

	struct stat fileStatus;
	stat( mediaFilename.c_str(), &fileStatus );

	return fileStatus.st_size;
}

int64_t MinimalMediaFileSystem::getFree()
{
	struct statvfs stats;
	int r = statvfs( mediaPath.c_str(), &stats);

	if (r != 0)
	{
		// error
		return 0;
	}

	int64_t freeBytes = stats.f_bsize * stats.f_bfree;
	return freeBytes;
}

uint32_t MinimalMediaFileSystem::getAcquisitionStartTime( const MediaRecordEx& mediaRecord )
{
	if (mediaRecord.mediaLocator.empty())
	{
		return 0;
	}

	const std::string mediaFilename = getMediaFilename( mediaRecord );

	struct stat fileStatus;
	stat( mediaFilename.c_str(), &fileStatus );

//	timespec t = fileStatus.st_ctim;
//	return t.tv_sec;
	return fileStatus.st_ctime;
}


std::string MinimalMediaFileSystem::getMediaFilename( const MediaRecordEx& mediaRecord ) const
{
	std::string mediaFilename = mediaPath + std::string("/") + mediaRecord.mediaLocator + ".ts";

	return mediaFilename;
}

NS_NICKEL_SYSTEM_CLOSE

