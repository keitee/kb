/*
 * MediaRecordStore.h
 *
 *  Created on: 26 Sep 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 *
 *  Interface between MinimalLocalMediaLibrary and the storage of MediaRecord objects
 */

#ifndef NICKEL_SYSTEM_MINIMAL_MEDIARECORDSTORE_H
#define NICKEL_SYSTEM_MINIMAL_MEDIARECORDSTORE_H

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>
#include <iron-system-api/iron-system-api.h>

#include <boost/weak_ptr.hpp>
#include "constants.h"
#include "utils.h"

NS_NICKEL_SYSTEM_OPEN

/*
 * @struct MediaRecordEx
 * @brief An extension of the MediaRecord data structure, with the addition of a unique key field & reference count
 */
struct MediaRecordEx : public MediaRecord
{
	MediaRecordEx() : mediaRecordIdentifierPrimaryKey(0), referenceCount(1), publishedStart(0) {}

	int64_t 	mediaRecordIdentifierPrimaryKey;
	int64_t		referenceCount;
	uint32_t	publishedStart;

	/*
	 * @brief fill the MediaRecord struct with values from the event/service pair
	 */
	void fillMediaRecord( const NS_IRON_SYSTEM::Event& event, const NS_IRON_SYSTEM::Service& service )
	{
		/// @todo Support configured language
		const char* LANGUAGE = "eng";

		if (!event.programmeCrid.empty())
		{
			contentIdentifier = event.programmeCrid;
		}
		else
		{
			contentIdentifier = event.eventLocator;
		}

		identifiers[IDENTIFIERS_KEY_EVENTLOCATOR] = event.eventLocator;
		if (!event.seriesCrid.empty())
		{
			identifiers[IDENTIFIERS_KEY_SERIES_CRID] = event.seriesCrid[0];
		}
		if (!event.recommendationCrid.empty())
		{
			identifiers[IDENTIFIERS_KEY_RECOMMENDATION_CRID] = event.recommendationCrid[0];
		}
		if (!event.collectionCrid.empty())
		{
			identifiers[IDENTIFIERS_KEY_COLLECTION_CRID] = event.collectionCrid[0];
		}
		if (!event.splitInstanceIdentifier.empty())
		{
			identifiers[IDENTIFIERS_KEY_SPLIT_INSTANCE_IDENTIFIER] = event.splitInstanceIdentifier;
		}
		if (!event.programmeCrid.empty())
		{
			identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID] = event.programmeCrid;
		}

		getMapValue( service.name, LANGUAGE, serviceName );
		getMapValue( event.shortTitle, LANGUAGE, title );
		getMapValue( event.mediumSynopsis, LANGUAGE, synopsis );
		publishedStart = event.start;
		publishedDuration = event.publishedDuration;
		adult = service.adult;
		guidanceCode = event.guidanceCode;
		getMapValue( event.guidanceText, LANGUAGE, guidanceText );

		/// @todo subtitles

		audioDescription = event.audioDescription;
		signing = event.signing;
	}


};

inline bool operator==( const MediaRecordEx& i, const MediaRecordEx& j )
{
	return (i.mediaRecordIdentifierPrimaryKey == j.mediaRecordIdentifierPrimaryKey) && (i.referenceCount == j.referenceCount)
			&& ( static_cast<MediaRecord>(i) == static_cast<MediaRecord>(j));
}

inline bool operator<( const MediaRecordEx& i, const MediaRecordEx& j )
{
	return i.mediaRecordIdentifierPrimaryKey < j.mediaRecordIdentifierPrimaryKey;
}

/*
 * @class MediaRecordStore
 * @brief Pure Virtual Interface for MediaRecordStore Component of Nickel.System.Minimal
 */
class MediaRecordStore
{
public:
	virtual ~MediaRecordStore() {}

	/*
	 * @brief Erase all MediaRecords from the store
	 */
	virtual void clear() = 0;

	/*
	 * @brief Create a MediaRecord based Event/Service data
	 * @note If mediaRecord.mediaRecordIdentifierPrimaryKey == 0, then it is populated with an auto-generated primary-key
	 * @note If mediaRecord.mediaRecordIdentifierPrimaryKey != 0, then the mediaRecord is inserted with that primary-key value
	 * @note mediaRecord.mediaRecordIdentifier is not used by this function
	 * @return The unique mediaRecordIdentifier for this MediaRecord
	 * @param mediaRecord The media record to add to the store, this reference is updated with
	 * 				      the unique mediaRecordIdentifier it is assigned
	 */
	virtual int64_t addMediaRecord( MediaRecordEx& mediaRecord ) = 0;

	/*
	 * @brief Delete a MediaRecord based on its' unique mediaRecordIdentifier
	 */
	virtual void deleteMediaRecord( int64_t mediaRecordIdentifier ) = 0;

	/*
	 * @brief Retrieve a MediaRecord based on its' unique mediaRecordIdentifier
	 * @throw MediaRecordNotFound if unable to find a matching MediaRecord
	 */
	virtual MediaRecordEx getMediaRecord( int64_t mediaRecordIdentifier ) = 0;

	/*
	 * @brief Update a MediaRecord based on its' unique mediaRecordIdentifier
	 */
	virtual void updateMediaRecord( const MediaRecordEx& mediaRecord ) = 0;

	/*
	 * @brief Retrieve a list of MediaRecords filtering by contentIdentifier
	 */
	virtual std::vector< MediaRecordEx > getMediaRecordsByContentIdentifier( const std::string& contentIdentifier ) = 0;


	/*
	 * @brief Retrieve a list of MediaRecords filtering by eventLocator
	 */
	virtual std::vector< MediaRecordEx > getMediaRecordsByEventLocator( const std::string& eventLocator ) = 0;

	/*
	 * @brief Retrieve a list of MediaRecords filtering by programme-crid
	 */
	virtual std::vector< MediaRecordEx > getMediaRecordsByProgrammeCrid( const std::string& programmeCrid ) = 0;

	/*
	 * @brief Retrieve a list of MediaRecords, filtering in multiple ways
	 */
	virtual std::vector< MediaRecordEx > getMediaRecords( FilterByType::Enum filterByType, FilterByPlayed::Enum filterByPlayed,
														SortBy::Enum sortBy, bool includeAdult, uint32_t start, uint32_t size ) = 0;

	/*
	 * @class IListener
	 * @brief Listener Interface for objects that are interested in changes to MediaRecords in the Store
	 */
	class IListener
	{
	public:
		virtual void onMediaRecordChanged( int64_t mediaRecordIdentifier, LibraryContentChangeType::Enum changeType ) = 0;
	};

	/*
	 * @brief Set the listener that will receive callbacks for changes to the Media Library
	 */
	virtual void setListener( boost::weak_ptr<IListener> listener ) = 0;

private:

};

NS_NICKEL_SYSTEM_CLOSE

#endif

