/*
 * Clock.h
 *
 *  Created on: 21 Nov 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 *
 *  Access the current time
 */

#ifndef CLOCK_SYSTEM_MINIMAL_CLOCK_H
#define CLOCK_SYSTEM_MINIMAL_CLOCK_H

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

NS_NICKEL_SYSTEM_OPEN

/*
 * @class Clock
 * @brief Access the current time
 */
class Clock
{
public:
	/*
	 * @brief Get the current time ( seconds since epoch )
	 */
	virtual uint32_t getCurrentTime() = 0;
};

NS_NICKEL_SYSTEM_CLOSE

#endif
