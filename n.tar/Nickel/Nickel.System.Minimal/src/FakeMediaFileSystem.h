/*
 * FakeMediaFileSystem.h
 *
 *  Created on: 10 Oct 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 *
 *  Fake implementation of MediaFileSystem interface,
 *  Provided for the purpose of unit-testing MinimalLocalMediaLibrary & testing UI systems
 */

#ifndef NICKEL_SYSTEM_MINIMAL_FAKEMEDIAFILESYSTEM_H
#define NICKEL_SYSTEM_MINIMAL_FAKEMEDIAFILESYSTEM_H

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>
#include <copper-system-api/copper-system-api.h>

#include "MediaFileSystem.h"
#include "Clock.h"

#include <boost/shared_ptr.hpp>

NS_NICKEL_SYSTEM_OPEN

class FakeMediaFileSystem : public MediaFileSystem
{
public:

	FakeMediaFileSystem();
	~FakeMediaFileSystem();

	void initialise( boost::shared_ptr<Clock> clock, boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository, boost::shared_ptr<MediaRecordStore> store, int64_t size );

public: // MediaFileSystem

	virtual uint32_t getDuration( const MediaRecordEx& mediaRecord );
	virtual int64_t getSize( const MediaRecordEx& mediaRecord );
	virtual int64_t getFree();
	virtual uint32_t getAcquisitionStartTime( const MediaRecordEx& mediaRecord );

private:

	boost::shared_ptr<MediaRecordStore> store;
	boost::shared_ptr<Clock> clock;

	int bitrateSD;
	int bitrateHD;
	int bitrateRadio;

	int64_t size;
};

NS_NICKEL_SYSTEM_CLOSE

#endif
