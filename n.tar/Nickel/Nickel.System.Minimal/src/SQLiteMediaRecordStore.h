/*
 * SQLiteMediaRecordStore.h
 *
 *  Created on: 26 Sep 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 *
 *  Implementation of MediaRecordStore interface using SQLite database
 */

#ifndef NICKEL_SYSTEM_MINIMAL_SQLITEMEDIARECORDSTORE_H
#define NICKEL_SYSTEM_MINIMAL_SQLITEMEDIARECORDSTORE_H

#include "MediaRecordStore.h"

#include <zinc-common/sqlite-deprecated/DB.h>
#include <zinc-common/sqlite-deprecated/TableObject.h>

#include <boost/weak_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

NS_NICKEL_SYSTEM_OPEN

class SQLiteMediaRecordStore : public MediaRecordStore, public NS_ZINC::sqlite::DB::IUpdateListener, public boost::enable_shared_from_this<SQLiteMediaRecordStore>
{
public:

	/*
	 * @struct Config
	 * @brief Configuration options
	 */
	struct Config
	{
		Config() : useTempMemoryDB(false) {}

		bool 		useTempMemoryDB;
		std::string	filename;
	};

	SQLiteMediaRecordStore( const Config& config );
	~SQLiteMediaRecordStore();

public: 	// MediaRecordStore

	virtual void clear();
	virtual int64_t addMediaRecord( MediaRecordEx& mediaRecord );
	virtual void deleteMediaRecord( int64_t mediaRecordIdentifier );
	virtual MediaRecordEx getMediaRecord( int64_t mediaRecordIdentifier );
	virtual void updateMediaRecord( const MediaRecordEx& mediaRecord );
	virtual std::vector< MediaRecordEx > getMediaRecordsByContentIdentifier( const std::string& contentIdentifier );
	virtual std::vector< MediaRecordEx > getMediaRecordsByEventLocator( const std::string& eventLocator );
	virtual std::vector< MediaRecordEx > getMediaRecordsByProgrammeCrid( const std::string& programmeCrid );
	virtual std::vector< MediaRecordEx > getMediaRecords( FilterByType::Enum filterByType, FilterByPlayed::Enum filterByPlayed,
															SortBy::Enum sortBy, bool includeAdult, uint32_t start, uint32_t size );
	virtual void setListener( boost::weak_ptr<IListener> listener );

public:		// sqlite::DB::IUpdateListener
	virtual void onUpdateDB( boost::shared_ptr<NS_ZINC::sqlite::DB> db, NS_ZINC::sqlite::DB::IUpdateListener::UpdateType updateType, const std::string& tableName, int64_t rowid );

private:

	void initialiseTables( const Config& config );
	void initialiseTable( NS_ZINC::sqlite::Table* table, const Config& config );

	boost::weak_ptr<IListener> listener;

	NS_ZINC::sqlite::TableObject<MediaRecordEx> tableMediaRecords;

	boost::shared_ptr<NS_ZINC::sqlite::DB> db;
};

NS_NICKEL_SYSTEM_CLOSE

#endif
