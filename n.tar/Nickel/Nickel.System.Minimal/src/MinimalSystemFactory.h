/*
 * MinimalSystemFactory.h
 *
 *  Created on: 26 Sep 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */

#ifndef NICKEL_SYSTEM_MINIMAL__MINIMALSYSTEMFACTORY_H_
#define NICKEL_SYSTEM_MINIMAL__MINIMALSYSTEMFACTORY_H_

#include <zinc-common/async/FutureDispatcher.h>
#include <zinc-common/EventDispatcher.h>
#include <nickel-system-api/nickel-system-api.h>
#include <copper-system-api/copper-system-api.h>
#include <iron-system-api/iron-system-api.h>
#include <cadmium-system-api/cadmium-system-api.h>

#include <zinc-common/async/FutureDispatcher.h>
#include <zinc-common/EventDispatcher.h>
#include <zinc-common/ActionProcessor.h>

#include <boost/shared_ptr.hpp>

#include "MediaRecordStore.h"
#include "MediaFileSystem.h"
#include "Clock.h"

NS_NICKEL_SYSTEM_OPEN

class MinimalSystemFactory : virtual public SystemFactory
{
public:
	MinimalSystemFactory( const char* args );

private: // IPC
	boost::shared_ptr<NS_ZINC::EventDispatcher> getEventDispatcher();
	boost::shared_ptr<NS_ZINC::FutureDispatcher> getFutureDispatcher();
	boost::shared_ptr<NS_ZINC::ActionProcessor> getActionProcessor();
	boost::shared_ptr<NS_ZINC::FutureDispatcher> futuredispatcher;
	boost::shared_ptr<NS_ZINC::EventDispatcher> eventdispatcher;
	boost::shared_ptr<NS_ZINC::ActionProcessor> actionProcessor;

private: // from SystemFactory
	virtual boost::shared_ptr<LocalMediaLibrary> createLocalMediaLibrary();
	virtual boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory();
	virtual boost::shared_ptr<MediaSettings> createMediaSettings();
	virtual boost::shared_ptr<OutputManager> createOutputManager();
	virtual boost::shared_ptr<ServiceListBuilder> createServiceListBuilder();
	virtual boost::shared_ptr<MediaRouter> createDefaultMediaRouter();

private:

	void parseArgs( const char* args );
	void injectXML( const std::string& filename );

	boost::shared_ptr<Clock> clock;

	boost::shared_ptr<LocalMediaLibrary> localMediaLibrary;
	boost::shared_ptr<MediaRouterFactory> mediaRouterFactory;
	boost::shared_ptr<MediaSettings> mediaSettings;
	boost::shared_ptr<OutputManager> outputManager;
	boost::shared_ptr<ServiceListBuilder> serviceListBuilder;
	boost::shared_ptr<MediaRouter> defaultMediaRouter;
	boost::shared_ptr<NS_CADMIUM_SYSTEM::LinearAcquisition> linearAcquisition;

	boost::shared_ptr<MediaRecordStore> mediaRecordStore;

	boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> createLocalStorageRepository();
	boost::shared_ptr<MediaRecordStore> createMediaRecordStore();
	boost::shared_ptr<NS_IRON_SYSTEM::ServiceRepository> createServiceRepository();
	boost::shared_ptr<NS_IRON_SYSTEM::EventRepository> createEventRepository();
	boost::shared_ptr<NS_CADMIUM_SYSTEM::LinearAcquisition> createLinearAcquisition();
	void createClock();

	boost::shared_ptr<MediaFileSystem> createFakeMediaFileSystem();
	boost::shared_ptr<MediaFileSystem> createMinimalMediaFileSystem();

	// Media File System
	bool isUsingFakeMedia;
	std::string mediaPath;
};

NS_NICKEL_SYSTEM_CLOSE

extern "C" {
	ZINC_EXPORT NS_ZINC::Plugin* createMinimalSystemFactory( const char* args );
}

#endif /* IRON_SYSTEM_MINIMALSYSTEMFACTORY_H_ */
