/*
 * FakeMediaFileSystem.cpp
 *
 *  Created on: 10 Oct 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */

#include "FakeMediaFileSystem.h"

#include <boost/foreach.hpp>

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;

namespace
{
	const std::string LSR_KEY_BROADCAST_SD_BITRATE = "platform.localmedialibrary.broadcastsdbitrate";
	const std::string LSR_KEY_BROADCAST_HD_BITRATE = "platform.localmedialibrary.broadcasthdbitrate";
	const std::string LSR_KEY_BROADCAST_RADIO_BITRATE = "platform.localmedialibrary.broadcastradiobitrate";

	class FakeMediaFileSystemException : public std::exception
	{
	public:
		FakeMediaFileSystemException( const std::string& key )
		{
			std::cerr << "FakeMediaFileSystemException: missing LSR KEY '" << key << "'" << std::endl;
		}
	};

	int getIntLSR( boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository, const std::string& key )
	{
		std::string value  =  localStorageRepository->getItem(0, "", key);

		if (value.empty())
		{
			throw FakeMediaFileSystemException( key );
		}

		return boost::lexical_cast<int>( value );
	}

}

FakeMediaFileSystem::FakeMediaFileSystem()
{

}

FakeMediaFileSystem::~FakeMediaFileSystem()
{

}

void FakeMediaFileSystem::initialise( boost::shared_ptr<Clock> _clock, boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository, boost::shared_ptr<MediaRecordStore> _store, int64_t _size )
{
	bitrateSD = getIntLSR( localStorageRepository, LSR_KEY_BROADCAST_SD_BITRATE );
	bitrateHD = getIntLSR( localStorageRepository, LSR_KEY_BROADCAST_HD_BITRATE );
	bitrateRadio = getIntLSR( localStorageRepository, LSR_KEY_BROADCAST_RADIO_BITRATE );

	clock = _clock;
	store = _store;
	size = _size;
}

uint32_t FakeMediaFileSystem::getDuration( const MediaRecordEx& mediaRecord )
{
	uint32_t time = clock->getCurrentTime();
	return time - mediaRecord.acquisitionDateTime;
}

int64_t FakeMediaFileSystem::getSize( const MediaRecordEx& mediaRecord )
{

	switch ( mediaRecord.acquisitionStatus )
	{
	case AcquisitionStatus::not_begun_yet:
		return 0;

	case AcquisitionStatus::begun:
		return (clock->getCurrentTime() - mediaRecord.acquisitionDateTime) * bitrateSD / 8;

	default:
		if (mediaRecord.size > 0)
		{
			// size has already been calculated for this MediaRecord
			return mediaRecord.size;
		}
		else
		{
			// calculate a size for this MediaRecord
			return mediaRecord.duration * bitrateSD / 8;
		}
	}
}

int64_t FakeMediaFileSystem::getFree()
{
	int64_t freeSize = size;

	// iterate through all MediaRecords, subtracting their size from freeSize
	int offset = 0;
	int chunkSize = 10;

	std::vector<MediaRecordEx> mediaRecords;

	do
	{
		mediaRecords = store->getMediaRecords(FilterByType::recordings_and_downloads,FilterByPlayed::played_and_unplayed, SortBy::least_recently_acquired, true, offset, chunkSize );

		BOOST_FOREACH( const MediaRecordEx& mediaRecord, mediaRecords )
		{
			freeSize -= getSize( mediaRecord );
		}

		offset += chunkSize;
	}
	while ( mediaRecords.size() > 0 );

	return freeSize;
}

uint32_t FakeMediaFileSystem::getAcquisitionStartTime( const MediaRecordEx& /*mediaRecord*/ )
{
	/// @note assumption made here that acquisition start time is only requested when acquisition is started
	return clock->getCurrentTime();
}

NS_NICKEL_SYSTEM_CLOSE
