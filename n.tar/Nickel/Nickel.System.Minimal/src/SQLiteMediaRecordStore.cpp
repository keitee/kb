/*
 * SQLiteMediaRecordStore.cpp
 *
 *  Created on: 26 Sep 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */

#include "SQLiteMediaRecordStore.h"

#include <zinc-common/sqlite-deprecated/Query.h>
#include <zinc-common/sqlite-deprecated/Cond.h>

#include <boost/assert.hpp>

NS_ZINC_OPEN

namespace sqlite
{
	/*
	 * @brief Register our custom enumeration types with sqlite::TableObject so that
	 *        it can safely serialise them as integer values
	 */

	TABLEOBJECT_TYPE_ENUM( NS_NICKEL_SYSTEM::AcquisitionStatus::Enum );
}

NS_ZINC_CLOSE

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;

namespace
{
	/*
	 * @brief key values used in the 'identifiers' field
	 */
	const std::string IDENTIFIERS_KEY_EVENTLOCATOR = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.eventLocator";
}


SQLiteMediaRecordStore::SQLiteMediaRecordStore( const Config& config )
{
	std::string filename;

	if (config.useTempMemoryDB)
	{
		// create a temporary Database in memory
		filename = ":memory:";
	}
	else
	{
		// open (or automatically create) a database file
		BOOST_ASSERT( !config.filename.empty() );
		filename = config.filename;
	}

	// create DB connection
	db = sqlite::DB::openDatabase( filename.c_str() );

	initialiseTables( config );
}

SQLiteMediaRecordStore::~SQLiteMediaRecordStore()
{

}

void SQLiteMediaRecordStore::initialiseTables( const Config& config )
{
	TABLEOBJECT_BEGIN( tableMediaRecords, "nickel_mediarecords", MediaRecordEx );

	// MediaRecordEx
	TABLEOBJECT_COLUMN_PRIMARY_KEY( mediaRecordIdentifierPrimaryKey );
	TABLEOBJECT_COLUMN( referenceCount );
	TABLEOBJECT_COLUMN( publishedStart );

	// MediaRecord
	TABLEOBJECT_COLUMN( contentIdentifier );
	TABLEOBJECT_COLUMN( identifiers );
	TABLEOBJECT_COLUMN( mediaLocator );
	TABLEOBJECT_COLUMN( serviceName );
	TABLEOBJECT_COLUMN( title );
	TABLEOBJECT_COLUMN( synopsis );
	TABLEOBJECT_COLUMN( publishedDuration );
	TABLEOBJECT_COLUMN( duration );
	TABLEOBJECT_COLUMN( adult );
	TABLEOBJECT_COLUMN( watershed );
	TABLEOBJECT_COLUMN( guidanceCode );
	TABLEOBJECT_COLUMN( guidanceText );
	TABLEOBJECT_COLUMN( subtitles );
	TABLEOBJECT_COLUMN( audioDescription );
	TABLEOBJECT_COLUMN( signing );
	TABLEOBJECT_COLUMN( acquisitionDateTime );
	TABLEOBJECT_COLUMN( acquisitionStatus );
	TABLEOBJECT_COLUMN( resumeAt );
	TABLEOBJECT_COLUMN( lastAccessed );
	TABLEOBJECT_COLUMN( isProtected );
	TABLEOBJECT_COLUMN( size );

	TABLEOBJECT_END();

	initialiseTable( &tableMediaRecords, config );
}

void SQLiteMediaRecordStore::initialiseTable( sqlite::Table* table, const Config& config )
{
    if (config.useTempMemoryDB)
	{
		BOOST_ASSERT( !db->has( table ));
	}

    if (!db->has( table ))
    {
    	db->create( table );
    }

    BOOST_ASSERT( db->has( table ) );
}

void SQLiteMediaRecordStore::onUpdateDB( boost::shared_ptr<sqlite::DB> /*db*/, sqlite::DB::IUpdateListener::UpdateType updateType, const std::string& tableName, int64_t rowid )
{
	if (tableName != tableMediaRecords.getName())
	{
		return;
	}

	boost::shared_ptr<IListener> l = listener.lock();
	if (l)
	{
		LibraryContentChangeType::Enum changeType;
		switch ( updateType )
		{
		case sqlite::DB::IUpdateListener::updated:
			changeType = LibraryContentChangeType::updated;
			break;
		case sqlite::DB::IUpdateListener::inserted:
			changeType = LibraryContentChangeType::added;
			break;
		case sqlite::DB::IUpdateListener::deleted:
			changeType = LibraryContentChangeType::deleted;
			break;
		default:
			BOOST_ASSERT(!"unknown update type");
			changeType = LibraryContentChangeType::updated;
		}

		l->onMediaRecordChanged( rowid, changeType );
	}
}

void SQLiteMediaRecordStore::clear()
{
	sqlite::Query query;
	query.deleteFrom( &tableMediaRecords );

	db->execute( query );
}

int64_t SQLiteMediaRecordStore::addMediaRecord( MediaRecordEx& mediaRecordEx )
{
	// insert the new MediaRecord into the database
	tableMediaRecords.insert( db, mediaRecordEx );

	// sqlite documentation states that the PRIMARY KEY field will be used as the ROWID
	int64_t mediaRecordIdentifierPrimaryKey = db->getLastInsertRowID();

	// store the generated mediaRecordIdentifier in the MediaRecord that we just stored
	mediaRecordEx.mediaRecordIdentifierPrimaryKey = mediaRecordIdentifierPrimaryKey;

	return mediaRecordIdentifierPrimaryKey;
}

void SQLiteMediaRecordStore::deleteMediaRecord( int64_t mediaRecordIdentifier )
{
	sqlite::Query query;
	query.deleteFrom( &tableMediaRecords ).where( sqlite::Cond().column( "mediaRecordIdentifierPrimaryKey").equals().value( mediaRecordIdentifier ) );

	db->execute( query );
}

MediaRecordEx SQLiteMediaRecordStore::getMediaRecord( int64_t mediaRecordIdentifier )
{
	sqlite::Query query = tableMediaRecords.getQuerySelect().where( sqlite::Cond().column("mediaRecordIdentifierPrimaryKey").equals().value( mediaRecordIdentifier ));

	std::vector<MediaRecordEx> mediaRecords = tableMediaRecords.get( db, query );

	if ( 0 == mediaRecords.size() )
	{
		throw MediaRecordNotFound();
	}

	MediaRecordEx& mediaRecordEx = mediaRecords[0];

	return mediaRecordEx;
}

void SQLiteMediaRecordStore::updateMediaRecord( const MediaRecordEx& mediaRecordEx )
{
	tableMediaRecords.update( db, mediaRecordEx );
}

std::vector< MediaRecordEx > SQLiteMediaRecordStore::getMediaRecordsByContentIdentifier( const std::string& contentIdentifier )
{
	std::vector< MediaRecordEx > mediaRecords;

	sqlite::Query query = tableMediaRecords.getQuerySelect();
	query.where( sqlite::Cond().column("contentIdentifier").equals().value( contentIdentifier ) );

	mediaRecords = tableMediaRecords.get( db, query );

	return mediaRecords;
}

std::vector< MediaRecordEx > SQLiteMediaRecordStore::getMediaRecordsByEventLocator( const std::string& eventLocator )
{
	std::vector< MediaRecordEx > mediaRecords;

	sqlite::Query query = tableMediaRecords.getQuerySelect();
	query.where( sqlite::Cond().column("identifiers").like().value( std::string("%{") + IDENTIFIERS_KEY_EVENTLOCATOR + std::string("}=>{") + eventLocator + std::string("}%") ) );

	mediaRecords = tableMediaRecords.get( db, query );

	return mediaRecords;
}

std::vector< MediaRecordEx > SQLiteMediaRecordStore::getMediaRecordsByProgrammeCrid( const std::string& programmeCrid )
{
	std::vector< MediaRecordEx > mediaRecords;

	sqlite::Query query = tableMediaRecords.getQuerySelect();
	query.where( sqlite::Cond().column("identifiers").like().value( std::string("%{") + IDENTIFIERS_KEY_PROGRAMME_CRID + std::string("}=>{") + programmeCrid + std::string("}%") ) );

	mediaRecords = tableMediaRecords.get( db, query );

	return mediaRecords;
}

std::vector< MediaRecordEx > SQLiteMediaRecordStore::getMediaRecords( FilterByType::Enum /*filterByType*/, FilterByPlayed::Enum filterByPlayed,
																SortBy::Enum sortBy, bool includeAdult, uint32_t start, uint32_t size )
{
	std::vector< MediaRecordEx > mediaRecords;

	sqlite::Query query = tableMediaRecords.getQuerySelect();

	sqlite::Cond cond;

	if (filterByPlayed != FilterByPlayed::played_and_unplayed)
	{
		sqlite::Cond condByPlayed;
		condByPlayed.column("resumeAt");

		switch (filterByPlayed)
		{
		case FilterByPlayed::played:
			condByPlayed.greaterThan().value( 0 );
			break;

		case FilterByPlayed::unplayed:
			condByPlayed.equals().value( 0 );
			break;

		default:
			break;
		}

		cond.cond( condByPlayed );
	}

	if (!includeAdult)
	{
		// remove adult content from the search
		sqlite::Cond condAdult;
		condAdult.column("adult").equals().value( 0 );

		if (!cond.empty())
		{
			cond.opAND();
		}

		cond.cond( condAdult );
	}

	switch (sortBy)
	{
	case SortBy::title_a_to_z:
		query.orderBy( "title" );
		break;
	case SortBy::title_z_to_a:
		query.orderByDesc( "title" );
		break;
	case SortBy::least_recently_acquired:
		query.orderBy( "acquisitionDateTime" );
		break;
	case SortBy::most_recently_acquired:
		query.orderByDesc( "acquisitionDateTime" );
		break;
	case SortBy::least_recently_watched:
		query.orderBy( "lastAccessed" );
		break;
	case SortBy::most_recently_watched:
		query.orderByDesc( "lastAccessed" );
		break;
	default:
		break;
	}

	query.offset( start );

	query.limit( size );

	query.where( cond );

	mediaRecords = tableMediaRecords.get( db, query );

	return mediaRecords;
}

void SQLiteMediaRecordStore::setListener( boost::weak_ptr<IListener> _listener )
{
	listener = _listener;

	if (listener.expired())
	{
		db->setUpdateListener( boost::weak_ptr<sqlite::DB::IUpdateListener>() );
	}
	else
	{
		boost::shared_ptr<sqlite::DB::IUpdateListener> sharedPtr = boost::dynamic_pointer_cast<sqlite::DB::IUpdateListener>( shared_from_this() );
		boost::weak_ptr<sqlite::DB::IUpdateListener> weakPtr( sharedPtr );

		db->setUpdateListener( weakPtr );
	}
}

NS_NICKEL_SYSTEM_CLOSE
