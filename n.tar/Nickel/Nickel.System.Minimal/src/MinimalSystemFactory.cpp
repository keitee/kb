/*
 * MinimalSystemFactory.cpp
 *
 *  Created on: 26 Sep 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 */


#include <nickel-system-api/LocalMediaLibraryConvertToAsync.h>
#include <zinc-common/MultipleListenerEventDispatcher.h>
#include <zinc-common/async/SequentialFutureDispatcher.h>
#include <zinc-binding-runtime/dbus/DBusConnectionManager.h>
#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <zinc-common/FixedPluginConfig.h>
#include <zinc-common/FilePluginConfig.h>
#include <zinc-common/PluginFactory.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/resource-finder/getMutableDataPath.h>
#include <copper-system-api/LocalStorageRepositoryConvertToSync.h>
#include <nickel-common/NickelLogger.h>
#include <nickel-system-api/Serialize.h>

#include <boost/make_shared.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/algorithm/string.hpp>

#include "MinimalSystemFactory.h"
#include "MinimalLocalMediaLibrarySync.h"
#include "SQLiteMediaRecordStore.h"
#include "FakeMediaFileSystem.h"
#include "MinimalMediaFileSystem.h"

NS_ZINC::Plugin *createMinimalSystemFactory( const char* args )
{
	return new NS_NICKEL_SYSTEM::MinimalSystemFactory( args );
}

NS_NICKEL_SYSTEM_OPEN

MinimalSystemFactory::MinimalSystemFactory( const char* args ) : isUsingFakeMedia(true)
{
	// forward most requests to Nickel.System.Fake
	NS_ZINC::FixedPluginConfig nickelPluginConfig( "libNickelSystemFake.so", "createFakeSystemFactory" );

	SystemFactory& factory = NS_ZINC::PluginFactory::getInstance<SystemFactory>(nickelPluginConfig);
	mediaRouterFactory = factory.createMediaRouterFactory();
	mediaSettings = factory.createMediaSettings();
	outputManager = factory.createOutputManager();
	serviceListBuilder = factory.createServiceListBuilder();
	defaultMediaRouter = factory.createDefaultMediaRouter();

	// create our Clock implementation
	createClock();

	// create our LocalMediaLibrary
	mediaRecordStore = createMediaRecordStore();
	boost::shared_ptr<NS_IRON_SYSTEM::EventRepository> eventRepository = createEventRepository();
	boost::shared_ptr<NS_IRON_SYSTEM::ServiceRepository> serviceRepository = createServiceRepository();
	boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository = createLocalStorageRepository();

	parseArgs( args );

	boost::shared_ptr<MediaFileSystem> mediaFileSystem;
	if (isUsingFakeMedia)
	{
		mediaFileSystem = createFakeMediaFileSystem();
	}
	else
	{
		mediaFileSystem = createMinimalMediaFileSystem();
	}

	boost::shared_ptr<MinimalLocalMediaLibrarySync> minimalLocalMediaLibrary = boost::make_shared<MinimalLocalMediaLibrarySync>();
	minimalLocalMediaLibrary->initialise( mediaRecordStore, eventRepository, serviceRepository, localStorageRepository, mediaFileSystem, clock );
	minimalLocalMediaLibrary->setDispatcher( getEventDispatcher() );
	localMediaLibrary = convertToAsync( minimalLocalMediaLibrary, *(getActionProcessor()) );

	// listen to Cadmium Events
	linearAcquisition = createLinearAcquisition();
	linearAcquisition->addListener( minimalLocalMediaLibrary );
}

boost::shared_ptr<NS_ZINC::EventDispatcher> MinimalSystemFactory::getEventDispatcher()
{
	if ( ! eventdispatcher)
	{
		eventdispatcher.reset(new NS_ZINC::MultipleListenerEventDispatcher());
	}
	return eventdispatcher;
}

boost::shared_ptr<NS_ZINC::FutureDispatcher> MinimalSystemFactory::getFutureDispatcher()
{
	if ( ! futuredispatcher)
	{
		futuredispatcher.reset(new NS_ZINC::SequentialFutureDispatcher());
	}
	return futuredispatcher;
}

boost::shared_ptr<NS_ZINC::ActionProcessor> MinimalSystemFactory::getActionProcessor()
{
	if ( ! actionProcessor )
	{
		actionProcessor = boost::make_shared<NS_ZINC::ActionProcessor>();
		actionProcessor->start();
	}
	return actionProcessor;
}

boost::shared_ptr<Zinc::Media::LocalMediaLibrary> MinimalSystemFactory::createLocalMediaLibrary()
{
	return localMediaLibrary;
}

boost::shared_ptr<Zinc::Media::MediaRouterFactory> MinimalSystemFactory::createMediaRouterFactory()
{
	return mediaRouterFactory;
}

boost::shared_ptr<Zinc::Media::MediaSettings> MinimalSystemFactory::createMediaSettings()
{
	return mediaSettings;
}

boost::shared_ptr<Zinc::Media::OutputManager> MinimalSystemFactory::createOutputManager()
{
	return outputManager;
}

boost::shared_ptr<Zinc::Media::ServiceListBuilder> MinimalSystemFactory::createServiceListBuilder()
{
	return serviceListBuilder;
}

boost::shared_ptr<Zinc::Media::MediaRouter> MinimalSystemFactory::createDefaultMediaRouter()
{
	return defaultMediaRouter;
}

boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> MinimalSystemFactory::createLocalStorageRepository()
{
	boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository;
	NS_ZINC::FilePluginConfig copperPluginConfig( NS_ZINC::PackageDataFinder().find("copper-system-factory.plugin-config"));
	NS_COPPER_SYSTEM::SystemFactory& copperSystemFactory = NS_ZINC::PluginFactory::getInstance<NS_COPPER_SYSTEM::SystemFactory>(copperPluginConfig);
	localStorageRepository = convertToSync( copperSystemFactory.createLocalStorageRepository() );
	return localStorageRepository;
}

boost::shared_ptr<MediaRecordStore> MinimalSystemFactory::createMediaRecordStore()
{
	// provide a Nickel.System.Minimal version of LocalMediaLibrary
	SQLiteMediaRecordStore::Config config;
	config.useTempMemoryDB = false;
	config.filename = NS_ZINC::getMutableDataPath() + std::string("nickel_minimal.sqlite");
	boost::shared_ptr<MediaRecordStore> store = boost::make_shared<SQLiteMediaRecordStore>( config );
	return store;
}


namespace
{
	/*
	 * @class FakeClock
	 * @brief Implementation of Clock using boost::posix_time
	 */
	class FakeClock : public Clock
	{
	public:
		virtual uint32_t getCurrentTime()
		{
			boost::posix_time::ptime systemTime = boost::get_system_time();
			boost::posix_time::ptime epoch = boost::posix_time::ptime(boost::gregorian::date(1970, 1, 1));
			uint32_t currentTime = (systemTime - epoch).total_seconds();
			return currentTime;
		}
	};
}

void MinimalSystemFactory::createClock()
{
	clock.reset( new FakeClock() );
}

boost::shared_ptr<MediaFileSystem> MinimalSystemFactory::createFakeMediaFileSystem()
{
	boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository = convertToSync(createLocalStorageRepository());

	/// @todo bring this in from config file perhaps?
	#define FREE_SPACE_BYTES int64_t(320 * 1024 * 1024)

	boost::shared_ptr<FakeMediaFileSystem> fakeMediaFileSystem( new FakeMediaFileSystem() );
	fakeMediaFileSystem->initialise( clock, localStorageRepository, mediaRecordStore, FREE_SPACE_BYTES );

	return fakeMediaFileSystem;
}

boost::shared_ptr<MediaFileSystem> MinimalSystemFactory::createMinimalMediaFileSystem()
{
	boost::shared_ptr<MinimalMediaFileSystem> minimalMediaFileSystem( new MinimalMediaFileSystem( mediaPath ) );

	return minimalMediaFileSystem;
}

boost::shared_ptr<NS_CADMIUM_SYSTEM::LinearAcquisition> MinimalSystemFactory::createLinearAcquisition()
{
	const NS_ZINC::FilePluginConfig cadmiumPluginConfig(NS_ZINC::PackageDataFinder().find("cadmium-system-factory.plugin-config"));
	NS_CADMIUM_SYSTEM::SystemFactory& cadmiumSystemFactory = NS_ZINC::PluginFactory::getInstance<NS_CADMIUM_SYSTEM::SystemFactory>(cadmiumPluginConfig);
	boost::shared_ptr<NS_CADMIUM_SYSTEM::LinearAcquisition> linearAcquisition = cadmiumSystemFactory.createLinearAcquisition();

	return linearAcquisition;
}

boost::shared_ptr<NS_IRON_SYSTEM::EventRepository> MinimalSystemFactory::createEventRepository()
{
	const NS_ZINC::FilePluginConfig ironPluginConfig(NS_ZINC::PackageDataFinder().find("iron-system-factory.plugin-config"));
	NS_IRON_SYSTEM::SystemFactory& ironSystemFactory = NS_ZINC::PluginFactory::getInstance<NS_IRON_SYSTEM::SystemFactory>(ironPluginConfig);
	boost::shared_ptr<NS_IRON_SYSTEM::EventRepository> eventRepository = ironSystemFactory.createEventRepository();

	return eventRepository;
}

boost::shared_ptr<NS_IRON_SYSTEM::ServiceRepository> MinimalSystemFactory::createServiceRepository()
{
	const NS_ZINC::FilePluginConfig ironPluginConfig(NS_ZINC::PackageDataFinder().find("iron-system-factory.plugin-config"));
	NS_IRON_SYSTEM::SystemFactory& ironSystemFactory = NS_ZINC::PluginFactory::getInstance<NS_IRON_SYSTEM::SystemFactory>(ironPluginConfig);
	boost::shared_ptr<NS_IRON_SYSTEM::ServiceRepository> serviceRepository = ironSystemFactory.createServiceRepository();

	return serviceRepository;
}

void MinimalSystemFactory::parseArgs( const char* _args )
{
	std::vector<std::string> args;
	boost::split(args, _args, boost::is_any_of(" "));

	BOOST_FOREACH( const std::string& arg, args )
	{
		if (arg.find( "--localmedialibrary-xml=") != std::string::npos)
		{
			std::string filename = arg.substr( arg.find('=') + 1 );
			injectXML( filename );
		}
		else if (arg == "--fake-media")
		{
			isUsingFakeMedia = true;
		}
		else if (arg == "--minimal-media")
		{
			isUsingFakeMedia = false;
		}
		else if (arg.find("--media-path") != std::string::npos)
		{
			mediaPath = arg.substr( arg.find('=') + 1 );
		}
	}
}

void MinimalSystemFactory::injectXML( const std::string& filename )
{
	NICKEL_INFO( "Injecting XML data from " << filename );

	// erase any existing media records
	mediaRecordStore->clear();

	// Inject MediaRecords
	std::vector<MediaRecord> mediaRecords;
	if (!NS_ZINC::serialize::readXMLFile( filename, "MediaRecords", mediaRecords ))
	{
		NICKEL_ERROR( "Failed to inject XML data");
		throw std::runtime_error("Failed to inject XML data");
	}

	BOOST_FOREACH( MediaRecord& mediaRecord, mediaRecords )
	{
		MediaRecordEx mediaRecordEx;
		*( static_cast<MediaRecord*>(&mediaRecordEx)) = mediaRecord;

		if (mediaRecordEx.identifiers.find( "MEDIARECORDEX_IMPORT_REFERENCECOUNT") != mediaRecordEx.identifiers.end())
		{
			mediaRecordEx.referenceCount = boost::lexical_cast<int64_t>( mediaRecordEx.identifiers["MEDIARECORDEX_IMPORT_REFERENCECOUNT"] );
		}

		mediaRecordEx.mediaRecordIdentifierPrimaryKey = boost::lexical_cast<int64_t>( mediaRecordEx.mediaRecordIdentifier );
		mediaRecordStore->addMediaRecord( mediaRecordEx );
	}
}

NS_NICKEL_SYSTEM_CLOSE
