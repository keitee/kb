/*
 * MinimalLocalMediaLibrarySync.cpp
 *
 *  Created on: 16 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */


#include <nickel-common/NickelLogger.h>

#include <boost/lexical_cast.hpp>
#include <boost/thread/locks.hpp>
#include <boost/foreach.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "MinimalLocalMediaLibrarySync.h"
#include "utils.h"
#include "../include/MinimalMediaLocator.h"

NS_NICKEL_SYSTEM_OPEN

namespace
{

	/*
	 * @class MinimalLocalMediaLibraryException
	 * @brief Exception thrown when we are unable to find a value in the LocalStoreRepository
	 */
	class MinimalLocalMediaLibraryException : public std::exception
	{
	public:
		MinimalLocalMediaLibraryException( const std::string& key )
		{
			std::cerr << "MinimalLocalMediaLibraryException: missing LSR KEY '" << key << "'" << std::endl;
		}
	};

	int getIntLSR( boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository, const std::string& key )
	{
		std::string value  =  localStorageRepository->getItem(0, "", key);

		if (value.empty())
		{
			throw MinimalLocalMediaLibraryException( key );
		}

		return boost::lexical_cast<int>( value );
	}

	bool getBoolLSR( boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository, const std::string& key )
	{
		std::string value  =  localStorageRepository->getItem(0, "", key);

		if (value.empty())
		{
			throw MinimalLocalMediaLibraryException( key );
		}


		return (value == "1" );
	}

	std::string stripTransportStreamIdentifier( const std::string& locator_in )
	{
		std::string locator = locator_in;

		if (locator.substr(0,6) == "dvb://")
		{
			std::string::size_type pos1, pos2;

			pos2 = std::string::npos;
			pos1 = locator.find('.');

			if (pos1 != std::string::npos)
			{
				pos2 = locator.find('.', pos1+1);
			}

			if (pos2 != std::string::npos)
			{
				locator.erase(pos1+1, pos2 - pos1 -1);
			}
		}

		return locator;
	}

	/*
	 * @brief Determine whether the recording (denoted by startTime/endTime) overlaps the watershed time period
	 */
	bool isWatershed( uint32_t startTime, uint32_t endTime )
	{
		// strip year/month/day info from start/end times
		// (projecting onto a single day to simplify time testing)
		uint32_t localStart = startTime % SECONDS_PER_DAY;
		uint32_t localEnd = endTime % SECONDS_PER_DAY;

		uint32_t duration = endTime - startTime;

		uint32_t watershedStart = boost::posix_time::duration_from_string( "21:00:00" ).total_seconds();
		uint32_t watershedEnd = boost::posix_time::duration_from_string( "05:30:00" ).total_seconds();

		bool isStartInWatershed = ( localStart < watershedEnd ) || ( localStart > watershedStart );
		if (isStartInWatershed)
		{
			return true;
		}

		bool isEndInWatershed = ( localEnd < watershedEnd ) || (localEnd > watershedStart );
		if (isEndInWatershed)
		{
			return true;
		}

		bool isOverlappingWatershed = ( (localStart + duration) >= watershedStart );
		if (isOverlappingWatershed)
		{
			return true;
		}

		return false;
	}


}

MinimalLocalMediaLibrarySync::MinimalLocalMediaLibrarySync()
{
}

void MinimalLocalMediaLibrarySync::initialise( boost::shared_ptr<MediaRecordStore> store,
		boost::shared_ptr<NS_IRON_SYSTEM::EventRepository> _eventRepository,
		boost::shared_ptr<NS_IRON_SYSTEM::ServiceRepository> _serviceRepository,
		boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> _localStorageRepository,
		boost::shared_ptr<MediaFileSystem> _mediaFileSystem,
		boost::shared_ptr<Clock> _clock )
{
	mediaRecordStore = store;
	eventRepository = _eventRepository;
	serviceRepository = _serviceRepository;
	localStorageRepository = _localStorageRepository;
	mediaFileSystem = _mediaFileSystem;
	clock = _clock;

	boost::weak_ptr<MediaRecordStore::IListener> weakPtr( boost::dynamic_pointer_cast<MediaRecordStore::IListener>( shared_from_this() ));
		mediaRecordStore->setListener( weakPtr );

	// load values from localStorageRepository
	lsrValueAutoDelete = getBoolLSR(localStorageRepository, LSR_KEY_AUTODELETE);
	lsrValueThreshold = getIntLSR( localStorageRepository, LSR_KEY_THRESHOLD );
	lsrValueBroadcastSDBitrate = getIntLSR( localStorageRepository, LSR_KEY_BROADCAST_SD_BITRATE );
	lsrValueBroadcastHDBitrate= getIntLSR( localStorageRepository, LSR_KEY_BROADCAST_HD_BITRATE );
	lsrValueBroadcastRadioBitrate = getIntLSR( localStorageRepository, LSR_KEY_BROADCAST_RADIO_BITRATE );
}

MinimalLocalMediaLibrarySync::~MinimalLocalMediaLibrarySync()
{

}


std::vector< MediaRecord > MinimalLocalMediaLibrarySync::getMediaRecords( const FilterByType::Enum filterByType_in, const FilterByPlayed::Enum filterByPlayed_in, const SortBy::Enum sortBy_in, const bool includeAdult_in, const uint32_t start_in, const uint32_t size_in)
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	std::vector< MediaRecordEx > results = mediaRecordStore->getMediaRecords( filterByType_in, filterByPlayed_in, sortBy_in, includeAdult_in, start_in, size_in );

	std::vector< MediaRecord > mediaRecords;
	BOOST_FOREACH( const MediaRecordEx& mediaRecordEx, results )
	{
		mediaRecords.push_back( fromMediaRecordEx( mediaRecordEx ) );
	}

	return mediaRecords;
}

MediaRecord MinimalLocalMediaLibrarySync::getMediaRecord(const std::string& mediaRecordIdentifier_in)
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	try
	{
		int64_t mediaRecordIdentifier;
		try
		{
			mediaRecordIdentifier = boost::lexical_cast<int64_t>( mediaRecordIdentifier_in );
		}
		catch (std::exception)
		{
			throw MediaRecordNotFound();
		}

		MediaRecordEx mediaRecordEx = mediaRecordStore->getMediaRecord( mediaRecordIdentifier );

		return fromMediaRecordEx( mediaRecordEx );
	}
	catch ( MediaRecordNotFoundException )
	{
		throw MediaRecordNotFoundException();
	}
}

std::vector< MediaRecord > MinimalLocalMediaLibrarySync::getMediaRecordsByContentIdentifier( const std::string& contentIdentifier_in)
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	const std::string contentIdentifier = stripTransportStreamIdentifier( contentIdentifier_in );

	std::vector< MediaRecordEx > results = mediaRecordStore->getMediaRecordsByContentIdentifier( contentIdentifier );

	// convert from MediaRecordEx to MediaRecord
	std::vector<MediaRecord> mediaRecords;
	BOOST_FOREACH( const MediaRecordEx& mediaRecordEx, results )
	{
		mediaRecords.push_back( fromMediaRecordEx( mediaRecordEx ) );
	}

	return mediaRecords;
}

bool MinimalLocalMediaLibrarySync::deleteMediaRecord(const std::string& mediaRecordIdentifier_in)
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	try
	{
		int64_t mediaRecordIdentifier;
		try
		{
			mediaRecordIdentifier = boost::lexical_cast<int64_t>( mediaRecordIdentifier_in );
		}
		catch (std::exception)
		{
			throw MediaRecordNotFound();
		}

		// test that MediaRecord exists
		MediaRecordEx mediaRecord = mediaRecordStore->getMediaRecord( mediaRecordIdentifier );

		// test whether we can delete the MediaRecord
		if (mediaRecord.acquisitionStatus == AcquisitionStatus::begun)
		{
			throw DeleteFailedDueToMediaRecordInUse();
		}
		else
		{
			mediaRecordStore->deleteMediaRecord( mediaRecordIdentifier );

			return true;
		}

	}
	catch ( MediaRecordNotFoundException )
	{
		throw MediaRecordNotFoundException();
	}
}

MediaStorageSpace MinimalLocalMediaLibrarySync::getStorageSpace()
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	MediaStorageSpace mediaStorageSpace;

	int offset = 0;
	int chunkSize = 10;

	std::vector<MediaRecordEx> mediaRecords;

	do
	{
		mediaRecords = mediaRecordStore->getMediaRecords(FilterByType::recordings_and_downloads,FilterByPlayed::played_and_unplayed, SortBy::least_recently_acquired, true, offset, chunkSize );

		BOOST_FOREACH( const MediaRecordEx& mediaRecord, mediaRecords )
		{
			int64_t size = 0;
			int64_t anticipatedSize = 0;

			switch (mediaRecord.acquisitionStatus)
			{
			case AcquisitionStatus::not_begun_yet:
			case AcquisitionStatus::failed:
				// nothing to calculate
				break;
			case AcquisitionStatus::begun:
				// calc anticipated size
				anticipatedSize = getAnticipatedSize( mediaRecord );

				// calc size
				size = mediaFileSystem->getSize( mediaRecord );

				if (anticipatedSize > size)
				{
					anticipatedSize -= size;
				}
				else
				{
					anticipatedSize = 0;
				}

				break;
			case AcquisitionStatus::acquired:
			case AcquisitionStatus::partially_acquired:
				size = mediaRecord.size;
			}

			mediaStorageSpace.usedForRecordings += size;
			mediaStorageSpace.anticipatedForRecordings += anticipatedSize;
		}

		offset += chunkSize;
	}
	while ( mediaRecords.size() > 0 );

	mediaStorageSpace.free = mediaFileSystem->getFree() - (mediaStorageSpace.anticipatedForRecordings + mediaStorageSpace.anticipatedForDownloads);

	return mediaStorageSpace;
}

bool MinimalLocalMediaLibrarySync::setMediaRecordProtected(const std::string& mediaRecordIdentifier_in, const bool isProtected_in)
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	try
	{
		int64_t mediaRecordIdentifier;
		try
		{
			mediaRecordIdentifier = boost::lexical_cast<int64_t>( mediaRecordIdentifier_in );
		}
		catch (std::exception)
		{
			throw MediaRecordNotFound();
		}

		MediaRecordEx mediaRecord = mediaRecordStore->getMediaRecord( mediaRecordIdentifier );

		mediaRecord.isProtected = isProtected_in;

		mediaRecordStore->updateMediaRecord( mediaRecord );

		return true;
	}
	catch ( MediaRecordNotFoundException )
	{
		throw MediaRecordNotFound();
	}
}

std::string MinimalLocalMediaLibrarySync::getMediaRecordTimingSignature(const std::string& mediaRecordIdentifier_in)
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	/*
	 * @note this function is currently subject to 'sunrise' clause in Content Acquisition specs, so we will simply check
	 *   whether the MediaRecord exists, and then return an empty string.
	 *
	 */

	try
	{
		// try to find the specified MediaRecord
		int64_t mediaRecordIdentifier;
		try
		{
			mediaRecordIdentifier = boost::lexical_cast<int64_t>( mediaRecordIdentifier_in );
		}
		catch (std::exception)
		{
			throw MediaRecordNotFound();
		}

		MediaRecordEx mediaRecord = mediaRecordStore->getMediaRecord( mediaRecordIdentifier );

		// return an empty string
		return "";
	}
	catch ( MediaRecordNotFoundException )
	{
		throw MediaRecordNotFound();
	}
}



boost::shared_ptr<MediaRecordStore> MinimalLocalMediaLibrarySync::getMediaRecordStore()
{
	return mediaRecordStore;
}

void MinimalLocalMediaLibrarySync::onMediaRecordChanged( int64_t mediaRecordIdentifier, LibraryContentChangeType::Enum changeType )
{
	// issue signal
	std::map< std::string, LibraryContentChangeType::Enum > changes;
	std::string strID = boost::lexical_cast<std::string>( mediaRecordIdentifier );
	changes[ strID ] = changeType;

	produceEvent( bind(&LocalMediaLibraryEventListener::LibraryContentChange, _1, changes) );
}

void MinimalLocalMediaLibrarySync::RecordingEvent(const std::string& eventLocator, const NS_CADMIUM_SYSTEM::RecordingEventStatus::Enum status)
{
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	std::vector<MediaRecordEx> mediaRecords = mediaRecordStore->getMediaRecordsByEventLocator( eventLocator );

	MediaRecordEx mediaRecord;
	bool isFound = false;

	BOOST_FOREACH( MediaRecordEx& it, mediaRecords )
	{
		// we could have multiple MediaRecords for an eventLocator, but only one of them can currently
		// be waiting to record, or actively recording
		switch (it.acquisitionStatus)
		{
			case AcquisitionStatus::begun:
			case AcquisitionStatus::not_begun_yet:
				mediaRecord = it;
				isFound = true;
				break;
			default:
				break;
		}

		if (isFound)
		{
			break;
		}
	}

	if (!isFound)
	{
		// we were unable to find a matching MediaRecord that is currently being recorded
		return;
	}

	// ignore redundant/repeated status changes
	switch (status)
	{
		case NS_CADMIUM_SYSTEM::RecordingEventStatus::begun:
			if (mediaRecord.acquisitionStatus != AcquisitionStatus::not_begun_yet)
			{
				// we can only begin, if we haven't begun yet
				return;
			}
			break;
		case NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired:
		case NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired:
		case NS_CADMIUM_SYSTEM::RecordingEventStatus::failed:
			if ( (mediaRecord.acquisitionStatus != AcquisitionStatus::begun) && (mediaRecord.acquisitionStatus != AcquisitionStatus::not_begun_yet))
			{
				// we can only conclude recording, if recording hasn't been concluded yet
				return;
			}
			break;
	}

	// handle change in status
	switch (status)
	{
	case NS_CADMIUM_SYSTEM::RecordingEventStatus::begun:
		{
			mediaRecord.acquisitionStatus = AcquisitionStatus::begun;

			mediaRecord.acquisitionDateTime = mediaFileSystem->getAcquisitionStartTime( mediaRecord );

			std::string eventLocator;
			getMapValue( mediaRecord.identifiers, IDENTIFIERS_KEY_EVENTLOCATOR, eventLocator );
			mediaRecord.mediaLocator = generateMediaLocator( mediaRecord.publishedStart, eventLocator, mediaRecord.title );
		}
		break;
	case NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired:
	case NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired:
		{
			if (status == NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired)
			{
				mediaRecord.acquisitionStatus = AcquisitionStatus::acquired;
			}
			else
			{
				mediaRecord.acquisitionStatus = AcquisitionStatus::partially_acquired;
			}

			mediaRecord.duration = mediaFileSystem->getDuration( mediaRecord );
			mediaRecord.size = mediaFileSystem->getSize( mediaRecord );

			/// delete previous media records for same programme-crid that FAILED to acquire
			std::string programmeCrid = mediaRecord.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID];
			if (!programmeCrid.empty())
			{
				std::vector<MediaRecordEx> previousMediaRecords = mediaRecordStore->getMediaRecordsByProgrammeCrid( programmeCrid );

				BOOST_FOREACH( MediaRecordEx& previousMediaRecord, previousMediaRecords )
				{
					if (previousMediaRecord.mediaRecordIdentifierPrimaryKey == mediaRecord.mediaRecordIdentifierPrimaryKey)
					{
						continue;
					}

					if (previousMediaRecord.acquisitionStatus == AcquisitionStatus::failed)
					{
						mediaRecordStore->deleteMediaRecord( previousMediaRecord.mediaRecordIdentifierPrimaryKey );
					}
				}
			}

		}
		break;
	case NS_CADMIUM_SYSTEM::RecordingEventStatus::failed:
		{
			mediaRecord.acquisitionStatus = AcquisitionStatus::failed;
		}
		break;
	}

	mediaRecordStore->updateMediaRecord( mediaRecord );
}

void MinimalLocalMediaLibrarySync::ScheduledRecordingListChange(const std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum >& changes)
{
	NICKEL_DEBUG("MinimalLocalMediaLibrarySync::ScheduledRecordingListChange()");
	boost::lock_guard<boost::mutex> scopedLock(mutexAPI);

	typedef std::pair< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > Change;
	BOOST_FOREACH( const Change& change, changes )
	{
		const std::string& eventLocator = change.first;
		const NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum& changeType = change.second;
		NICKEL_DEBUG("MinimalLocalMediaLibrarySync::ScheduledRecordingListChange( " << eventLocator << ", " << enum_to_string(changeType) << " )");
		switch ( changeType )
		{
			case NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added:
			{
				std::vector<MediaRecordEx> mediaRecords = mediaRecordStore->getMediaRecordsByEventLocator( eventLocator );

				if (mediaRecords.size() != 0)
				{
					/// @todo Deal with re-use of EventLocators every 3 weeks.
					/// @note Would it be enough to only look for MediaRecords that are in an in-complete recording state?
					///   ( i.e. eventLocators are re-used every 3 weeks, you can only book recordings a week in advance, so a
					///          previous use of an EventLocator would have generated a MediaRecord that has finished recording 2 weeks ago )

					// we already have a mediaRecord for this eventLocator

					// increase its' ref count
					MediaRecordEx& mediaRecord = mediaRecords[0];

					mediaRecord.referenceCount ++;
					mediaRecordStore->updateMediaRecord( mediaRecord );

					return;
				}

				NICKEL_DEBUG("MinimalLocalMediaLibrarySync::ScheduledRecordingListChange added " << eventLocator );
				// create a MediaRecord for the specified eventLocator
				MediaRecordEx mediaRecord;

				// get the relevant event/service data from Iron
				NS_IRON_SYSTEM::Event event;
				NS_IRON_SYSTEM::Service service;

				try
				{
					event = eventRepository->getEvent( eventLocator ).get();
					service = serviceRepository->getService( event.serviceLocator ).get();
				}
				catch ( NS_IRON_SYSTEM::EventNotFoundException )
				{
					// unable to find matching Event
					NICKEL_DEBUG("EventNotFoundException");
					return;
				}
				catch ( NS_IRON_SYSTEM::ServiceNotFoundException )
				{
					// unable to find matching Service
					NICKEL_DEBUG("ServiceNotFoundException");
					return;
				}

				// convert event/service to MediaRecord
				mediaRecord.fillMediaRecord( event,service );

				uint32_t startTime = event.start;
				uint32_t endTime = event.start + event.publishedDuration;
				mediaRecord.watershed = isWatershed( startTime, endTime );

				mediaRecord.acquisitionStatus = AcquisitionStatus::not_begun_yet;

				mediaRecordStore->addMediaRecord( mediaRecord );
			}
			break;
			case NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::updated:
			{
				NICKEL_DEBUG("MinimalLocalMediaLibrarySync::ScheduledRecordingListChange updated " << eventLocator );
				std::vector<MediaRecordEx> mediaRecords = mediaRecordStore->getMediaRecordsByEventLocator( eventLocator );

				if (mediaRecords.empty())
				{
					// error - we don't have a mediaRecord for this eventLocator
					return;
				}

				NS_IRON_SYSTEM::Event event;

				try
				{
					event = eventRepository->getEvent( eventLocator ).get();

				}
				catch ( NS_IRON_SYSTEM::EventNotFoundException )
				{
					// unable to find matching Event
					NICKEL_DEBUG("EventNotFoundException");
					return;
				}

				BOOST_FOREACH( MediaRecordEx& mediaRecord, mediaRecords )
				{
					// update media record with latest version of Event

					mediaRecord.publishedStart = event.start;
					mediaRecord.publishedDuration = event.publishedDuration;

					uint32_t startTime = event.start;
					uint32_t endTime = event.start + event.publishedDuration;
					mediaRecord.watershed = isWatershed( startTime, endTime );

					mediaRecordStore->updateMediaRecord( mediaRecord );
				}
			}
			break;
			case NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::deleted:
			{
				NICKEL_DEBUG("MinimalLocalMediaLibrarySync::ScheduledRecordingListChange deleted " << eventLocator );
				std::vector<MediaRecordEx> mediaRecords = mediaRecordStore->getMediaRecordsByEventLocator( eventLocator );

				if (mediaRecords.empty())
				{
					// error - we don't have a mediaRecord for this eventLocator
					return;
				}

				MediaRecordEx& mediaRecord = mediaRecords[0];

				if (mediaRecord.acquisitionStatus == AcquisitionStatus::not_begun_yet)
				{
					if (mediaRecord.referenceCount > 1)
					{
						mediaRecord.referenceCount --;
						mediaRecordStore->updateMediaRecord( mediaRecord );
					}
					else
					{
						// this MediaRecord is dangling & unused - so we will clear it away
						mediaRecordStore->deleteMediaRecord( mediaRecord.mediaRecordIdentifierPrimaryKey );
					}
				}
			}
			break;
			default:
				// not supported yet
				break;
		}
	}
}

void MinimalLocalMediaLibrarySync::BookingListChange(const std::map< std::string, NS_CADMIUM_SYSTEM::BookingListChangeType::Enum >& /*changes*/) {}
void MinimalLocalMediaLibrarySync::ScheduledRecordingConflict(const std::vector< std::string >& /*eventLocators*/) {}
void MinimalLocalMediaLibrarySync::TunerExhaustionWarning(const std::vector< std::string >& /*eventLocators*/) {}

int64_t MinimalLocalMediaLibrarySync::getAnticipatedSize( const MediaRecord& mediaRecord )
{
	switch (mediaRecord.acquisitionStatus)
	{
		case AcquisitionStatus::not_begun_yet:
		case AcquisitionStatus::begun:
		{
			// we need to know the estimated length of the recording
			int64_t duration = 0;
			try
			{
				std::string eventLocator;
				getMapValue( mediaRecord.identifiers, IDENTIFIERS_KEY_EVENTLOCATOR, eventLocator );

				NS_IRON_SYSTEM::Event event = eventRepository->getEvent( eventLocator ).get();
				duration = event.publishedDuration;
			}
			catch ( NS_IRON_SYSTEM::EventNotFoundException )
			{
				// unable to find Event, we can't calculate the anticipated size
				return 0;
			}

			return duration * lsrValueBroadcastSDBitrate / 8;
		}
		default:
		{
			// recording has already completed/failed
			return 0;
		}
	}
}

MediaRecord MinimalLocalMediaLibrarySync::fromMediaRecordEx( const MediaRecordEx& mediaRecordEx )
{
	MediaRecord mediaRecord = static_cast<MediaRecord>( mediaRecordEx );

	mediaRecord.mediaRecordIdentifier = boost::lexical_cast<std::string>( mediaRecordEx.mediaRecordIdentifierPrimaryKey );

	return mediaRecord;
}

NS_NICKEL_SYSTEM_CLOSE
