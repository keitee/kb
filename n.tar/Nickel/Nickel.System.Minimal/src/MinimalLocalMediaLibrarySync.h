/*
 * MinimalLocalMediaLibrarySync.h
 *
 *  Created on: 16 Nov 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *  Copyright (C) 2011 YouView TV Ltd
 *
 *  Minimal implementation of the LocalMediaLibrary System API (Synchronous version)
 *
 */

#ifndef NICKEL_SYSTEM_MINIMAL_MINIMALLOCALMEDIALIBRARYSYNC_H
#define NICKEL_SYSTEM_MINIMAL_MINIMALLOCALMEDIALIBRARYSYNC_H

#include <zinc-common/zinc-common.h>

#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/LocalMediaLibrarySync.h>
#include <iron-system-api/iron-system-api.h>
#include <cadmium-system-api/cadmium-system-api.h>
#include <copper-system-api/copper-system-api.h>

#include "MediaRecordStore.h"
#include "MediaFileSystem.h"
#include "Clock.h"

#include <boost/enable_shared_from_this.hpp>
#include <boost/thread/mutex.hpp>

NS_NICKEL_SYSTEM_OPEN

class MinimalLocalMediaLibrarySync : public LocalMediaLibrarySync,
					public MediaRecordStore::IListener, public boost::enable_shared_from_this<MinimalLocalMediaLibrarySync>,
					virtual public NS_CADMIUM_SYSTEM::LinearAcquisitionEventListener
{
public:
	MinimalLocalMediaLibrarySync();

	void initialise( boost::shared_ptr<MediaRecordStore> store,
					 boost::shared_ptr<NS_IRON_SYSTEM::EventRepository> eventRepository,
					 boost::shared_ptr<NS_IRON_SYSTEM::ServiceRepository> serviceRepository,
					 boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository,
					 boost::shared_ptr<MediaFileSystem> mediaFileSystem,
					 boost::shared_ptr<Clock> clock );

	~MinimalLocalMediaLibrarySync();

	boost::shared_ptr<MediaRecordStore> getMediaRecordStore();

public: // LocalMediaLibrarySync
	virtual std::vector< MediaRecord > getMediaRecords(const FilterByType::Enum filterByType_in, const FilterByPlayed::Enum filterByPlayed_in, const SortBy::Enum sortBy_in, const bool includeAdult_in, const uint32_t start_in, const uint32_t size_in);
	virtual MediaRecord getMediaRecord(const std::string& mediaRecordIdentifier_in);
	virtual std::vector< MediaRecord > getMediaRecordsByContentIdentifier(const std::string& contentIdentifier_in);
	virtual bool deleteMediaRecord(const std::string& mediaRecordIdentifier_in);
	virtual MediaStorageSpace getStorageSpace();
	virtual bool setMediaRecordProtected(const std::string& mediaRecordIdentifier_in, const bool isProtected_in);
	virtual std::string getMediaRecordTimingSignature(const std::string& mediaRecordIdentifier_in);

public: // MediaRecordStore::IListener
	virtual void onMediaRecordChanged( int64_t mediaRecordIdentifier, LibraryContentChangeType::Enum changeType );

public: // LinearAcquisitionEventListener
	virtual void RecordingEvent(const std::string& eventLocator, const NS_CADMIUM_SYSTEM::RecordingEventStatus::Enum status);
	virtual void ScheduledRecordingListChange(const std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum >& changes);
	virtual void BookingListChange(const std::map< std::string, NS_CADMIUM_SYSTEM::BookingListChangeType::Enum >& changes);
	virtual void ScheduledRecordingConflict(const std::vector< std::string >& eventLocators);
	virtual void TunerExhaustionWarning(const std::vector< std::string >& eventLocators);


public: // utility
	static MediaRecord fromMediaRecordEx( const MediaRecordEx& mediaRecordEx );

private:
	int64_t getAnticipatedSize( const MediaRecord& mediaRecord );

	boost::shared_ptr<MediaRecordStore> mediaRecordStore;

	boost::shared_ptr<NS_IRON_SYSTEM::EventRepository> eventRepository;
	boost::shared_ptr<NS_IRON_SYSTEM::ServiceRepository> serviceRepository;

	boost::shared_ptr<NS_COPPER_SYSTEM::LocalStorageRepositorySync> localStorageRepository;

	boost::shared_ptr<Clock> clock;

	boost::mutex mutexAPI;

	bool lsrValueAutoDelete;
	int lsrValueThreshold;
	int lsrValueBroadcastSDBitrate;
	int lsrValueBroadcastHDBitrate;
	int lsrValueBroadcastRadioBitrate;

	boost::shared_ptr<MediaFileSystem> mediaFileSystem;
};

NS_NICKEL_SYSTEM_CLOSE

#endif
