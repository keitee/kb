/*
 * MinimalMediaFileSystem.h
 *
 *  Created on: 20 Feb 2012
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2012 YouView TV Ltd
 */

#ifndef NICKELSYSTEMMINIMAL_MINIMALMEDIAFILESYSTEM_H
#define NICKELSYSTEMMINIMAL_MINIMALMEDIAFILESYSTEM_H

#include "MediaFileSystem.h"

NS_NICKEL_SYSTEM_OPEN

class MinimalMediaFileSystem : public MediaFileSystem
{
public:
	MinimalMediaFileSystem( const std::string& mediaPath );

public: // MediaFileSystem
	virtual uint32_t getDuration( const MediaRecordEx& mediaRecord );
	virtual int64_t getSize( const MediaRecordEx& mediaRecord );
	virtual int64_t getFree();
	virtual uint32_t getAcquisitionStartTime( const MediaRecordEx& mediaRecord );

private:
	std::string getMediaFilename( const MediaRecordEx& mediaRecord ) const;

	std::string mediaPath;			// directory that media files are stored in
};

NS_NICKEL_SYSTEM_CLOSE

#endif // NICKELSYSTEMMINIMAL_MINIMALMEDIAFILESYSTEM_H
