/**
 * utils.h
 *
 * Author: morgan.henry@youview.com
 *
 * Shared utility functions for this implementation
 *
 */
#ifndef NICKEL_SYSTEM_MINIMAL_UTILS_H
#define NICKEL_SYSTEM_MINIMAL_UTILS_H

/*
 * @brief currently used to try to grab a value from a const map (that may not be there)
 * @todo Extend eventually to deal with language-of-choice and default-language fallbacks
 */
template <class T>
inline void getMapValue( const std::map< std::string, T > m, const std::string& key, T& value )
{
	typedef std::map< std::string, T > MapType;
	typedef typename MapType::const_iterator iterator;
	iterator it;

	it = m.find( key );

	if (it != m.end())
	{
		value = it->second;
	}
}

#endif // NICKEL_SYSTEM_MINIMAL_UTILS_H
