/**
 * constants.h
 *
 * Author: morgan.henry@youview.com
 *
 * Bunch of local constants for this Minimal implementation
 */

#ifndef NICKEL_SYSTEM_MINIMAL_CONSTANTS_H
#define NICKEL_SYSTEM_MINIMAL_CONSTANTS_H

#include <string>

/*
 * @brief key values used in the 'identifiers' field
 */
const std::string IDENTIFIERS_KEY_EVENTLOCATOR = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.eventLocator";
const std::string IDENTIFIERS_KEY_PROGRAMME_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.programmeCRID";
const std::string IDENTIFIERS_KEY_SERIES_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.seriesCRID";
const std::string IDENTIFIERS_KEY_RECOMMENDATION_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.recommendationCRID";
const std::string IDENTIFIERS_KEY_COLLECTION_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.collectionCRID";
const std::string IDENTIFIERS_KEY_SPLIT_INSTANCE_IDENTIFIER = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2011-10-03#linear.splitInstanceIdentifier";



/*
 * @brief key values used in LocalStorageRepository
 */
const std::string LSR_KEY_AUTODELETE = "platform.localmedialibrary.autodelete";
const std::string LSR_KEY_THRESHOLD = "platform.localmedialibrary.threshold";
const std::string LSR_KEY_BROADCAST_SD_BITRATE = "platform.localmedialibrary.broadcastsdbitrate";
const std::string LSR_KEY_BROADCAST_HD_BITRATE = "platform.localmedialibrary.broadcasthdbitrate";
const std::string LSR_KEY_BROADCAST_RADIO_BITRATE = "platform.localmedialibrary.broadcastradiobitrate";

/*
 * @brief Timing constants
 */
const uint32_t SECONDS_PER_DAY = 24 * 60 * 60;

#endif
