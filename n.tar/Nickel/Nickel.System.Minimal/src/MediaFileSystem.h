/*
 * MediaFileSystem.h
 *
 *  Created on: 10 Oct 2011
 *      Author: jim.knowler@youview.com
 *
 *  Copyright (C) 2011 YouView TV Ltd
 *
 *  Interface between MinimalLocalMediaLibrary and the storage of Media Files
 */

#ifndef NICKEL_SYSTEM_MINIMAL_MEDIAFILESYSTEM_H
#define NICKEL_SYSTEM_MINIMAL_MEDIAFILESYSTEM_H

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include "MediaRecordStore.h"

#include <boost/weak_ptr.hpp>

NS_NICKEL_SYSTEM_OPEN

class MediaFileSystem
{
public:
	virtual ~MediaFileSystem() {}

	/*
	 * @brief Get the duration (in seconds) of the media associated with this MediaRecord
	 * @note This function is called once for each MediaRecord when Acquisition has completed (successfully, or partially successful)
	 */
	virtual uint32_t getDuration( const MediaRecordEx& mediaRecord ) = 0;

	/*
	 * @brief Get the size (in bytes) of the media associated with this MediaRecord
	 * @note This function can be called any time from pre-acquisition, to during-acquisition, to post-acquisition
	 */
	virtual int64_t getSize( const MediaRecordEx& mediaRecord ) = 0;

	/*
	 * @brief Get the actual free space (in bytes) on your file system remaining to store media files
	 */
	virtual int64_t getFree() = 0;

	/*
	 * @brief Get the time that acquisition of this MediaRecord began
	 * @note This could be as simple as retrieving the time that the associated media file was created
	 */
	virtual uint32_t getAcquisitionStartTime( const MediaRecordEx& mediaRecord ) = 0;

private:

};

NS_NICKEL_SYSTEM_CLOSE

#endif

