/**
 * MinimalMediaLocator.h
 *
 *  Created on: 21 Feb 2012
 *      Author: jim.knowler@youview.com
 *
 * Generation of MediaLocators for recorded media
 * Shared by Nickel.System.Minimal & Cadmium.System.Minimal
 */

#ifndef NICKELSYSTEMMINIMAL__MINIMALMEDIALOCATOR_H
#define NICKELSYSTEMMINIMAL__MINIMALMEDIALOCATOR_H

#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include <boost/date_time/posix_time/posix_time.hpp>

NS_NICKEL_SYSTEM_OPEN

/**
 * Make a string safe for using as a filename or in a media-locator
 *
 * This implementation isn't a true url-encode, but it'll do for the time being
 *
 * TODO: replace with a proper url-encode
 *
 */
inline std::string urlSafe(std::string text)
{
	using namespace boost::algorithm;

	std::string t = text;
	erase_all(t, " ");
	erase_all(t, ":");
	erase_all(t, " ");
	replace_all(t, "&", "_");
	replace_all(t, "+", "_");

	return t;
}

inline std::string generateMediaLocator( uint32_t publishedStartTime, const std::string& eventLocator, const std::string& title )
{
	static const boost::posix_time::ptime epoch(boost::gregorian::date(1970, 1, 1));

	std::string mediaLocator = "dvr://";

	mediaLocator += urlSafe( to_iso_string( epoch + boost::posix_time::seconds( publishedStartTime ) ) );
	mediaLocator += "__";
	mediaLocator += urlSafe( eventLocator );
	mediaLocator += "__";
	mediaLocator += urlSafe( title );

	return mediaLocator;
}

NS_NICKEL_SYSTEM_CLOSE

#endif

