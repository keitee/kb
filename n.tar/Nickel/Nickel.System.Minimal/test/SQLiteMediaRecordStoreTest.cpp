/*
 * SQLiteMediaRecordStoreTest.cpp
 *
 *  Created on: 23 September 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */


#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/FactoryPluginLoader.h>

#include <boost/make_shared.hpp>

#include "../src/SQLiteMediaRecordStore.h"

#include "MockListener.h"

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;
using namespace testing;

class SQLiteMediaRecordStoreTest : public CppUnit::TestFixture, public NS_ZINC::UnitTestSandbox
{
public:
	void setUp()
	{
	}

	void tearDown()
	{
	}

	/*
	 * @brief create an empty store for use
	 */
	boost::shared_ptr<MediaRecordStore> createStore()
	{
		SQLiteMediaRecordStore::Config config;
		config.useTempMemoryDB = true;

		boost::shared_ptr<MediaRecordStore> store = boost::make_shared<SQLiteMediaRecordStore>( config );

		return store;
	}

	/*
	 * @brief create an empty MediaRecord
	 */
	MediaRecordEx createMediaRecord( boost::shared_ptr<MediaRecordStore> store )
	{
		MediaRecordEx mediaRecord;
		store->addMediaRecord( mediaRecord );

		return mediaRecord;
	}

	void testAddMediaRecord()
	{
		boost::shared_ptr<MediaRecordStore> store = createStore();

		boost::shared_ptr<MockListener> mockListener( new MockListener() );
		store->setListener( mockListener );

		// add a MediaRecord
		MediaRecordEx newMediaRecord;
		newMediaRecord.publishedDuration = 60;
		newMediaRecord.mediaRecordIdentifier = "not a number";

		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,LibraryContentChangeType::added)).Times(1);
		int64_t mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE( "newMediaRecord.mediaRecordIdentifierPrimaryKey should be populated by addMediaRecord()", mediaRecordIdentifier, newMediaRecord.mediaRecordIdentifierPrimaryKey );

	}

	void testGetMediaRecord()
	{
		boost::shared_ptr<MediaRecordStore> store = createStore();

		boost::shared_ptr<MockListener> mockListener( new MockListener() );
		store->setListener( mockListener );

		// fail to get mediaRecord (to test empty DB)
		CPPUNIT_ASSERT_THROW( store->getMediaRecord( 100 ), MediaRecordNotFoundException );

		// add a MediaRecord
		MediaRecordEx newMediaRecord;
		newMediaRecord.publishedDuration = 60;
		newMediaRecord.publishedStart = 30;
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,LibraryContentChangeType::added)).Times(1);
		int mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// succeed at getting MediaRecord (to test match MediaRecord by mediaRecordIdentifier)
		MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( newMediaRecord.publishedDuration, mediaRecord.publishedDuration );
		CPPUNIT_ASSERT_EQUAL( newMediaRecord.publishedStart, mediaRecord.publishedStart );

		// fail at getting another unknown MediaRecord (to test match MediaRecord by mediaRecordIdentifier)
		CPPUNIT_ASSERT_THROW( store->getMediaRecord( mediaRecordIdentifier+1 ), MediaRecordNotFoundException );
	}

	void testDeleteMediaRecord()
	{
		boost::shared_ptr<MediaRecordStore> store = createStore();

		boost::shared_ptr<MockListener> mockListener( new MockListener() );
		store->setListener( mockListener );

		// fail at deleting an unknown MediaRecord
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		CPPUNIT_ASSERT_NO_THROW( store->deleteMediaRecord( 101 ) );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// add a MediaRecord
		MediaRecordEx newMediaRecord;
		newMediaRecord.publishedDuration = 60;
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,LibraryContentChangeType::added)).Times(1);
		int64_t mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// succeed at getting MediaRecordEx we have just added
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);

		MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( newMediaRecord.publishedDuration, mediaRecord.publishedDuration );

		// fail to delete an unknown MediaRecord (make sure we're filtering on mediaRecordIdentifier)
		CPPUNIT_ASSERT_NO_THROW( store->deleteMediaRecord( mediaRecordIdentifier + 1 ) );

		// still succeed at getting MediaRecord
		CPPUNIT_ASSERT_NO_THROW( store->getMediaRecord( mediaRecordIdentifier ));

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// succeed at deleting the MediaRecord we have just added
		EXPECT_CALL( *mockListener, onMediaRecordChanged( mediaRecordIdentifier, LibraryContentChangeType::deleted)).Times(1);
		store->deleteMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// fail at getting the MediaRecord (that we have just deleted)
		CPPUNIT_ASSERT_THROW( store->getMediaRecord( mediaRecordIdentifier ), MediaRecordNotFoundException );
	}

	void testUpdateMediaRecord()
	{
		boost::shared_ptr<MediaRecordStore> store = createStore();

		boost::shared_ptr<MockListener> mockListener( new MockListener() );
		store->setListener( mockListener );

		// add a MediaRecord
		MediaRecordEx newMediaRecord;
		newMediaRecord.publishedDuration = 60;
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,LibraryContentChangeType::added)).Times(1);
		int64_t mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// succeed at getting MediaRecord we have just added
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL( newMediaRecord.publishedDuration, mediaRecord.publishedDuration );

		// amend the MediaRecord and update it
		mediaRecord.publishedDuration = 90;
		CPPUNIT_ASSERT( newMediaRecord.publishedDuration != mediaRecord.publishedDuration );
		EXPECT_CALL( *mockListener, onMediaRecordChanged(mediaRecordIdentifier,LibraryContentChangeType::updated)).Times(1);
		store->updateMediaRecord( mediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// succeed at getting new version of MediaRecord
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		MediaRecordEx mediaRecordUpdated = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL( mediaRecord.publishedDuration, mediaRecordUpdated.publishedDuration );
		CPPUNIT_ASSERT( newMediaRecord.publishedDuration != mediaRecordUpdated.publishedDuration );
	}

	void testGetMediaRecordsByContentIdentifier()
	{
		boost::shared_ptr<MediaRecordStore> store = createStore();

		MediaRecordEx mediaRecord1 = createMediaRecord( store );
		mediaRecord1.contentIdentifier = "my content identifier 1";
		store->updateMediaRecord( mediaRecord1 );

		MediaRecordEx mediaRecord2 = createMediaRecord( store );
		mediaRecord2.contentIdentifier = "my content identifier 2";
		store->updateMediaRecord( mediaRecord2 );

		MediaRecordEx mediaRecord3 = createMediaRecord( store );
		mediaRecord3.contentIdentifier = mediaRecord2.contentIdentifier;
		store->updateMediaRecord( mediaRecord3 );

		MediaRecordEx mediaRecord4 = createMediaRecord( store );
		mediaRecord4.contentIdentifier = "my content identifier 4";
		store->updateMediaRecord( mediaRecord4 );

		boost::shared_ptr<MockListener> mockListener( new MockListener() );
		store->setListener( mockListener );

		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		std::vector<MediaRecordEx> mediaRecords1 = store->getMediaRecordsByContentIdentifier( mediaRecord1.contentIdentifier );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords1 - num MediaRecords", 1, int(mediaRecords1.size()) );
		CPPUNIT_ASSERT(mediaRecord1.contentIdentifier == mediaRecords1[0].contentIdentifier );

		std::vector<MediaRecordEx> mediaRecords2 = store->getMediaRecordsByContentIdentifier( mediaRecord2.contentIdentifier );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords2 - num MediaRecords", 2, int(mediaRecords2.size()) );
		CPPUNIT_ASSERT( mediaRecord2 == mediaRecords2[0] );
		CPPUNIT_ASSERT( mediaRecord3 == mediaRecords2[1] );

		std::vector<MediaRecordEx> mediaRecords4 = store->getMediaRecordsByContentIdentifier( mediaRecord4.contentIdentifier );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords4 - num MediaRecords", 1, int(mediaRecords4.size()) );
		CPPUNIT_ASSERT( mediaRecord4 == mediaRecords4[0] );

		std::vector<MediaRecordEx> mediaRecords5 = store->getMediaRecordsByContentIdentifier( "unknown content identifier" );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords5 - num MediaRecords", 0, int(mediaRecords5.size()) );
	}

	void testGetMediaRecords()
	{
		boost::shared_ptr<MediaRecordStore> store = createStore();

		/// @todo filterByType    ( recordings, downloads, both) - we're only supporting LinearAcquisition recordings

		const uint32_t NUM_RECORDS = 8;
		int isAdult[NUM_RECORDS] = { 1, 1, 0, 0, 1, 1, 0, 1 };
		uint32_t lastAccessed[NUM_RECORDS] = { 1,4,3,2,6,5,8,7 };
		uint32_t acquisitionDateTime[NUM_RECORDS] = { 8,7,4,1,2,5,6,3 };
		uint32_t resumeAt[NUM_RECORDS] = { 0,0,1,1,0,0,1,0 };			// nb. 0 == never-played
		const char* title[NUM_RECORDS] = { "a", "b", "c", "e", "d", "f", "g", "h" };

		MediaRecordEx mediaRecords[NUM_RECORDS];
		for (size_t i=0; i<NUM_RECORDS; i++)
		{
			MediaRecordEx& mediaRecord = mediaRecords[i];

			mediaRecord.adult = (1 == isAdult[ i ]);
			mediaRecord.title = title[i];
			mediaRecord.lastAccessed = lastAccessed[i];
			mediaRecord.acquisitionDateTime = acquisitionDateTime[i];
			mediaRecord.resumeAt = resumeAt[i];

			store->addMediaRecord( mediaRecord );
		}

		boost::shared_ptr<MockListener> mockListener( new MockListener() );
		store->setListener( mockListener );

		// - include adult, sortby a-to-z
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		std::vector< MediaRecordEx > results = store->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(0), NUM_RECORDS );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z: num-results", size_t(8), results.size() );

		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[2]", mediaRecords[2] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[3]", mediaRecords[4] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[4]", mediaRecords[3] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[5]", mediaRecords[5] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[6]", mediaRecords[6] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[7]", mediaRecords[7] == results[7] );


		// - not adult, sortby z-to-a
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_z_to_a, false, uint32_t(0), NUM_RECORDS );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("not-adult, z-a: num-results", size_t(3), results.size() );
		CPPUNIT_ASSERT_MESSAGE("not-adult, z-a: results[0]", mediaRecords[6] == results[0]);
		CPPUNIT_ASSERT_MESSAGE("not-adult, z-a: results[1]", mediaRecords[3] == results[1]);
		CPPUNIT_ASSERT_MESSAGE("not-adult, z-a: results[2]", mediaRecords[2] == results[2]);

		// - include adult, sortby least-recently-acquired
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::least_recently_acquired, true, uint32_t(0), NUM_RECORDS );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby least-recently-acquired: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[0]", mediaRecords[3] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[1]", mediaRecords[4] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[2]", mediaRecords[7] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[3]", mediaRecords[2] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[4]", mediaRecords[5] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[5]", mediaRecords[6] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[6]", mediaRecords[1] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[7]", mediaRecords[0] == results[7] );

		// - include adult, sortby most-recently-acquired
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::most_recently_acquired, true, uint32_t(0), NUM_RECORDS );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby most-recently-acquired: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[7]", mediaRecords[3] == results[7] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[6]", mediaRecords[4] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[5]", mediaRecords[7] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[4]", mediaRecords[2] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[3]", mediaRecords[5] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[2]", mediaRecords[6] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[0]", mediaRecords[0] == results[0] );

		/// @todo check ASSUMPTION that recently-watched implies querying the 'lastAccessed' field

		// - include adult, sortby least-recently-watched
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::least_recently_watched, true, uint32_t(0), NUM_RECORDS );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby least-recently-watched: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[1]", mediaRecords[3] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[2]", mediaRecords[2] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[3]", mediaRecords[1] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[4]", mediaRecords[5] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[5]", mediaRecords[4] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[6]", mediaRecords[7] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[7]", mediaRecords[6] == results[7] );

		// - include adult, sortby most-recently-watched
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::most_recently_watched, true, uint32_t(0), NUM_RECORDS );

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby most-recently-watched: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[7]", mediaRecords[0] == results[7] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[6]", mediaRecords[3] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[5]", mediaRecords[2] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[4]", mediaRecords[1] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[3]", mediaRecords[5] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[2]", mediaRecords[4] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[1]", mediaRecords[7] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[0]", mediaRecords[6] == results[0] );

		// - include adult, sortby a-to-z, played
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played, SortBy::title_a_to_z, true, uint32_t(0), NUM_RECORDS );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, played: num-results", size_t(3), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[0]", mediaRecords[2] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[1]", mediaRecords[3] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[2]", mediaRecords[6] == results[2] );

		// - include adult, sortby a-to-z, unplayed
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::unplayed, SortBy::title_a_to_z, true, uint32_t(0), NUM_RECORDS );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, unplayed: num-results", size_t(5), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[2]", mediaRecords[4] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[3]", mediaRecords[5] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[4]", mediaRecords[7] == results[4] );

		// - include adult, sortby a-to-z, start/size
		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(0), 5 );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, start-size[a]: num-results", size_t(5), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[2]", mediaRecords[2] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[3]", mediaRecords[4] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[4]", mediaRecords[3] == results[4] );

		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(5), 5 );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, start-size[b]: num-results", size_t(3), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[b]: results[0]", mediaRecords[5] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[b]: results[1]", mediaRecords[6] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[b]: results[2]", mediaRecords[7] == results[2] );

		EXPECT_CALL( *mockListener, onMediaRecordChanged(_,_)).Times(0);
		results = store->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(10), 5 );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, start-size[c]: num-results", size_t(0), results.size() );
	}

public:
	CPPUNIT_TEST_SUITE(SQLiteMediaRecordStoreTest);

	CPPUNIT_TEST(testAddMediaRecord);
	CPPUNIT_TEST(testGetMediaRecord);
	CPPUNIT_TEST(testDeleteMediaRecord);
	CPPUNIT_TEST(testUpdateMediaRecord);
	CPPUNIT_TEST(testGetMediaRecordsByContentIdentifier);
	CPPUNIT_TEST(testGetMediaRecords);


	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(SQLiteMediaRecordStoreTest);

NS_NICKEL_SYSTEM_CLOSE
