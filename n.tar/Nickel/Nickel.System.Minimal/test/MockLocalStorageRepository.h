/*
 * MockServiceRepository.h
 *
 *  Created on: 7 Oct 2011
 *      Author: Jim.Knowler@youview.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#ifndef NICKELSYSTEMMINIMAL_TEST_MOCKLOCALSTORAGEREPOSITORY_H
#define NICKELSYSTEMMINIMAL_TEST_MOCKLOCALSTORAGEREPOSITORY_H

#include <nickel-system-api/macros.h>
#include <copper-system-api/macros.h>
#include <copper-system-api/copper-system-api.h>

#include <gmock/gmock.h>

NS_NICKEL_SYSTEM_OPEN

class MockLocalStorageRepository : public NS_COPPER_SYSTEM::LocalStorageRepositorySync
{
public:

	MOCK_CONST_METHOD3( getItem, std::string(const int32_t authType_in, const std::string& authToken_in, const std::string& key_in) );

	MOCK_METHOD4( setItem, void(const int32_t authType_in, const std::string& authToken_in, const std::string& key_in, const std::string& value_in) );

	MOCK_METHOD3( deleteItem, void(const int32_t authType_in, const std::string& authToken_in, const std::string& key_in) );

	MOCK_METHOD3( deleteTree, void(const int32_t authType_in, const std::string& authToken_in, const std::string& key_in) );

	typedef std::map< std::string, std::string > ChildItemsType;
	MOCK_CONST_METHOD4( getChildItems, ChildItemsType(const int32_t authType_in, const std::string& authToken_in, const std::string& key_in, const bool immediateItems_in) );

	MOCK_METHOD3( createNotifier, boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageNotifier >(const int32_t authType_in, const std::string& authToken_in, const std::vector< std::string >& keys_in) );

	MOCK_METHOD3( destroyNotifier, void(const int32_t authType_in, const std::string& authToken_in, const boost::shared_ptr< NS_COPPER_SYSTEM::LocalStorageNotifier > notifier_in));


};

NS_NICKEL_SYSTEM_CLOSE

#endif
