/*
 * MockClock.h
 *
 *  Created on: 7 Oct 2011
 *      Author: Jim.Knowler@youview.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#ifndef NICKEL_SYSTEM_MINIMAL_TEST_MOCKCLOCK_H
#define NICKEL_SYSTEM_MINIMAL_TEST_MOCKCLOCK_H

#include "../src/Clock.h"

#include <gmock/gmock.h>

NS_NICKEL_SYSTEM_OPEN

class MockClock : public Clock
{
public:

	MOCK_METHOD0( getCurrentTime, uint32_t() );
};

NS_NICKEL_SYSTEM_CLOSE

#endif
