/*
 * MockServiceRepository.h
 *
 *  Created on: 7 Oct 2011
 *      Author: Jim.Knowler@youview.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#ifndef NICKELSYSTEMMINIMAL_TEST_MOCKSERVICEREPOSITORY_H
#define NICKELSYSTEMMINIMAL_TEST_MOCKSERVICEREPOSITORY_H

#include <nickel-system-api/macros.h>
#include <iron-system-api/macros.h>
#include <iron-system-api/iron-system-api.h>

#include <gmock/gmock.h>

NS_NICKEL_SYSTEM_OPEN

class MockServiceRepository : public NS_IRON_SYSTEM::ServiceRepository
{
public:

	MOCK_METHOD0(getServiceList, NS_ZINC::Future< std::vector< std::string > >() );
	MOCK_METHOD1(getService, NS_ZINC::Future< NS_IRON_SYSTEM::Service >(const std::string& serviceLocator_in) );
	MOCK_METHOD0(getReceivableRegions, NS_ZINC::Future< std::vector< NS_IRON_SYSTEM::TargetRegion > >() );
	MOCK_METHOD0(getSelectedRegion, NS_ZINC::Future< NS_IRON_SYSTEM::TargetRegion >() );
	MOCK_METHOD4(setSelectedRegion, NS_ZINC::Future< void >(const std::string& countryCode_in, const int32_t primaryRegionCode_in, const int32_t secondaryRegionCode_in, const int32_t tertiaryRegionCode_in) );
	MOCK_METHOD0(getNetworkChangeNotifications, NS_ZINC::Future< std::vector< NS_IRON_SYSTEM::NetworkChangeNotification > >() );
};

NS_NICKEL_SYSTEM_CLOSE

#endif
