/*
 * MockEventRepository.h
 *
 *  Created on: 7 Oct 2011
 *      Author: Jim.Knowler@youview.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#ifndef NICKELSYSTEMMINIMAL_TEST_MOCKEVENTREPOSITORY_H
#define NICKELSYSTEMMINIMAL_TEST_MOCKEVENTREPOSITORY_H

#include <nickel-system-api/macros.h>
#include <iron-system-api/macros.h>
#include <iron-system-api/iron-system-api.h>

#include <gmock/gmock.h>

NS_NICKEL_SYSTEM_OPEN

class MockEventRepository : public NS_IRON_SYSTEM::EventRepository
{
public:

	MOCK_METHOD1(getPresentFollowing, NS_ZINC::Future< std::vector< NS_IRON_SYSTEM::Event > >(const std::string& serviceLocator_in));
	MOCK_METHOD1(getEvent, NS_ZINC::Future< NS_IRON_SYSTEM::Event >(const std::string& eventLocator_in));
	MOCK_METHOD3(getScheduleEvents, NS_ZINC::Future< std::vector< NS_IRON_SYSTEM::Event > >(const std::vector< std::string >& serviceLocators_in, const uint32_t startTime_in, const uint32_t endTime_in));
	MOCK_METHOD1(findByProgrammeCrid, NS_ZINC::Future< std::vector< NS_IRON_SYSTEM::Event > >(const std::string& programmeCrid_in));
	MOCK_METHOD1(findBySeriesCrid, NS_ZINC::Future< std::vector< NS_IRON_SYSTEM::Event > >(const std::string& seriesCrid_in));

};

NS_NICKEL_SYSTEM_CLOSE

#endif
