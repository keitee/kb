/*
 * MockListener.h
 *
 *  Created on: 4 Oct 2011
 *      Author: Jim.Knowler@youview.com
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */

#ifndef NICKELSYSTEMMINIMAL_TEST_MOCKLISTENER_H
#define NICKELSYSTEMMINIMAL_TEST_MOCKLISTENER_H

#include <nickel-system-api/macros.h>

#include "../src/MediaRecordStore.h"

#include <gmock/gmock.h>

NS_NICKEL_SYSTEM_OPEN

class MockListener : public MediaRecordStore::IListener
{
public:

	MOCK_METHOD2( onMediaRecordChanged, void( int64_t mediaRecordIdentifier, LibraryContentChangeType::Enum changeType ) );
};

NS_NICKEL_SYSTEM_CLOSE

#endif
