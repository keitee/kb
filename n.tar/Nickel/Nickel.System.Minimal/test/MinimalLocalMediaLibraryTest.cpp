/*
 * MinimalLocalMediaLibraryTest.cpp
 *
 *  Created on: 23 September 2011
 *      Author: jim.knowler@youview.co.uk
 *
 *   Copyright (C) 2011 YouView TV Ltd
 */


#include <zinc-common/zinc-common.h>
#include <nickel-system-api/nickel-system-api.h>
#include <nickel-system-api/MockLocalMediaLibraryEventListener.h>
#include <nickel-system-api/LocalMediaLibraryConvertToAsync.h>

#include <zinc-common/testsupport/PluginTestFixture.h>
#include <zinc-common/testsupport/PluginTestMacros.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/FactoryPluginLoader.h>
#include <zinc-common/testsupport/FutureMockActions.h>

#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/MultipleListenerEventDispatcher.h>
#include <zinc-common/async/Promise.h>

#include <boost/make_shared.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "../src/MinimalLocalMediaLibrarySync.h"
#include "../src/SQLiteMediaRecordStore.h"
#include "../src/FakeMediaFileSystem.h"

#include <cadmium-system-api/cadmium-system-api.h>

#include "MockEventRepository.h"
#include "MockServiceRepository.h"
#include "MockLocalStorageRepository.h"
#include "MockClock.h"

#include "../include/MinimalMediaLocator.h"

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;
using namespace testing;

typedef LocalMediaLibrary MinimalLocalMediaLibrary ;

namespace
{
	/*
	 * @brief key values used in the 'identifiers' field
	 */
	const std::string IDENTIFIERS_KEY_EVENTLOCATOR = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.eventLocator";
	const std::string IDENTIFIERS_KEY_SERIES_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.seriesCRID";
	const std::string IDENTIFIERS_KEY_PROGRAMME_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.programmeCRID";
	const std::string IDENTIFIERS_KEY_RECOMMENDATION_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.recommendationCRID";
	const std::string IDENTIFIERS_KEY_COLLECTION_CRID = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2010-12-09#linear.collectionCRID";
	const std::string IDENTIFIERS_KEY_SPLIT_INSTANCE_IDENTIFIER = "http://refdata.youview.com/mpeg7cs/YouViewIdentifierTypeCS/2011-10-03#linear.splitInstanceIdentifier";

	/*
	 * @brief key values used in LocalStorageRepository
	 */
	const std::string LSR_KEY_AUTODELETE = "platform.localmedialibrary.autodelete";
	const std::string LSR_KEY_THRESHOLD = "platform.localmedialibrary.threshold";
	const std::string LSR_KEY_BROADCAST_SD_BITRATE = "platform.localmedialibrary.broadcastsdbitrate";
	const std::string LSR_KEY_BROADCAST_HD_BITRATE = "platform.localmedialibrary.broadcasthdbitrate";
	const std::string LSR_KEY_BROADCAST_RADIO_BITRATE = "platform.localmedialibrary.broadcastradiobitrate";

	/*
	 * @brief config values for FakeMediaFileSystem
	 */
	#define FREE_SPACE_BYTES int64_t(320 * 1024 * 1024)

	/*
	 * @brief Constants used by several tests
	 */
	const uint32_t SECONDS_PER_DAY = 24 * 60 * 60;
}

class MinimalLocalMediaLibraryTest : public CppUnit::TestFixture, public NS_ZINC::UnitTestSandbox
{
public:

	boost::shared_ptr< MockEventRepository > mockEventRepository;
	boost::shared_ptr< MockServiceRepository > mockServiceRepository;
	boost::shared_ptr< MockLocalStorageRepository > mockLocalStorageRepository;
	boost::shared_ptr< MockClock > mockClock;
	boost::shared_ptr< MediaRecordStore > store;

	boost::shared_ptr<Dispatcher> asyncFromSyncDispatcher;

	int lsrValueThreshold;
	int lsrValueBroadcastSDBitrate;
	int lsrValueBroadcastHDBitrate;
	int lsrValueBroadcastRadioBitrate;

	void setUp()
	{
		asyncFromSyncDispatcher = boost::make_shared<SingleThreadDispatcher>();
		lsrValueThreshold = 20 * 1024;								// megabytes
		lsrValueBroadcastSDBitrate = 1 * 1024 * 1024 * 8;			// bits per second
		lsrValueBroadcastHDBitrate = 2 * 1024 * 1024 * 8;			// bits per second
		lsrValueBroadcastRadioBitrate = 256 * 1024 * 8;				// bits per second
	}

	void tearDown()
	{
		asyncFromSyncDispatcher.reset();
	}

	/*
	 * @brief Create a new MinimalLocalMediaLibrary, powered by an SQLiteMediaRecordStore
	 */
	boost::shared_ptr<LocalMediaLibrary> createMinimalLocalMediaLibrary()
	{
		SQLiteMediaRecordStore::Config config;
		config.useTempMemoryDB = true;

		store = boost::make_shared<SQLiteMediaRecordStore>( config );
		mockEventRepository.reset( new MockEventRepository() );
		mockEventRepository->setDispatcher(boost::make_shared<MultipleListenerEventDispatcher>());
		mockServiceRepository.reset( new MockServiceRepository() );
		mockServiceRepository->setDispatcher(boost::make_shared<MultipleListenerEventDispatcher>());

		mockLocalStorageRepository.reset( new MockLocalStorageRepository() );
		EXPECT_CALL( *mockLocalStorageRepository, getItem(0, StrEq(""), StrEq(LSR_KEY_AUTODELETE) ) ).WillRepeatedly(Return( "1" ));
		EXPECT_CALL( *mockLocalStorageRepository, getItem(0, StrEq(""), StrEq(LSR_KEY_THRESHOLD) ) ).WillRepeatedly(Return( boost::lexical_cast<std::string>(lsrValueThreshold) ));
		EXPECT_CALL( *mockLocalStorageRepository, getItem(0, StrEq(""), StrEq(LSR_KEY_BROADCAST_SD_BITRATE) ) ).WillRepeatedly(Return( boost::lexical_cast<std::string>(lsrValueBroadcastSDBitrate) ));
		EXPECT_CALL( *mockLocalStorageRepository, getItem(0, StrEq(""), StrEq(LSR_KEY_BROADCAST_HD_BITRATE) ) ).WillRepeatedly(Return( boost::lexical_cast<std::string>(lsrValueBroadcastHDBitrate) ));
		EXPECT_CALL( *mockLocalStorageRepository, getItem(0, StrEq(""), StrEq(LSR_KEY_BROADCAST_RADIO_BITRATE) ) ).WillRepeatedly(Return( boost::lexical_cast<std::string>(lsrValueBroadcastRadioBitrate) ));

		mockClock.reset( new MockClock() );
		EXPECT_CALL( *mockClock, getCurrentTime() ).WillRepeatedly( Return(0) );

		boost::shared_ptr<MinimalLocalMediaLibrarySync> lml_sync = boost::make_shared<MinimalLocalMediaLibrarySync>();

		boost::shared_ptr<FakeMediaFileSystem> fakeMediaFileSystem( new FakeMediaFileSystem() );
		fakeMediaFileSystem->initialise( mockClock, mockLocalStorageRepository, store, FREE_SPACE_BYTES );

		lml_sync->initialise( store, mockEventRepository, mockServiceRepository, mockLocalStorageRepository, fakeMediaFileSystem, mockClock );
		boost::shared_ptr<LocalMediaLibrary> minimalLocalMediaLibrary = convertToAsync( lml_sync, *asyncFromSyncDispatcher );

		minimalLocalMediaLibrary->setDispatcher(boost::make_shared<MultipleListenerEventDispatcher>());

		return minimalLocalMediaLibrary;
	}

	boost::shared_ptr< MediaRecordStore > getMediaRecordStore()
	{
		return store;
	}

	/**
	 * White-box used to simulate the events from LinearAcquisition
	 *
	 * Should be replaced with a LA mock
	 */
	boost::shared_ptr< MinimalLocalMediaLibrarySync > getMinimalLocalMediaLibrarySync(boost::shared_ptr< LocalMediaLibrary > lml)
	{
		return boost::dynamic_pointer_cast<MinimalLocalMediaLibrarySync>( unconvertToSync(lml) );
	}

	/*
	 * @brief create an empty MediaRecord
	 */
	MediaRecordEx createMediaRecord( boost::shared_ptr<MediaRecordStore> store )
	{
		MediaRecordEx mediaRecord;
		mediaRecord.acquisitionStatus = AcquisitionStatus::not_begun_yet;

		store->addMediaRecord( mediaRecord );

		return mediaRecord;
	}

	typedef std::map< std::string, LibraryContentChangeType::Enum > MapLibContentChange;
	typedef std::pair< std::string, LibraryContentChangeType::Enum > MapLibContentChangePair;

	/*
	 * @class LibraryContentChangeTypeMatcher
	 * @brief Implementation of a GMOCK matcher for testing only the LibraryContentChangeType field of a LibraryContentChange signal
	 * @note This is useful when testing for an 'added' signal, when we don't know the mediaContentIdentifier that we should expect
	 */
	class LibraryContentChangeTypeMatcher : public MatcherInterface<const MapLibContentChangePair&>
	{

	public:
		explicit LibraryContentChangeTypeMatcher(LibraryContentChangeType::Enum _expectedChangeType)
			: expectedChangeType(_expectedChangeType) {}

		virtual bool MatchAndExplain(const MapLibContentChangePair& o, MatchResultListener* /*listener*/) const
		{
			return o.second == expectedChangeType;
		}

		virtual void DescribeTo(::std::ostream* os) const
		{
			*os << "LibraryContentChangeType equals " << expectedChangeType;
		}

		virtual void DescribeNegationTo(::std::ostream* os) const
		{
			*os << "LibraryContentChangeType does not equal " << expectedChangeType;
		}

	private:
		const LibraryContentChangeType::Enum expectedChangeType;
	};

	inline Matcher<const MapLibContentChangePair&> LibraryContentChangeTypeEq(LibraryContentChangeType::Enum _expectedChangeType)
	{
		return MakeMatcher(new LibraryContentChangeTypeMatcher(_expectedChangeType));
	}


	/*
	 * @brief Following specs in Annex D of "Content Acquisition and management" specifications
	 */
	void testMappingLinearMetadataToMediaRecord()
	{
		boost::shared_ptr<LocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		/// @todo figure out how to choose which language to use
		/// @todo test support for different languages

		const char* LANGUAGE = "eng";

		NS_IRON_SYSTEM::Event event;
		NS_IRON_SYSTEM::Service service;

		event.programmeCrid = "my programme CRID";
		service.name[LANGUAGE] = "my service name";
		event.eventLocator = "dvb://1111..2222;3333";
		event.shortTitle[LANGUAGE] = "my short title";
		event.mediumSynopsis[LANGUAGE] = "my medium synopsis";
		service.adult = false;
		event.guidanceCode = "my guidance code";
		event.guidanceText[ LANGUAGE ] = "my guidance text";
		event.audioDescription = false;
		event.signing = false;
		event.splitInstanceIdentifier ="A9";
		event.programmeCrid = "my-programme-crid";
		event.seriesCrid.push_back( "my series crid" );
		event.recommendationCrid.push_back( "my recommendation crid" );
		event.collectionCrid.push_back( "my collection crid" );

		MediaRecordEx mediaRecord;
		mediaRecord.fillMediaRecord( event, service );

		CPPUNIT_ASSERT_EQUAL_MESSAGE("contentIdentifier", event.programmeCrid, mediaRecord.contentIdentifier);

		CPPUNIT_ASSERT_EQUAL( uint32_t(6), mediaRecord.identifiers.size() );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("identifiers - eventlocator", event.eventLocator, mediaRecord.identifiers[IDENTIFIERS_KEY_EVENTLOCATOR]);
		CPPUNIT_ASSERT_EQUAL_MESSAGE("identifiers - series crid", event.seriesCrid[0], mediaRecord.identifiers[IDENTIFIERS_KEY_SERIES_CRID]);
		CPPUNIT_ASSERT_EQUAL_MESSAGE("identifiers - recommendation crid", event.recommendationCrid[0], mediaRecord.identifiers[IDENTIFIERS_KEY_RECOMMENDATION_CRID]);
		CPPUNIT_ASSERT_EQUAL_MESSAGE("identifiers - collection crid", event.collectionCrid[0], mediaRecord.identifiers[IDENTIFIERS_KEY_COLLECTION_CRID]);
		CPPUNIT_ASSERT_EQUAL_MESSAGE("identifiers - split instance identifier", event.splitInstanceIdentifier, mediaRecord.identifiers[IDENTIFIERS_KEY_SPLIT_INSTANCE_IDENTIFIER]);
		CPPUNIT_ASSERT_EQUAL_MESSAGE("identifiers - programme crid", event.programmeCrid, mediaRecord.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID]);

		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaLocator", std::string(""), mediaRecord.mediaLocator );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("serviceName", service.name[ LANGUAGE ], mediaRecord.serviceName );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("title", event.shortTitle[ LANGUAGE ], mediaRecord.title );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("synopsis", event.mediumSynopsis[ LANGUAGE ], mediaRecord.synopsis );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("publishedDuration", event.publishedDuration, mediaRecord.publishedDuration );
		/// @todo duration
		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult", service.adult, mediaRecord.adult );	/// @todo test true/false
		/// @todo watershed
		CPPUNIT_ASSERT_EQUAL_MESSAGE("guidanceCode", event.guidanceCode, mediaRecord.guidanceCode );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("guidanceText", event.guidanceText[ LANGUAGE ], mediaRecord.guidanceText );
		/// @todo subtitles
		CPPUNIT_ASSERT_EQUAL_MESSAGE("audioDescription", event.audioDescription, mediaRecord.audioDescription );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("signing", event.signing, mediaRecord.signing );

		/// @todo acquisitionDateTime
		/// @todo acquisitionStatus
		/// @todo played
		/// @todo lastAccessed
		/// @todo isProtected
		/// @todo size

		// test that the eventLocator is used if programmeCrid is not available
		event.programmeCrid.clear();
		// test the 'true' states of boolean fields
		service.adult = true;
		event.audioDescription = true;
		event.signing = true;

		MediaRecordEx mediaRecord2;
		mediaRecord2.fillMediaRecord( event, service );

		CPPUNIT_ASSERT_EQUAL_MESSAGE("contentIdentifier", event.eventLocator, mediaRecord2.contentIdentifier );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("audioDescription", event.audioDescription, mediaRecord2.audioDescription );
		CPPUNIT_ASSERT_EQUAL_MESSAGE("signing", event.signing, mediaRecord2.signing );
	}

	void testGetMediaRecords()
	{
		boost::shared_ptr<LocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		/// @todo filterByType    ( recordings, downloads, both) - we're only supporting LinearAcquisition recordings

		const uint32_t NUM_RECORDS = 8;
		int isAdult[NUM_RECORDS] = { 1, 1, 0, 0, 1, 1, 0, 1 };
		uint32_t lastAccessed[NUM_RECORDS] = { 1,4,3,2,6,5,8,7 };
		uint32_t acquisitionDateTime[NUM_RECORDS] = { 8,7,4,1,2,5,6,3 };
		uint32_t resumeAt[NUM_RECORDS] = { 0,0,1,1,0,0,1,0 };			// nb. 0 == never-played
		const char* title[NUM_RECORDS] = { "a", "b", "c", "e", "d", "f", "g", "h" };

		MediaRecord mediaRecords[NUM_RECORDS];
		for ( uint i=0 ; i<NUM_RECORDS ; i++ )
		{
			MediaRecordEx mediaRecord;

			mediaRecord.adult = (1 == isAdult[ i ]);
			mediaRecord.title = title[i];
			mediaRecord.lastAccessed = lastAccessed[i];
			mediaRecord.acquisitionDateTime = acquisitionDateTime[i];
			mediaRecord.resumeAt = resumeAt[i];
			store->addMediaRecord( mediaRecord );

			mediaRecords[i] = MinimalLocalMediaLibrarySync::fromMediaRecordEx( mediaRecord );
		}

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		// - include adult, sortby a-to-z
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		std::vector< MediaRecord > results = minimalLocalMediaLibrary->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[2]", mediaRecords[2] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[3]", mediaRecords[4] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[4]", mediaRecords[3] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[5]", mediaRecords[5] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[6]", mediaRecords[6] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z: results[7]", mediaRecords[7] == results[7] );


		// - not adult, sortby z-to-a
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_z_to_a, false, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("not-adult, z-a: num-results", size_t(3), results.size() );
		CPPUNIT_ASSERT_MESSAGE("not-adult, z-a: results[0]", mediaRecords[6] == results[0]);
		CPPUNIT_ASSERT_MESSAGE("not-adult, z-a: results[1]", mediaRecords[3] == results[1]);
		CPPUNIT_ASSERT_MESSAGE("not-adult, z-a: results[2]", mediaRecords[2] == results[2]);

		// - include adult, sortby least-recently-acquired
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::least_recently_acquired, true, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby least-recently-acquired: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[0]", mediaRecords[3] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[1]", mediaRecords[4] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[2]", mediaRecords[7] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[3]", mediaRecords[2] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[4]", mediaRecords[5] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[5]", mediaRecords[6] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[6]", mediaRecords[1] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-acquired: results[7]", mediaRecords[0] == results[7] );

		// - include adult, sortby most-recently-acquired
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::most_recently_acquired, true, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby most-recently-acquired: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[7]", mediaRecords[3] == results[7] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[6]", mediaRecords[4] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[5]", mediaRecords[7] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[4]", mediaRecords[2] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[3]", mediaRecords[5] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[2]", mediaRecords[6] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-acquired: results[0]", mediaRecords[0] == results[0] );

		/// @todo check ASSUMPTION that recently-watched implies querying the 'lastAccessed' field

		// - include adult, sortby least-recently-watched
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::least_recently_watched, true, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby least-recently-watched: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[1]", mediaRecords[3] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[2]", mediaRecords[2] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[3]", mediaRecords[1] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[4]", mediaRecords[5] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[5]", mediaRecords[4] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[6]", mediaRecords[7] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby least-recently-watched: results[7]", mediaRecords[6] == results[7] );

		// - include adult, sortby most-recently-watched
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::most_recently_watched, true, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("sortby most-recently-watched: num-results", size_t(8), results.size() );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[7]", mediaRecords[0] == results[7] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[6]", mediaRecords[3] == results[6] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[5]", mediaRecords[2] == results[5] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[4]", mediaRecords[1] == results[4] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[3]", mediaRecords[5] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[2]", mediaRecords[4] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[1]", mediaRecords[7] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("sortby most-recently-watched: results[0]", mediaRecords[6] == results[0] );

		// - include adult, sortby a-to-z, played
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played, SortBy::title_a_to_z, true, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, played: num-results", size_t(3), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[0]", mediaRecords[2] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[1]", mediaRecords[3] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[2]", mediaRecords[6] == results[2] );

		// - include adult, sortby a-to-z, unplayed
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::unplayed, SortBy::title_a_to_z, true, uint32_t(0), NUM_RECORDS ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, unplayed: num-results", size_t(5), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[2]", mediaRecords[4] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[3]", mediaRecords[5] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, played: results[4]", mediaRecords[7] == results[4] );

		// - include adult, sortby a-to-z, start/size
		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
				FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(0), 5 ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, start-size[a]: num-results", size_t(5), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[0]", mediaRecords[0] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[1]", mediaRecords[1] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[2]", mediaRecords[2] == results[2] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[3]", mediaRecords[4] == results[3] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[a]: results[4]", mediaRecords[3] == results[4] );

		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(5), 5 ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, start-size[b]: num-results", size_t(3), results.size() );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[b]: results[0]", mediaRecords[5] == results[0] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[b]: results[1]", mediaRecords[6] == results[1] );
		CPPUNIT_ASSERT_MESSAGE("adult, a-z, start-size[b]: results[2]", mediaRecords[7] == results[2] );

		EXPECT_CALL( *mockListener, LibraryContentChange(_) ).Times(0);
		results = minimalLocalMediaLibrary->getMediaRecords(
						FilterByType::recordings_and_downloads, FilterByPlayed::played_and_unplayed, SortBy::title_a_to_z, true, uint32_t(10), 5 ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		CPPUNIT_ASSERT_EQUAL_MESSAGE("adult, a-z, start-size[c]: num-results", size_t(0), results.size() );

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	void testGetMediaRecord()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecord( "99" ).get(), MediaRecordNotFoundException );

		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecord( "not a number" ).get(), MediaRecordNotFoundException );

		MediaRecordEx newMediaRecord;
		newMediaRecord.title = "my test media record";

		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1);
		int64_t id = store->addMediaRecord( newMediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		std::string strID = boost::lexical_cast<std::string>( id );

		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		MediaRecord mediaRecord = minimalLocalMediaLibrary->getMediaRecord( strID ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_MESSAGE( "get MediaRecord that we just added", MinimalLocalMediaLibrarySync::fromMediaRecordEx(newMediaRecord) == mediaRecord );

		std::string strBadID = strID + "99";
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecord( strBadID ).get(), MediaRecordNotFoundException );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	void testGetMediaRecordsByContentIdentifier()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();
		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		MediaRecordEx mediaRecord1 = createMediaRecord( store );
		mediaRecord1.contentIdentifier = "my content identifier 1";
		store->updateMediaRecord( mediaRecord1 );

		MediaRecordEx mediaRecord2 = createMediaRecord( store );
		mediaRecord2.contentIdentifier = "my content identifier 2";
		store->updateMediaRecord( mediaRecord2 );

		MediaRecordEx mediaRecord3 = createMediaRecord( store );
		mediaRecord3.contentIdentifier = mediaRecord2.contentIdentifier;
		store->updateMediaRecord( mediaRecord3 );

		MediaRecordEx mediaRecord4 = createMediaRecord( store );
		mediaRecord4.contentIdentifier = "my content identifier 4";
		store->updateMediaRecord( mediaRecord4 );

		MediaRecordEx mediaRecord5 = createMediaRecord( store );
		mediaRecord5.contentIdentifier = "dvb://1111..1111;1111";
		store->updateMediaRecord( mediaRecord5 );

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);

		std::vector<MediaRecord> mediaRecords1 = minimalLocalMediaLibrary->getMediaRecordsByContentIdentifier( mediaRecord1.contentIdentifier ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords1 - num MediaRecords", 1, int(mediaRecords1.size()) );
		CPPUNIT_ASSERT(mediaRecord1.contentIdentifier == mediaRecords1[0].contentIdentifier );

		std::vector<MediaRecord> mediaRecords2 = minimalLocalMediaLibrary->getMediaRecordsByContentIdentifier( mediaRecord2.contentIdentifier ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords2 - num MediaRecords", 2, int(mediaRecords2.size()) );
		CPPUNIT_ASSERT( MinimalLocalMediaLibrarySync::fromMediaRecordEx(mediaRecord2) == mediaRecords2[0] );
		CPPUNIT_ASSERT( MinimalLocalMediaLibrarySync::fromMediaRecordEx(mediaRecord3) == mediaRecords2[1] );

		std::vector<MediaRecord> mediaRecords4 = minimalLocalMediaLibrary->getMediaRecordsByContentIdentifier( mediaRecord4.contentIdentifier ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords4 - num MediaRecords", 1, int(mediaRecords4.size()) );
		CPPUNIT_ASSERT( MinimalLocalMediaLibrarySync::fromMediaRecordEx(mediaRecord4) == mediaRecords4[0] );

		std::vector<MediaRecord> mediaRecords5 = minimalLocalMediaLibrary->getMediaRecordsByContentIdentifier( "unknown content identifier" ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords5 - num MediaRecords", 0, int(mediaRecords5.size()) );

		std::vector<MediaRecord> mediaRecords6 = minimalLocalMediaLibrary->getMediaRecordsByContentIdentifier( "dvb://1111.9999.1111;1111" ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE("mediaRecords6 - num MediaRecords", 1, int(mediaRecords6.size()) );
		CPPUNIT_ASSERT( MinimalLocalMediaLibrarySync::fromMediaRecordEx(mediaRecord5) == mediaRecords6[0] );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		/// @todo test with transport_stream_identifier included-in/stripped-from eventLocator that we search with

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	void testDeleteMediaRecord()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();
		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		// fail at deleting an unknown media record
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->deleteMediaRecord( "101" ).get(), MediaRecordNotFoundException );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// fail at deleting a badly formed media record identifier
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecord( "not a number" ).get(), MediaRecordNotFoundException );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// add a media record
		MediaRecordEx newMediaRecord;
		newMediaRecord.title = "my test MediaRecord";
		newMediaRecord.acquisitionStatus = AcquisitionStatus::not_begun_yet;
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) )) ).Times(1);
		int64_t mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		std::string strID = boost::lexical_cast<std::string>( mediaRecordIdentifier );

		// succeed at getting media record we have just added
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		MediaRecord mediaRecord = minimalLocalMediaLibrary->getMediaRecord( strID ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT( MinimalLocalMediaLibrarySync::fromMediaRecordEx(newMediaRecord) == mediaRecord );

		// fail to delete an unknown media record (make sure we're filtering on mediaRecordIdentifier)
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->deleteMediaRecord( strID + "1" ).get(), MediaRecordNotFoundException );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// succeed at deleting the media record we have just added
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::deleted) )) ).Times(1);
		bool success = minimalLocalMediaLibrary->deleteMediaRecord( strID ).get();
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL_MESSAGE("successfully delete media record (AcquisitionStatus::not_begun_yet)", true, success );

		// fail at getting the media record (that we have just deleted)
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecord( strID ).get(), MediaRecordNotFoundException );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		///////////////////////////////////////
		// Signal DeleteFailedDueToMediaRecordInUse

		// test that we can't delete MediaRecords while they are recording
		{
			MediaRecordEx newMediaRecord;
			newMediaRecord.acquisitionStatus = AcquisitionStatus::begun;
			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) )) ).Times(1);
			mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
			strID = boost::lexical_cast<std::string>( mediaRecordIdentifier );

			EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
			CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->deleteMediaRecord( strID ).get(), DeleteFailedDueToMediaRecordInUseException );
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		}

		// test we can delete MediaRecord when acquired
		{
			MediaRecordEx newMediaRecord;
			newMediaRecord.acquisitionStatus = AcquisitionStatus::acquired;
			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) )) ).Times(1);
			mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
			strID = boost::lexical_cast<std::string>( mediaRecordIdentifier );

			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::deleted) )) ).Times(1);
			success = minimalLocalMediaLibrary->deleteMediaRecord( strID ).get();
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
			CPPUNIT_ASSERT_EQUAL_MESSAGE("successfully delete media record (AcquisitionStatus::acquired)", true, success );
		}

		// test we can delete MediaRecord when partially_acquired
		{
			MediaRecordEx newMediaRecord;
			newMediaRecord.acquisitionStatus = AcquisitionStatus::partially_acquired;
			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) )) ).Times(1);
			mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
			strID = boost::lexical_cast<std::string>( mediaRecordIdentifier );

			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::deleted) )) ).Times(1);
			success = minimalLocalMediaLibrary->deleteMediaRecord( strID ).get();
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
			CPPUNIT_ASSERT_EQUAL_MESSAGE("successfully delete media record (AcquisitionStatus::partially_acquired)", true, success );
		}


		// test we can delete MediaRecord when failed to acquire
		{
			MediaRecordEx newMediaRecord;
			newMediaRecord.acquisitionStatus = AcquisitionStatus::failed;
			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) )) ).Times(1);
			mediaRecordIdentifier = store->addMediaRecord( newMediaRecord );
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
			strID = boost::lexical_cast<std::string>( mediaRecordIdentifier );

			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::deleted) )) ).Times(1);
			success = minimalLocalMediaLibrary->deleteMediaRecord( strID ).get();
			CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
			CPPUNIT_ASSERT_EQUAL_MESSAGE("successfully delete media record (AcquisitionStatus::failed)", true, success );
		}

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );

	}

	void testGetStorageSpace()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();
		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		// test without any MediaRecord objects
		MediaStorageSpace storageSpace = minimalLocalMediaLibrary->getStorageSpace().get();
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForRecordings );
		CPPUNIT_ASSERT_EQUAL( FREE_SPACE_BYTES, storageSpace.free );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForRecordings );

		// test with a not_begun_yet MediaRecord object
		MediaRecordEx mediaRecord;
		mediaRecord.acquisitionStatus = AcquisitionStatus::not_begun_yet;
		store->addMediaRecord( mediaRecord );

		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForRecordings );
		CPPUNIT_ASSERT_EQUAL( FREE_SPACE_BYTES, storageSpace.free );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForRecordings );

		// test with an acquired MediaRecord object
		mediaRecord.size = 100;
		mediaRecord.acquisitionStatus = AcquisitionStatus::acquired;
		store->updateMediaRecord( mediaRecord );

		storageSpace = minimalLocalMediaLibrary->getStorageSpace().get();
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForRecordings );
		CPPUNIT_ASSERT_EQUAL( FREE_SPACE_BYTES - int64_t(100), storageSpace.free );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(100), storageSpace.usedForRecordings );

		// test with a MediaRecord we partially_acquired
		mediaRecord.acquisitionStatus = AcquisitionStatus::partially_acquired;
		store->updateMediaRecord( mediaRecord );

		storageSpace = minimalLocalMediaLibrary->getStorageSpace().get();
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForRecordings );
		CPPUNIT_ASSERT_EQUAL( FREE_SPACE_BYTES - int64_t(100), storageSpace.free );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(100), storageSpace.usedForRecordings );

		// test with a MediaRecord we failed to acquire
		mediaRecord.acquisitionStatus = AcquisitionStatus::failed;
		mediaRecord.size = 0;
		store->updateMediaRecord( mediaRecord );

		storageSpace = minimalLocalMediaLibrary->getStorageSpace().get();
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForRecordings );
		CPPUNIT_ASSERT_EQUAL( FREE_SPACE_BYTES, storageSpace.free );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForRecordings );

		// test with a MediaRecord object that we are currently acquiring
		std::string eventLocator = "dvb://1111..2222;3333";
		mediaRecord.acquisitionStatus = AcquisitionStatus::begun;
		mediaRecord.acquisitionDateTime = 20;
		mediaRecord.size = 0;
		mediaRecord.identifiers[ IDENTIFIERS_KEY_EVENTLOCATOR ] = eventLocator;
		store->updateMediaRecord( mediaRecord );

		NS_IRON_SYSTEM::Event event;
		event.eventLocator = eventLocator;
		event.publishedDuration = 80;

		EXPECT_CALL( *mockClock, getCurrentTime() ).WillRepeatedly(Return(50) );
		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(eventLocator) ) ).WillOnce( returnNewCompletedFuture( event ) );

		storageSpace = minimalLocalMediaLibrary->getStorageSpace().get();

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));

		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(30 * lsrValueBroadcastSDBitrate / 8), storageSpace.usedForRecordings );
		CPPUNIT_ASSERT_EQUAL( int64_t(50 * lsrValueBroadcastSDBitrate / 8), storageSpace.anticipatedForRecordings );
		CPPUNIT_ASSERT_EQUAL( FREE_SPACE_BYTES - int64_t( (30 + 50) * lsrValueBroadcastSDBitrate / 8), storageSpace.free );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForDownloads );

		// test with combination of acquired and acquiring MediaRecord object
		MediaRecordEx mediaRecord2;
		mediaRecord2.size = 400;
		mediaRecord2.acquisitionStatus = AcquisitionStatus::acquired;
		store->addMediaRecord( mediaRecord2 );

		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(eventLocator) ) ).WillOnce( returnNewCompletedFuture( event ) );

		storageSpace = minimalLocalMediaLibrary->getStorageSpace().get();

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));

		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.anticipatedForDownloads );
		CPPUNIT_ASSERT_EQUAL( int64_t(400) + int64_t(30 * int64_t(lsrValueBroadcastSDBitrate) / 8), storageSpace.usedForRecordings );
		CPPUNIT_ASSERT_EQUAL( int64_t(50 * int64_t(lsrValueBroadcastSDBitrate) / 8), storageSpace.anticipatedForRecordings );
		CPPUNIT_ASSERT_EQUAL( FREE_SPACE_BYTES - ( int64_t(400) + int64_t( (30 + 50) * int64_t(lsrValueBroadcastSDBitrate) / 8)), storageSpace.free );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), storageSpace.usedForDownloads );

	}

	void testSetMediaRecordProtected()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();
		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		MediaRecordEx newMediaRecord;
		newMediaRecord.isProtected = false;
		int64_t id = store->addMediaRecord( newMediaRecord );
		std::string strID = boost::lexical_cast<std::string>( id );

		MediaRecord mediaRecord = minimalLocalMediaLibrary->getMediaRecord( strID ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE( "initialised false", false, mediaRecord.isProtected );

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strID,LibraryContentChangeType::updated)) ) ).Times(1);

		bool success = minimalLocalMediaLibrary->setMediaRecordProtected( strID, true ).get();

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL_MESSAGE( "set to true (success)", true, success );
		mediaRecord = minimalLocalMediaLibrary->getMediaRecord( strID ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE( "set to true", true, mediaRecord.isProtected );

		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strID,LibraryContentChangeType::updated)) ) ).Times(1);

		success = minimalLocalMediaLibrary->setMediaRecordProtected( strID, false ).get();

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL_MESSAGE( "set to false (success)", true, success );
		mediaRecord = minimalLocalMediaLibrary->getMediaRecord( strID ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE( "set to false", false, mediaRecord.isProtected );

		// fail while trying to access unknown media record
		std::string badStrID = strID + "42";
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->setMediaRecordProtected( badStrID, false ).get(), MediaRecordNotFoundException );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// fail while trying to use a malformed media record identifier
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecord( "not a number" ).get(), MediaRecordNotFoundException );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	void testGetMediaRecordTimingSignature()
	{
		boost::shared_ptr<LocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		MediaRecordEx newMediaRecord;
		newMediaRecord.title = "my test media record";

		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1);
		int64_t id = store->addMediaRecord( newMediaRecord );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);

		std::string strID = boost::lexical_cast<std::string>( id );
		std::string strTimingSignature = minimalLocalMediaLibrary->getMediaRecordTimingSignature( strID ).get();
		CPPUNIT_ASSERT_EQUAL_MESSAGE("timing signature should be empty", std::string(""), strTimingSignature );

		std::string badStrID = strID + "999";
		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecordTimingSignature( badStrID ).get(), MediaRecordNotFoundException );

		CPPUNIT_ASSERT_THROW( minimalLocalMediaLibrary->getMediaRecordTimingSignature( "not a number" ).get(), MediaRecordNotFoundException );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	/*
	 * @brief Test the creation & updating of MediaRecord objects based on 'ScheduleRecordingListChange' and 'RecordingEvent' signals from Cadmium
	 */
	void testMediaRecordAcquire()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		// test data
		NS_IRON_SYSTEM::Service testService;
		testService.serviceLocator = "dvb://1111..2222";

		NS_IRON_SYSTEM::Event testEvent;
		testEvent.eventLocator = "dvb://1111..2222.1111";
		testEvent.serviceLocator = testService.serviceLocator;
		testEvent.start = 100;
		testEvent.publishedDuration = 50;

		// used to discover the mediaRecordIdentifier of the MediaRecord added for each 'added' ScheduledRecordingListChange signal
		MapLibContentChange libraryContentChangeAdded;

		// create MediaRecord for new ScheduledRecording
		EXPECT_CALL( *mockServiceRepository, getService( StrEq(testService.serviceLocator) ) ).WillOnce( returnNewCompletedFuture( testService) );
		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillOnce( returnNewCompletedFuture( testEvent ) );
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );
		std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > mapChanges;
		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added;

		// issue the ScheduledRecordingListChange signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));

		std::string strMediaRecordIdentifier = libraryContentChangeAdded.begin()->first;
		int64_t mediaRecordIdentifier = boost::lexical_cast<int64_t>( strMediaRecordIdentifier );

		MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::not_begun_yet, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );
		CPPUNIT_ASSERT_EQUAL( uint32_t(100), mediaRecord.publishedStart );
		CPPUNIT_ASSERT_EQUAL( uint32_t(50), mediaRecord.publishedDuration );
		CPPUNIT_ASSERT_EQUAL( std::string(""), mediaRecord.mediaLocator );

		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).WillOnce(Return(5));

		// issue a RecordingEvent signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::begun);

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::begun, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(5), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );
		std::string expectedMediaLocator = generateMediaLocator( mediaRecord.publishedStart, testEvent.eventLocator, mediaRecord.title );
		CPPUNIT_ASSERT_EQUAL( expectedMediaLocator, mediaRecord.mediaLocator );

		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).WillRepeatedly( Return(20));

		// issue a RecordingEvent signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::acquired, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(5), mediaRecord.acquisitionDateTime );						// time (seconds since apex)
		CPPUNIT_ASSERT_EQUAL( int64_t(15 * lsrValueBroadcastSDBitrate / 8), mediaRecord.size );		// bytes
		CPPUNIT_ASSERT_EQUAL( uint32_t(15), mediaRecord.duration );									// the acquired duration in seconds

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	void testMediaRecordAcquireFailure()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		// test data
		NS_IRON_SYSTEM::Service testService;
		testService.serviceLocator = "dvb://1111..2222";

		NS_IRON_SYSTEM::Event testEvent;
		testEvent.eventLocator = "dvb://1111..2222.2222";
		testEvent.serviceLocator = testService.serviceLocator;

		// used to discover the mediaRecordIdentifier of the MediaRecord added for each 'added' ScheduledRecordingListChange signal
		MapLibContentChange libraryContentChangeAdded;

		// create MediaRecord for new ScheduledRecording
		EXPECT_CALL( *mockServiceRepository, getService( StrEq(testService.serviceLocator) ) ).WillOnce( returnNewCompletedFuture( testService ) );
		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillOnce( returnNewCompletedFuture( testEvent ) );
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );
		std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > mapChanges;
		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added;
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));

		std::string strMediaRecordIdentifier = libraryContentChangeAdded.begin()->first;
		int64_t mediaRecordIdentifier = boost::lexical_cast<int64_t>( strMediaRecordIdentifier );
		MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::not_begun_yet, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );

		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).WillOnce(Return(10));

		// issue a RecordingEvent
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::begun);

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));

		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );

		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::begun, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(10), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );

		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).Times(0);

		// issue a RecordingEvent
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::failed);

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::failed, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(10), mediaRecord.acquisitionDateTime );						// time (seconds since apex)
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );										// bytes
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );									// the acquired duration in seconds

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	void testMediaRecordPartialAcquire()
	{
		// partially acquire a linear event

		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		// test data
		NS_IRON_SYSTEM::Service testService;
		testService.serviceLocator = "dvb://1111..2222";

		NS_IRON_SYSTEM::Event testEvent;
		testEvent.eventLocator = "dvb://1111..2222.3333";
		testEvent.serviceLocator = testService.serviceLocator;

		// used to discover the mediaRecordIdentifier of the MediaRecord added for each 'added' ScheduledRecordingListChange signal
		MapLibContentChange libraryContentChangeAdded;

		// create MediaRecord for new ScheduledRecording
		EXPECT_CALL( *mockServiceRepository, getService( StrEq(testService.serviceLocator) ) ).WillOnce( returnNewCompletedFuture( testService ) );
		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillOnce( returnNewCompletedFuture( testEvent ) );
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );
		std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > mapChanges;
		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added;

		// issue ScheduledRecordingListChange signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));

		std::string strMediaRecordIdentifier = libraryContentChangeAdded.begin()->first;
		int64_t mediaRecordIdentifier = boost::lexical_cast<int64_t>( strMediaRecordIdentifier );
		MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::not_begun_yet, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );

		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).WillOnce(Return(40));

		// issue RecordingEvent signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::begun);

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::begun, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(40), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );

		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).WillRepeatedly( Return(100));

		// issue RecordingEvent signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired);

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::partially_acquired, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(40), mediaRecord.acquisitionDateTime );						// time (seconds since apex)
		CPPUNIT_ASSERT_EQUAL( int64_t(60 * lsrValueBroadcastSDBitrate / 8), mediaRecord.size );		// bytes
		CPPUNIT_ASSERT_EQUAL( uint32_t(60), mediaRecord.duration );

		// JK - trying to avoid race condition seen on build servers
		minimalLocalMediaLibrary->removeListener( mockListener );
	}

	/*
	 * @brief Test that ScheduledRecordingListChange signals:
	 *     - create MediaRecords as required
	 *     - update MediaRecords that we already have
	 *     - delete 'not_begun_yet' MediaRecords if the user deletes the relevant ScheduledRecording before anything has been recorded
	 */
	void testScheduledRecordingListChange()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		NS_IRON_SYSTEM::Service testService;
		testService.serviceLocator = "dvb://1111..2222";

		NS_IRON_SYSTEM::Event testEvent;
		testEvent.eventLocator = "dvb://1111..2222.3333";
		testEvent.serviceLocator = testService.serviceLocator;

		boost::posix_time::time_duration td = boost::posix_time::duration_from_string( "19:00:00" );
		testEvent.start = td.total_seconds();
		testEvent.publishedDuration = 60;

		// used to discover the mediaRecordIdentifier of the MediaRecord added for each 'added' ScheduledRecordingListChange signal
		MapLibContentChange libraryContentChangeAdded;

		boost::shared_ptr< StrictMock<MockLocalMediaLibraryEventListener> > mockListener(new StrictMock<MockLocalMediaLibraryEventListener>() );
		minimalLocalMediaLibrary->addListener(mockListener);

		// 1. ScheduledRecordingListChange::added
		// -------------------------------------------------------------------

		// create MediaRecord for new ScheduledRecording
		EXPECT_CALL( *mockServiceRepository, getService( StrEq(testService.serviceLocator) ) ).WillOnce( returnNewCompletedFuture( testService ) );
		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillOnce( returnNewCompletedFuture( testEvent ) );
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );
		std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > mapChanges;
		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added;

		// issue ScheduledRecordingListChange signal to create MediaRecord
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		std::vector<MediaRecordEx> mediaRecords = store->getMediaRecordsByEventLocator( testEvent.eventLocator );
		CPPUNIT_ASSERT_EQUAL( uint32_t(1), mediaRecords.size() );
		CPPUNIT_ASSERT_EQUAL( testEvent.publishedDuration, mediaRecords[0].publishedDuration );
		CPPUNIT_ASSERT_EQUAL( testEvent.start, mediaRecords[0].publishedStart );
		CPPUNIT_ASSERT_EQUAL( false, mediaRecords[0].watershed );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		// 2. ScheduledRecordingListChange::updated
		// -------------------------------------------------------------------

		// move the media record into the watershed
		td = boost::posix_time::duration_from_string( "21:00:00" );
		testEvent.start = td.total_seconds();
		testEvent.publishedDuration = 500;		// change the published duration

		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillOnce( returnNewCompletedFuture( testEvent ) );
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::updated) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );

		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::updated;
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		mediaRecords = store->getMediaRecordsByEventLocator( testEvent.eventLocator );
		CPPUNIT_ASSERT_EQUAL( uint32_t(1), mediaRecords.size() );
		CPPUNIT_ASSERT_EQUAL( testEvent.publishedDuration, mediaRecords[0].publishedDuration );
		CPPUNIT_ASSERT_EQUAL( testEvent.start, mediaRecords[0].publishedStart );
		CPPUNIT_ASSERT_EQUAL( true, mediaRecords[0].watershed );

		// 3. ScheduledRecordingListChange::deleted
		// -------------------------------------------------------------------

		// issue ScheduledRecordingListChange signal to destroy the MediaRecord
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::deleted) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );

		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::deleted;
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));

		mediaRecords = store->getMediaRecordsByEventLocator( testEvent.eventLocator );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecords.size() );

	}

	void testMediaRecordWatershed()
	{

		// used to discover the mediaRecordIdentifier of the MediaRecord added for each 'added' ScheduledRecordingListChange signal
		MapLibContentChange libraryContentChangeAdded;

		struct WatershedTest
		{
			const char* startTime;
			const char* endTime;
			bool watershed;
			bool subsequentDays;
			NS_CADMIUM_SYSTEM::RecordingEventStatus::Enum status;

		};

		const int num_tests = 26;
		const WatershedTest watershedTests[num_tests] =
		{
				// > start/stop on the same day

				// startTime	endTime			watershed	subsequentDays	status
				{ "00:00:00",	"05:29:59",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// fully inside of 0:00am-5:30 am
				{ "02:00:00",	"05:30:01",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// start inside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "02:00:00",	"21:00:01",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// start inside of 0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "05:30:01",	"20:59:59",		false,		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired},					// start outside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "20:59:59",	"21:00:01",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// start outside of  0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "21:00:01",	"23:59:59",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// fully inside of 9:00pm-0:00pm

				{ "00:00:00",	"05:29:59",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// fully inside of 0:00am-5:30 am
				{ "02:00:00",	"05:30:01",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// start inside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "02:00:00",	"21:00:01",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// start inside of 0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "05:30:01",	"20:59:59",		false, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired},		// start outside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "21:00:01",	"21:00:01",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// start outside of  0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "21:00:01",	"23:59:59",		true, 		false,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// fully inside of 9:00pm-0:00pm

				// > start/stop on subsequent days

				// startTime	endTime			watershed	subsequentDays	status
				{ "00:00:00",	"05:29:59",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// fully inside of 0:00am-5:30 am
				{ "02:00:00",	"05:30:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// start inside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "02:00:00",	"21:00:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// start inside of 0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "05:30:01",	"20:59:59",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired},					// start outside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "20:59:59",	"21:00:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// start outside of  0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "21:00:01",	"23:59:59",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// fully inside of 9:00pm-0:00pm

				{ "00:00:00",	"05:29:59",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// fully inside of 0:00am-5:30 am
				{ "02:00:00",	"05:30:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// start inside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "02:00:00",	"21:00:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// start inside of 0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "05:30:01",	"20:59:59",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired},		// start outside of 0:00am-5:30 am, finish outside of 9:00pm-0:00pm
				{ "21:00:01",	"21:00:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// start outside of  0:00am-5:30 am, finish inside of 9:00pm-0:00pm
				{ "21:00:01",	"23:59:59",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// fully inside of 9:00pm-0:00pm

				{ "20:59:59",	"05:30:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired },				// encompassing the watershed time window
				{ "20:59:59",	"05:30:01",		true, 		true,			NS_CADMIUM_SYSTEM::RecordingEventStatus::partially_acquired },		// encompassing the watershed time window
		};

		const uint32_t testDaySeconds = 23 * SECONDS_PER_DAY;	// set the tests on the 23rd January 1970

		for ( int i=0; i<num_tests; i++)
		{
			const WatershedTest& watershedTest = watershedTests[i];

			// helpful message to determine which test has failed
			char msg[64];
			sprintf( msg, "watershedTest[%d]", i);

			boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

			boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
			minimalLocalMediaLibrary->addListener(mockListener);

			boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

			// convert time to required format

			boost::posix_time::time_duration td = boost::posix_time::duration_from_string( watershedTest.startTime );
			uint32_t startTime = td.total_seconds();
			startTime += testDaySeconds;

			td = boost::posix_time::duration_from_string( watershedTest.endTime );
			uint32_t endTime = td.total_seconds();
			endTime += testDaySeconds;
			if (watershedTest.subsequentDays)
			{
				endTime += SECONDS_PER_DAY;
			}

			// test data
			NS_IRON_SYSTEM::Service testService;
			testService.serviceLocator = "dvb://1111..2222";
			EXPECT_CALL( *mockServiceRepository, getService( StrEq(testService.serviceLocator) ) ).WillRepeatedly( returnNewCompletedFuture( testService ) );

			NS_IRON_SYSTEM::Event testEvent;
			testEvent.eventLocator = "dvb://1111..2222.2222";
			testEvent.serviceLocator = testService.serviceLocator;
			testEvent.start = startTime;
			testEvent.publishedDuration = endTime - startTime;

			EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillRepeatedly( returnNewCompletedFuture( testEvent ) );

			// create media record

			EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
			EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );

			std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > mapChanges;
			mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added;
			getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

			CPPUNIT_ASSERT_MESSAGE( msg, Mock::VerifyAndClearExpectations(mockListener.get()));
			CPPUNIT_ASSERT_MESSAGE( msg, Mock::VerifyAndClearExpectations(mockClock.get()));
			CPPUNIT_ASSERT_MESSAGE( msg, Mock::VerifyAndClearExpectations(mockEventRepository.get()));
			CPPUNIT_ASSERT_MESSAGE( msg, Mock::VerifyAndClearExpectations(mockServiceRepository.get()));

			std::string strMediaRecordIdentifier = libraryContentChangeAdded.begin()->first;
			int64_t mediaRecordIdentifier = boost::lexical_cast<int64_t>( strMediaRecordIdentifier );
			MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );

			CPPUNIT_ASSERT_EQUAL_MESSAGE( msg, NS_NICKEL_SYSTEM::AcquisitionStatus::not_begun_yet, mediaRecord.acquisitionStatus );
			CPPUNIT_ASSERT_EQUAL_MESSAGE( msg, watershedTest.watershed, mediaRecord.watershed );

		}

	}

	void testMultipleScheduledRecordingsForAnEvent__not_begun_yet()
	{
		// 1. create ScheduledRecording a
		//  -> which creates MediaRecord X
		// 2. create ScheduledRecording b
		//  -> ignored
		// 3. delete ScheduledRecording a
		//  -> ignored
		// 4. delete ScheduledRecording b
		//  -> which deletes MediaRecord X

		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();
		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		NS_IRON_SYSTEM::Service testService;
		testService.serviceLocator = "dvb://1111..2222";

		NS_IRON_SYSTEM::Event testEvent;
		testEvent.eventLocator = "dvb://1111..2222.3333";
		testEvent.serviceLocator = testService.serviceLocator;

		// used to discover the mediaRecordIdentifier of the MediaRecord added for each 'added' ScheduledRecordingListChange signal
		MapLibContentChange libraryContentChangeAdded;

		boost::shared_ptr< StrictMock<MockLocalMediaLibraryEventListener> > mockListener(new StrictMock<MockLocalMediaLibraryEventListener>() );
		minimalLocalMediaLibrary->addListener(mockListener);

		std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > mapChanges;

		// Issue ScheduledRecordingListChange 'added' signal to create MediaRecord
		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added;

		EXPECT_CALL( *mockServiceRepository, getService( StrEq(testService.serviceLocator) ) ).WillOnce( returnNewCompletedFuture( testService ) );
		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillOnce( returnNewCompletedFuture( testEvent ) );
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL( uint32_t(1), store->getMediaRecordsByEventLocator( testEvent.eventLocator ).size() );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));

		// Issue a 2nd ScheduledRecordingListChange 'added' signal, and make sure that we don't create a 2nd MediaRecord
		EXPECT_CALL( *mockServiceRepository, getService( _ ) ).Times(0);
		EXPECT_CALL( *mockEventRepository, getEvent( _ ) ).Times(0);
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::updated) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL( uint32_t(1), store->getMediaRecordsByEventLocator( testEvent.eventLocator ).size() );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));

		// Issue first ScheduledRecordingListChange 'deleted' signal, make sure we don't delete the MediaRecord
		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::deleted;

		EXPECT_CALL( *mockServiceRepository, getService( _ ) ).Times(0);
		EXPECT_CALL( *mockEventRepository, getEvent( _ ) ).Times(0);
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::updated) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL( uint32_t(1), store->getMediaRecordsByEventLocator( testEvent.eventLocator ).size() );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));

		// Issue second ScheduledRecordingListChange 'deleted' signal, make sure we delete the MediaRecord
		EXPECT_CALL( *mockServiceRepository, getService( _ ) ).Times(0);
		EXPECT_CALL( *mockEventRepository, getEvent( _ ) ).Times(0);
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::deleted) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), store->getMediaRecordsByEventLocator( testEvent.eventLocator ).size() );
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
	}

	void testMultipleScheduledRecordingsForAnEvent__redundant_RecordingEvent()
	{
		// 1. send two 'begun' signals
		//  - make sure we only respond to the first signal

		// 2. send two 'acquired' signals
		//  - make sure we only respond to the first signal

		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		// test data
		NS_IRON_SYSTEM::Service testService;
		testService.serviceLocator = "dvb://1111..2222";

		NS_IRON_SYSTEM::Event testEvent;
		testEvent.eventLocator = "dvb://1111..2222.1111";
		testEvent.serviceLocator = testService.serviceLocator;

		// used to discover the mediaRecordIdentifier of the MediaRecord added for each 'added' ScheduledRecordingListChange signal
		MapLibContentChange libraryContentChangeAdded;

		// create MediaRecord for new ScheduledRecording
		EXPECT_CALL( *mockServiceRepository, getService( StrEq(testService.serviceLocator) ) ).WillOnce( returnNewCompletedFuture( testService) );
		EXPECT_CALL( *mockEventRepository, getEvent( StrEq(testEvent.eventLocator) ) ).WillOnce( returnNewCompletedFuture( testEvent ) );
		EXPECT_CALL( *mockClock, getCurrentTime() ).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( LibraryContentChangeTypeEq(LibraryContentChangeType::added) ) ) ).Times(1).WillOnce( SaveArg<0>(&libraryContentChangeAdded) );
		std::map< std::string, NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::Enum > mapChanges;
		mapChanges[testEvent.eventLocator] = NS_CADMIUM_SYSTEM::ScheduledRecordingListChangeType::added;

		// issue the ScheduledRecordingListChange signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->ScheduledRecordingListChange( mapChanges );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));

		std::string strMediaRecordIdentifier = libraryContentChangeAdded.begin()->first;
		int64_t mediaRecordIdentifier = boost::lexical_cast<int64_t>( strMediaRecordIdentifier );

		MediaRecordEx mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::not_begun_yet, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );

		// issue a 'begun' RecordingEvent signal
		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).WillOnce(Return(5));

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::begun);

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::begun, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(5), mediaRecord.acquisitionDateTime );
		CPPUNIT_ASSERT_EQUAL( int64_t(0), mediaRecord.size );
		CPPUNIT_ASSERT_EQUAL( uint32_t(0), mediaRecord.duration );

		// repeat the 'begun' RecordingEvent signal
		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		EXPECT_CALL( *mockClock, getCurrentTime()).Times(0);

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::begun);

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));

		// issue an 'acquired' RecordingEvent signal
		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( ElementsAre( MapLibContentChangePair(strMediaRecordIdentifier, LibraryContentChangeType::updated) ) ) ).Times(1);
		EXPECT_CALL( *mockClock, getCurrentTime()).WillRepeatedly( Return(20));

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
		mediaRecord = store->getMediaRecord( mediaRecordIdentifier );
		CPPUNIT_ASSERT_EQUAL( NS_NICKEL_SYSTEM::AcquisitionStatus::acquired, mediaRecord.acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( uint32_t(5), mediaRecord.acquisitionDateTime );						// time (seconds since apex)
		CPPUNIT_ASSERT_EQUAL( int64_t(15 * lsrValueBroadcastSDBitrate / 8), mediaRecord.size );		// bytes
		CPPUNIT_ASSERT_EQUAL( uint32_t(15), mediaRecord.duration );									// the acquired duration in seconds

		// repeat the 'acquired' RecordingEvent signal
		EXPECT_CALL( *mockEventRepository, getEvent(_)).Times(0);
		EXPECT_CALL( *mockServiceRepository, getService(_)).Times(0);
		EXPECT_CALL( *mockListener, LibraryContentChange( _ ) ).Times(0);
		EXPECT_CALL( *mockClock, getCurrentTime()).Times(0);

		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( testEvent.eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired );

		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockClock.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockListener.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockEventRepository.get()));
		CPPUNIT_ASSERT(Mock::VerifyAndClearExpectations(mockServiceRepository.get()));
	}

	void testReacquiringFailedAcquisition()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		std::string eventLocator = "dvb://1111..1111;1111";

		MediaRecordEx mediaRecordFailed;
		mediaRecordFailed.identifiers[IDENTIFIERS_KEY_EVENTLOCATOR] = eventLocator;
		mediaRecordFailed.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID] = "my-programme-crid";
		mediaRecordFailed.acquisitionStatus = AcquisitionStatus::failed;

		MediaRecordEx mediaRecordNew;
		mediaRecordNew.identifiers[IDENTIFIERS_KEY_EVENTLOCATOR] = eventLocator;
		mediaRecordNew.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID] = "my-programme-crid";
		mediaRecordNew.acquisitionStatus = AcquisitionStatus::begun;

		store->addMediaRecord( mediaRecordNew );
		store->addMediaRecord( mediaRecordFailed );

		// make sure media records have been given unique identifiers
		CPPUNIT_ASSERT( mediaRecordFailed.mediaRecordIdentifierPrimaryKey != mediaRecordNew.mediaRecordIdentifierPrimaryKey );

		CPPUNIT_ASSERT_EQUAL( uint32_t(2), store->getMediaRecordsByEventLocator( eventLocator ).size() );

		// fake a RecordingEvent signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired );

		std::vector<MediaRecordEx> mediaRecords = store->getMediaRecordsByEventLocator( eventLocator );

		CPPUNIT_ASSERT_EQUAL( uint32_t(1), mediaRecords.size() );
		CPPUNIT_ASSERT_EQUAL( mediaRecordNew.mediaRecordIdentifierPrimaryKey, mediaRecords[0].mediaRecordIdentifierPrimaryKey );
		CPPUNIT_ASSERT_EQUAL( AcquisitionStatus::acquired, mediaRecords[0].acquisitionStatus );
	}

	void testReacquiringPartialAcquisition()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		std::string eventLocator = "dvb://1111..1111;1111";

		MediaRecordEx mediaRecordPartialAcquisition;
		mediaRecordPartialAcquisition.identifiers[IDENTIFIERS_KEY_EVENTLOCATOR] = eventLocator;
		mediaRecordPartialAcquisition.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID] = "my-programme-crid";
		mediaRecordPartialAcquisition.acquisitionStatus = AcquisitionStatus::partially_acquired;

		MediaRecordEx mediaRecordNew;
		mediaRecordNew.identifiers[IDENTIFIERS_KEY_EVENTLOCATOR] = eventLocator;
		mediaRecordNew.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID] = "my-programme-crid";
		mediaRecordNew.acquisitionStatus = AcquisitionStatus::begun;

		store->addMediaRecord( mediaRecordPartialAcquisition );
		store->addMediaRecord( mediaRecordNew );

		// make sure media records have been given unique identifiers
		CPPUNIT_ASSERT( mediaRecordPartialAcquisition.mediaRecordIdentifierPrimaryKey != mediaRecordNew.mediaRecordIdentifierPrimaryKey );

		CPPUNIT_ASSERT_EQUAL( uint32_t(2), store->getMediaRecordsByEventLocator( eventLocator ).size() );

		// fake a RecordingEvent signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired );

		std::vector<MediaRecordEx> mediaRecords = store->getMediaRecordsByEventLocator( eventLocator );

		CPPUNIT_ASSERT_EQUAL( uint32_t(2), mediaRecords.size() );
		std::sort( mediaRecords.begin(), mediaRecords.end() );
		CPPUNIT_ASSERT_EQUAL( mediaRecordPartialAcquisition.mediaRecordIdentifierPrimaryKey, mediaRecords[0].mediaRecordIdentifierPrimaryKey );
		CPPUNIT_ASSERT_EQUAL( AcquisitionStatus::partially_acquired, mediaRecords[0].acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( mediaRecordNew.mediaRecordIdentifierPrimaryKey, mediaRecords[1].mediaRecordIdentifierPrimaryKey );
		CPPUNIT_ASSERT_EQUAL( AcquisitionStatus::acquired, mediaRecords[1].acquisitionStatus );
	}

	void testReacquiringSuccessfulAcquisition()
	{
		boost::shared_ptr<MinimalLocalMediaLibrary> minimalLocalMediaLibrary = createMinimalLocalMediaLibrary();

		boost::shared_ptr<MockLocalMediaLibraryEventListener> mockListener(new MockLocalMediaLibraryEventListener());
		minimalLocalMediaLibrary->addListener(mockListener);

		boost::shared_ptr<MediaRecordStore> store = getMediaRecordStore();

		std::string eventLocator = "dvb://1111..1111;1111";

		MediaRecordEx mediaRecordAcquired;
		mediaRecordAcquired.identifiers[IDENTIFIERS_KEY_EVENTLOCATOR] = eventLocator;
		mediaRecordAcquired.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID] = "my-programme-crid";
		mediaRecordAcquired.acquisitionStatus = AcquisitionStatus::acquired;

		MediaRecordEx mediaRecordNew;
		mediaRecordNew.identifiers[IDENTIFIERS_KEY_EVENTLOCATOR] = eventLocator;
		mediaRecordNew.identifiers[IDENTIFIERS_KEY_PROGRAMME_CRID] = "my-programme-crid";
		mediaRecordNew.acquisitionStatus = AcquisitionStatus::begun;

		store->addMediaRecord( mediaRecordAcquired );
		store->addMediaRecord( mediaRecordNew );

		// make sure media records have been given unique identifiers
		CPPUNIT_ASSERT( mediaRecordAcquired.mediaRecordIdentifierPrimaryKey != mediaRecordNew.mediaRecordIdentifierPrimaryKey );

		CPPUNIT_ASSERT_EQUAL( uint32_t(2), store->getMediaRecordsByEventLocator( eventLocator ).size() );

		// fake a RecordingEvent signal
		getMinimalLocalMediaLibrarySync(minimalLocalMediaLibrary)->RecordingEvent( eventLocator, NS_CADMIUM_SYSTEM::RecordingEventStatus::acquired );

		std::vector<MediaRecordEx> mediaRecords = store->getMediaRecordsByEventLocator( eventLocator );

		CPPUNIT_ASSERT_EQUAL( uint32_t(2), mediaRecords.size() );
		std::sort( mediaRecords.begin(), mediaRecords.end() );
		CPPUNIT_ASSERT_EQUAL( mediaRecordAcquired.mediaRecordIdentifierPrimaryKey, mediaRecords[0].mediaRecordIdentifierPrimaryKey );
		CPPUNIT_ASSERT_EQUAL( AcquisitionStatus::acquired, mediaRecords[0].acquisitionStatus );
		CPPUNIT_ASSERT_EQUAL( mediaRecordNew.mediaRecordIdentifierPrimaryKey, mediaRecords[1].mediaRecordIdentifierPrimaryKey );
		CPPUNIT_ASSERT_EQUAL( AcquisitionStatus::acquired, mediaRecords[1].acquisitionStatus );
	}

public:
	CPPUNIT_TEST_SUITE(MinimalLocalMediaLibraryTest);

	// test supporting functions
	CPPUNIT_TEST(testMappingLinearMetadataToMediaRecord);

	// test LinearMediaLibrary API
	CPPUNIT_TEST(testGetMediaRecords);
	CPPUNIT_TEST(testGetMediaRecord);
	CPPUNIT_TEST(testGetMediaRecordsByContentIdentifier);
	CPPUNIT_TEST(testDeleteMediaRecord);
	CPPUNIT_TEST(testGetStorageSpace);
	CPPUNIT_TEST(testSetMediaRecordProtected);
	CPPUNIT_TEST(testGetMediaRecordTimingSignature);

	// test special fields in MediaRecord structures
	CPPUNIT_TEST(testMediaRecordWatershed);

	// test handling signals from Cadmium
	CPPUNIT_TEST(testMediaRecordAcquire);
	CPPUNIT_TEST(testMediaRecordAcquireFailure);
	CPPUNIT_TEST(testMediaRecordPartialAcquire);
	CPPUNIT_TEST(testScheduledRecordingListChange);

	// special cases tests
	CPPUNIT_TEST(testMultipleScheduledRecordingsForAnEvent__not_begun_yet);
	CPPUNIT_TEST(testMultipleScheduledRecordingsForAnEvent__redundant_RecordingEvent);

	CPPUNIT_TEST(testReacquiringFailedAcquisition);
	CPPUNIT_TEST(testReacquiringPartialAcquisition);
	CPPUNIT_TEST(testReacquiringSuccessfulAcquisition);


	CPPUNIT_TEST_SUITE_END();
};

CPPUNIT_TEST_SUITE_REGISTRATION(MinimalLocalMediaLibraryTest);

NS_NICKEL_SYSTEM_CLOSE
