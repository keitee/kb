/*
 * ProxySystemFactoryTest.cpp
 *
 *  Created on: Aug 9, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2012, Youview TV Ltd.
 */


#include "../include/testsupport/Stub.h"

#include <nickel-system-api/SystemFactory.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/FixedPluginConfig.h>
#include <zinc-common/PluginFactory.h>

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;

class ZINC_LOCAL ProxySystemFactoryTest : UnitTestSandbox, public CppUnit::TestFixture {

public:

	void setUp() {}

	void tearDown() {}

	void test_canLoadFactory() {

		loadFactory();
	}

	void test_defaultNickelImplementationLoadedForOtherServices() {

		SystemFactory& factory = loadFactory();

		boost::shared_ptr<ServiceListBuilder> serviceListBuilder (factory.createServiceListBuilder());

		CPPUNIT_ASSERT_EQUAL(std::string("default"), dynamic_cast<Stub*>(serviceListBuilder.get())->getStubName());
	}

private:

	SystemFactory& loadFactory() {

		FixedPluginConfig config("libNickelSystemProxy.so", "createSystemFactory");
		SystemFactory& factory = PluginFactory::getInstance<SystemFactory>(config);

		return factory;
	}

	CPPUNIT_TEST_SUITE(ProxySystemFactoryTest);

	CPPUNIT_TEST(test_canLoadFactory);
	CPPUNIT_TEST(test_defaultNickelImplementationLoadedForOtherServices);

	CPPUNIT_TEST_SUITE_END();

};

CPPUNIT_TEST_SUITE_REGISTRATION(ProxySystemFactoryTest);

NS_NICKEL_SYSTEM_CLOSE

