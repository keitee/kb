/*
 * ProxySystemFactoryWhiteboxTest.cpp
 *
 *  Created on: Aug 10, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2012, Youview TV Ltd.
 */


#include "../include/testsupport/Stub.h"

#include "../src/ProxySystemFactory.h"
#include "../src/ProxyMediaRouterFactory.h"

#include <nickel-system-api/SystemFactory.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/FixedPluginConfig.h>
#include <zinc-common/PluginFactory.h>

#include <boost/assign.hpp>
#include <string>
#include <set>
#include <map>

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;
using namespace std;
using namespace boost::assign;

class ZINC_LOCAL ProxySystemFactoryWhiteboxTest : UnitTestSandbox, public CppUnit::TestFixture {

public:

	void setUp() {}

	void tearDown() {}

	void test_canLoadFactory() {

		loadFactory();
	}

	void test_findMediaRouterPluginConfigFiles() {

		string configDir(PackageDataFinder().find("findMediaRouterPluginConfigFiles-test-files"));

		set<boost::filesystem::path> expectedFiles;

		expectedFiles.insert(configDir + "/http-application%2Fdash%2Bxml.plugin-config");
		expectedFiles.insert(configDir + "/http-default.plugin-config");
		expectedFiles.insert(configDir + "/http-video%2Fx-matroska.plugin-config");
		expectedFiles.insert(configDir + "/https-application%2Fvnd.apple.mpegurl.plugin-config");
		expectedFiles.insert(configDir + "/https-default.plugin-config");

		vector<boost::filesystem::path> files(findMediaRouterPluginConfigFiles(configDir));

		set<boost::filesystem::path> actualFiles;

		actualFiles.insert(files.begin(), files.end());

		CPPUNIT_ASSERT_EQUAL_MESSAGE("Wrong number of media router plugin config files found.",
                expectedFiles.size(), files.size());

        BOOST_FOREACH(const boost::filesystem::path& file, expectedFiles) {
            CPPUNIT_ASSERT_MESSAGE(string("Failed to find expected plugin-config file: ")+file.string(),
                    (actualFiles.find(file) != actualFiles.end()));
        }
	}

	void test_correctProtocolToMediaRouterFactoryMappingsAreCreated() {

		SystemFactory& factory(loadFactory());

		boost::shared_ptr<MediaRouterFactory> mrf(factory.createMediaRouterFactory());

		boost::shared_ptr<ProxyMediaRouterFactory> proxyMediaRouterFactory(boost::dynamic_pointer_cast<ProxyMediaRouterFactory>(mrf));

        const ProtocolMediaRouterFactoryMap& actual(proxyMediaRouterFactory->getProtocolMediaRouterFactoryMap());

        vector<string> httpPlugins;
        httpPlugins += "http-application/dash+xml", "http-application/vnd.apple.mpegurl", "http-default";

        vector<string> httpsPlugins;
        httpsPlugins += "https-application/vnd.apple.mpegurl", "https-video/mpeg4-generic", "https-video/x-matroska";
        map<string, vector<string> > expected;
        expected["http"] = httpPlugins;
        expected["https"] = httpsPlugins;
        expected["linear"] = vector<string>(1, "linear-default");

        CPPUNIT_ASSERT_EQUAL_MESSAGE(
                "Wrong number of MediaRouterFactories in protocol->factory map.",
                expected.size(), actual.size());

        BOOST_FOREACH(const MIMEMediaRouterFactoryMap& protoMap, actual) {

            const string& proto(protoMap.first);

            for(size_t i = 0; i < protoMap.second.size(); ++i)
            {
                const string& expectedImpl(expected[proto][i]);

                boost::shared_ptr<MediaRouterFactory> mrf(protoMap.second[i].second);
                boost::shared_ptr<Stub> stub(boost::dynamic_pointer_cast<Stub>(mrf));

                const string& actualImpl(stub->getStubName());

                CPPUNIT_ASSERT_EQUAL_MESSAGE(string("Wrong implementation for: ") + proto + expectedImpl,
                        expectedImpl, actualImpl);
            }
        }
	}

private:

	SystemFactory& loadFactory() {
		systemFactory.reset(createSystemFactory());
		return *systemFactory;
	}

    std::auto_ptr<SystemFactory> systemFactory;

	CPPUNIT_TEST_SUITE(ProxySystemFactoryWhiteboxTest);

    CPPUNIT_TEST(test_canLoadFactory);
	CPPUNIT_TEST(test_findMediaRouterPluginConfigFiles);
    CPPUNIT_TEST(test_correctProtocolToMediaRouterFactoryMappingsAreCreated);

	CPPUNIT_TEST_SUITE_END();

};

CPPUNIT_TEST_SUITE_REGISTRATION(ProxySystemFactoryWhiteboxTest);

NS_NICKEL_SYSTEM_CLOSE
