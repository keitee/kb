/**
 * ProxyMediaRouterTest.cpp
 *
 * Created on: Dec 15, 2014
 *     Author: Tom Bailey
 *
 *
 * Copyright 2014, YouView TV Ltd.
 */

#include "../src/ProxyMediaRouter.h"

#include "../src/ProxySystemFactory.h"
#include "../include/testsupport/StubSystemFactory.h"
#include "../include/testsupport/SimpleMediaRouterFactory.h"
#include <zinc-common/async/SingleThreadDispatcher.h>
#include <zinc-common/testsupport/CppUnit.h>
#include <zinc-common/testsupport/UnitTestSandbox.h>
#include <zinc-common/testsupport/VerifyAndClearMock.h>
#include <zinc-common/async/async-helpers.h>
#include <zinc-http/mime/MIMETypes.h>
#include <nickel-system-api/SystemFactory.h>
#include <nickel-system-api/NotConfiguredException.h>
#include <nickel-system-api/IllegalReconfigurationException.h>
#include <nickel-system-api/OutOfBoundsException.h>
#include <nickel-system-api/InvalidLocatorException.h>
#include <nickel-system-api/SetSourceReason.h>
#include <boost/shared_ptr.hpp>
#include <boost/assign.hpp>
#include <memory>

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;
using namespace boost::assign;

using testing::_;
using testing::Expectation;
using testing::Assign;
using testing::Return;
using testing::Invoke;
using testing::InSequence;
using testing::StrictMock;

class ProxyMediaRouterTest;

class MockMediaRouterState
{
public:
    MockMediaRouterState(ProxyMediaRouterTest& test_)
        : test(test_)
    {}

    NS_ZINC::Future<void> setSource(const std::string& source_, SetSourceReason::Enum);

    NS_ZINC::Future<void> setSink(const std::string& sink_);

    NS_ZINC::Future<void> recycle();

    NS_ZINC::Future<void> start();
private:
    ProxyMediaRouterTest& test;

    std::string source;
    std::string sink;
};

struct ErrorEventData
{
    ErrorEventData(const ErrorEventValue::Enum error_,
        const ErrorEventContext::Enum context_,
        const std::string& info_)
        : error(error_),
        context(context_),
        info(info_)
    {}
    ErrorEventValue::Enum error;
    ErrorEventContext::Enum context;
    std::string info;

    bool operator==(const ErrorEventData& other)
    {
        return (other.error == error
                && other.context == context
                && other.info == info);
    }
};

class SimpleMediaRouterEventListener : public MediaRouterEventListener
{
public:
    virtual void BufferStatusEvent(const BufferStatusEventValue::Enum)
    {}

    void DrmEvent(const DrmEventValue::Enum,
            const std::string&,
            const std::string&)
    {}

    void PositionChangeEvent(const Position&)
    {}

    void SourceEvent(const SourceEventValue::Enum,
            const SetSourceReason::Enum)
    {}

    void SpeedChangeEvent()
    {}

    void StatusEvent(const StatusEventValue::Enum)
    {}

	void ErrorEvent(const ErrorEventValue::Enum error,
            const ErrorEventContext::Enum context,
            const std::string& info)
    {
        errorEvents.push_back(ErrorEventData(error, context, info));
    }

    bool errorEventReceived() const
    {
        return !errorEvents.empty();
    }

    std::vector<ErrorEventData>& getErrorEvents()
    {
        return errorEvents;
    }

private:
    std::vector<ErrorEventData> errorEvents;
};

std::string getSourceProtocol(const std::string& source)
{
    size_t endAt = source.find_first_of("://");

    if (endAt == std::string::npos) {
        throw InvalidLocatorException("Invalid form for source URL. Missing protocol.");
    }

    return source.substr(0, endAt);
}

class ZINC_LOCAL ProxyMediaRouterTest : private UnitTestSandbox,
    public CppUnit::TestFixture
{
public:
    ProxyMediaRouterTest()
        : sink("decoder://0"),
        dvbSource("dvb://233a..1044"),
        linearSource("linear:http://54.225.86.153/INT01_LCN_400.sdp")
    {}

    void setUp()
    {
        theDispatcher.reset(new SingleThreadDispatcher);
        mediaRouterFactory.reset(new SimpleMediaRouterFactory("default", theDispatcher));
        systemFactory.reset(new StubSystemFactory("default", theDispatcher,
                mediaRouterFactory));

        std::stringstream mimeFile(
                "http-application/dash+xml mpd\n"
                "http-application/vnd.apple.mpegurl m3u8\n"
                );
        mimeTypes.reset(new mime::MIMETypes(mimeFile));
    }

    void tearDown()
    {
        theDispatcher.reset();
    }

    /**
     * This test reproduces a specific scenario encountered when testing the
     * proxy. It replicates the sequence of calls involved in switching from
     * DVB to an IP channel and back.
     */
    void test_setSourceAndRecycle()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr = makeProxy();
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        MockMediaRouterState state(*this);

        // Check sensible values are returned by getSourceInformation, getSink
        // and getSource when the proxy is uninitialised
        typedef std::map<std::string, std::string> SourceInfo;
        NS_ZINC::Future<SourceInfo> srcInfoFuture = pmr->getSourceInformation();

        CPPUNIT_ASSERT(srcInfoFuture.get() == SourceInfo());
        CPPUNIT_ASSERT(pmr->getSink().get().empty());
        CPPUNIT_ASSERT(pmr->getSource().get().empty());

        // Set source and sink
        EXPECT_CALL(*mockMediaRouter, setSink(sink)).WillOnce(Return(makeCompletedFuture()));
        EXPECT_CALL(*mockMediaRouter, setSource(dvbSource, SetSourceReason::mhegstandard))
            .WillOnce(Return(makeCompletedFuture()));
        pmr->setSink(sink).get();
        pmr->setSource(dvbSource, SetSourceReason::mhegstandard).get();

        // Verify we get the previously set values for source and sink
        EXPECT_CALL(*mockMediaRouter, getSource())
            .WillOnce(Return(makeCompletedFuture(dvbSource)));
        EXPECT_CALL(*mockMediaRouter, getSink())
            .WillOnce(Return(makeCompletedFuture(sink)));
        CPPUNIT_ASSERT(pmr->getSink().get() == sink);
        CPPUNIT_ASSERT(pmr->getSource().get() == dvbSource);

        // Recycle the proxy
        EXPECT_CALL(*mockMediaRouter, recycle()).WillOnce(Return(makeCompletedFuture()));
        pmr->recycle().get();

        // Set sink _before_ source, as the tuner control does
        EXPECT_CALL(*mockMediaRouter, setSink(sink))
            .WillOnce(Invoke(&state, &MockMediaRouterState::setSink));
        EXPECT_CALL(*mockMediaRouter, setSource(linearSource, SetSourceReason::mhegstandard))
            .WillOnce(Invoke(&state, &MockMediaRouterState::setSource));
        pmr->setSink(sink).get();

        // Verify that setSink returns the sink we just set even though setting
        // on the real media router is deferred
        CPPUNIT_ASSERT(pmr->getSink().get() == sink);
        pmr->setSource(linearSource, SetSourceReason::mhegstandard).get();

        EXPECT_CALL(*mockMediaRouter, start())
            .WillOnce(Invoke(&state, &MockMediaRouterState::start));
        pmr->start().get();
    }

    void test_DVBChannelChangeWorks()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr = makeProxy();
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Set source and sink
        EXPECT_CALL(*mockMediaRouter, setSink(sink)).WillOnce(Return(makeCompletedFuture()));
        EXPECT_CALL(*mockMediaRouter, setSource(dvbSource, SetSourceReason::mhegstandard))
            .WillOnce(Return(makeCompletedFuture()));
        EXPECT_CALL(*mockMediaRouter, start()).WillOnce(Return(makeCompletedFuture()));
        pmr->setSink(sink).get();
        pmr->setSource(dvbSource, SetSourceReason::mhegstandard).get();
        pmr->start();

        // Change the channel

        // TunerControl will first check the sink
        EXPECT_CALL(*mockMediaRouter, getSink())
            .WillOnce(Return(makeCompletedFuture(sink)));
        CPPUNIT_ASSERT(pmr->getSink().get() == sink);

        // The channel is changed by calling setSource. This is the only use case
        // where it is valid to call setSource on a sourced media router without
        // first calling recycle()
        std::string newChannel("dvb://233a..2045");
        EXPECT_CALL(*mockMediaRouter, setSource(newChannel, SetSourceReason::mhegstandard))
            .WillOnce(Return(makeCompletedFuture()));
        pmr->setSource(newChannel, SetSourceReason::mhegstandard).get();
    }

    void test_invalidSourceGeneratesException()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr = makeProxy();
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        try
        {
            Future<void> future = pmr->setSource("invalidsource", SetSourceReason::mhegstandard);
            CPPUNIT_FAIL("Expected InvalidLocatorException");
        }
        catch(const InvalidLocatorException&)
        {
            ;
        }
    }

    /**
     * Test that an exception thrown by a call that is deferred until setSource
     * is called gets reported to the caller.
     */
    void test_deferredSetVideoWindowExceptionMakesSetSourceFail()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        VideoWindowDescriptor
            videoWindow(0.0, 0.0, 0.5, 0.5, 0.0, 0.0, 1.0, 1.0);

        boost::shared_ptr<SimpleMediaRouterEventListener> eventListener
            = boost::make_shared<SimpleMediaRouterEventListener>();
        pmr->addListener(eventListener);

        std::string errorMessage("Video window out of bounds");
        // Set sink, video window followed by source. setVideoWindow will be
        // deferred until media router creation and will throw
        EXPECT_CALL(*mockMediaRouter, setSink(sink)).WillOnce(Return(makeCompletedFuture()));
        EXPECT_CALL(*mockMediaRouter, setVideoWindow(videoWindow)).WillOnce(Return(
                    makeErrorFuture<void, OutOfBoundsException>(
                        errorMessage)));
        pmr->setSink(sink).get();
        pmr->setVideoWindow(videoWindow).get();
        NS_ZINC::Future<void> future = 
            pmr->setSource(dvbSource, SetSourceReason::mhegstandard);

        try
        {
            future.get();
            CPPUNIT_ASSERT_MESSAGE("Expected IllegalReconfigurationException from"
                    " media router", false);
        }
        catch(const IllegalReconfigurationException& ex)
        {
            CPPUNIT_ASSERT(pmr->getSource().get().empty());
            CPPUNIT_ASSERT(eventListener->errorEventReceived());
            CPPUNIT_ASSERT(eventListener->getErrorEvents().size() == 1);
            ErrorEventData& errorEvent = eventListener->getErrorEvents().front();
            CPPUNIT_ASSERT(errorEvent ==
                    ErrorEventData(ErrorEventValue::other,
                        ErrorEventContext::other,
                        errorMessage));
        };
    }

    void expectAndVerify(boost::shared_ptr<ProxyMediaRouter> pmr,
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter)
    {
        EXPECT_CALL(*mockMediaRouter, setSource(dvbSource, SetSourceReason::mhegstandard))
            .WillOnce(Return(makeCompletedFuture()));

        pmr->setSource(dvbSource, SetSourceReason::mhegstandard).get();
        // Gmock will validate that all parameters are passed to the proxied media router
        // once setSource is called
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
    }

    //@{
    /**
     * Test setting the properties of the MR that can be set while the MR is
     * unsourced.
     */
    void test_setSink()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        // Check default
        CPPUNIT_ASSERT(pmr->getSink().get().empty());
        // Set value
        pmr->setSink(sink).get();
        // Check value
        CPPUNIT_ASSERT(pmr->getSink().get() == sink);

        // Verify that setSink has not yet been called on the proxied media router
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);

        // Now tell the proxied media router to expect a setSink call
        EXPECT_CALL(*mockMediaRouter, setSink(sink)).WillOnce(
                Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setCaptureMode()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        TimeShiftCaptureMode::Enum captureMode = TimeShiftCaptureMode::enabled;
        CPPUNIT_ASSERT(pmr->getCaptureMode().get() == TimeShiftCaptureMode::disabled);
        pmr->setCaptureMode(captureMode).get();
        CPPUNIT_ASSERT(pmr->getCaptureMode().get() == captureMode);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setCaptureMode(captureMode))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setVideoWindow()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        VideoWindowDescriptor
            defaultVideoWindow(0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0);
        VideoWindowDescriptor
            videoWindow(0.0, 0.0, 0.5, 0.5, 0.0, 0.0, 1.0, 1.0);

        CPPUNIT_ASSERT(pmr->getVideoWindow().get() == defaultVideoWindow);
        pmr->setVideoWindow(videoWindow).get();
        CPPUNIT_ASSERT(pmr->getVideoWindow().get() == videoWindow);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setVideoWindow(videoWindow))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setMediaDuration()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        int32_t mediaDuration = 98798;
        CPPUNIT_ASSERT(pmr->getMediaDuration().get() == 0);
        pmr->setMediaDuration(mediaDuration).get();
        CPPUNIT_ASSERT(pmr->getMediaDuration().get() == mediaDuration);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setMediaDuration(mediaDuration))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setPlaySpeed()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        double playSpeed = 2.0;
        CPPUNIT_ASSERT(pmr->getPlaySpeed().get() == 1.0);
        pmr->setPlaySpeed(playSpeed).get();
        CPPUNIT_ASSERT(pmr->getPlaySpeed().get() == playSpeed);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setPlaySpeed(playSpeed))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setEndTime()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        int32_t endTime = 71246147;
        CPPUNIT_ASSERT(pmr->getEndTime().get() == 0);
        pmr->setEndTime(endTime).get();
        CPPUNIT_ASSERT(pmr->getEndTime().get() == endTime);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setEndTime(endTime))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setBufferingMode()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        std::map<std::string, std::string> defaultModes;
        insert(defaultModes)
            ("adaptivemode", "default")
            ("bufferconstraints", "threshold")
            ("startupmode", "auto");

        std::map<std::string, std::string> requiredModes;
        insert(requiredModes)
            ("adaptivemode", "threshold")
            ("bufferconstraints", "default")
            ("startupmode", "default");

        CPPUNIT_ASSERT(pmr->getBufferingMode().get() == defaultModes);
        pmr->setBufferingMode(requiredModes).get();
        CPPUNIT_ASSERT(pmr->getBufferingMode().get() == requiredModes);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setBufferingMode(requiredModes))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setVideoTerminationMode()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        VideoTerminationMode::Enum terminationMode = VideoTerminationMode::disappear;
        CPPUNIT_ASSERT(pmr->getVideoTerminationMode().get() == VideoTerminationMode::freeze);
        pmr->setVideoTerminationMode(terminationMode).get();
        CPPUNIT_ASSERT(pmr->getVideoTerminationMode().get() == terminationMode);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setVideoTerminationMode(terminationMode))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    void test_setVolume()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        int32_t volume = -10;
        CPPUNIT_ASSERT(pmr->getVolume().get() == 0);
        pmr->setVolume(volume).get();
        CPPUNIT_ASSERT(pmr->getVolume().get() == volume);
        VERIFY_AND_CLEAR_MOCK(mockMediaRouter);
        EXPECT_CALL(*mockMediaRouter, setVolume(volume))
            .WillOnce(Return(makeCompletedFuture()));
        expectAndVerify(pmr, mockMediaRouter);
    }

    //@}

    void test_invalidVideoWindowRaisesException()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // Tell Gmock to expect these calls in sequence to ensure call
        // ordering is preserved
        InSequence dummy;

        VideoWindowDescriptor
            videoWindow(0.0, 0.0, 2.5, 0.5, 0.0, 0.0, 1.0, 1.0);

        try
        {
            pmr->setVideoWindow(videoWindow).get();
            CPPUNIT_FAIL("Expected OutOfBoundsException from media router");
        }
        catch(const OutOfBoundsException&)
        {
            ;
        }
    }

    void test_getVideoTrackUnsourced()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // These defaults are based on the Humax MR
        Track defaultTrack(-1, "",
                TrackFormat::other,
                TrackType::audio,
                TrackUsage::undefined);

        CPPUNIT_ASSERT(pmr->getVideoTrack().get() == defaultTrack);
    }

    void test_getAudioTrackUnsourced()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        // These defaults are based on the Humax MR
        Track defaultTrack(-1, "",
                TrackFormat::other,
                TrackType::audio,
                TrackUsage::undefined);

        CPPUNIT_ASSERT(pmr->getAudioTrack().get() == defaultTrack);
    }

    void test_callsWhileSourcingAreDeferred()
    {
        boost::shared_ptr<ProxyMediaRouter> pmr(makeProxy());
        boost::shared_ptr<MockMediaRouterAsync> mockMediaRouter = makeMockMediaRouter();

        Promise<void> sourcePromise(*theDispatcher);
        Future<void> sourceFuture = sourcePromise.getFuture();

        InSequence inSequence;
        EXPECT_CALL(*mockMediaRouter, setSink(sink)).WillOnce(Return(makeCompletedFuture()));
        EXPECT_CALL(*mockMediaRouter, setSource(dvbSource, SetSourceReason::mhegstandard))
            .WillOnce(Return(sourceFuture));
        EXPECT_CALL(*mockMediaRouter, setSubtitleTrack(0, "eng")).WillOnce(Return(makeCompletedFuture()));
        Future<void> sinkFuture = pmr->setSink(sink);
        pmr->setSource(dvbSource, SetSourceReason::mhegstandard);
        Future<void> subtitleFuture = pmr->setSubtitleTrack(0, "eng");

        sourcePromise.complete();
        sourceFuture.get();
        sinkFuture.get();
        subtitleFuture.get();
    }


    template<typename T>
    Future<T> makeCompletedFuture(const T& val)
    {
        return NS_ZINC::completedFuture(*theDispatcher,
                val);
    }

    Future<void> makeCompletedFuture() const
    {
        return NS_ZINC::completedFuture(*theDispatcher);
    }

    template<typename T, typename Exception>
    Future<T> makeErrorFuture()
    {
        return makeErrorFuture<T, Exception>("");
    }

    template<typename T, typename Exception>
    Future<T> makeErrorFuture(const std::string& what)
    {
        return exceptionalFuture<T>(*theDispatcher, Exception(what));
    }

private:

    boost::shared_ptr<ProxyMediaRouter> makeProxy()
    {
        boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory(
                systemFactory->createMediaRouterFactory());

        ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap;

        boost::shared_ptr<ProxyMediaRouter> proxy
            = boost::make_shared<ProxyMediaRouter>(
                    theDispatcher,
                    defaultMediaRouterFactory,
                    protocolMediaRouterFactoryMap,
                    mimeTypes);
        proxy->setDispatcher(theDispatcher);
        return proxy;
    }

    boost::shared_ptr<MockMediaRouterAsync> makeMockMediaRouter()
    {
        boost::shared_ptr<StrictMock<MockMediaRouterAsync> > mockMediaRouter
            = boost::make_shared<StrictMock<MockMediaRouterAsync> >();

        // Pass this mock to the factory. This means this mock will be returned
        // when the Proxy creates a MediaRouter
        mediaRouterFactory->setMockMediaRouter(mockMediaRouter);
        return mockMediaRouter;
    }

    CPPUNIT_TEST_SUITE(ProxyMediaRouterTest);
    
    CPPUNIT_TEST(test_setSourceAndRecycle);
    CPPUNIT_TEST(test_deferredSetVideoWindowExceptionMakesSetSourceFail);
    CPPUNIT_TEST(test_setSink);
    CPPUNIT_TEST(test_setCaptureMode);
    CPPUNIT_TEST(test_setMediaDuration);
    CPPUNIT_TEST(test_setVideoWindow);
    CPPUNIT_TEST(test_setPlaySpeed);
    CPPUNIT_TEST(test_setEndTime);
    CPPUNIT_TEST(test_setBufferingMode);
    CPPUNIT_TEST(test_setVideoTerminationMode);
    CPPUNIT_TEST(test_setVolume);
    CPPUNIT_TEST(test_invalidVideoWindowRaisesException);
    CPPUNIT_TEST(test_getVideoTrackUnsourced);
    CPPUNIT_TEST(test_getAudioTrackUnsourced);
    CPPUNIT_TEST(test_DVBChannelChangeWorks);
    CPPUNIT_TEST(test_invalidSourceGeneratesException);
    CPPUNIT_TEST(test_callsWhileSourcingAreDeferred);

    CPPUNIT_TEST_SUITE_END();

    std::string sink;
    std::string dvbSource;
    std::string linearSource;

    boost::shared_ptr<SimpleMediaRouterFactory> mediaRouterFactory;
    std::auto_ptr<StubSystemFactory> systemFactory;
    boost::shared_ptr<NS_ZINC::Dispatcher> theDispatcher;
    boost::shared_ptr<mime::MIMETypes> mimeTypes;
};

CPPUNIT_TEST_SUITE_REGISTRATION(ProxyMediaRouterTest);

NS_ZINC::Future<void>
MockMediaRouterState::setSource(const std::string& source_, SetSourceReason::Enum)
{
    if(!source.empty())
    {
        if(getSourceProtocol(source) != "dvb"
            || getSourceProtocol(source_) != "dvb")
        {
            throw IllegalReconfigurationException("source has already been set");
        }
    }
    source = source_;
    return test.makeCompletedFuture();
}

NS_ZINC::Future<void>
MockMediaRouterState::setSink(const std::string& sink_)
{
    if(!sink.empty())
    {
        throw IllegalReconfigurationException("sink has already been set");
    }
    sink = sink_;
    return test.makeCompletedFuture();
}

NS_ZINC::Future<void>
MockMediaRouterState::recycle()
{
    sink.clear();
    source.clear();
    return test.makeCompletedFuture();
}

NS_ZINC::Future<void>
MockMediaRouterState::start()
{
    if(source.empty() || sink.empty())
    {
        return test.makeErrorFuture<void, NotConfiguredException>();
    }
    return test.makeCompletedFuture();
}

NS_NICKEL_SYSTEM_CLOSE
