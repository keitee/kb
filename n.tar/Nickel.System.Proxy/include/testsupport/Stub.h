/*
 * Stub.h
 *
 *  Created on: Aug 9, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2012, Youview TV Ltd.
 */

#ifndef NICKEL_SYSTEM_PROXY_TEST_STUB_H_
#define NICKEL_SYSTEM_PROXY_TEST_STUB_H_

#include <nickel-system-api/macros.h>
#include <zinc-common/async/Dispatcher.h>
#include <string>

NS_NICKEL_SYSTEM_OPEN

class ZINC_EXPORT Stub {

public:

	explicit Stub(const std::string& stubName_,
            boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_);

	inline const std::string& getStubName() const {
		return stubName;
	}

	virtual ~Stub();

protected:

	std::string stubName;
    boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;
};


NS_NICKEL_SYSTEM_CLOSE


#endif /* NICKEL_SYSTEM_PROXY_TEST_STUB_H_ */
