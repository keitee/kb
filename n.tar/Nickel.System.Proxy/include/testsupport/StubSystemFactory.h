#ifndef STUBSYSTEMFACTORY_H
#define STUBSYSTEMFACTORY_H

/**
 * StubSystemFactory.h
 *
 * Created on: Dec 29, 2014
 *     Author: Tom Bailey
 *
 *
 * Copyright 2014, YouView TV Ltd.
 */

#include <nickel-system-api/SystemFactory.h>
#include <zinc-common/async/SingleThreadDispatcher.h>
#include "StubMediaRouterFactory.h"
#include "StubServiceListBuilder.h"

NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL StubSystemFactory : public SystemFactory, public Stub {

public:

	explicit StubSystemFactory(const std::string& stubName,
            boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_)
        : Stub(stubName, dispatcher_),
		mediaRouterFactory(new StubMediaRouterFactory(stubName, dispatcher_)),
		serviceListBuilder(new StubServiceListBuilder(stubName, dispatcher_)) {
	}

	StubSystemFactory(const std::string& stubName,
            boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_,
            boost::shared_ptr<MediaRouterFactory> mediaRouterFactory_)
        : Stub(stubName, dispatcher_),
		mediaRouterFactory(mediaRouterFactory_),
		serviceListBuilder(new StubServiceListBuilder(stubName, dispatcher_)) {
	}

	boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory() {
		return mediaRouterFactory;
	}

	boost::shared_ptr<MediaRouter> createDefaultMediaRouter() {
		return boost::shared_ptr<MediaRouter>();
	}

	boost::shared_ptr<LocalMediaLibrary> createLocalMediaLibrary() {
		return boost::shared_ptr<LocalMediaLibrary>();
	}

	boost::shared_ptr<MediaSettings> createMediaSettings() {
		return boost::shared_ptr<MediaSettings>();
	}

	boost::shared_ptr<OutputManager> createOutputManager() {
		return boost::shared_ptr<OutputManager>();
	}

	boost::shared_ptr<ServiceListBuilder> createServiceListBuilder() {
		return serviceListBuilder;
	}

private:

	boost::shared_ptr<MediaRouterFactory> mediaRouterFactory;
	boost::shared_ptr<ServiceListBuilder> serviceListBuilder;
};

NS_NICKEL_SYSTEM_CLOSE

#endif // STUBSYSTEMFACTORY_H
