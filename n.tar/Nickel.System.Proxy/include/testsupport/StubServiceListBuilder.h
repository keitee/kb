#ifndef STUBSERVICELISTBUILDER_H
#define STUBSERVICELISTBUILDER_H

/**
 * StubServiceListBuilder.h
 *
 * Created on: Dec 29, 2014
 *     Author: Tom Bailey
 *
 *
 * Copyright 2014, YouView TV Ltd.
 */

#include "Stub.h"
#include <zinc-common/async/Promise.h>
#include <nickel-system-api/ServiceListBuilder.h>

namespace Zinc
{
    class Dispatcher;
}

NS_NICKEL_SYSTEM_OPEN

class ZINC_LOCAL StubServiceListBuilder : public ServiceListBuilder, public Stub {

public:

	StubServiceListBuilder(const std::string& stubName_, boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_) :
		Stub(stubName_, dispatcher_) {
	}

	virtual NS_ZINC::Future< void > serviceScan() {
        return NS_ZINC::completedFuture(*dispatcher);
	}

	virtual NS_ZINC::Future< void > stopServiceScan() {
        return NS_ZINC::completedFuture(*dispatcher);
	}
};

NS_NICKEL_SYSTEM_CLOSE

#endif // STUBSERVICELISTBUILDER_H
