/*
 * ProxyMediaRouter.h
 *
 *  Created on: Aug 6, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2015, Youview TV Ltd.
 */

#ifndef NICKEL_SYSTEM_PROXY_PROXYMEDIAROUTER_H_
#define NICKEL_SYSTEM_PROXY_PROXYMEDIAROUTER_H_

#include <nickel-system-api/MediaRouter.h>
#include <nickel-system-api/MediaRouterFactory.h>
#include <nickel-system-api/MediaRouterEventListener.h>

#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/Promise.h>
#include <zinc-common/type-traits/call-traits.h>

#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/optional.hpp>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/ptr_container/ptr_deque.hpp>

#include <vector>
#include <string>

namespace mime
{
    class MIMETypes;
}

NS_NICKEL_SYSTEM_OPEN

typedef std::pair<std::string, boost::shared_ptr<MediaRouterFactory> > MIMEMediaRouterFactory;
typedef std::pair<std::string, std::vector<MIMEMediaRouterFactory> > MIMEMediaRouterFactoryMap;
typedef std::vector<MIMEMediaRouterFactoryMap> ProtocolMediaRouterFactoryMap;

struct AbstractDeferredCall {

	virtual ~AbstractDeferredCall() {}

	virtual void operator()(const MediaRouter* mediaRouter) = 0;
};


template <typename T>
struct future_type;

template <typename T>
struct future_type<NS_ZINC::Future<T> > {
	typedef T type;
};

template<typename Functor>
struct returned_future_type {
	typedef typename future_type<typename Functor::result_type>::type type;
};


class ZINC_LOCAL ProxyMediaRouter : public MediaRouter,
    public boost::enable_shared_from_this<ProxyMediaRouter>,
    public MediaRouterEventListener {

public:

	ProxyMediaRouter(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_,
			boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory_,
			ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap_,
            boost::shared_ptr<mime::MIMETypes> mimeTypes_);


	virtual NS_ZINC::Future< void > setSource(const std::string& mediaLocator_in, const SetSourceReason::Enum reason_in);

	virtual NS_ZINC::Future< std::string > getSource() const;

	virtual NS_ZINC::Future< void > setVolume(const int32_t volume_in);

	virtual NS_ZINC::Future< int32_t > getVolume() const;

	virtual NS_ZINC::Future< void > setAudioTrack(const int32_t tag_in);

	virtual NS_ZINC::Future< void > setAudioTrackExternal(const std::string& mediaLocator_in, const int32_t tag_in);

	virtual NS_ZINC::Future< Track > getAudioTrack() const;

	virtual NS_ZINC::Future< void > setVideoTrack(const int32_t tag_in);

	virtual NS_ZINC::Future< void > setVideoTrackExternal(const std::string& mediaLocator_in, const int32_t tag_in);

	virtual NS_ZINC::Future< Track > getVideoTrack() const;

	virtual NS_ZINC::Future< void > setSubtitleTrack(const int32_t tag_in, const std::string& language_in);

	virtual NS_ZINC::Future< Track > getSubtitleTrack() const;

	virtual NS_ZINC::Future< int32_t > addSubtitleTrack(const std::string& subtitleLocator_in);

	virtual NS_ZINC::Future< std::vector< Track > > getTracks() const;

	virtual NS_ZINC::Future< void > setVideoWindow(const VideoWindowDescriptor& videoWindow_in);

	virtual NS_ZINC::Future< VideoWindowDescriptor > getVideoWindow() const;

	virtual NS_ZINC::Future< void > setPlaySpeed(const double speed_in);

	virtual NS_ZINC::Future< double > getPlaySpeed() const;

	virtual NS_ZINC::Future< void > seekPosition(const SeekReference::Enum whence_in, const int32_t offset_in, const SeekMode::Enum mode_in);

	virtual NS_ZINC::Future< Position > getPosition() const;

	virtual NS_ZINC::Future< void > setSink(const std::string& mediaLocator_in);

	virtual NS_ZINC::Future< std::string > getSink() const;

	virtual NS_ZINC::Future< void > setEndTime(const int32_t end_in);

	virtual NS_ZINC::Future< int32_t > getEndTime() const;

	virtual NS_ZINC::Future< void > start();

	virtual NS_ZINC::Future< void > startDeferred();

	virtual NS_ZINC::Future< ControlCapabilities > getControlCapabilities() const;

	virtual NS_ZINC::Future< void > stop();

	virtual NS_ZINC::Future< void > setBufferingMode(const std::map< std::string, std::string >& bufferingMode_in);

	virtual NS_ZINC::Future< std::map< std::string, std::string > > getBufferingMode() const;

	virtual NS_ZINC::Future< void > startBuffering();

	virtual NS_ZINC::Future< void > stopBuffering();

	virtual NS_ZINC::Future< BufferStatus > getBufferStatus() const;

	virtual NS_ZINC::Future< void > setVideoTerminationMode(const VideoTerminationMode::Enum mode_in);

	virtual NS_ZINC::Future< VideoTerminationMode::Enum > getVideoTerminationMode() const;

	virtual NS_ZINC::Future< std::map< std::string, std::string > > getSourceInformation() const;

	virtual NS_ZINC::Future< void > setMediaDuration(const int32_t duration_in);

	virtual NS_ZINC::Future< int32_t > getMediaDuration() const;

	virtual NS_ZINC::Future< ABRStreamSet > getABRStreamSet() const;

	virtual NS_ZINC::Future< ABRStatus > getABRStatus() const;

	virtual NS_ZINC::Future< void > setABRStream(const int32_t streamIndex_in, const bool deferred_in);

	virtual NS_ZINC::Future< void > setCaptureMode(const TimeShiftCaptureMode::Enum mode_in);

	virtual NS_ZINC::Future< TimeShiftCaptureMode::Enum > getCaptureMode() const;

	virtual NS_ZINC::Future< void > recycle();

    //@{
    /** Override required functions from nickel::client::MediaRouterEventListener.
     *  
     *  We want to receive notifications from the MediaRouters we are proxying
     *  and forward them to our clients.
     */
    void BufferStatusEvent(const BufferStatusEventValue::Enum event);

    void DrmEvent(const DrmEventValue::Enum resultRef,
            const std::string& drmMediaIdentifier,
            const std::string& rightsIssuerUrl);

    void PositionChangeEvent(const Position& position);


    void SourceEvent(const SourceEventValue::Enum event,
            const SetSourceReason::Enum reason);

    void SpeedChangeEvent();

    void StatusEvent(const StatusEventValue::Enum event);


	void ErrorEvent(const ErrorEventValue::Enum error,
            const ErrorEventContext::Enum context,
            const std::string& info);

    //@}

private:

	friend class SetSourceContinuation;
	friend class SetPropertiesContinuation;

	inline bool isSourced() const {
		return !lastSource.empty();
	}

	void setSourceComplete(const std::string& newSource, boost::shared_ptr<MediaRouter> newImpl, boost::shared_ptr<MediaRouterFactory> newFactory);
	void setSourceFailed(const NS_ZINC::ErrorCode& err);

	boost::shared_ptr<MediaRouterFactory> findFactoryGivenSource(const std::string& source) const;

	template<typename Functor>
	typename Functor::result_type deferCall(Functor f) const;

	template<typename Functor>
	typename Functor::result_type deferForwardOrThrow(Functor f) const;

	template<typename Functor>
	NS_ZINC::Future<void> deferForwardOrIgnore(Functor f) const;

    template<typename Functor>
    typename Functor::result_type deferForwardOrDefault(Functor f,
           const typename returned_future_type<Functor>::type& defaultValue) const;

	boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;

	boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory;
	ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap;

	boost::shared_ptr<MediaRouter> impl;

    /**
     * MediaRouter properties which can be set on an unsourced MediaRouter.
     *
     * The list of properties is based on the behaviour of the the Humax
     * MediaRouter
     */
	struct UnsourcedProperties {
		boost::optional<std::string> sink;
        boost::optional<TimeShiftCaptureMode::Enum> captureMode;
        boost::optional<VideoWindowDescriptor> videoWindow;
		boost::optional<int32_t> mediaDuration;
		boost::optional<double> playSpeed;
		boost::optional<int32_t> endTime;
        boost::optional<std::map< std::string, std::string > > bufferingMode;
        boost::optional<VideoTerminationMode::Enum> videoTerminationMode;
		boost::optional<int32_t> volume;
	};

	UnsourcedProperties properties;

	std::string lastSource;
	boost::shared_ptr<MediaRouterFactory> lastFactory;

	bool sourcing;

	mutable boost::recursive_mutex mutex;
	typedef boost::recursive_mutex::scoped_lock scoped_lock;

	mutable boost::ptr_deque<AbstractDeferredCall> deferredCalls;

    boost::shared_ptr<mime::MIMETypes> mimeTypes;
};

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_PROXY_PROXYMEDIAROUTER_H_ */
