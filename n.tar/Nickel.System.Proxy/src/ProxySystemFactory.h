/*
 * ProxySystemFactory.h
 *
 *  Created on: Aug 10, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2015, Youview TV Ltd.
 */

#ifndef NICKEL_SYSTEM_PROXY_PROXYSYSTEMFACTORY_H_
#define NICKEL_SYSTEM_PROXY_PROXYSYSTEMFACTORY_H_

#include <nickel-system-api/SystemFactory.h>
#include <boost/shared_ptr.hpp>
#include <boost/filesystem.hpp>

NS_NICKEL_SYSTEM_OPEN

std::vector<boost::filesystem::path> findMediaRouterPluginConfigFiles(
        const std::string& configDir) ZINC_LOCAL;

class ZINC_LOCAL ProxySystemFactory : public SystemFactory {

public:

	ProxySystemFactory();

	boost::shared_ptr<MediaRouterFactory> createMediaRouterFactory();
	boost::shared_ptr<MediaRouter> createDefaultMediaRouter();

	boost::shared_ptr<LocalMediaLibrary> createLocalMediaLibrary();
	boost::shared_ptr<MediaSettings> createMediaSettings();
	boost::shared_ptr<OutputManager> createOutputManager();
	boost::shared_ptr<ServiceListBuilder> createServiceListBuilder();

    static const std::string DEFAULT_MIME_TYPE;

private:

	friend class ProxySystemFactoryWhiteboxTest;

	void loadImplementations();

	boost::shared_ptr<NS_ZINC::Dispatcher> getDispatcher();

	boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;

	SystemFactory* defaultImplementation;

	boost::shared_ptr<MediaRouterFactory> proxyMediaRouterFactory;

	boost::shared_ptr<MediaRouter> defaultMediaRouter;

};


/**
 * Compare two objects that have a public member called 'first', e.g. std::pair.
 */
template<typename T>
bool pairCompare(const T& l, const T& r)
{
	return l.first < r.first;
}

/**
 * Call std::lower_bound on a sorted vector<std::pair> with the correct comparator.
 *
 * The factory uses vector<std::pair> as a mapping type.
 */
template<typename Vector>
typename Vector::iterator lowerBoundInVectorOfPairs(Vector& map,
        typename Vector::value_type key)
{
    return std::lower_bound(map.begin(), map.end(), key,
                &pairCompare<typename Vector::value_type>);
}

template<typename Vector>
typename Vector::const_iterator lowerBoundInVectorOfPairs(const Vector& map,
        typename Vector::value_type key)
{
    // Provide an overload for const container by casting away the const-ness
    // and calling non-const version, in line with the STL containers
    return lowerBoundInVectorOfPairs(const_cast<Vector&>(map), key);
}

/**
 * Find an entry in a sorted vector<std::pair>.
 *
 * The factory uses vector<std::pair> as a mapping type.
 */
template<typename Vector>
typename Vector::const_iterator findInVectorOfPairs(const Vector& map,
        typename Vector::value_type key)
{
    typename Vector::const_iterator iter = lowerBoundInVectorOfPairs(map, key);

    if(iter != map.end() && iter->first == key.first)
    {
        return iter;
    }
    else
    {
        return map.end();
    }
}

NS_NICKEL_SYSTEM_CLOSE

extern "C" {
	NS_NICKEL_SYSTEM::SystemFactory*  createSystemFactory() ZINC_EXPORT;
}

#endif /* NICKEL_SYSTEM_PROXY_PROXYSYSTEMFACTORY_H_ */
