/*
 * ProxyMediaRouterFactory.cpp
 *
 *  Created on: Aug 6, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2015, Youview TV Ltd.
 */

#include "ProxyMediaRouterFactory.h"
#include "ProxyMediaRouter.h"

#include <zinc-common/async/Dispatcher.h>
#include <zinc-common/async/async-helpers.h>
#include <zinc-http/mime/MIMETypes.h>
#include <nickel-common/NickelLogger.h>

#include <boost/shared_ptr.hpp>

NS_NICKEL_SYSTEM_OPEN

ProxyMediaRouterFactory::ProxyMediaRouterFactory(
			boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_,
			boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory_,
			ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap_) :

	dispatcher(dispatcher_),
	defaultMediaRouterFactory(defaultMediaRouterFactory_),
	protocolMediaRouterFactoryMap(protocolMediaRouterFactoryMap_),
    mimeTypes(boost::make_shared<mime::MIMETypes>())
{
	NICKEL_FUNC_TRACE;
}

ProxyMediaRouterFactory::~ProxyMediaRouterFactory() {

}

NS_ZINC::Future<boost::shared_ptr<MediaRouter> > ProxyMediaRouterFactory::createMediaRouter() {
	NICKEL_FUNC_TRACE;

	return NS_ZINC::completedFuture(
            *dispatcher, boost::shared_ptr<MediaRouter>(new ProxyMediaRouter(
                dispatcher, defaultMediaRouterFactory, protocolMediaRouterFactoryMap,
                mimeTypes)));
}

NS_NICKEL_SYSTEM_CLOSE
