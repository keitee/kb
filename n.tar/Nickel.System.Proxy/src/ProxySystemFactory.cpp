/*
 * ProxySystemFactory.cpp
 *
 *  Created on: Aug 6, 2012
 *      Author: john.sadler@youview.com, tom.bailey@youview.com
 *
 *  Copyright 2015, Youview TV Ltd.
 */

#include "ProxySystemFactory.h"

#include "ProxyMediaRouterFactory.h"


#include <nickel-system-api/LocalMediaLibrary.h>
#include <nickel-system-api/MediaRouter.h>
#include <nickel-system-api/MediaSettings.h>
#include <nickel-system-api/OutputManager.h>
#include <nickel-system-api/ServiceListBuilder.h>
#include <nickel-common/NickelLogger.h>

#include <zinc-common/PluginFactory.h>
#include <zinc-common/FilePluginConfig.h>
#include <zinc-common/resource-finder/PackageDataFinder.h>
#include <zinc-common/async/SingleThreadDispatcher.h>

#include <boost/foreach.hpp>
#include <boost/filesystem.hpp>

#include <exception>
#include <vector>
#include <string>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>

#include <libsoup/soup.h>

NS_NICKEL_SYSTEM_OPEN

using namespace NS_ZINC;

const std::string ProxySystemFactory::DEFAULT_MIME_TYPE = "default";

ProxySystemFactory::ProxySystemFactory() {
	loadImplementations();
}

std::vector<boost::filesystem::path> findMediaRouterPluginConfigFiles(const std::string& configDir) {
	NICKEL_FUNC_TRACE;

	using namespace std;

	vector<boost::filesystem::path> configFiles;

    boost::filesystem::path directory(configDir);

	if (!boost::filesystem::is_directory(directory)) {
		throw std::runtime_error("Failed to read implementation plugin config directory.");
	}

    for(boost::filesystem::directory_iterator iter(directory);
            iter != boost::filesystem::directory_iterator();
            ++iter)
    {
        if(boost::filesystem::is_regular_file(iter->path())
            || boost::filesystem::is_symlink(iter->path()))
        {
			configFiles.push_back(iter->path());
        }
	}

	return configFiles;
}


void ProxySystemFactory::loadImplementations() {
	NICKEL_FUNC_TRACE;

	using namespace std;


	// First, we need a default factory, from which we will get our
	// LML, ServiceListBuilder, OutputManager implementations.

	FilePluginConfig defaultPluginConfig(PackageDataFinder().find("default-system-factory.plugin-config"));
	defaultImplementation = boost::addressof(PluginFactory::getInstance<SystemFactory>(defaultPluginConfig));


	// Now we go looking for through the configuration directory that is
	// specific to just the MediaRouter service.
	// Here we may find several plugin-config files, including another "default"
	// which this time will be the default for the MediaRouter service only.
	// (if the default is not found, then we will fall-back to the main default,
	// above).

	string configDir(PackageDataFinder().find("mediarouter-plugin-config"));

	vector<boost::filesystem::path> configFiles(findMediaRouterPluginConfigFiles(configDir));

	boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory;
	ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap;

	BOOST_FOREACH(const boost::filesystem::path& fullPath, configFiles)
    {
        string fileStem = fullPath.stem();

		FilePluginConfig pluginConfig(fullPath.string());

		SystemFactory& factory(PluginFactory::getInstance<SystemFactory>(pluginConfig));

        if(fileStem == "default-mediarouter")
        {
            defaultMediaRouterFactory = factory.createMediaRouterFactory();
        }
        else
        {
            size_t protocolEnd(fileStem.find_first_of('-'));

            if (protocolEnd == string::npos)
            {
                string msg("Plugin config file has invalid name format. "
                        "Filename should start with protocol, then hyphen. File is: ");
                msg += fullPath.string();
                throw runtime_error(msg);
            }

            string protocol(fileStem.substr(0, protocolEnd));
            string mimeType(fileStem.substr(protocolEnd + 1, string::npos));

            if(mimeType != DEFAULT_MIME_TYPE)
            {
                // MIME type will be URI-encoded
                boost::shared_ptr<char> decodedMimeType(soup_uri_decode(mimeType.c_str()), &free);
                mimeType = decodedMimeType.get();
            }

            // Check if there is an entry for this protocol.
            ProtocolMediaRouterFactoryMap::iterator protMapIter = lowerBoundInVectorOfPairs(
                    protocolMediaRouterFactoryMap, MIMEMediaRouterFactoryMap(protocol,
                        std::vector<MIMEMediaRouterFactory>()));

            if(protMapIter == protocolMediaRouterFactoryMap.end()
                    || protMapIter->first != protocol)
            {
                // No entry for this protocol, so add one
                protMapIter = protocolMediaRouterFactoryMap.insert(protMapIter,
                        MIMEMediaRouterFactoryMap(protocol,
                            std::vector<MIMEMediaRouterFactory>()));
            }

            NICKEL_DEBUG("*** KT: add {" << protocol << ", " << mimeType << "}" );

            // Add the MIME type to the protocol's list
            protMapIter->second.push_back(std::make_pair(mimeType, factory.createMediaRouterFactory()));
        }
	}

    // We now need to sort the per-protocol lists
    BOOST_FOREACH(MIMEMediaRouterFactoryMap& protocolMap, protocolMediaRouterFactoryMap)
    {
        std::sort(protocolMap.second.begin(), protocolMap.second.end(), 
                &pairCompare<MIMEMediaRouterFactory>);
    }

    if(!defaultMediaRouterFactory)
    {
        defaultMediaRouterFactory = defaultImplementation->createMediaRouterFactory();
    }

	proxyMediaRouterFactory = boost::make_shared<ProxyMediaRouterFactory>(getDispatcher(),
            defaultMediaRouterFactory, protocolMediaRouterFactoryMap);
}

boost::shared_ptr<NS_ZINC::Dispatcher> ProxySystemFactory::getDispatcher() {
	NICKEL_FUNC_TRACE;

	if (!dispatcher) {
		dispatcher = boost::make_shared<NS_ZINC::SingleThreadDispatcher>();
	}

	return dispatcher;
}

boost::shared_ptr<MediaRouterFactory> ProxySystemFactory::createMediaRouterFactory() {
	NICKEL_FUNC_TRACE;
	return proxyMediaRouterFactory;
}

boost::shared_ptr<MediaRouter> ProxySystemFactory::createDefaultMediaRouter() {
	NICKEL_FUNC_TRACE;

	if (!defaultMediaRouter) {
		defaultMediaRouter = defaultImplementation->createDefaultMediaRouter();
	}

	return defaultMediaRouter;
}

boost::shared_ptr<LocalMediaLibrary> ProxySystemFactory::createLocalMediaLibrary() {
	NICKEL_FUNC_TRACE;
	return defaultImplementation->createLocalMediaLibrary();
}

boost::shared_ptr<MediaSettings> ProxySystemFactory::createMediaSettings() {
	NICKEL_FUNC_TRACE;
	return defaultImplementation->createMediaSettings();
}

boost::shared_ptr<OutputManager> ProxySystemFactory::createOutputManager() {
	NICKEL_FUNC_TRACE;
	return defaultImplementation->createOutputManager();
}

boost::shared_ptr<ServiceListBuilder> ProxySystemFactory::createServiceListBuilder() {
	NICKEL_FUNC_TRACE;
	return defaultImplementation->createServiceListBuilder();
}

NS_NICKEL_SYSTEM_CLOSE

extern "C" {
	NS_NICKEL_SYSTEM::SystemFactory*  createSystemFactory() ZINC_EXPORT;
	NS_NICKEL_SYSTEM::SystemFactory* createSystemFactory() {
		return new NS_NICKEL_SYSTEM::ProxySystemFactory();
	}
}

