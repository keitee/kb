/*
 * ProxyMediaRouter.cpp
 *
 *  Created on: Aug 6, 2012
 *      Author: john.sadler@youview.com, tom.bailey@youview.com
 *
 *  Copyright 2015, Youview TV Ltd.
 */


#include "ProxyMediaRouter.h"
#include "ProxySystemFactory.h"

#include <nickel-system-api/NotConfiguredException.h>
#include <nickel-system-api/InvalidLocatorException.h>
#include <nickel-system-api/IllegalReconfigurationException.h>
#include <nickel-system-api/InvalidDurationException.h>
#include <nickel-system-api/OutOfBoundsException.h>
#include <nickel-system-api/MediaRouterEventListener.h>
#include <nickel-common/NickelLogger.h>
#include <zinc-common/async/Promise.h>
#include <zinc-common/async/Continuation.h>
#include <zinc-common/async/FutureBarrier.h>
#include <zinc-common/async/async-helpers.h>
#include <zinc-common/EnumConv.h>
#include <zinc-http/mime/MIMETypes.h>

#include <boost/range.hpp>
#include <libsoup/soup.h>

#include <algorithm>
#include <utility>

NS_NICKEL_SYSTEM_OPEN

ProxyMediaRouter::ProxyMediaRouter(
			boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_,
			boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory_,
			ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap_,
            boost::shared_ptr<mime::MIMETypes> mimeTypes_) :

	dispatcher(dispatcher_),
	defaultMediaRouterFactory(defaultMediaRouterFactory_),
	protocolMediaRouterFactoryMap(protocolMediaRouterFactoryMap_),
    sourcing(false),
    mimeTypes(mimeTypes_)
{
	NICKEL_FUNC_TRACE;
}


namespace {

// Default values for the bufferingModes map, based on the values returned by
// the Humax media router
const std::pair<std::string, std::string> bufferingModes[] = {
    std::pair<std::string, std::string>("adaptivemode", "default"),
    std::pair<std::string, std::string>("bufferconstraints", "threshold"),
    std::pair<std::string, std::string>("startupmode", "auto")
};

const std::map<std::string, std::string> defaultBufferingModes(
        boost::begin(bufferingModes), boost::end(bufferingModes));

std::string getSourceProtocol(const std::string& source) {

    // FIXME This should be find, not find_first_of
	size_t endAt = source.find_first_of("://");

	if (endAt == std::string::npos) {
		throw InvalidLocatorException("Invalid form for source URL. Missing protocol.");
	}

	return source.substr(0, endAt);
}

std::string getMediaExtension(const std::string& source) {

    size_t dot = source.find_last_of('.');

	if (dot == std::string::npos) {
		return std::string();
	}

    return source.substr(dot + 1, std::string::npos);
}

bool validateSourceCoordinate(double coordinate)
{
    return (coordinate >= 0.0 && coordinate <= 1.0);
}

/**
 * Free a SOUPURI, avoiding libsoup warnings about nulls.
 */
void SoupURIQuietFree(SoupURI* uri)
{
    if(uri)
    {
        soup_uri_free(uri);
    }
}

boost::shared_ptr<SoupURI> decodeCompoundURI(boost::shared_ptr<SoupURI> sourceURI)
{
    // Determine if this URI is an MS3 compound URI, i.e. a URI which embeds
    // another URI
    if(soup_uri_get_fragment(sourceURI.get()))
    {
        // URI has a fragment portion - but does it look like a URI? 
        boost::shared_ptr<SoupURI> mediaURI(soup_uri_new(soup_uri_get_fragment(sourceURI.get())),
                &SoupURIQuietFree);

        if(mediaURI && soup_uri_get_scheme(mediaURI.get())
                && soup_uri_get_host(mediaURI.get()))
        {
            // Embedded URI has at least a scheme (protocol), host and path,
            // so it's probably valid
            sourceURI = mediaURI;
        }
    }
    return sourceURI;
}

}

class SetSourceContinuation;

class ZINC_LOCAL SetPropertiesContinuation
    : public NS_ZINC::Continuation<void, SetPropertiesContinuation> {

	friend class NS_ZINC::Continuation<void, SetPropertiesContinuation>;

public:

    void onError(const NS_ZINC::ErrorCode& err);

private:
    void start(boost::shared_ptr<ProxyMediaRouter> proxy_,
            boost::shared_ptr<MediaRouter> impl_,
            boost::shared_ptr<SetSourceContinuation> parentContinuation_,
            const ProxyMediaRouter::UnsourcedProperties& mrProperties_);

    void onPropertiesSet();

    boost::shared_ptr<ProxyMediaRouter> proxy;
    ProxyMediaRouter::UnsourcedProperties properties;
	boost::shared_ptr<MediaRouter> impl;
    boost::shared_ptr<SetSourceContinuation> parentContinuation;
};

class ZINC_LOCAL SetSourceContinuation : public NS_ZINC::Continuation<void, SetSourceContinuation> {

	friend class NS_ZINC::Continuation<void, SetSourceContinuation>;

public:

	void onError(const NS_ZINC::ErrorCode& err) {

		promise.error(err);

		proxy->setSourceFailed(err);
	}

    void onPropertiesFailure(const std::string& failureMessage)
    {
        setPropertiesFailureMessage = failureMessage;
    }

private:

	void start(boost::shared_ptr<ProxyMediaRouter> proxy_, const std::string& source_, const SetSourceReason::Enum reason_) {
        NICKEL_FUNC_TRACE;

		// I take copies of the proxy state, in case it is modified before the continuation
		// completes.
		//
		// This start() method will be called by the same thread that calls ProxyMediaRouter::setSource(), so I
		// assume it is OK to access proxy state from here (as lock will already be held).
		//
		proxy = proxy_;
		properties = proxy->properties;
		impl = proxy->impl;
		source = source_;
		reason = reason_;

		// Can only re-source MediaRouter without recycling if in linear configuration:
		if (proxy->isSourced()) {

			// TODO Handle exception?
			if ("dvb" != getSourceProtocol(proxy->lastSource) || "dvb" != getSourceProtocol(source)) {

				promise.exception(
					IllegalReconfigurationException("Must recycle MediaRouter before calling setSource() again, unless old and new sources are both linear.")
				);
				return;
			}

		} else {

			factory = proxy->findFactoryGivenSource(source);

			// This covers the cases where we have no implementation MediaRouter, or
			// a recycled one that is not compatible with the source media.
			// In both cases, we create a new one of the appropriate type.
			//
			if (factory != proxy->lastFactory) {
				continueOnSuccess(factory->createMediaRouter(), &SetSourceContinuation::onMediaRouterCreated);
				return;
			}
		}

		// We only reach here if we have a recycled MediaRouter implementation already,
		// or we have an existing dvb MediaRouter and we are setting another dvb source.
		//
		// In these cases, we do not have to create a new MediaRouter implementation, so
		// we move straight on to setting the properties.
		//
		setProperties();
	}

	void onMediaRouterCreated(boost::shared_ptr<MediaRouter> impl_) {

        NICKEL_FUNC_TRACE;

		impl = impl_;
        impl->addListener(proxy);
		setProperties();
    }

    void setProperties()
    {
        continueOnSuccess(SetPropertiesContinuation::create(getDispatcher(),
                proxy, impl, shared_from_this(), properties),
            &SetSourceContinuation::onPropertiesSet);
    }

    void onPropertiesSet()
    {
        NICKEL_FUNC_TRACE;

        continueOnSuccess(impl->setSource(source, reason), &SetSourceContinuation::complete);
    }

	void complete() {

        NICKEL_FUNC_TRACE;

		promise.complete();

		proxy->setSourceComplete(source, impl, factory);
	}

	boost::shared_ptr<ProxyMediaRouter> proxy;
	ProxyMediaRouter::UnsourcedProperties properties;
	boost::shared_ptr<MediaRouter> impl;
	std::string source;
	SetSourceReason::Enum reason;

	boost::shared_ptr<MediaRouterFactory> factory;

    boost::optional<std::string> setPropertiesFailureMessage;
};

void SetPropertiesContinuation::start(boost::shared_ptr<ProxyMediaRouter> proxy_,
        boost::shared_ptr<MediaRouter> impl_,
        boost::shared_ptr<SetSourceContinuation> parentContinuation_,
        const ProxyMediaRouter::UnsourcedProperties& mrProperties_)
{
    NICKEL_FUNC_TRACE;
    proxy = proxy_;
    parentContinuation = parentContinuation_;
    properties = mrProperties_;
    impl = impl_;

    NS_ZINC::FutureBarrier barrier(getDispatcher());
    if (properties.mediaDuration) {
        barrier.add(impl->setMediaDuration(*properties.mediaDuration));
    }
    if (properties.sink) {
        barrier.add(impl->setSink(*properties.sink));
    }
    if (properties.captureMode) {
        barrier.add(impl->setCaptureMode(*properties.captureMode));
    }
    if (properties.videoWindow) {
        barrier.add(impl->setVideoWindow(*properties.videoWindow));
    }
    if (properties.playSpeed) {
        barrier.add(impl->setPlaySpeed(*properties.playSpeed));
    }
    if (properties.endTime) {
        barrier.add(impl->setEndTime(*properties.endTime));
    }
    if (properties.bufferingMode) {
        barrier.add(impl->setBufferingMode(*properties.bufferingMode));
    }
    if (properties.videoTerminationMode) {
        barrier.add(impl->setVideoTerminationMode(
                    *properties.videoTerminationMode));
    }
    if (properties.volume) {
        barrier.add(impl->setVolume(*properties.volume));
    }

    continueOnSuccess(barrier, &SetPropertiesContinuation::onPropertiesSet);
}

void SetPropertiesContinuation::onError(const NS_ZINC::ErrorCode& err)
{
    NICKEL_FUNC_TRACE;

    // Emit an error event for media router clients
    proxy->ErrorEvent(ErrorEventValue::other,
        ErrorEventContext::other,
        err.message());

    // Translate whatever exception the set* call generated into an
    // IllegalReconfigurationException, which setSource is allowed to throw
    promise.exception(IllegalReconfigurationException(err.message()));
}

void SetPropertiesContinuation::onPropertiesSet()
{
    NICKEL_FUNC_TRACE;
    promise.complete();
}

template<typename T>
void chainedComplete(NS_ZINC::Promise<T> promiseToComplete, NS_ZINC::FutureValue<T> fv) {

	if (!fv.getError()) {
		promiseToComplete.complete(fv.get());
	} else {
		promiseToComplete.error(fv.getError());
	}
}

template<>
void chainedComplete<void>(NS_ZINC::Promise<void> promiseToComplete, NS_ZINC::FutureValue<void> fv) {

	if (!fv.getError()) {
		promiseToComplete.complete();
	} else {
		promiseToComplete.error(fv.getError());
	}
}

template<typename Functor, typename T>
class DeferredCall : public AbstractDeferredCall {

public:

	DeferredCall(boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher, Functor method_) :
		promise(*dispatcher),
		method(method_) {

	}

	NS_ZINC::Future<T> getFuture() {
		return promise.getFuture();
	}

    void operator()(const MediaRouter* mediaRouter) {
        method(const_cast<MediaRouter*>(mediaRouter))
            .then(boost::bind(&chainedComplete<T>, promise, _1));
	}

private:

	NS_ZINC::Promise<T> promise;
	Functor method;
};

template<typename Functor>
typename Functor::result_type ProxyMediaRouter::deferCall(Functor f) const {

    NICKEL_FUNC_TRACE;
	typedef typename returned_future_type<Functor>::type T;

	std::auto_ptr<DeferredCall<Functor, T> > deferred(new DeferredCall<Functor, T>(dispatcher, f));
	NS_ZINC::Future<T> future(deferred->getFuture());
	deferredCalls.push_back(deferred);
	return future;
}

template<typename Functor>
typename Functor::result_type ProxyMediaRouter::deferForwardOrThrow(Functor f) const {

    NICKEL_FUNC_TRACE;

	typedef typename returned_future_type<Functor>::type T;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(f);
	}

	if (!isSourced()) {
		return NS_ZINC::exceptionalFuture<T>(*dispatcher, NotConfiguredException());
	}

	return f(impl.get());
}

template<typename Functor>
NS_ZINC::Future<void> ProxyMediaRouter::deferForwardOrIgnore(Functor f) const {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(f);
	}

	if (!isSourced()) {
		return NS_ZINC::completedFuture(*dispatcher);
	}

	return f(impl.get());
}

template<typename Functor>
typename Functor::result_type ProxyMediaRouter::deferForwardOrDefault(Functor f,
       const typename returned_future_type<Functor>::type& defaultValue) const
{

    NICKEL_FUNC_TRACE;

	typedef typename returned_future_type<Functor>::type T;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(f);
	}

	if (!isSourced())
    {
		return NS_ZINC::completedFuture<T>(*dispatcher, defaultValue);
	}

	return f(impl.get());
}

// See spec A.1.1
NS_ZINC::Future< void > ProxyMediaRouter::setSource(const std::string& mediaLocator_in, const SetSourceReason::Enum reason_in) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(boost::bind(&MediaRouter::setSource, _1, mediaLocator_in, reason_in));
	}

	sourcing = true;
	return SetSourceContinuation::create(*dispatcher, shared_from_this(), mediaLocator_in, reason_in);
}

/**
 * This is called by SetSourceContinuation::complete(). The idea is to contain all the
 * state manipulation in one place.
 */
void ProxyMediaRouter::setSourceComplete(const std::string& newSource, boost::shared_ptr<MediaRouter> newImpl, boost::shared_ptr<MediaRouterFactory> newFactory) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	lastSource = newSource;
	impl = newImpl;

	if (newFactory) {
		lastFactory = newFactory;
	}

	properties = UnsourcedProperties();

	sourcing = false;

	// Some calls may have been deferred whilst we were setting the source.
	// process those now, but stop if one of them is a call to setSource().
    // FIXME Does not check for setSource() - should it?

	while (!deferredCalls.empty() && !sourcing) {
		deferredCalls.front()(this);
		deferredCalls.pop_front();
	}
}

/**
 * This is called by SetSourceContinuation::onError().
 */
void ProxyMediaRouter::setSourceFailed(const NS_ZINC::ErrorCode&) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	sourcing = false;

	// Some calls may have been deferred whilst we were setting the source.
	// process those now, but stop if one of them is a call to setSource().

	while (!deferredCalls.empty() && !sourcing) {
		deferredCalls.front()(this);
		deferredCalls.pop_front();
	}
}

NS_ZINC::Future< std::string > ProxyMediaRouter::getSource() const {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

    return deferForwardOrDefault(boost::bind(&MediaRouter::getSource, _1), lastSource);
}


NS_ZINC::Future< void > ProxyMediaRouter::setSink(const std::string& mediaLocator_in) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(boost::bind(&MediaRouter::setSink, _1, mediaLocator_in));
	}

	properties.sink = mediaLocator_in;

    if(!isSourced())
    {
        return NS_ZINC::completedFuture(*dispatcher);
    }

	// FIXME: What to do if sink is invalid but source not yet set (so can't pass straight
	// to impl for checking)
	//
	return impl->setSink(mediaLocator_in);
}

NS_ZINC::Future< std::string > ProxyMediaRouter::getSink() const {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

    return deferForwardOrDefault(boost::bind(&MediaRouter::getSink, _1),
            properties.sink.get_value_or(std::string()));
}


NS_ZINC::Future< void > ProxyMediaRouter::setMediaDuration(const int32_t duration_in) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(boost::bind(&MediaRouter::setMediaDuration, _1, duration_in));
	}

    if(isSourced())
    {
        return impl->setMediaDuration(duration_in);
    }
    else
    {
        if(duration_in < 0)
        {
            return NS_ZINC::exceptionalFuture<void>(*dispatcher, InvalidDurationException());
        }
        else
        {
            properties.mediaDuration = duration_in;
            return NS_ZINC::completedFuture(*dispatcher);
        }
    }
}

NS_ZINC::Future< int32_t > ProxyMediaRouter::getMediaDuration() const {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

    // The MR spec (s 6.18) states that media duration has a default value
    // of -1 but the Humax MR returns 0.
    return deferForwardOrDefault(boost::bind(&MediaRouter::getMediaDuration, _1),
            properties.mediaDuration.get_value_or(0));
}

NS_ZINC::Future< void > ProxyMediaRouter::recycle() {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(boost::bind(&MediaRouter::recycle, _1));
	}

	properties = UnsourcedProperties();

	lastSource.clear();

	if (impl) {

		// Recycle, but don't drop the implementation.
		// We need to check whether it is the right one when setSource() is
		// next called.
		return impl->recycle();
	}

	return NS_ZINC::completedFuture(*dispatcher);
}

NS_ZINC::Future< void > ProxyMediaRouter::setVolume(const int32_t volume_in) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(boost::bind(&MediaRouter::setVolume, _1, volume_in));
	}

    if(isSourced())
    {
        return impl->setVolume(volume_in);
    }
    else
    {
        if(volume_in > 0)
        {
            return NS_ZINC::exceptionalFuture<void>(*dispatcher, OutOfBoundsException());
        }
        else
        {
            properties.volume = volume_in;
            return NS_ZINC::completedFuture(*dispatcher);
        }
    }
}

NS_ZINC::Future< int32_t > ProxyMediaRouter::getVolume() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getVolume, _1),
            properties.volume.get_value_or(0));
}

NS_ZINC::Future< void > ProxyMediaRouter::setAudioTrack(const int32_t tag_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setAudioTrack, _1, tag_in));
}

NS_ZINC::Future< void > ProxyMediaRouter::setAudioTrackExternal(const std::string& mediaLocator_in, const int32_t tag_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setAudioTrackExternal, _1, mediaLocator_in, tag_in));
}

NS_ZINC::Future< Track > ProxyMediaRouter::getAudioTrack() const {

    NICKEL_FUNC_TRACE;
    // These defaults are based on the Humax MR
    static const Track defaultTrack(-1, "",
            TrackFormat::other,
            TrackType::audio,
            TrackUsage::undefined);
	return deferForwardOrDefault(boost::bind(&MediaRouter::getAudioTrack, _1), defaultTrack);
}

NS_ZINC::Future< void > ProxyMediaRouter::setVideoTrack(const int32_t tag_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setVideoTrack, _1, tag_in));
}

NS_ZINC::Future< void > ProxyMediaRouter::setVideoTrackExternal(const std::string& mediaLocator_in, const int32_t tag_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setVideoTrackExternal, _1, mediaLocator_in, tag_in));
}

NS_ZINC::Future< Track > ProxyMediaRouter::getVideoTrack() const {

    NICKEL_FUNC_TRACE;

    // These defaults are based on the Humax MR
    static const Track defaultTrack(-1, "",
            TrackFormat::other,
            TrackType::audio,
            TrackUsage::undefined);

	return deferForwardOrDefault(boost::bind(&MediaRouter::getVideoTrack, _1), defaultTrack);
}

NS_ZINC::Future< void > ProxyMediaRouter::setSubtitleTrack(const int32_t tag_in, const std::string& language_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setSubtitleTrack, _1, tag_in, language_in));
}

NS_ZINC::Future< Track > ProxyMediaRouter::getSubtitleTrack() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getSubtitleTrack, _1), Track());
}

NS_ZINC::Future< int32_t > ProxyMediaRouter::addSubtitleTrack(const std::string& subtitleLocator_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::addSubtitleTrack, _1, subtitleLocator_in), 1);
}

NS_ZINC::Future< std::vector< Track > > ProxyMediaRouter::getTracks() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getTracks, _1), std::vector< Track >());
}

NS_ZINC::Future< void > ProxyMediaRouter::setVideoWindow(const VideoWindowDescriptor& videoWindow_in) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

    if(!isSourced())
    {
        if(!sourcing)
        {
            if(validateSourceCoordinate(videoWindow_in.sourceX) &&
                    validateSourceCoordinate(videoWindow_in.sourceY) &&
                    validateSourceCoordinate(videoWindow_in.sourceWidth) &&
                    validateSourceCoordinate(videoWindow_in.sourceHeight) &&
                    videoWindow_in.destinationWidth >= 0.0 &&
                    videoWindow_in.destinationHeight >= 0.0)
            {
                properties.videoWindow = videoWindow_in;
                return NS_ZINC::completedFuture(*dispatcher);
            }
            else
            {
                return NS_ZINC::exceptionalFuture<void>(*dispatcher, OutOfBoundsException());
            }
        }
        else
        {
            properties.videoWindow = videoWindow_in;
        }
    }
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setVideoWindow, _1, videoWindow_in));
}

NS_ZINC::Future< VideoWindowDescriptor > ProxyMediaRouter::getVideoWindow() const {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

    return deferForwardOrDefault(boost::bind(&MediaRouter::getVideoWindow, _1),
                properties.videoWindow.get_value_or(
                    VideoWindowDescriptor(0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0)));
}

NS_ZINC::Future< void > ProxyMediaRouter::setPlaySpeed(const double speed_in) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

    if(!isSourced())
    {
        properties.playSpeed = speed_in;
        if(!sourcing)
        {
            return NS_ZINC::completedFuture(*dispatcher);
        }
    }
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setPlaySpeed, _1, speed_in));
}

NS_ZINC::Future< double > ProxyMediaRouter::getPlaySpeed() const {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	return deferForwardOrDefault(boost::bind(&MediaRouter::getPlaySpeed, _1),
            properties.playSpeed.get_value_or(1.0));
}

NS_ZINC::Future< void > ProxyMediaRouter::seekPosition(const SeekReference::Enum whence_in,
        const int32_t offset_in, const SeekMode::Enum mode_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrThrow(boost::bind(&MediaRouter::seekPosition, _1, whence_in, offset_in, mode_in));
}

NS_ZINC::Future< Position > ProxyMediaRouter::getPosition() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getPosition, _1), Position());
}

NS_ZINC::Future< void > ProxyMediaRouter::setEndTime(const int32_t end_in) {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

    if(!isSourced())
    {
        properties.endTime = end_in;
        if(!sourcing)
        {
            return NS_ZINC::completedFuture(*dispatcher);
        }
    }
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setEndTime, _1, end_in));
}

NS_ZINC::Future< int32_t > ProxyMediaRouter::getEndTime() const {

    NICKEL_FUNC_TRACE;

	scoped_lock lock(mutex);

	return deferForwardOrDefault(boost::bind(&MediaRouter::getEndTime, _1),
            properties.endTime.get_value_or(0));
}

NS_ZINC::Future< void > ProxyMediaRouter::start() {

    NICKEL_FUNC_TRACE;
	return deferForwardOrThrow(boost::bind(&MediaRouter::start, _1));
}

NS_ZINC::Future< void > ProxyMediaRouter::startDeferred() {

    NICKEL_FUNC_TRACE;
	return deferForwardOrThrow(boost::bind(&MediaRouter::startDeferred, _1));
}

NS_ZINC::Future< ControlCapabilities > ProxyMediaRouter::getControlCapabilities() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getControlCapabilities, _1),
            ControlCapabilities());
}

NS_ZINC::Future< void > ProxyMediaRouter::stop() {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::stop, _1));
}

NS_ZINC::Future< void > ProxyMediaRouter::setBufferingMode(const std::map< std::string, std::string >& bufferingMode_in) {

    NICKEL_FUNC_TRACE;

    scoped_lock lock(mutex);

	if (sourcing) {
		return deferCall(boost::bind(&MediaRouter::setBufferingMode, _1, bufferingMode_in));
	}

	properties.bufferingMode = bufferingMode_in;

    if(!isSourced())
    {
        return NS_ZINC::completedFuture(*dispatcher);
    }

	return impl->setBufferingMode(bufferingMode_in);
}

NS_ZINC::Future< std::map< std::string, std::string > > ProxyMediaRouter::getBufferingMode() const {

    NICKEL_FUNC_TRACE;

    scoped_lock lock(mutex);

	return deferForwardOrDefault(boost::bind(&MediaRouter::getBufferingMode, _1),
            properties.bufferingMode.get_value_or(defaultBufferingModes));
}

NS_ZINC::Future< void > ProxyMediaRouter::startBuffering() {

    NICKEL_FUNC_TRACE;
	return deferForwardOrThrow(boost::bind(&MediaRouter::startBuffering, _1));
}

NS_ZINC::Future< void > ProxyMediaRouter::stopBuffering() {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::stopBuffering, _1));
}

NS_ZINC::Future< BufferStatus > ProxyMediaRouter::getBufferStatus() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getBufferStatus, _1), BufferStatus());
}

NS_ZINC::Future< void > ProxyMediaRouter::setVideoTerminationMode(const VideoTerminationMode::Enum mode_in) {

    NICKEL_FUNC_TRACE;

    scoped_lock lock(mutex);

    if(!isSourced())
    {
        properties.videoTerminationMode = mode_in;
        if(!sourcing)
        {
            return NS_ZINC::completedFuture(*dispatcher);
        }
    }
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setVideoTerminationMode, _1, mode_in));
}

NS_ZINC::Future< VideoTerminationMode::Enum > ProxyMediaRouter::getVideoTerminationMode() const {

    NICKEL_FUNC_TRACE;

    scoped_lock lock(mutex);

	return deferForwardOrDefault(boost::bind(&MediaRouter::getVideoTerminationMode, _1),
            properties.videoTerminationMode.get_value_or(VideoTerminationMode::freeze));
}

NS_ZINC::Future< std::map< std::string, std::string > > ProxyMediaRouter::getSourceInformation() const {

    NICKEL_FUNC_TRACE;
	scoped_lock lock(mutex);

    return deferForwardOrDefault(boost::bind(&MediaRouter::getSourceInformation, _1),
        std::map< std::string, std::string >());
}

NS_ZINC::Future< ABRStreamSet > ProxyMediaRouter::getABRStreamSet() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getABRStreamSet, _1),
            ABRStreamSet());
}

NS_ZINC::Future< ABRStatus > ProxyMediaRouter::getABRStatus() const {

    NICKEL_FUNC_TRACE;
	return deferForwardOrDefault(boost::bind(&MediaRouter::getABRStatus, _1), ABRStatus());
}

NS_ZINC::Future< void > ProxyMediaRouter::setABRStream(const int32_t streamIndex_in, const bool deferred_in) {

    NICKEL_FUNC_TRACE;
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setABRStream, _1, streamIndex_in, deferred_in));
}

NS_ZINC::Future< void > ProxyMediaRouter::setCaptureMode(const TimeShiftCaptureMode::Enum mode_in) {

    NICKEL_FUNC_TRACE;

    scoped_lock lock(mutex);

    if(!isSourced())
    {
        properties.captureMode = mode_in;
        if(!sourcing)
        {
            return NS_ZINC::completedFuture(*dispatcher);
        }
    }
	return deferForwardOrIgnore(boost::bind(&MediaRouter::setCaptureMode, _1, mode_in));
}

NS_ZINC::Future< TimeShiftCaptureMode::Enum > ProxyMediaRouter::getCaptureMode() const {

    NICKEL_FUNC_TRACE;
    scoped_lock lock(mutex);

    return deferForwardOrDefault(boost::bind(&MediaRouter::getCaptureMode, _1), 
        properties.captureMode.get_value_or(TimeShiftCaptureMode::disabled));
}

boost::shared_ptr<MediaRouterFactory> ProxyMediaRouter::findFactoryGivenSource(const std::string& source) const {

    NICKEL_FUNC_TRACE;

    std::string mediaExtension = "default";

    if(source.empty())
    {
        throw InvalidLocatorException("Empty media locator");
    }

    boost::shared_ptr<SoupURI> sourceURI(soup_uri_new(source.c_str()), &SoupURIQuietFree);

    if(!sourceURI.get() || !soup_uri_get_scheme(sourceURI.get()))
    {
        throw InvalidLocatorException("Invalid media locator");
    }

    sourceURI = decodeCompoundURI(sourceURI);

    const std::string protocol(soup_uri_get_scheme(sourceURI.get()));

    std::string mimeType(ProxySystemFactory::DEFAULT_MIME_TYPE);

    ProtocolMediaRouterFactoryMap::const_iterator protIter = findInVectorOfPairs(
        protocolMediaRouterFactoryMap, MIMEMediaRouterFactoryMap(protocol,
                std::vector<MIMEMediaRouterFactory>()));

    // We found an entry for this protocol, search by MIME type
    if(protIter != protocolMediaRouterFactoryMap.end())
    {
        // If the URL has a query portion, take the file extension from that.
        // Otherwise a URL of the form http://host/cms.jsp?media=film.ts would
        // be parsed as having a .jsp extension rather than a .ts extension. Of
        // course this approach only really works if there is just a single
        // query parameter.
        const char* mediaName = soup_uri_get_query(sourceURI.get());

        if(!mediaName)
        {
            mediaName = soup_uri_get_path(sourceURI.get());
        }

        const std::string extension = getMediaExtension(mediaName ? mediaName : "");

        NICKEL_DEBUG("*** KT: extension: " << extension );

        if(!extension.empty())
        {
            const std::string retrievedMIMEType = mimeTypes->getMIMEType(extension);
            if(!retrievedMIMEType.empty())
            {
                mimeType = retrievedMIMEType;
                NICKEL_DEBUG("*** KT: mime type: " << mimeType );
            }
        }

        std::vector<MIMEMediaRouterFactory>::const_iterator mimeIter = findInVectorOfPairs(
                protIter->second, MIMEMediaRouterFactory(mimeType,
                    boost::shared_ptr<MediaRouterFactory>()));

        if(mimeIter != protIter->second.end())
        {
            // Found an exact match (protcol & MIME type)
            return mimeIter->second;
        }
        else if(mimeType != ProxySystemFactory::DEFAULT_MIME_TYPE)
        {
            // Try searching for a protocol default
            mimeIter = findInVectorOfPairs(
                protIter->second, MIMEMediaRouterFactory(
                    ProxySystemFactory::DEFAULT_MIME_TYPE,
                    boost::shared_ptr<MediaRouterFactory>()));

            if(mimeIter != protIter->second.end())
            {
                return mimeIter->second;
            }
        }
    }

    // Return the default media router factory
    return defaultMediaRouterFactory;
}

void ProxyMediaRouter::BufferStatusEvent(
        const BufferStatusEventValue::Enum event)
{
    NICKEL_FUNC_TRACE;
    produceEvent(boost::bind(
        &NS_NICKEL_SYSTEM::MediaRouterEventListener::BufferStatusEvent, _1,
        event));
}

void ProxyMediaRouter::DrmEvent(const DrmEventValue::Enum resultRef,
        const std::string& drmMediaIdentifier,
        const std::string& rightsIssuerUrl)
{
    NICKEL_FUNC_TRACE;
    produceEvent(boost::bind(
            &NS_NICKEL_SYSTEM::MediaRouterEventListener::DrmEvent, _1,
            resultRef,
            drmMediaIdentifier,
            rightsIssuerUrl));
}

void ProxyMediaRouter::PositionChangeEvent(const Position& position)
{
    NICKEL_FUNC_TRACE;
    produceEvent(boost::bind(
                &NS_NICKEL_SYSTEM::MediaRouterEventListener::PositionChangeEvent,
                _1,
                position));
}

void ProxyMediaRouter::SourceEvent(const SourceEventValue::Enum event,
            const SetSourceReason::Enum reason)
{
    NICKEL_FUNC_TRACE;
    produceEvent(boost::bind(
                &NS_NICKEL_SYSTEM::MediaRouterEventListener::SourceEvent, _1,
                event,
                reason));
}

void ProxyMediaRouter::SpeedChangeEvent()
{
    NICKEL_FUNC_TRACE;
    produceEvent(boost::bind(
                &NS_NICKEL_SYSTEM::MediaRouterEventListener::SpeedChangeEvent, _1));
}

void ProxyMediaRouter::StatusEvent(const StatusEventValue::Enum event)
{
    NICKEL_FUNC_TRACE;
    produceEvent(boost::bind(
                &NS_NICKEL_SYSTEM::MediaRouterEventListener::StatusEvent, _1,
                event));
}

void ProxyMediaRouter::ErrorEvent(const ErrorEventValue::Enum error,
            const ErrorEventContext::Enum context,
            const std::string& info)
{
    NICKEL_FUNC_TRACE;
    produceEvent(boost::bind(
                &NS_NICKEL_SYSTEM::MediaRouterEventListener::ErrorEvent, _1,
                error,
                context,
                info));
}

NS_NICKEL_SYSTEM_CLOSE
