/*
 * ProxyMediaRouterFactory.h
 *
 *  Created on: Aug 6, 2012
 *      Author: john.sadler@youview.com
 *
 *  Copyright 2015, Youview TV Ltd.
 */

#ifndef NICKEL_SYSTEM_PROXY_PROXYMEDIAROUTERFACTORY_H_
#define NICKEL_SYSTEM_PROXY_PROXYMEDIAROUTERFACTORY_H_

#include "ProxyMediaRouter.h"

#include <nickel-system-api/MediaRouterFactory.h>
#include <zinc-common/async/Dispatcher.h>

namespace mime
{
    class MIMETypes;
}

NS_NICKEL_SYSTEM_OPEN


class ZINC_LOCAL ProxyMediaRouterFactory : public MediaRouterFactory {

public:

	ProxyMediaRouterFactory(
			boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher_,
			boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory_,
			ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap_);

	virtual ~ProxyMediaRouterFactory();

	virtual NS_ZINC::Future<boost::shared_ptr<MediaRouter> > createMediaRouter();

public: // these are for tests.

	inline boost::shared_ptr<MediaRouterFactory> getDefaultMediaRouterFactory() const {
		return defaultMediaRouterFactory;
	}

	inline const ProtocolMediaRouterFactoryMap& getProtocolMediaRouterFactoryMap() const {
		return protocolMediaRouterFactoryMap;
	}

private:

	boost::shared_ptr<NS_ZINC::Dispatcher> dispatcher;
	boost::shared_ptr<MediaRouterFactory> defaultMediaRouterFactory;
	ProtocolMediaRouterFactoryMap protocolMediaRouterFactoryMap;
    boost::shared_ptr<mime::MIMETypes> mimeTypes;
};

NS_NICKEL_SYSTEM_CLOSE

#endif /* NICKEL_SYSTEM_PROXY_PROXYMEDIAROUTERFACTORY_H_ */
